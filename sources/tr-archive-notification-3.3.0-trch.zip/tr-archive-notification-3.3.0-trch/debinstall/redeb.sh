#!/usr/bin/env bash

# IMPORTANT
# Protect agaisnt mispelling a var and rm -rf /
set -u
set -e

SRC=/tmp/tr-archive-notify-deb-src
DIST=/tmp/tr-archive-notify-deb-dist
SYSROOT=${SRC}/sysroot
DEBIAN=${SRC}/DEBIAN

rm -rf ${DIST}
mkdir -p ${DIST}/

rm -rf ${SRC}
rsync -a deb-src/ ${SRC}/
mkdir -p ${SYSROOT}/var/www/tr-archive/trarchive-notification

rsync -a --exclude '.ci*' --exclude '.git' --exclude 'docker' --exclude 'trarchive-notification-application.service' --exclude 'cicd' --exclude '.ci*'  ../. ${SYSROOT}/var/www/tr-archive/trarchive-notification/. --delete

find ${SRC}/ -type d -exec chmod 0755 {} \;
find ${SRC}/ -type f -exec chmod go-w {} \;

let SIZE=`du -s ${SYSROOT} | sed s'/\s\+.*//'`+8
pushd ${SYSROOT}/
tar czf ${DIST}/data.tar.gz [a-z]*
popd
sed s"/SIZE/${SIZE}/" -i ${DEBIAN}/control
pushd ${DEBIAN}
tar czf ${DIST}/control.tar.gz *
popd

pushd ${DIST}/
echo 2.0 > ./debian-binary

find ${DIST}/ -type d -exec chmod 0755 {} \;
find ${DIST}/ -type f -exec chmod go-w {} \;
ar r ${DIST}/trarchive_notification.deb debian-binary control.tar.gz data.tar.gz
popd
rsync -a ${DIST}/trarchive_notification.deb ./
