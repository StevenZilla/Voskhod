<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::group(['namespace' => 'App\Http\Controllers'], function () {
    Route::get('/test', 'TestController');
    Route::group(['prefix' => 'notification', 'namespace' => 'Notification'], function () {
        Route::get('/stream', 'StreamController');
        Route::get('/{id}', 'ShowController')->where('id', '[0-9]+');
        Route::get('/', 'IndexController');



        Route::get('/read', 'ReadAllController');
        Route::get('/read/{id}', 'ReadController')->where('id', '[0-9]+');
        Route::delete('/all', 'DestroyAllController');
        Route::delete('/{id}', 'DestroyController')->where('id', '[0-9]+');
    });
});

Route::fallback(function () {
    return response()->json([
        'code' => 404,
        'message' => 'Page Not Found. (Notification service)',
    ], 404);
});
