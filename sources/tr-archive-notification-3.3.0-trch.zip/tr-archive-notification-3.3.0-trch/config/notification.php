<?php


return [
    'notification_key' => env('NOTIFICATION_KEY'),
    'notification_key_prefix' => 'base64:',
    'notification_cookie_name' => env('NOTIFICATION_COOKIE_NAME', 'uc_notification_local'),
    'notification_redis_prefix' => env('REDIS_PREFIX'),
];
