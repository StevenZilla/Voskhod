TR-ARCHIVE-NOTIFICATION
Сервис доставки уведомлений


# Контракт сообщения в очереди для redis ( pub -> sub) :  

```
event_stream_{uid_stream-уникальный идентфикатор сообщения}

{
    "date": "2023-05-02 11:16:22", // дата  формироования уведомления
    "uid": "1d04ca3e-df1a-0cb4-c325-6ef4003ca2ab", // guid - идентификатор оика организации 
    "title": "Требует согласования: Опись документов постоянного хранения №-5525.", // заголовок соообщения 
    "method": [ // тип отправи: 1 -  sse
        1
    ],
    "message": {
        "descr": "Требует согласования: obj:register.",  /
        "resource_metadata": {
            "object": {
                "object_id": 1,
                "object_name": "Опись документов постоянного хранения №-5525",
                "object_code": "obj:register"
            }
        }
    },
    "target_user": { // получаетель уведомления
        "uid": "8354c8fe-9122-421b-b9a3-087c891e5a3e",
        "email": "admin"
    }
}

```


# Особенности деплоя:  

Используется sse, для  отправки уведомлений на  клиент.

Если  используется  в качесве прокси  nginx

Для корректной работы sse: в прокси домена, для  location 

необходимо отключить, след  функционал
```
  location /notify {  
        
       gzip  off;
       chunked_transfer_encoding off;
       proxy_buffering off;
       proxy_cache off;
  }
```

Функциональные возможности

Отправка уведомлений в режиме реального времени:
- sse (Server Sent Events) https://learn.javascript.ru/server-sent-events
- ****

Настройка проекта
1) Сделать копию файла example.env с именем .env в корне проекта
2) Сгенерировать ключ приложения командой php artisan key:generate
3) Изменить параметры файла конфигурации .env
4) Выполнить миграции БД командой php artisan migrate 

CRON (планировщик задач)

php artisan notification:sync

Для корректной работы сервиса нотификации необходимо:
В проекте серверной части tr-archive-back (https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-back)
1) Cгенерировать NOTIFICATION_KEY= командой notification_key:generate
2) Заполнить параметр NOTIFICATION_COOKIE_NAME=
3) Скопировать полученные значения NOTIFICATION_KEY= и NOTIFICATION_COOKIE_NAME= из файла .env проекта серверной части tr-archive-back (https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-back) в файл .env сервсиа нотификации.


Для тестирования проекта с помощью postman
1) Авторизоваться в tr-archive-back {{url1}}/login/
2) Получить cookie от tr-archive-back для аутентификации в сервисе нотификации {{url1}}/ead/users/notification_cookie
3) Протестировать получение уведомлений по sse {{url2}}/notification/stream (Необходима cookie аутентификации и header uid Тр-архива)
4) Аналогично протестировать 
- чтение всех уведомлений {{url2}}/notification/read 
- чтение конкретного (выбранного) уведомления {{url2}}/notification/read/:id
- получение всех уведомлений {{url2}}/notification
