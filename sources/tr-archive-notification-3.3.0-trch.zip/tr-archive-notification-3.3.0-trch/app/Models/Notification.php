<?php

namespace App\Models;

use App\Models\Traits\Filterable;
use App\Models\Traits\Orderable;
use App\Models\Traits\OrderbaleDefault;
use App\Models\Traits\Paginal;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Notification extends Model
{
    use HasFactory;
    use SoftDeletes;
    use Paginal;
    use Filterable;
    use Orderable;
    use OrderbaleDefault;

    protected $namespaceFilter = '\App\Services\Notification\NotificationFilterService';
    protected $namespaceOrder =  '\App\Services\Notification\NotificationOrderService';
    protected $namespaceOrderDefault = '\App\Services\Notification\NotificationOrderDefaultService';
    protected $table = 'notifications';
    protected $guarded = [];
}
