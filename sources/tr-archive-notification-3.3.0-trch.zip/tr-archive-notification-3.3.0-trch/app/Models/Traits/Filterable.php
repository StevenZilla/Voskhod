<?php

namespace App\Models\Traits;

use App\Http\Filters\FilterInterface;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

trait Filterable
{
    /**
     * @param Builder $builder
     * @param Request $request
     * @return void
     */
    protected function scopeFilters(Builder $builder, Request $request)
    {
        if (! empty($this->namespaceFilter)) {
            $filters = new $this->namespaceFilter($request, $this->getTable());
            $filters->apply($builder);
        }
    }
}
