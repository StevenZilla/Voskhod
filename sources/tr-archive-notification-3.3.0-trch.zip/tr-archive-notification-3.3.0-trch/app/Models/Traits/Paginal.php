<?php

namespace App\Models\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

trait Paginal
{
    /**
     * @param Builder $builder
     * @param Request $request
     * @param array $columns
     * @param int|null $pageLength
     * @param int|null $pageNumber
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function scopeAutoPaginate(Builder $builder, Request $request, array $columns = ['*'], int $pageLength = null, int $pageNumber = null)
    {
        $page = $this->validateRequestQueryPageNumber($request, $pageNumber);
        $length = $this->validateRequestQueryPageLength($request, $pageLength);
        $queryParams = $request->query->all();
        unset($queryParams['page']['number']);

        return $builder->paginate($length, $columns, 'page[number]', $page)->appends($queryParams);
    }

    /**
     * @param $request
     * @param $pageLengthControl
     * @return int|mixed page length
     */
    private function validateRequestQueryPageLength($request, $pageLengthControl)
    {
        if (isset($request->query('page')['size'])) {
            return $request->query('page')['size'];
        } elseif ($pageLengthControl) {
            return $pageLengthControl;
        } else {
            return 15;
        }
    }

    /**
     * @param $request
     * @param $pageNumberControl
     * @return int|mixed page number
     */
    private function validateRequestQueryPageNumber($request, $pageNumberControl)
    {
        if (isset($request->query('page')['number'])) {
            return $request->query('page')['number'];
        } elseif ($pageNumberControl) {
            return $pageNumberControl;
        } else {
            return 1;
        }
    }
}
