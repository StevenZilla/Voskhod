<?php

namespace App\Models\Traits;

/**
 * Подключает статическую функцию, для возврата имени таблицы текущей модели.
 */
trait Named
{
    /**
     * Возвращает имя таблицы модели.
     * @return string
     */
    public static function getTableName(): string
    {
        return (new static)->getTable();
    }
}
