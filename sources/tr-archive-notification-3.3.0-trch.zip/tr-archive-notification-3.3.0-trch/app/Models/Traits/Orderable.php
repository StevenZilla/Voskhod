<?php

namespace App\Models\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

trait Orderable
{
    protected function scopeOrders(Builder $builder, Request $request)
    {
        $orders = new $this->namespaceOrder($request, $this->getTable());
        $orders->apply($builder);
    }
}
