<?php

namespace App\Models\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

trait OrderbaleDefault
{
    protected function scopeOrderDefault(Builder $builder, Request $request, $columnName, $orderDirection, $collate = '')
    {
        $orderDefault = new $this->namespaceOrderDefault($request, $this->getTable(), $columnName, $orderDirection, $collate);
        $orderDefault->apply($builder);
    }
}
