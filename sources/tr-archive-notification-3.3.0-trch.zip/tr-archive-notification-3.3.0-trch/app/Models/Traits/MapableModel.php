<?php

namespace App\Models\Traits;

use App\Models\HandBooks\Archive;

trait MapableModel
{
    /**
     * @param $request
     * @return Archive
     */
    public function mapModel($request)
    {
        foreach ($this->map as $key => $value) {
            if (!empty($request[$value])) {
                $this[$key] = $request[$value];
            }
        }

        return $this;
    }
}
