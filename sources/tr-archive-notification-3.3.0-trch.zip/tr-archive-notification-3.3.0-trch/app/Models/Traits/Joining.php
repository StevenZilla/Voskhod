<?php

namespace App\Models\Traits;

use Illuminate\Database\Eloquent\Builder;

trait Joining
{

    /**
     * @param Builder $builder
     * @param string $table
     * @return bool
     *
     * Возвращает true,  если $table уже был приджойнен
     */
    public function isJoined(Builder $builder, string $table)
    {
        $joins = $builder->getQuery()->joins;
        if ($joins == null) {
            return false;
        }
        foreach ($joins as $join) {
            if ($join->table == $table) {
                return true;
            }
        }

        return false;
    }
}
