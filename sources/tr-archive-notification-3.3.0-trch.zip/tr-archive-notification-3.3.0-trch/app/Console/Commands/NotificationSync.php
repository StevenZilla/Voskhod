<?php

namespace App\Console\Commands;

use App\Models\Notification;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Carbon;

class NotificationSync extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notification:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync notifications between redis and postgresql';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }


    public function handle()
    {
        try {
            //log начинаю пасринг
            $date = Carbon::now()->format('Y-m-d H:i:s');
            echo "{$date} Начинаю приём уведомлений из Redis db9";
            Log::info('start sync notifications');
            $redisConnection = Redis::connection('event_stream');
            $redisKeys = $redisConnection->keys(env('REDIS_PREFIX') . '*');
            foreach ($redisKeys as $key) {

                $redisData = $redisConnection->get($key);
                $data = json_decode($redisData);
                $methods = $data->method;
                foreach ($methods as $method) {
                    Notification::create([
                        'uid' => $data->uid,
                        'date' => $data->date,
                        'title' => $data->title,
                        'message' => json_encode($data->message),
                        'user_guid' => $data->target_user->uid,
                        'email' => $data->target_user->email,
                        'read' => 'f',
                        'send' => 'f',
                        'method' => $method
                    ]);
                }
                $redisConnection->del($key);
            }
        } catch (\Exception $e) {
            //    log
            Log::error('Sync notification ERROR ' . $e);
        }
    }
}
