<?php

namespace App\Services\Notification;

use App\Http\Resources\Notification\StreamResource;
use App\Models\Notification;
use Carbon\Carbon;
use Illuminate\Encryption\Encrypter;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\Log;

class NotificationService
{

    /**
     * @param $request
     * @param $cookie
     * @param $message
     * @return StreamedResponse
     */
    public function openStream($decodedData, $uid)
    {
        $start = time();
        $maxExecution = env('MAX_EXECUTION_TIME') ?? 1000000;
        $eventInterval = env(('EVENT_INTERVAL')) ?? 2000000;

        return $response = new StreamedResponse(function () use ($start, $maxExecution, $eventInterval, $decodedData, $uid) {
            while (true) {
                if (time() >= $start + $maxExecution) {
                    exit(419);
                }
                if (Carbon::now()->timestamp > $decodedData->end_time) {
                    //отпрвить ответ, что сессия истекла
                    return response(null, 401);
                    // echo 'data:{ "messages": ' . json_encode($messagesArray) . ', "unread_count":' . $unreadMessagesCount . ', "total": ' . $total . '}';
                    // echo "\n\n";
                } else {
                    $unreadMessages = Notification::select(['id', 'date', 'title', 'message'])
                        ->where('user_guid', $decodedData->user)
                        ->where('uid', $uid)
                        ->where('read', 'f')
                        ->where('method', 1)->limit(env('STREAM_MESSAGE_COUNT'))->orderBy('date', 'desc')->get();


                    $unreadMessagesCount = Notification::select(['id', 'date', 'title', 'message'])
                        ->where('user_guid', $decodedData->user)
                        ->where('uid', $uid)
                        ->where('read', 'f')
                        ->where('method', 1)->count();
                    // $unreadMessagesCount = $unreadMessages->count();
                    $total = Notification::where('user_guid', $decodedData->user)
                        ->where('uid', $uid)
                        ->where('method', 1)->count();

                    $messagesArray = StreamResource::collection($unreadMessages)->collection;
                    if ($messagesArray) {
                        echo 'data:{ "messages": ' . json_encode($messagesArray) . ', "unread_count":' . $unreadMessagesCount . ', "total": ' . $total . '}';
                        echo "\n\n";
                    }
                }
                ob_flush();
                flush();
                usleep($eventInterval);
            }
        });
    }

    /**
     * @return void
     */
    public function IEfix()
    {
        echo ':' . str_repeat(" ", 2048) . "\n";
    }


    /**
     * @param int $userId
     * @return void
     */
    public function readAll($user_guid, $uid)
    {
        Notification::where('user_guid', $user_guid)->where('uid', $uid)->update(['read' => true]);
    }



    /**
     * @param int $userId
     * @param int $notificationId
     * @return void
     */
    public function read($user_guid, $uid, int $notificationId)
    {
        Notification::where('user_guid', $user_guid)->where('uid', $uid)->where('id', $notificationId)->update(['read' => true]);
    }



    /**
     * decryptCookie
     *
     * @param  mixed $request
     * @return obj
     */
    public function decryptCookie($request)
    {
        try {
            $prefix = config('notification.notification_key_prefix');
            $base64Key = config('notification.notification_key');
            if (Str::startsWith($key = $base64Key, $prefix)) {
                $key = base64_decode(Str::after($key, $prefix));
            }
            $encrypter = new Encrypter($key, 'AES-256-CBC');
            // $test = config('notification.notification_cookie_name');
            $cookie = $request->cookie(config('notification.notification_cookie_name'));
            $decryptedData = $encrypter->decrypt($cookie);

            return json_decode($decryptedData);
        } catch (\Exception $e) {
            Log::error('Не удалось расшифровать куку ' . $e);
        }
    }


    public function deleteNotification($user_guid, $uid, int $notificationId)
    {
        Notification::where('user_guid', $user_guid)->where('uid', $uid)->where('id', $notificationId)->forceDelete();
    }
    public function deleteAllNotification($user_guid, $uid)
    {
        Notification::where('user_guid', $user_guid)->where('uid', $uid)->forceDelete();
    }
}
