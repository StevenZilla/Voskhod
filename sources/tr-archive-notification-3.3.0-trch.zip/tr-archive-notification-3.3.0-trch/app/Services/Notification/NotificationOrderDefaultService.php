<?php

namespace App\Services\Notification;

use App\Services\Utils\OrderDefaultService;

class NotificationOrderDefaultService extends OrderDefaultService
{
    protected function date($tableName, $columnName, $orderDirection, $collate)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'date' . ' ' . $orderDirection);
    }
    protected function id($tableName, $columnName, $orderDirection, $collate)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'id' . ' ' . $orderDirection);
    }


}
