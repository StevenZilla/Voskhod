<?php

namespace App\Services\Notification;

use App\Services\Utils\OrderService;

class NotificationOrderService extends OrderService
{
    protected function id($orderDirection, $tableName)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'id' . ' ' . $orderDirection);
    }
    protected function date($orderDirection, $tableName)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'date' . ' ' . $orderDirection);
    }
    protected function title($orderDirection, $tableName)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'title' . '  collate "C" ' . $orderDirection);
    }
    protected function read($orderDirection, $tableName)
    {
        return $this->builder->orderByRaw($this->tableName . '.' . 'read' . ' ' . $orderDirection);
    }
}
