<?php

namespace App\Services\Notification;

use App\Services\Utils\FilterService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class NotificationFilterService extends FilterService
{
    protected function q(string $value): Builder
    {
        return $this->builder->where(function ($sql) use ($value) {
            return $sql->where(DB::raw("LOWER(notifications.title)"), 'ilike', "%{$value}%");
        });
        //return $this->builder->whereRaw('"title" LIKE \'%' . mb_strtolower($value) . '%\'');
    }

    protected function search(string $value): Builder
    {
        return $this->builder->where(function ($sql) use ($value) {
            return $sql->where(DB::raw("LOWER(notifications.title)"), 'ilike', "%{$value}%");
        });
        //return $this->builder->whereRaw('"title" LIKE \'%' . mb_strtolower($value) . '%\'');
    }
    protected function is_read(string $value): Builder
    {
        return $this->builder->where('read', mb_strtolower($value));
    }
}
