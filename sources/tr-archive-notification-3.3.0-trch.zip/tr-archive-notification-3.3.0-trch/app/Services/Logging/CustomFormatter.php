<?php

namespace App\Services\Logging;

use Monolog\Logger;

class CustomFormatter
{
    public function __invoke($logger)
    {
        foreach ($logger->getHandlers() as $handler) {
            $handler->pushProcessor(new CustomIntrospectionProcessor(Logger::DEBUG, ['Illuminate\\', 'App\\Services\\Logging\\']));
        }
    }
}
