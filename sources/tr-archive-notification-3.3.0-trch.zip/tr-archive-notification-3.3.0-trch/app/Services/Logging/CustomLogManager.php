<?php

namespace App\Services\Logging;

use Illuminate\Log\LogManager;
use Illuminate\Log\ParsesLogConfiguration;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use Psr\Log\LoggerInterface;

class CustomLogManager extends LogManager
{
    use ParsesLogConfiguration;

    /**
     * Resolve the given log instance by name.
     *
     * @param  string  $name
     * @param  array|null  $config
     * @return LoggerInterface
     *
     * @throws InvalidArgumentException
     */
    protected function resolve($name, ?array $config = null)
    {
        $config = $config ?? $this->configurationFor($name);

        if (is_null($config)) {
            throw new InvalidArgumentException("Log [{$name}] is not defined.");
        }

        if (! empty($config['path'])) {
            if (! empty(request()->header('uid'))) {
                $uidInstance = request()->header('uid');
            } else {
                try {
                    $uidInstance = DB::table('system_param')
                        ->where('code', 'guid_oik_in_medo')
                        ->pluck('value')->first();
                } catch (\Exception $e) {
                    $uidInstance = '';
                }
            }

            if (! empty($uidInstance)) {
                $path = $config['path'];
                $basename = basename($path);
                $newBasename = str_replace('.log', "-{$uidInstance}.log", $basename);
                $config['path'] = str_replace($basename, $newBasename, $path);
            }
        }

        if (isset($this->customCreators[$config['driver']])) {
            return $this->callCustomCreator($config);
        }

        $driverMethod = 'create'.ucfirst($config['driver']).'Driver';

        if (method_exists($this, $driverMethod)) {
            return $this->{$driverMethod}($config);
        }

        throw new InvalidArgumentException("Driver [{$config['driver']}] is not supported.");
    }
}
