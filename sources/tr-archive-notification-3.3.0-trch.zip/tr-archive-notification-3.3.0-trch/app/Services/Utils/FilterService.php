<?php

namespace App\Services\Utils;

use App\Models\Traits\Joining;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class FilterService
{
    use Joining;

    /** @var Request  $request */
    protected $request;

    /** @var Builder $builder */
    protected $builder;

    /** @var string $tableName */
    protected $tableName;

    /**
     * @param Request $request
     * @param string $tableName
     */
    public function __construct(Request $request, string $tableName)
    {
        $this->request = $request;
        $this->tableName = $tableName;
    }

    /**
     * @param Builder $builder
     * @return Builder
     */
    public function apply(Builder $builder) : Builder
    {
        $this->builder = $builder;

        foreach ($this->request->query() as $name => $value) {
            if (method_exists($this, $name) && $value != "") {
                $value = mb_strtolower($value);
                call_user_func([$this, $name], $value);
            }
        }

        $this->builder->select("{$this->tableName}.*");

        return $this->builder;
    }
}
