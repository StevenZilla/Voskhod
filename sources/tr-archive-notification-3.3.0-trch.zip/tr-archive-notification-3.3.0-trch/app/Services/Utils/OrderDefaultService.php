<?php

namespace App\Services\Utils;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class OrderDefaultService
{
    /** @var Request */
    protected $request;

    /** @var Request */
    protected $builder;

    /** @var string */
    protected $tableName;

    protected $columnName;
    protected $orderDirection;

    protected $collate;

    /**
     * @param Request $request
     */
    public function __construct(Request $request, string $tableName, string $columnName, string $orderDirection, string $collate)
    {
        $this->request = $request;
        $this->tableName = $tableName;
        $this->columnName = $columnName;
        $this->orderDirection = $orderDirection;
        $this->collate = $collate;
    }

    public function apply(Builder $builder): Builder
    {
        $this->builder = $builder;
        if (empty($this->request->query('sort'))) {
            call_user_func([$this, $this->columnName], $this->tableName, $this->columnName, $this->orderDirection, $this->collate);
        }
        $this->builder->select("{$this->tableName}.*");

        return $this->builder;
    }
}
