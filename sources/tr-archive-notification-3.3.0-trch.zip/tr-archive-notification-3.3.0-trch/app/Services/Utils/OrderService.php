<?php

namespace App\Services\Utils;

use App\Models\Traits\Joining;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use function App\Utils\starts_with;

class OrderService
{
    use Joining;

    /** @var Request $request */
    protected $request;

    protected $disparateTypes = [
        'integer',
        'date',
        'datetime',
        'datetimetz',
        'boolean',
        'decimal',
        'bigint'
    ]; // типы, применение к которым collate не допустимо

    /** @var Builder $builder */
    protected $builder;

    /** @var string $tableName */
    protected $tableName;

    /**
     * @param Request $request
     */
    public function __construct(Request $request, string $tableName)
    {
        $this->request = $request;
        $this->tableName = $tableName;
    }

    /**
     * @param Builder $builder
     * @return Builder
     */
    public function apply(Builder $builder): Builder
    {
        $this->builder = $builder;
        $sorts = explode(',', $this->request->query('sort', 'id'));

        $columnNames = DB::getSchemaBuilder()->getColumnListing($this->tableName);
        $columnTypes = $this->getColumnTypes($columnNames);

        foreach ($sorts as $sortColumn) {
            $sortDirection = starts_with($sortColumn, '-') ? 'desc' : 'asc';
            $sortColumn = mb_strtolower(ltrim($sortColumn, '-')); //получаем имя сортируемой колонки

            if (method_exists($this, $sortColumn)) {
                call_user_func([$this, $sortColumn], $sortDirection, $this->tableName);
                //если возникнут с совпадением имени функции сортировки и вспомогательных функций, добавить префикс к $sortColumn и к именам соответсвующих функций
            } elseif(in_array($sortColumn,$columnNames)) { // если не определён метод вручную, тогда проверяем что такая колонка существует в текущей таблице
                    if(in_array($columnTypes[$sortColumn], $this->disparateTypes)) {
//                        Запрос на сортирвку без collate
                        $this->builder->orderByRaw($this->tableName.'.'.$sortColumn.' '.$sortDirection);
                    } else {
//                            Запрос на сортирвку с collate
                        $this->builder->orderByRaw($this->tableName.'.'.$sortColumn.' collate "C" '.$sortDirection);
                    }
            }
        }
        $this->builder->select("{$this->tableName}.*");

        return $this->builder;
    }

    private function getColumnTypes($columnNames)
    {
        $columnTypes = array();
        foreach ($columnNames as $column) {
            $columnTypes[$column] = DB::getSchemaBuilder()->getColumnType($this->tableName, $column);
        }

        return ($columnTypes);
    }

}
