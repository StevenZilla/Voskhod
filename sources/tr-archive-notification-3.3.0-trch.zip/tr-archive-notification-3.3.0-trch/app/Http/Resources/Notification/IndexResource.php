<?php

namespace App\Http\Resources\Notification;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'notifications' => NotificationResource::collection($this),
            'count' => $this->resource->total(),
            'next' => $this->resource->nextPageUrl(),
            'prev' => $this->resource->previousPageUrl(),
            'first' => $this->resource->url(1),
            'last' => $this->resource->url($this->lastPage()),
        ];
    }
}
