<?php

namespace App\Http\Controllers\Auth;

use App\Exceptions\AuthException\LoginException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterNewUser;
use App\Models\User\User;
use App\Services\CheckDate\CheckDate;
use App\Services\Mail\CustomMail;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Handle a registration request for the application.
     *
     * @param RegisterNewUser $request
     * @return \Illuminate\Http\JsonResponse
     * @throws LoginException
     */
    public function register(RegisterNewUser $request)
    {
        $inputs = $request->all();
        if ($request->exists('end_date') && $request->exists('start_date')) {
            $messageCheckDate = CheckDate::checkStartEndDate($request->get('start_date'), $request->get('end_date'));

            if ($messageCheckDate !== 'true') {
                $msg = 'При регистрации пользователя проверка начала/окончания действия доступа компонента не прошла. ';

                return response()->json(['code' => 400, 'message' => $msg], 400);
            }
        }

        if (empty($request->get('end_date'))) {
            $inputs['end_date'] = Carbon::now()->addYears(100)->toDateTimeString();
        }

        if (empty($request->get('start_date'))) {
            $inputs['start_date'] = Carbon::now()->toDateTimeString();
        }

        event(new Registered($user = $this->create($inputs)));

        if ($this->registered($request, $user)) {
            CustomMail::register($user, $inputs['password']);

            return response()->json(['code' => 201, 'message' => $user->id], 201);
        } else {
            throw new LoginException('Ошибка! Пользователь не создан');
        }
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User\User
     */
    protected function create(array $data)
    {
        $user = new User();
        $user->fio = $data['fio'];
        $user->login = $data['login'];
        $user->email = $data['email'];
        $user->password = $data['password'];
        $user->tmp_password = $data['password'];
        $user->tmp_password_end_time = Carbon::now()->addMinutes(config('auth.count_minutes_life_tmp_pass'));
        $user->start_date = $data['start_date'];
        $user->end_date = $data['end_date'];
        $user->is_2fa = $data['is_2fa'] ?? false;
        $user->is_block = $data['is_block'] ?? false;

        $user->save();

        return $user;
    }

    protected function registered(Request $request, $user)
    {
        return true;
    }
}
