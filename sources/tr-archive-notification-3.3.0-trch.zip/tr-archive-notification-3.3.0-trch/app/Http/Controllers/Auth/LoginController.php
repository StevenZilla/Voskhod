<?php

namespace App\Http\Controllers\Auth;

use App\Exceptions\AuthException\LoginException;
use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginUser;
use App\Http\Requests\Auth\LogoutUser;
use App\Jobs\CheckCompromPassword;
use App\Models\Session\Session;
use App\Models\System\SystemParam;
use App\Models\User\CompromPassword;
use App\Models\User\User;
use App\Services\Mail\CustomMail;
use App\Services\SessionService;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    protected $uidOik = null;
    protected $isSet2FA = false;
    protected $code2FA = false;
    protected $isChangePassword = false;
    protected $messageChangesPassword;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username()
    {
        return 'login';
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request)
    {
        $user = User::where($this->username(), $request->input($this->username()))->first();

        if ($user->is_block) {
            $login = SystemParam::where('code', 'smtp_login')->pluck('value')->first();

            $message = 'Обратитесь к администратору для сброса пароля';
            if (! empty($login)) {
                $message .= 'по email - '.$login;
            }

            throw new BaseException($message);
        }

        if ($user->is_2fa) {
            $this->isSet2FA = true;
        }

        $todayDate = Carbon::now()->parse();

        if (! empty($user->start_date)) {
            $userStartDay = Carbon::parse($user->start_date);

            if ($todayDate->diffInMinutes($userStartDay, false) > 0) {
                $msg = "Пользователь [{$user->id}] {$user->fio} еще не активен. Активность пользователя начнется в {$user->start_date}";
                Log::error($msg);

                throw new LoginException('Пользователь еще не активен. Активность пользователя начнется в '.$user->start_date);
            }
        }

        if (! empty($user->end_date)) {
            $userEndDay = Carbon::parse($user->end_date);

            if ($userEndDay->diffInMinutes($todayDate, false) > 0) {
                throw new LoginException('Пользователь уже не активен. Активность пользователя закончилась '.$user->end_date);
            }
        }

        $minPassExpDay = SystemParam::where('code', 'min_pass_exp_date')->pluck('value')->first();
        $maxPassExpDay = SystemParam::where('code', 'max_pass_exp_date')->pluck('value')->first();
        $passwordDay = Carbon::parse($user->update_password_date)->diffInDays($todayDate, false);

        if (! empty($user->tmp_password) && ! empty($user->tmp_password_end_time)) {
            if (Carbon::createFromFormat('Y-m-d H:i:s', $user->tmp_password_end_time)->diffInMinutes(Carbon::now(), false) <= 0) {
                $this->isChangePassword = true;
            }
        }

        if ($minPassExpDay <= $passwordDay
                    && $passwordDay <= $maxPassExpDay
                    && ($maxPassExpDay - $passwordDay) <= config('auth.count_days_update_pass')) {
            $this->isChangePassword = true;
        } elseif ($passwordDay > $maxPassExpDay) {
            if (CustomMail::resetPassword($user, $this->uidOik)) {
                $this->messageChangesPassword = 'Временный пароль отправлен на почту '.$user->email;
                $this->isChangePassword = true;
            }
        }

        $response = $request->only($this->username(), 'password');

        if (CompromPassword::where('password', $response['password'])->exists()) {
            $this->isChangePassword = true;

            CheckCompromPassword::dispatch($user, $this->uidOik)->onQueue('check_comprom_password');
        }

        $user->log_date = Carbon::now()->toDateTimeString();
        $user->save();

        $response['password'] .= $user->salt;

        return $response;
    }

    /**
     * Attempt to log the user into the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function attemptLogin(Request $request)
    {
        $credentials = $this->credentials($request);

        return $this->guard()->attempt($credentials);
    }

    /**
     * The user has been authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  mixed  $user
     * @return mixed
     */
    protected function authenticated(Request $request, $user)
    {
        $maxCountOpenSession = SystemParam::where('name', 'Максимальное количество открытых сессий пользователя')->pluck('value')->first();
        $openSession = Session::where('user_id', $user->id)->where('end_date', null)->count();

        if ($maxCountOpenSession <= $openSession) {
            Log::error("У пользователя [{$user->id}] {$user->fio} превышен лимит открытых сессий. Максимальное количество сессий - {$maxCountOpenSession}");

            throw new LoginException('Превышено максимальное количество сессий пользователя');
        }

        $session = new Session();
        $session->user_id = $user->id;
        $session->sessions_id = $request->session()->getId();
        $session->start_date = Carbon::now()->toDateTimeString();

        if ($this->isSet2FA) {
            $this->code2FA = CustomMail::sendCode2FA($user, $this->uidOik);

            if (! empty($this->code2FA)) {
                $session->setAttribute('2fa_code', $this->code2FA);
                $session->setAttribute('2fa_code_end_time', Carbon::now()->addMinutes(config('session.code_lifetime_2fa')));
                $session->is_trust = false;
            }
        }

        $session->save();

        return $session->id ?? null;
    }

    /**
     * Send the response after the user was authenticated.
     */
    protected function sendLoginResponse(Request $request)
    {
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);

        if ($sessionId = $this->authenticated($request, $this->guard()->user())) {
            $request->session()->put('user_ip', $request->getClientIp());
            $request->session()->put('user_id', $this->guard()->user()->id);
            $request->session()->put('session_id', $sessionId);
            $request->session()->put('last_active', Carbon::now()->toDateTimeString());

            $dataResponse = [];

            if ($this->isChangePassword) {
                $dataResponse['code'] = 202;
                $dataResponse['message'] = $this->messageChangesPassword ?? $this->guard()->user()->id;
                $dataResponse['is_change_password'] = true;
            }

            if ($this->isSet2FA && ! empty($this->code2FA)) {
                $dataResponse['code'] = 202;
                $dataResponse['message'] = 'Введите код отправленный вам на почту';
                $dataResponse['is_trust'] = true;
            }

            if (! empty($dataResponse)) {
                return response()->json($dataResponse, $dataResponse['code']);
            }

            if (! ($this->isSet2FA && $this->isChangePassword)) {
                return response()->json(['code' => 201, 'message' => $this->guard()->user()->id], 201);
            }
        } else {
            throw new LoginException('Ошибка записи сессии');
        }
    }

    /**
     * Handle a login request to the application.
     */
    public function login(LoginUser $request)
    {
        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {
            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        try {
            $this->incrementLoginAttempts($request);
//            return $this->sendFailedLoginResponse($request);
            $this->sendFailedLoginResponse($request);
        } catch (\Exception $e) {
            if ($e->getMessage() == 'The given data was invalid.') {
                $message = 'Неверный пароль';
                $msg = "Пользователь с логином - {$request->login} ввел неправильный пароль";
                Log::error($msg);
            } else {
                $message = $e->getMessage();
                Log::error("Ошибка авторизации, пользователь с логином - {$request->login} не смог авторизоваться");
            }

            return response()->json(['message' => $message], 401);
        }
    }

    /**
     * Log the user out of the application.
     *
     * @param  \App\Http\Requests\Auth\LogoutUser  $request
     */
    public function logout(LogoutUser $request)
    {
        try {
            $userId = Auth::id();
            SessionService::closeSession($request->session()->get('session_id'));
        } catch (\Exception $e) {
            Log::error('Не удалось закрыть сессию');

            return response()->json(['code' => 500, 'message' => 'Не удалось закрыть сессию'], 500);
        }

        $this->guard()->logout();
        $request->session()->invalidate();

        return response()->json(['code' => 200, 'message' => $userId], 200);
    }

    /**
     * Get the maximum number of attempts to allow.
     *
     * @return int
     */
    public function maxAttempts()
    {
        $value = intval(SystemParam::where('code', 'count_unsuccessful_attempts_auth')->pluck('value')->first());
        $login = request()->request->get('login');
        Log::info("Количество попыток при авторизации - {$value} у пользователя - {$login}");

        return $value;
    }

    /**
     * Get the number of minutes to throttle for.
     *
     * @return int
     */
    public function decayMinutes()
    {
        $value = intval(SystemParam::where('code', 'count_minute_unsuccessful_auth')->pluck('value')->first());
        $login = request()->request->get('login');
        Log::info("Количество минут блокировки при авторизации - {$value} у пользователя - $login");

        return $value;
    }
}
