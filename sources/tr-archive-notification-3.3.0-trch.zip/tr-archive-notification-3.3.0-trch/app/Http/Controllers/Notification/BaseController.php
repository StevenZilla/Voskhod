<?php

namespace App\Http\Controllers\Notification;

use App\Http\Controllers\Controller;
use App\Services\Notification\NotificationService;

class BaseController extends Controller
{
    public $service = null;
    public function __construct(NotificationService $service)
    {
        $this->service = $service;
    }
}
