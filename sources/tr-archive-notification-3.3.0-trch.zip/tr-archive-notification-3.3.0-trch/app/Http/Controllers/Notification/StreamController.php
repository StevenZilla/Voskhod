<?php

namespace App\Http\Controllers\Notification;

use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;


class StreamController extends BaseController
{
    public function __invoke(Request $request)
    {
        if ($request->hasHeader('cookie')) {
            if ($request->hasHeader('uid')) {
                $uid = $request->header('uid');
            } else {
                return response(null, 400);
            }
            $decodedData = $this->service->decryptCookie($request);
            if ($decodedData == null) {
                return response(['message' => 'cookie decryption error', 'code' => 400], 400);
            }
            try {
                if (Carbon::now()->timestamp > $decodedData->end_time) {
                    return response(null, 401);
                }
            } catch (Exception $e) {
                return response(['message' => 'expired cookies', 'code' => 400], 400);
            }

            $response = $this->service->openStream($decodedData, $uid);
            $this->service->IEfix();
            $response->headers->set("Content-Type", "text/event-stream");
            $response->headers->set('X-Accel-Buffering', 'no');
            $response->headers->set('Cache-Control', 'no-cache');
            return $response;
        } else {
            return response(['message' => 'cookie.error', 'code' => 400], 400);
        }
    }
}
