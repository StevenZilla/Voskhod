<?php

namespace App\Http\Controllers\Notification;

use Exception;
use Carbon\Carbon;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\Notification\IndexResource;

class IndexController extends BaseController
{
    public function __invoke(Request $request)
    {
        try {
            if ($request->hasHeader('cookie')) {
                if ($request->hasHeader('uid')) {
                    $uid = $request->header('uid');
                } else {
                    return response(["message" => "отсутствует идентификатор инстанции"], 400);
                }

                $decodedData = $this->service->decryptCookie($request);
                if ($decodedData == null) {
                    return response(['message' => 'cookie decryption error', 'code' => 400], 400);
                }
                try {
                    if (Carbon::now()->timestamp > $decodedData->end_time) {
                        return response(null, 401);
                    }
                } catch (Exception $e) {
                    return response(['message' => 'expired cookies', 'code' => 400], 400);
                }
                try {
                    $notifications = Notification::where('user_guid', $decodedData->user)->where('uid', $uid)->where('method', 1)->filters($request)->orderDefault($request, 'date', 'desc')->autoPaginate($request);
                    return new IndexResource($notifications);
                } catch (Exception $e) {
                    Log::error("Ошибка выборки данных" . $e->getMessage());
                    return response(['message' => "Ошибка выборки данных", 'code' => 500], 500);
                }
            } else {
                return response(['message' => ["message" => "Cookie не найдены"], 'code' => 401], 400);
            }
        } catch (\Exception $e) {
            Log::error("Ошибка сервера" . $e->getMessage());
            return response(['message' => "Ошибка сервера", 'code' => 500], 500);
        }
    }
}
