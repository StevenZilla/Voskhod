<?php

namespace App\Http\Controllers\Notification;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;

class DestroyController extends BaseController
{
    public function __invoke(int $id, Request $request)
    {
        try {
            if ($request->hasHeader('cookie')) {
                if ($request->hasHeader('uid')) {
                    $uid = $request->header('uid');
                } else {
                    return response(null, 400);
                }
                $decodedData = $this->service->decryptCookie($request);
                if ($decodedData == null) {
                    return response(['message' => 'cookie decryption error', 'code' => 400], 400);
                }
                try {
                    if (Carbon::now()->timestamp > $decodedData->end_time) {
                        return response(null, 401);
                    }
                } catch (Exception $e) {
                    return response(['message' => 'expired cookies', 'code' => 400], 400);
                }

                $this->service->deleteNotification($decodedData->user, $uid, $id);

                return response(null, 204);
            } else {
                return response(['message' => 'cookie.error', 'code' => 400], 400);
            }
        } catch (\Exception $e) {
            return response(['message' => 'server error', 'code' => 500], 500);
        }
    }
}
