<?php

namespace App\Http\Controllers\Notification;

use App\Http\Resources\Notification\NotificationResource;
use Illuminate\Http\Request;
use App\Models\Notification;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;

class ShowController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(int $id, Request $request)
    {
        try {
            if ($request->hasHeader('cookie')) {
                if ($request->hasHeader('uid')) {
                    $uid = $request->header('uid');
                } else {
                    return response(null, 400);
                }
                $decodedData = $this->service->decryptCookie($request);
                if ($decodedData == null) {
                    return response(['message' => 'cookie decryption error', 'code' => 400], 400);
                }
                try {
                    if (Carbon::now()->timestamp > $decodedData->end_time) {
                        return response(null, 401);
                    }
                } catch (Exception $e) {
                    return response(['message' => 'expired cookies', 'code' => 400], 400);
                }

                try {
                    $notification = Notification::findOrFail($id)->where('user_guid', $decodedData->user)->where('uid', $uid)->first();
                } catch (Exception $e) {
                    Log::error("Ошибка выборки данных" . $e->getMessage());
                    return response(['message' => "Ошибка выборки данных", 'code' => 500], 500);
                }
                return new NotificationResource($notification);
            } else {
                return response(['message' => 'cookie.error', 'code' => 401], 400);
            }
        } catch (\Exception $e) {
            return response(['message' => 'Уведомления с таким id не существует', 'code' => 400], 500);
        }
    }
}
