<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Notification\BaseController;
use Illuminate\Encryption\Encrypter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Exception;
use Carbon\Carbon;
use App\Models\Notification;

class TestController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        try {
            if ($request->hasHeader('cookie')) {
                if ($request->hasHeader('uid')) {
                    $uid = $request->header('uid');
                } else {
                    return response(["message" => "отсутствует идентификатор инстанции"], 400);
                }

                $decodedData = $this->service->decryptCookie($request);
                if ($decodedData == null) {
                    return response(['message' => 'cookie decryption error' . config('notification.notification_cookie_name'), 'code' => 400], 400);
                }
                dd($decodedData);
                try {
                    if (Carbon::now()->timestamp > $decodedData->end_time) {
                        return response(null, 401);
                    }
                } catch (Exception $e) {
                    return response(['message' => 'expired cookies', 'code' => 400], 400);
                }
            } else {
                return response(['message' => ["message" => "Cookie не найдены"], 'code' => 401], 400);
            }
        } catch (\Exception $e) {

            return response(['message' => "Ошибка сервера", 'code' => 500], 500);
        }
    }
}
