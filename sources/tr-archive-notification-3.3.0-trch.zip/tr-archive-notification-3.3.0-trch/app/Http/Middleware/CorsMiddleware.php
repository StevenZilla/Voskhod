<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Response;

class CorsMiddleware
{
    /**
     * Handle an incoming request.
     * Устанавливает корсы для запроса.
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
//        dd('test');
        $origin = $request->header('host');
        $allowedOrigins = [
            'http://localhost:8080',
            'http://swerqwre.it-thematic.ru:8080',
            'https://trarchive.it-thematic.ru',
            'http://trfront.local:8093',
            'trfront.local:9095',
            'http://trfront.local:9095',
            'http://trfront.local',

            'trfront.local',
            '127.0.0.1:8080',
            '127.0.0.1:8000',
            '127.0.0.1:8001',
            'localhost',
            '0.0.0.0:8001', ];

        if ($request->isMethod('OPTIONS')) {
            $response = Response::make();
        } else {
            $response = $next($request);
        }

        if (in_array($origin, $allowedOrigins)) {
            return $response
                ->header('Access-Control-Allow-Methods', 'OPTIONS, GET, POST, PUT, PATCH')
                ->header('Access-Control-Allow-Headers', 'Accept, Authorization, Content-Type, Content-Range, Content-Disposition, Content-Description, Origin, Content-Type')
                ->header('Access-Control-Allow-Origin', $origin)
                ->header('Access-Control-Allow-Credentials', true);
        }

        return $response;
    }
}
