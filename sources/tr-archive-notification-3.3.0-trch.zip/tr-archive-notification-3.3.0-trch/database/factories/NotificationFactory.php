<?php

namespace Database\Factories;

use App\Models\Notification;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

class NotificationFactory extends Factory
{
    protected $model = Notification::class;
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {



        return [
            'guid'=>$this->faker->uuid(),
            'date'=>$this->faker->dateTime('now', 'Europe/Moscow'),
            'title' =>$this->faker->sentence(5),
            'message' => json_encode($this->faker->words(7)) ,
            'user_id'=> $this->faker->numberBetween(1,3),
            'email' => $this->faker->unique()->safeEmail(),
            'method' => $this->faker->numberBetween(1,2),
            'read' => $this->faker->numberBetween(0,1),
            'send' => 0,
        ];
    }
}
