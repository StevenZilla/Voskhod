# trarchive ui

## Sсheme
![Схема проекта](https://app.diagrams.net/#G1exYZG4STEEBb51ffbuTOtRe7obmzmFju#%7B%22pageId%22%3A%22R2lEEEUBdFMjLlhIrx00%22%7D)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


### Особенности  кук 

google234234234

## Dependencies
- Vue (2.7.14) [](url)
- node (12.18.3)
- vuetify (2.4.0)
- vue-router (3.5.2)
- vuex (3.6.2)

