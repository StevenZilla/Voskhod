import Vue from 'vue'
import App from './App.vue'
import { abilitiesPlugin } from '@casl/vue'
import router from './router'
import store from './storages'
import axios from 'axios'
import Vuelidate from 'vuelidate'
import vuetify from './plugins/vuetify'
import VueCookies from 'vue-cookies'
import mixins from './utils/mixins'
import InstantSearch from 'vue-instantsearch'
import '@/assets/scss/daterangepicker.scss'

import AppNotify from './components/AppNotify'
import TemplateCreate from './components/TemplateCreate'
import TemplateDetail from './components/TemplateDetail'
import TemplateButtons from './components/TemplateButtons'
import BtnSaveSlot from './components/BtnSaveSlot'
import BtnCancelSlot from './components/BtnCancelSlot'
import LoadingComponentVue from './components/LoadingComponentVue'
import DatePickerActions from './components/DatePickerActions.vue'
import PaginationTable from './components/PaginationTable.vue'
import DateRangePicker from 'vue2-daterange-picker'
import { ObserveVisibility } from 'vue-observe-visibility'

import registersModule from './modules/registers'
import agreementsModule from './modules/agreements'
import nomenclaturesModule from './modules/nomenclatures'
import dossiersModule from './modules/dossiers'
import tksModule from './modules/tks'
import actsModule from './modules/acts'
import deleteActsModule from './modules/delete-acts'
import loginModule from './modules/login'
import usersModule from './modules/administration/users'
import rolesModule from './modules/administration/roles'
import eventsModule from './modules/administration/events'
import edsModule from './modules/eds'
import nsiModule from './modules/nsi'
import supportModule from './modules/administration/support'
import settingsModule from './modules/settings'
import { registerModules } from './register-modules'
import './assets/scss/override.scss'
import './assets/scss/main.scss'

import { GET_CONFIG_URL } from './services/app'
Vue.use(abilitiesPlugin, store.getters.ABILITY)

registerModules({
  registers: registersModule,
  agreements: agreementsModule,
  nomenclatures: nomenclaturesModule,
  dossiers: dossiersModule,
  tks: tksModule,
  acts: actsModule,
  deleteActs: deleteActsModule,
  nsi: nsiModule,
  login: loginModule,
  events: eventsModule,
  users: usersModule,
  roles: rolesModule,
  eds: edsModule,
  settings: settingsModule,
  support: supportModule
})

export const eventBus = new Vue()

Vue.prototype.$axios = axios
Vue.prototype.$eventBus = eventBus
Vue.config.productionTip = false

// Vue.config.errorHandler = (msg, vm, info) => {
//   console.log('msg', msg)
//   console.log('vm', vm)
//   console.log('info', info)
// }

Vue.use(Vuelidate)
Vue.use(VueCookies)
Vue.use(InstantSearch)
Vue.mixin(mixins)

Vue.component('AppNotify', AppNotify)
Vue.component('TemplateCreate', TemplateCreate)
Vue.component('TemplateDetail', TemplateDetail)
Vue.component('TemplateButtons', TemplateButtons)
Vue.component('BtnSaveSlot', BtnSaveSlot)
Vue.component('BtnCancelSlot', BtnCancelSlot)
Vue.component('LoadingComponentVue', LoadingComponentVue)
Vue.component('DatePickerActions', DatePickerActions)
Vue.component('PaginationTable', PaginationTable)
Vue.component('DateRangePicker', DateRangePicker)

Vue.directive('observe-visibility', ObserveVisibility)

Vue.directive('click-outside-custom', {
  bind: function (el, binding, vnode) {
    el.clickOutsideEvent = function (event) {
      if (!(el === event.target || el.contains(event.target))) {
        vnode.context[binding.expression](event)
      }
    }
    document.body.addEventListener('click', el.clickOutsideEvent)
  },
  unbind: function (el) {
    document.body.removeEventListener('click', el.clickOutsideEvent)
  }
})

async function initApp () {
  await GET_CONFIG_URL()
  Vue.prototype.$eventBus = eventBus

  new Vue({
    vuetify,
    store,
    router,
    render: h => h(App)
  }).$mount('#app')
}

initApp()
