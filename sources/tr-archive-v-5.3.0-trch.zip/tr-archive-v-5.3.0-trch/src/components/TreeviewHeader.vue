<template>
  <div class="structure__info d-flex justify-end align-end">
    <v-btn
      outlined
      class="mr-3 rounded-lg"
      color="secondary"
      @click="$emit('switch-nodes')"
      :disabled="disable"
    >
      <v-icon class="mr-2">mdi-{{ openNodes.length ? 'collapse' : 'expand' }}-all-outline</v-icon>
      {{ openNodes.length ? 'Свернуть' : 'Развернуть' }} все
    </v-btn>
  </div>
</template>

<script>
export default {
  name: 'TreeviewHeader',

  props: {
    openNodes: {
      type: Array,
      required: true
    },
    disable: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss">

</style>
