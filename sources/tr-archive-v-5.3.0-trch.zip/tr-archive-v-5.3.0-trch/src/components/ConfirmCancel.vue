<template>
  <v-card>
    <v-card-title class="d-block mb-0">
      {{ text }}
      <!--      TODO потом поправить на нормальный выход-->
      <br/>
      Вы уверены, что хотите выйти без сохранения изменений?
    </v-card-title>

    <v-card-actions class="justify-end">
      <v-btn
        class="rounded-lg"
        color="secondary"
        outlined
        @click="$emit('cancel')"
      >Нет
      </v-btn>
      <v-btn
        class="rounded-lg"
        color="secondary"
        @click="$emit('confirm')"
      >Да
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>

export default {
  props: {
    blocks: {
      type: Array
    }
  },

  computed: {
    text () {
      let _text = ''
      if (!this.blocks) _text = 'У вас остались несохраненные изменения.'
      else {
        _text = `У вас остались несохраненные изменения в блок${this.blocks.length > 1 ? 'ах' : 'е'}
      ${this.blocks ? this.blocks.join(', ') : ''}.`
      }
      return _text
    }
  }
}
</script>

<style>
</style>
