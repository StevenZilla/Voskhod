<template>
  <div class="btn-resize" ref="resize" :style="{ height: height }">
    <div class="btn-resize_line"></div>
    <div class="btn-resize_icon">
      <div class="btn-resize_box">
        <div class="point"></div>
        <div class="point"></div>
        <div class="point"></div>
        <div class="point"></div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'resize-width',
  props: ['height'],
  data: () => ({
    startX: 0,
    initialWidth: 0
  }),
  mounted () {
    this.$refs.resize.parentElement.style.position = 'relative'
    this.$refs.resize.addEventListener('mousedown', (event) => {
      this.isResizing = true
      this.startX = event.clientX
      this.initialWidth = this.$refs.resize.parentElement.previousElementSibling.offsetWidth

      document.addEventListener('mousemove', this.mouseMoveHandler)
      document.addEventListener('mouseup', this.mouseUpHandler)
    })
  },
  methods: {
    mouseMoveHandler (event) {
      if (this.isResizing) {
        document.getElementById('app').style.pointerEvents = 'none'
        let newWidth = this.initialWidth + event.clientX - this.startX
        if (newWidth < 250) newWidth = 250
        if (newWidth > 1650) newWidth = 1650
        this.$refs.resize.parentElement.previousElementSibling.style.width = newWidth + 'px'
      }
    },

    mouseUpHandler () {
      this.isResizing = false
      document.removeEventListener('mousemove', this.mouseMoveHandler)
      document.removeEventListener('mouseup', this.mouseUpHandler)
      document.getElementById('app').style.pointerEvents = ''
    }
  }
}
</script>
<style scoped lang="scss">
.btn-resize {
  position: absolute;
  top: 0;
  left: -2px;
  width: 9px;
  border-radius: 8px !important;
  cursor: col-resize;
  height: -webkit-fill-available;
  &:hover &_line{
    background-color: #9DBDED;
    width: 4px;
    height: inherit;
    position: absolute;
    left: 2px;
  }
  &_icon {
    position: absolute;
    top: 200px;
    width: 10px;
    height: 60px;
  }
  &_box {
    position: absolute;
    top: 15px;
  }
}
.point {
  width: 5px;
  height: 5px;
  background: radial-gradient(circle, #000026, #9DBDED);
  border-radius: 50%;
  margin-bottom: 3px;
  margin-left: 4px;
}
</style>
