<template>
  <v-card>
    <v-card-title class="mb-0">{{ title }}</v-card-title>
    <v-card-text>
      <v-alert
        icon="mdi-alert"
        class="warning-alert mb-0 border-bottom rounded"
      >{{ text }}</v-alert>
    </v-card-text>

    <v-card-actions class="justify-end">
      <v-btn
        class="mr-2 rounded-lg"
        color="secondary"
        outlined
        @click="$emit('close-popup')"
      >Отменить</v-btn>
      <v-btn
        class="rounded-lg"
        color="secondary"
        @click="confirmDelete()"
      >Удалить</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: 'Удаление раздела'
    },

    text: {
      type: String,
      default: 'Вы уверены, что хотите удалить данный раздел? Все связанные подразделы и дела также удалятся.'
    }
  },
  methods: {
    confirmDelete () {
      this.$emit('confirm-delete')
    }
  }
}
</script>

<style>

</style>
