<template>
  <div class="detail__buttons">
    <div class="detail__buttons-left">
      <slot name="buttons-left"></slot>
    </div>

    <div class="detail__buttons-right">
      <slot name="buttons-right"></slot>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="scss">

</style>
