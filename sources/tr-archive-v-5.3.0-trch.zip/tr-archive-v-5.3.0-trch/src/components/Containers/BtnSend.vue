<template>
  <v-dialog
    v-model="isSend"
    max-width="425px"
    transition="scroll-y-transition"
    content-class="dialog-auto-height"
    @click:outside="refreshData()"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        color="secondary"
        class="mr-3 rounded-lg"
        outlined
        :loading="loading"
        v-bind="attrs"
        v-on="on"
      ><v-icon class="mr-2">{{ getBtnIcon(typeSend) }}</v-icon>
        {{ getBtnText(typeSend, typeItem) }}</v-btn>
    </template>

    <WrapperContainers
      :type-send="typeSend"
      :type-item="typeItem"
      :item-id-send="itemIdSend"
      @close-popup="refreshData()"
    />
  </v-dialog>
</template>

<script>

const WrapperContainers = () => import(/* webpackChunkName: 'wrapper-containers' */'@/components/Containers/WrapperContainers.vue')

export default {
  components: {
    WrapperContainers
  },

  props: {
    typeSend: {
      type: String,
      required: true
    },

    typeItem: {
      type: String,
      required: true
    },

    itemIdSend: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    loading: false,
    isSend: false
  }),

  methods: {
    getBtnIcon (type) {
      switch (type) {
        case 'tk':
          return 'mdi-database-check-outline'

        case 'ak':
          return 'mdi-database-clock-outline'

        default:
          return ''
      }
    },

    getBtnText (typeSend, typeItem) {
      if (typeItem === 'register-ed') {
        if (typeSend === 'tk') return 'По описи в ЦХЭД'
        if (typeSend === 'ak') return 'По описи во временное хранилище'
      }

      if (typeSend === 'tk') return 'Отправить в ЦХЭД'
      if (typeSend === 'ak') return 'Отправить во временное хранилище'
    },

    refreshData () {
      this.isSend = false
      this.loading = true
      setTimeout(async () => {
        this.$emit('refresh-data')
        this.loading = false
      }, 2500)
    }
  }
}
</script>

<style lang="scss">

.notification-block {
  .v-alert {
    font-size: 14px;
  }
  .v-alert__icon {
    align-self: auto;
  }
}

</style>
