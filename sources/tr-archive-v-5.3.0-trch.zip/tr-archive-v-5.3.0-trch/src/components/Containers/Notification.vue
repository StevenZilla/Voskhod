<template>
  <v-card class="py-3 px-5">
    <v-toolbar
      dense
      flat
      class="popup-toolbar px-0"
    ><v-toolbar-title>Формирование ТК</v-toolbar-title>
      <v-btn
        icon
        dark
        @click="$emit('close-popup')"
      ><v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>

    <div class="notification-block transfer">
      <div class="notification-block__content transfer__fields">
        <v-alert
          v-if="error"
          dense
          icon="mdi-alert"
          type="error"
        >
          Произошла ошибка при отправке ТК
        </v-alert>
        <v-alert
          v-else
          dense
          type="info"
          icon="mdi-bell-ring"
          :color="isLoad ? '#FF9500' : 'success'"
        >{{ filledTextTk }}</v-alert>
      </div>
      <div class="notification-block__actions transfer__actions">
        <v-btn
          class="rounded-lg"
          color="secondary"
          @click="$emit('close-popup')"
        >Понятно</v-btn>
      </div>
    </div>
  </v-card>
</template>

<script>

export default {
  props: {
    typeSend: {
      type: String,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: true,
      default: true
    },

    error: {
      type: Boolean,
      required: true,
      default: false
    },

    dateSend: {
      type: String,
      required: true,
      default: new Date()
    }
  },

  computed: {
    filledTextTk () {
      if (this.isLoad) return this.getTextBefore(this.typeSend, this.itemIdSend)
      else return this.getTextAfter(this.typeSend, this.dateSend)
    }
  },

  methods: {
    getTextBefore (type) {
      if (type === 'tk') {
        return 'Транспортный контейнер формируется. Пожалуйста, не закрывайте браузер до окончания процесса отправки'
      }
      if (type === 'ak') {
        return 'Архивный контейнер формируется. Пожалуйста, не закрывайте браузер до окончания процесса отправки'
      }
    },

    getTextAfter (type, date) {
      let text = ''
      if (type === 'tk') text = `Транспортный контейнер от ${date} отправлен.`
      if (type === 'ak') text = `Архивный контейнер от ${date} отправлен.`
      return text
    }
  }
}
</script>

<style lang="scss">

.notification-block {
  .v-alert {
    font-size: 14px;
  }
  .v-alert__icon {
    align-self: auto;
  }
}
</style>
