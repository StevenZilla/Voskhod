<template>
  <div class="wrapper-containers">
    <v-card>
      <h3 style="padding: 10px; text-align: center;">
        {{ `${typeSendList[typeItem].title} ${titleType}` }}
      </h3>
      <div style="min-height: 50px"></div>

      <div class="wrapper-containers__actions">
        <v-btn
          class="mr-3 rounded-lg"
          color="secondary"
          outlined
          @click="$emit('close-popup')"
        >Отменить
        </v-btn>
        <v-btn
          data-qa="send"
          class="rounded-lg"
          color="secondary"
          @click="submitHandler()"
        >Отправить
        </v-btn>
      </div>
    </v-card>

    <v-dialog
      v-model="isOpenNotification"
      persistent
      content-class="dialog-auto-height"
      max-width="550px"
    >
      <Notification
        :type-send="typeSend"
        :is-load="isLoad"
        :error="errorSend"
        :date-send="dateSend"
        @close-popup="close"
      />
    </v-dialog>
  </div>
</template>

<script>

import { SEND_TKS } from '@/services/app'

const Notification = () => import('./Notification.vue')

export default {
  components: {
    Notification
  },

  props: {
    typeSend: {
      type: String,
      required: true
    },

    typeItem: {
      type: String,
      required: true
    },

    itemIdSend: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    errorSend: false,
    isOpenNotification: false,
    isLoad: false,
    dateSend: '',
    typeSendList: {
      ed: {
        id: 'ed_id',
        title: 'Передача ЭАД на хранение'
      },
      register: {
        id: 'register_id',
        title: 'Передача описи на хранение'
      },
      'register-ed': {
        id: 'register_by_ed_id',
        title: 'Передача ЭАД на хранение'
      },
      nom: {
        id: 'nom_id',
        title: 'Передача номенклатуры на хранение'
      }
    }
  }),

  computed: {
    titleType () {
      if (this.typeSend === 'tk') return 'в ЦХЭД'
      if (this.typeSend === 'ak') return 'во временное хранилище'
      return 'unknown'
    }
  },

  methods: {
    getCodeRequest (type) {
      switch (type) {
        case 'tk':
          return 'eds_tk'

        case 'ak':
          return 'eds_ak'
      }
    },

    submitHandler () {
      this.isLoad = true
      this.errorSend = false

      const sendItem = {
        [this.typeSendList[this.typeItem].id]: this.itemIdSend // это пример register_id: 3
      }

      this.isOpenNotification = true

      SEND_TKS(this.typeSend, sendItem).then(resp => {
        console.log('resp', resp)
        if (resp) this.dateSend = resp
        this.isLoad = false
      }).catch((err) => {
        this.errorSend = true
        console.error(err)
      }).finally(() => {
        this.isOpenNotification = true
      })
    },

    close () {
      this.isLoad = true
      this.isOpenNotification = false
      this.$emit('close-popup')
      this.isLoad = false
    }
  }
}
</script>

<style lang="scss">
</style>
