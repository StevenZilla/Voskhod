<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <treeselect
      v-model="filter.query"
      class="w-100 scroll-treeselect"
      valueFormat="object"
      placeholder="Все статьи"
      append-to-body
      :multiple="true"
      :disabled="disabled"
      :options="diKindsList"
      @input="$emit('set-filter', filter)"
    />
  </div>
</template>

<script>

import { Treeselect } from '@riophae/vue-treeselect'
import { GET_CLASSIFIER } from '@/services/app'

export default {
  components: { Treeselect },

  props: {
    resetFilter: {
      type: Boolean
    },

    selectedClassifier: {
      required: true,
      default: null
    },

    disabled: {
      type: Boolean,
      required: false
    }
  },

  data: () => ({
    diKindsList: [],
    filter: {
      title: 'Вид документа',
      code: 'diKinds',
      query: null
    }
  }),

  watch: {
    selectedClassifier: {
      handler (newV) {
        if (newV) this.getData()
      },
      deep: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_CLASSIFIER(this.selectedClassifier.query.value).then(resp => {
        this.diKindsList = resp
        this.diKindsList.forEach(group => {
          this.prepareData(group)
        })
      })
    },

    prepareData (node) {
      node.pk = node.id
      node.id = `${node.id}.${node.type}`
      node.label = node.name
      if (node.children?.length) {
        node.children.forEach(child => {
          this.prepareData(child)
        })
      }
    }
  }
}

</script>

<style lang="scss">
  .scroll-treeselect {
  max-height: 120px !important;
  overflow-y: auto !important;
}
</style>
