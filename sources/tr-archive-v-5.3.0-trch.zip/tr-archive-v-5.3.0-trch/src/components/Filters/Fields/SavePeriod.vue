<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-text-field
      v-model="filter.query"
      class="rounded-lg"
      placeholder="Введите срок хранения"
      outlined
      clearable
      hide-details
      :disabled="disabled"
      :filled="disabled"
      @input="$emit('set-filter', filter)"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    disabled: {
      type: Boolean,
      default: true
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Срок хранения (лет)',
      code: 'savePeriod',
      query: null
    }
  }),

  watch: {
    disabled (newV) {
      if (newV) this.removeFilter()
    },

    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">
</style>
