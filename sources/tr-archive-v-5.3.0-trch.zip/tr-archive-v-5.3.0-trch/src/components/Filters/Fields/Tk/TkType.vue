<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все типы"
      :items="tkTypeList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_TK_TYPES } from '@/modules/tks/services/api'

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    tkTypeList: [],
    filter: {
      title: 'Тип ТК',
      code: 'tkType',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_TK_TYPES().then(resp => { this.tkTypeList = resp })
    }
  }
}

</script>

<style lang="scss">

</style>
