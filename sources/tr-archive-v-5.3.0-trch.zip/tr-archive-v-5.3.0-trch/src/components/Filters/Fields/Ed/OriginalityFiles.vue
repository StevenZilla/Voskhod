<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
        v-model="filter.query"
        class="rounded-lg"
        return-object
        hide-details
        solo
        outlined
        clearable
        placeholder="Все"
        :items="originalsList"
        :no-data-text="'Нет результатов'"
        @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>
export default {
  name: 'OriginalityFiles',

  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    originalsList: [
      {
        text: 'Подлинник',
        value: true
      },
      {
        text: 'Копия',
        value: false
      }
    ],
    filter: {
      title: 'Подлинность основного файла документа',
      code: 'isDocOriginal',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">

</style>
