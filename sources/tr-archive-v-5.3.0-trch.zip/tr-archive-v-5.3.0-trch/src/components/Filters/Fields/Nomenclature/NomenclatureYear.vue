<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      data-qa="reg-date"
      hide-details
      clearable
      solo
      outlined
      append-icon="mdi-calendar-blank"
      placeholder="Выберите год"
      multiple
      color="secondary"
      :items="arrayYearsMix"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
      @click:clear="removeFilter"
    ></v-autocomplete>
  </div>
</template>

<script>

export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Год номенклатуры дела',
      code: 'nomYear',
      query: ''
    }
  }),

  watch: {
    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = []
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">

</style>
