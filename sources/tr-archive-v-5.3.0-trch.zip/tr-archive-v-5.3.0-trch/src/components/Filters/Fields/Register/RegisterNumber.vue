<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-text-field
      v-model="filter.query"
      class="rounded-lg"
      placeholder="Введите номер сводной описи"
      solo
      outlined
      clearable
      hide-details
      @input="$emit('set-filter', filter)"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Номер сводной описи',
      code: 'registerNumber',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">
</style>
