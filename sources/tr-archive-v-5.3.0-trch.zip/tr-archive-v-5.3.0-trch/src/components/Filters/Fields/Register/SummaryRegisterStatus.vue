<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все статусы"
      color="secondary"
      :items="registerStatusList"
      :no-data-text="'Нет результатов'"
      :loading="loading"
      :loader-height="5"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_REGISTER_STATUS } from '@/modules/registers/submodules/summary/services/api'

export default {
  props: {
    resetFilter: {
      type: Boolean
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    registerStatusList: [],
    loading: false,
    filter: {
      title: 'Статус обработки',
      code: 'registerStatusId',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      this.loading = true
      GET_REGISTER_STATUS()
        .then(resp => { this.registerStatusList = resp.map(item => ({ text: item.value, value: item.id })) })
        .finally(() => {
          this.loading = false
        })
    }
  }
}

</script>

<style lang="scss">

</style>
