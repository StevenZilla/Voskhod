<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все виды"
      :items="registerTypesList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_REGISTER_TYPES } from '@/services/app'

export default {
  props: {
    resetFilter: {
      type: Boolean
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    registerTypesList: [],
    filter: {
      title: 'Вид описи',
      code: 'registerType',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_REGISTER_TYPES().then(resp => { this.registerTypesList = resp.map(item => ({ text: item.value, value: item.id })) })
    }
  }
}

</script>

<style lang="scss">

</style>
