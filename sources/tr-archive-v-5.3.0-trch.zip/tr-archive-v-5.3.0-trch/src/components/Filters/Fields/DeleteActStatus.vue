<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
        v-model="filter.query"
        class="rounded-lg"
        return-object
        hide-details
        solo
        outlined
        clearable
        placeholder="Все статусы"
        :items="actStatuses"
        :no-data-text="'Нет результатов'"
        @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_DELETE_ACT_STATUS } from '@/modules/delete-acts/services/api'

export default {
  props: {
    resetFilter: {
      type: Boolean
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    actStatuses: [],
    filter: {
      title: 'Статус',
      code: 'deleteActStatus',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_DELETE_ACT_STATUS().then(resp => { this.actStatuses = resp.map(item => ({ text: item.value, value: item.id })) })
    }
  }
}

</script>

<style lang="scss">

</style>
