<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      data-qa="reg-date"
      hide-details
      clearable
      outlined
      solo
      append-icon="mdi-calendar-blank"
      :placeholder="multiple ? 'гггг-гггг' : 'гггг'"
      :multiple="multiple"
      color="secondary"
      item-color="secondary"
      :items="arrayYearsMix"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
      @click:clear="removeFilter"
    ></v-autocomplete>
  </div>
</template>

<script>

import isBefore from 'date-fns/isBefore'

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    multiple: {
      type: Boolean,
      required: false,
      default: true
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Год',
      code: 'regDate',
      query: []
    }
  }),

  watch: {
    resetFilter (newV) {
      if (newV) this.removeFilter()
    },

    'filter.query' (newV) {
      if (!this.multiple) return
      if (isBefore(new Date(newV[1]), new Date(newV[0]))) {
        this.filter.query = [newV[1], newV[0]]
      }
      if (this.filter.query.length === 3) this.filter.query.shift()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = []
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">

</style>
