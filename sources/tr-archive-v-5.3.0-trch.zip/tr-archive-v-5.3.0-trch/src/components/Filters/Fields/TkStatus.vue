<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все статусы"
      :items="tkStatusesList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_TK_STATUSES_LIST } from '@/services/app'

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Статус отправки в ЦХЭД',
      code: 'tkStatus',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  computed: {
    tkStatusesList () {
      return this.$store.getters.GET_FILTER_TK_STATUS_LIST
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      if (!this.$store.state.tkStatusesList.length) GET_TK_STATUSES_LIST()
    }
  }
}

</script>

<style lang="scss">

</style>
