<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      hide-details
      clearable
      outlined
      solo
      append-icon="mdi-calendar-blank"
      placeholder="гггг"
      color="secondary"
      item-color="secondary"
      :items="arrayYearsNoLimitMix"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
      @click:clear="removeFilter"
    ></v-autocomplete>
  </div>
</template>

<script>

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Год окончания хранения',
      code: 'expirationYear',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">

</style>
