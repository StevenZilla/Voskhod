<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-text-field
      v-model="filter.query"
      class="rounded-lg"
      data-qa="email"
      solo
      outlined
      clearable
      placeholder="Введите e-mail"
      @input="$emit('set-filter', filter)"
      hide-details
    >
    </v-text-field>
  </div>
</template>

<script>
export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'E-mail',
      code: 'email',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}
</script>

<style lang="scss">
</style>
