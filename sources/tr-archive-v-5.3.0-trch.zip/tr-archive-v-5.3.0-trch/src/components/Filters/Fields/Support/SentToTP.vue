<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все"
      :items="eventsTypesList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    eventsTypesList: [
      { text: 'Да', value: true },
      { text: 'Нет', value: false }
    ],
    filter: {
      title: 'Отправлено в ТП',
      code: 'is_sent',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}
</script>

<style lang="scss">
</style>
