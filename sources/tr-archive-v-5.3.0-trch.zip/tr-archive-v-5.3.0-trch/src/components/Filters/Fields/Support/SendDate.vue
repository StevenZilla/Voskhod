<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <date-range-picker
      v-model="dateRangeMix.start"
      style="width: 100%"
      opens="right"
      show-dropdowns
      time-picker
      :append-to-body="true"
      :ranges="false"
      :locale-data="localeSettings"
      @toggle="$_setBeginDate($event, filter.query, 'start')"
      @update="filter.query = $_setDate($event, 'time', true)"
      @select="$emit('set-filter', filter)"
    >
      <template #input>
        <v-text-field
          class="rounded-lg"
          readonly
          solo
          outlined
          hide-details
          append-icon="mdi-calendar-blank"
          clearable
          placeholder="дд.мм.гггг — дд.мм.гггг"
          :value="$_getFormatDate(filter.query)"
          @click:clear="removeFilter"
        ></v-text-field>
      </template>

      <div slot="footer" slot-scope="data" class="slot">
        <DatePickerActions
          :disabled="!!data.in_selection"
          @cancel="data.clickCancel"
          @apply="data.clickApply"
        />
      </div>
    </date-range-picker>
  </div>
</template>

<script>
export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Дата и время отправки',
      code: 'sendDate',
      query: []
    }
  }),

  watch: {
    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = []
      this.$emit('set-filter', this.filter.code)
    }
  }
}
</script>

<style lang="scss">
</style>
