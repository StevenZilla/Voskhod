<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все виды"
      :items="saveTypeList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_SAVE_TYPE_LIST } from '@/services/app'

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    saveTypeList: [],
    filter: {
      title: 'Вид хранения',
      code: 'saveType',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_SAVE_TYPE_LIST().then(resp => {
        this.saveTypeList = resp.map(item => ({ text: item.value, value: item.id, code: item.code }))
      })
    }
  }
}

</script>

<style lang="scss">

</style>
