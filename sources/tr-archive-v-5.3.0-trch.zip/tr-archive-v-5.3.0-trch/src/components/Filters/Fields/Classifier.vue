<template>
  <div class="form-group classifier">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все реестры"
      :attach="true"
      :items="classifiersList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_CLASSIFIER_LIST } from '@/services/app'

export default {
  props: {
    resetFilter: {
      type: Boolean
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    classifiersList: [],
    filter: {
      title: 'Реестр видов документов',
      code: 'classifier',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_CLASSIFIER_LIST().then(resp => {
        this.classifiersList = resp.map(item => {
          return {
            text: item.name,
            value: item.id
          }
        })
      })
    }
  }
}

</script>

<style lang="scss">
.classifier > .theme--light .v-menu__content {
  background-color: #f5f5f5
}
</style>
