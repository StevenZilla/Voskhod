<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все статусы"
      :items="dossierStatusesList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_DOSSIERS_STATUS } from '@/modules/dossiers/services/api'

export default {
  name: 'DossierStatus',

  props: {
    resetFilter: {
      type: Boolean
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    dossierStatusesList: [],
    filter: {
      title: 'Статус дела',
      code: 'status',
      query: null
    }
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    isLoad: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    },

    getData () {
      GET_DOSSIERS_STATUS().then(resp => { this.dossierStatusesList = resp })
    }
  }
}

</script>

<style lang="scss">

</style>
