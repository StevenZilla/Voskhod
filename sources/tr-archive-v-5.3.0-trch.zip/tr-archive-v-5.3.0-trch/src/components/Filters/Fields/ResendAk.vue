<template>
  <div class="form-group">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Все"
      :items="booleanList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>

export default {
  props: {
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Переотправить во временное хранилище',
      code: 'resendAk',
      query: null
    },
    booleanList: [
      {
        text: 'Да',
        value: true
      },
      {
        text: 'Нет',
        value: false
      }
    ]
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}

</script>

<style lang="scss">

</style>
