<template>
  <div class="form-group w-24">
    <span class="form-group__title">{{ filter.title }}</span>
    <v-autocomplete
      v-model="filter.query"
      class="rounded-lg"
      return-object
      outlined
      solo
      hide-details
      clearable
      color="secondary"
      placeholder="Все"
      :items="actualList"
      :no-data-text="'Нет результатов'"
      @input="$emit('set-filter', filter)"
    ></v-autocomplete>
  </div>
</template>

<script>
export default {
  props: {
    resetFilter: {
      type: Boolean
    }
  },

  data: () => ({
    filter: {
      title: 'Актуальность',
      code: 'actual',
      query: null
    },
    actualList: [
      {
        text: 'Да',
        value: true
      },
      {
        text: 'Нет',
        value: false
      }
    ]
  }),

  watch: {
    'filter.query' (newV) {
      if (!newV) this.removeFilter()
    },

    resetFilter (newV) {
      if (newV) this.removeFilter()
    }
  },

  methods: {
    removeFilter () {
      this.filter.query = null
      this.$emit('set-filter', this.filter.code)
    }
  }
}
</script>

<style lang="scss">
</style>
