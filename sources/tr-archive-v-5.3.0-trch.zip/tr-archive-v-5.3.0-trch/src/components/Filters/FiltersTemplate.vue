<template>
  <div class="filter">
    <transition-group
      tag="div"
      @before-enter="beforeEnter"
      @enter="enter"
      @leave="leave"
    >
      <div v-show="!fullFilter" ref="chips" :key="1">
        <slot name="chips"></slot>
      </div>

      <div v-show="fullFilter" :key="2" :class="{'filter--full': fullFilter}">
        <div class="filter__fields">
          <slot name="filter-fields"></slot>
        </div>

        <slot name="filter-footer"></slot>
      </div>
    </transition-group>
  </div>
</template>

<script>

import Velocity from 'velocity-animate'

export default {
  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },
    chipsLength: {
      type: Number,
      required: false
    }
  },

  watch: {
    chipsLength (newV) {
      if (newV === 0) this.leave(this.$refs.chips)
    }
  },

  methods: {
    beforeEnter (el) {
      el.style.opacity = 0
      el.style.overflow = 'hidden'
      el.style.height = 0
    },

    enter (el, done) {
      setTimeout(function () {
        Velocity(
          el,
          { opacity: 1, height: el.scrollHeight, overflow: 'visible' },
          { duration: 100 },
          { complete: done }
        )
      })
    },

    leave (el, done) {
      setTimeout(function () {
        Velocity(
          el,
          { opacity: 0, height: 0, overflow: 'hidden' },
          { duration: 100 },
          { complete: done }
        )
      })
    }
  }
}
</script>

<style scoped lang="scss">
  .filter--full {
  height: auto !important;
}

.bg {
  background-color: red;
}
</style>
