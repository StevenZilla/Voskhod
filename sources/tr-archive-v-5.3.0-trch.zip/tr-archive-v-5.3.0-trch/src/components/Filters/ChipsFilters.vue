<template>
  <div class="panel-search__chips">
    <transition-group name="scale-transition">
      <v-chip
        v-for="(chip) in chipsList"
        class="chip"
        close
        outlined
        :key="chip.title"
        @click:close="$emit('remove-filter', chip.code)"
      >{{ chip.title }}: {{ Array.isArray(chip.value) ? checkFormatDate(chip.value) : chip.value }}</v-chip>
    </transition-group>
  </div>
</template>

<script>

import { parse, isValid } from 'date-fns'

export default {
  name: 'ChipsFilters',
  props: {
    chipsList: {
      type: Array,
      required: true,
      default: () => []
    }
  },

  methods: {
    checkFormatDate (date) {
      const newDate = []

      if (isValid(parse(date[0], 'yyyy-MM-dd', new Date()))) {
        console.log('date', date)
        newDate[0] = this.$_formatDate(date[0])
        newDate[1] = this.$_formatDate(date[1])
      }
      if (isValid(parse(date[0], 'yyyy-MM-dd HH:mm:ss', new Date()))) {
        newDate[0] = this.$_formatDate(date[0], 'time')
        newDate[1] = this.$_formatDate(date[1], 'time')
      }
      if (isValid(parse(date[0], 'yyyy', new Date()))) {
        newDate[0] = date[0]
        newDate[1] = date[1]
      }
      return newDate.join(' - ')
    }
  }
}
</script>

<style lang="scss">

.panel-search__chips {
  display: flex;
  flex-wrap: wrap;

  .chip {
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
  }
}
</style>
