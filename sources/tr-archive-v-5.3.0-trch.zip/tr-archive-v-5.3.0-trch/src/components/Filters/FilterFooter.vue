<template>
  <div class="filter__footer">
    <v-btn
      class="mr-3 rounded-lg"
      color="secondary"
      outlined
      :disabled="disabled"
      @click="$emit('accept-filters')"
    >Найти
    </v-btn>
    <v-btn
      class="rounded-lg"
      color="secondary"
      outlined
      :disabled="!searchTouch"
      @click="$emit('clear-filters')"
    >Сбросить фильтр
    </v-btn>
  </div>
</template>

<script>

export default {
  name: 'FilterFooter',

  props: {
    searchTouch: {
      type: Boolean,
      default: true
    },

    disabled: {
      type: Boolean,
      required: true
    }
  }
}
</script>

<style lang="scss">

</style>
