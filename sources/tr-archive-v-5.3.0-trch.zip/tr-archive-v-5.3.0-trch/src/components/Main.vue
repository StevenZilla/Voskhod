<template>
  <v-main>
    <AppHeader
      @open-notify="isOpenNotification = true"
      @toggle-drawer="drawer = $event"
    />

    <!--        <ChangeTempPassword v-if="isChangePassword"/>-->

    <div class="app__inner">
      <template>
        <AppMenu :class="{ active: drawer }" :drawer="drawer"/>

        <div class="content" :class="{ active: drawer }">
          <div class="content__block">
            <div v-if="loadingPage" class="loader-page">
              <LoadingComponentVue/>
            </div>

            <keep-alive :include="keepComponent">
              <router-view></router-view>
            </keep-alive>
          </div>
        </div>
      </template>
    </div>

    <!-- Уведомления в системе -->
    <v-dialog
      v-model="isOpenNotification"
      max-width="1150"
      content-class="dialog-auto-height"
      transition="scroll-y-transition"
      @click:outside="isOpenNotification = false"
    >
      <AppNotification @close-popup="isOpenNotification = false"/>
    </v-dialog>
  </v-main>
</template>

<script>

import version from '../../VERSION.txt'
import { mapState } from 'vuex'
import AppNotification from '@/components/UserNotificaton/AppNotification.vue'
import { format } from 'date-fns'

const AppHeader = () => import(/* webpackChunkName: 'header' */'@/components/AppHeader')
const AppMenu = () => import(/* webpackChunkName: 'app-menu' */'@/components/AppMenu/Menu.vue')
export default {
  components: {
    AppNotification,
    AppHeader,
    AppMenu
  },

  data: () => ({
    version,
    drawer: false,
    isOpenNotification: false
  }),

  computed: {
    ...mapState({
      isChangePassword: state => state.login.isChangePassword,
      keepComponent: state => state.keepComponent,
      loadingPage: state => state.loadingPage,
      userInfo: state => state.userInfo
    }),

    date () {
      return format(new Date(), 'yyyy')
    }
  }
}
</script>

<style lang="scss">
.v-main {
  height: 100%;
}

.content__footer-text {
  justify-content: space-between;
  display: flex;
  min-width: 97%;
}
</style>
