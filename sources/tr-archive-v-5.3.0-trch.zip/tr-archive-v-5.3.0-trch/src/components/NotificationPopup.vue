<template>
  <v-card>
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    ><v-toolbar-title>{{ title }}</v-toolbar-title>
      <v-btn
        icon
        dark
        @click="$emit('close-popup')"
      ><v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>
    <div class="popup-form">
      <div class="notification-block__content transfer__fields">
        <v-alert
          dense
          type="info"
          icon="mdi-bell-ring"
          :color="'#E52E2E'"
        >{{ text }}</v-alert>
      </div>
      <div class="d-flex justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          @click="$emit('close-popup')"
        >Понятно</v-btn>
      </div>
    </div>
  </v-card>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: ''
    },
    text: {
      type: String,
      default: 'Вы достигли максимального количества уровней'
    }
  }
}
</script>

<style>

</style>
