<template>
<ul style="list-style: none;">
  <li v-for="child in items" :key="child.id">
    <span>
      {{ child.num_show }}
    </span>
    <span v-if="child.type === 'kind'"> - </span>
    <span :class="{'font-weight-bold': child.type === 'group'}">{{ child.name }}</span>
    <ViewTreeKinds v-if="child.children" :items="child.children"/>
  </li>
</ul>
</template>

<script>

export default {
  name: 'ViewTreeKinds',

  props: {
    items: {
      type: Array
    }
  }
}
</script>

<style lang="scss">

</style>
