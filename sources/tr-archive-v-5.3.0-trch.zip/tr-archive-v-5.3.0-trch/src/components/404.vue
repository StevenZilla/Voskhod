<template>
  <v-alert
    type="error"
    icon="mdi-alert"
    color="error"
  >Данной страницы не существует</v-alert>
</template>

<style>
</style>
