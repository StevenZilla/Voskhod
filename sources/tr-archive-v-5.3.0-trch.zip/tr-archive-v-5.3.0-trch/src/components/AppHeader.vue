<template>
  <v-app-bar
    color="primary"
    class="header"
    flat
    dark
  >
<!--    <Snowf-->
<!--      v-if="isOurStand"-->
<!--      :amount="50"-->
<!--      :size="13"-->
<!--      :speed="1"-->
<!--      :wind="0"-->
<!--      :opacity="0.8"-->
<!--      :swing="1"-->
<!--      :image="showPath"-->
<!--      :zIndex="null"-->
<!--      :resize="true"-->
<!--      color="#fff"-->
<!--    />-->

    <v-app-bar-nav-icon
      class="py-8 px-8"
      :ripple="false"
      @click="toggleDrawer()"
    >
      <v-icon>mdi-text-short</v-icon>
    </v-app-bar-nav-icon>

    <v-toolbar-title class="header__title pl-8">АРХИВ</v-toolbar-title>

    <v-spacer></v-spacer>

    <CreateInc />

    <div class="icons-block">
      <v-btn
        id="icon-ntf"
        class="rounded-xl"
        icon
        small
        outlined
        :color="userNotifications ? 'warning' : ''"
        @click="$emit('open-notify')"
      >
        <v-icon small>mdi-bell-ring-outline</v-icon>
      </v-btn>
      <v-badge
        v-if="userNotifications"
        class="notify-badge"
        label="icon-ntf"
        overlap
        color="error"
        inline
        :content="userNotifications > 100 ? '99+' : userNotifications"
      ></v-badge>
    </div>

    <div v-if="userInfo" class="mr-5">
      <v-btn
        outlined
        icon
        class="rounded-xl ml-5 grey darken-4"
      >{{ userInfo.fio.slice(0, 2).toUpperCase() }}
      </v-btn>
      <span class="mx-2">{{ userInfo.fio }}</span>
    </div>

    <v-btn
      data-qa="logout"
      outlined
      class="rounded-lg"
      :loading="loading"
      @click="submitHandler()"
    >Выйти
    </v-btn>
  </v-app-bar>
</template>

<script>

// import Snowf from 'vue-snowf'
import { LOGOUT, ESIA_LOGOUT } from '@/modules/login/services/api'
import { mapState } from 'vuex'
import { GET_USER_NOTIFICATION_COOKIE, SETUP_STREAM } from '@/modules/administration/users/services/api'
import CreateInc from '@/modules/administration/support/components/create-info/CreateInc.vue'

const showPath = require('../assets/icons/snow.svg')

export default {
  components: {
    CreateInc
    // Snowf
  },

  data: () => ({
    showPath,
    drawer: false,
    loading: false
  }),

  computed: {
    ...mapState({
      userNotifications: state => state.users.userNotifications,
      userInfo: state => state.userInfo,
      isEsiaisAuthorized: state => state.isEsiaisAuthorized
    }),

    isOurStand () {
      const route = this.$config.VUE_APP_HOST.replace('/api', '')
      return route === 'https://dev.archive.eadsc.ru'
    }
  },

  async mounted () {
    await GET_USER_NOTIFICATION_COOKIE()
    SETUP_STREAM()
  },

  methods: {
    async submitHandler () {
      this.loading = true
      this.isEsiaisAuthorized
        ? await ESIA_LOGOUT()
        : await LOGOUT()
      this.loading = false
    },

    toggleDrawer () {
      if (this.drawer === true) {
        this.drawer = false
        this.$emit('toggle-drawer', this.drawer)
      } else {
        this.drawer = true
        this.$emit('toggle-drawer', this.drawer)
      }
    }
  }
}
</script>

<style lang="scss">

.icons-block {
  position: relative;
  margin-right: 10px;

  .notify-badge.v-badge {
    position: absolute;
    top: 50%;
    right: -25px;
    transform: translateY(-50%)
  }
}

.header__title {
  font-size: 20px;
  letter-spacing: 0.2em;
  font-weight: bold;
}

.header {
  position: fixed;
  z-index: 10000;
  box-shadow: inset 0px -1px 0px #CBCBCD;

  .v-toolbar__content {
    padding: 4px 12px;
  }
}
</style>
