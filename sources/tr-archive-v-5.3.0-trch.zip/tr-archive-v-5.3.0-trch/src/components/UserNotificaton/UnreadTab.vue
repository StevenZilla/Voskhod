<template>
<div>
  <v-alert
    v-if="error"
    class="mt-3 mx-3"
    dense
    type="error"
    icon="mdi-alert"
    color="error"
  >Не получилось получить уведомления.</v-alert>

  <template v-else>
    <div v-if="notificationList.count">
      <v-btn
        outlined
        color="secondary"
        class="rounded-lg ml-3 my-3"
        @click="submitHandler()"
      >
        <v-icon class="mr-1">mdi-check</v-icon>
        Отметить все как просмотренные
      </v-btn>

      <v-data-table
        item-key="id"
        loading-text="Загрузка данных"
        no-data-text="Нет данных"
        class="main-table scroll-popup-table no-hover"
        hide-default-header
        hide-default-footer
        :headers="headers"
        :loading="loading"
        :server-items-length="notificationList.count"
        :options.sync="options"
        :page.sync="page"
        :items="notificationList.notifications"
        :items-per-page="itemsPerPage"
        @page-count="pageCount = $event"
      >
        <template #item.id="{ index }">
          {{ index + 1 }}
        </template>

        <template #item.message="{ item }">
            <span
              v-html="convertTemplate(item.message)"
              @click.capture="showDetail"
            ></span>
        </template>

        <template #item.icon="{ item }">
          <v-btn
            color="secondary"
            class="rounded-lg"
            icon
            @click.stop="submitHandler(item.id)"
          >
            <v-icon>mdi-email-open-outline</v-icon>
          </v-btn>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{ props }">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </div>

    <div v-else class="no-data d-flex justify-center">
      <v-icon color="#D9D9DE" size="128">mdi-alert-circle-outline</v-icon>
      <p>Новых уведомлений нет</p>
    </div>
  </template>
</div>
</template>

<script>

import { GET_USER_NOTIFICATION, READ_NOTIFICATION } from '@/modules/administration/users/services/api'

export default {
  name: 'UnreadTab',
  props: {
    headers: {
      type: Array,
      required: true
    },

    showDetail: {
      type: Function
    },

    convertTemplate: {
      type: Function
    },

    filter: {
      type: URLSearchParams
    },

    tabCount: {
      type: Number
    },

    trigger: {
      type: Number
    }
  },
  data: () => ({
    loading: true,
    error: false,
    notificationList: {},
    options: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 10
  }),

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) this.getNotification()
      },
      deep: true
    },

    trigger (newV) {
      if (newV && this.tabCount === 0) this.getNotification()
    }
  },

  computed: {
    sortParams () {
      const paramsSort = new URLSearchParams()
      paramsSort.append('is_read', 'false')
      paramsSort.append('page[size]', this.itemsPerPage)
      if (this.options !== null) {
        const { page } = this.options
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    this.getNotification()
  },

  methods: {
    getNotification () {
      this.loading = true
      this.error = false
      const searchParams = this.combineSearchParamsMix(this.filter, this.sortParams)
      GET_USER_NOTIFICATION(searchParams).then(resp => {
        this.notificationList = resp
        this.$emit('get-count', this.notificationList.count)
      }).catch(e => {
        console.log('e', e)
        this.error = true
      }).finally(() => {
        this.loading = false
      })
    },

    async submitHandler (id) {
      try {
        await READ_NOTIFICATION(id)
        await this.getNotification()
        this.$emit('get-count-read')
      } catch (e) {
        console.log(e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
