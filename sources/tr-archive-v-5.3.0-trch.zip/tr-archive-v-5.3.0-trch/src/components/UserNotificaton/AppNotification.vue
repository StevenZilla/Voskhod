<template>
<v-card class="select-popup">
  <v-toolbar
    dense
    flat
    class="popup-toolbar"
  >
    <v-toolbar-title>Уведомления</v-toolbar-title>
    <v-btn dark icon @click="$emit('close-popup')">
      <v-icon color="element">mdi-close</v-icon>
    </v-btn>
  </v-toolbar>

  <div class="dialog-panel-search">
    <div class="form-group mb-5">
      <v-text-field
        v-model="search"
        rounded
        class="rounded-lg"
        dense
        outlined
        placeholder="Поиск"
        clearable
        hide-details
        @click:clear="search = null, trigger++"
      >
        <template #append>
          <v-btn
            dense
            color="secondary"
            class="rounded-lg"
            icon
            @click="trigger++"
          ><v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>
      </v-text-field>
    </div>
  </div>

  <div class="main-table-inner">
    <v-tabs v-model="tabItem" height="48" class="notify-tabs" color="secondary">
      <v-tab :ripple="false">Новые
        <v-badge
          label="icon-ntf"
          overlap
          class="tab-badge"
          color="grey"
          inline
          :content="unreadCount ? unreadCount : '0'"
        ></v-badge>
      </v-tab>

      <v-tab-item>
        <UnreadTab
          :headers="headers"
          :show-detail="showDetail"
          :convert-template="convertTemplate"
          :filter="filterParams"
          :tab-count="tabItem"
          :trigger="trigger"
          @get-count="unreadCount = $event"
          @get-count-read="getCountRead()"
        />
      </v-tab-item>

      <v-tab :ripple="false">Прочитанные
        <v-badge
          label="icon-ntf"
          overlap
          class="tab-badge"
          color="grey"
          inline
          :content="currentReadCount ? currentReadCount : readCount"
        ></v-badge>
      </v-tab>

      <v-tab-item>
        <ReadTab
          :headers="headers"
          :show-detail="showDetail"
          :convert-template="convertTemplate"
          :filter="filterParams"
          :tab-count="tabItem"
          :trigger="trigger"
          @get-count="currentReadCount = $event"
        />
      </v-tab-item>
    </v-tabs>
  </div>
</v-card>
</template>

<script>

import UnreadTab from './UnreadTab.vue'
import ReadTab from './ReadTab.vue'
import { GET_USER_NOTIFICATION } from '@/modules/administration/users/services/api'

export default {
  components: {
    UnreadTab,
    ReadTab
  },
  data: () => ({
    trigger: 0,
    tabItem: 0,
    unreadCount: 0,
    readCount: 0,
    currentReadCount: '',
    search: null,
    headers: [
      {
        text: '',
        value: 'id',
        align: 'center',
        cellClass: 'first-column'
      },
      {
        text: '',
        value: 'message',
        cellClass: 'second-column'
      },
      {
        text: '',
        value: 'icon',
        cellClass: 'third-column'
      }
    ]
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.search) {
        paramsFilter.append('q', this.search)
      }
      return paramsFilter
    }
  },

  async mounted () {
    await this.getCurrentCount()
  },

  methods: {
    getCountRead () {
      this.getCurrentCount()
    },

    getCurrentCount () {
      const readNotification = new URLSearchParams()
      readNotification.append('is_read', 'true')

      GET_USER_NOTIFICATION(readNotification).then(resp => {
        this.currentReadCount = resp.count
        console.log('currentReadCount', this.currentReadCount)
      }).catch(e => {
        console.log('e', e)
        this.error = true
      }).finally(() => {
        this.loading = false
      })
    },

    getSpan (text, code, id) {
      return `<span
                class="active-link"
                style="cursor: pointer"
                data-link="${this.createDataAttr(code, id)}"
              >${text}</span>`
    },

    createDataAttr (code, id) {
      const _code = code.replace('obj:', '')
      const itemRoute = this.$router.getRoutes().find(route => route.meta.code === _code)
      if (!itemRoute) return ''
      return id ? `${itemRoute.path.replace(':id', id)}` : itemRoute.meta.parent
    },

    showDetail (e) {
      const evt = e.target.dataset.link
      this.$router.push({ path: evt })
      this.$emit('close-popup')
    },

    convertTemplate (msg) {
      const objRegex = /(obj:\w*)/g
      let count = 0
      return msg.descr.replace(objRegex, (match) => {
        const object = msg.resource_metadata.object[count]
        match = this.getSpan(object.object_name, object.object_code, object.object_id)
        count++
        return match
      })
    }

    /* onKeyDown (e) {
      if (e.code === 'Enter') {
        this.searchNotify()
      }
    } */
  }

  /* beforeMount () {
    document.addEventListener('keydown', this.onKeyDown)
  },

  activated () {
    document.removeEventListener('keydown', this.onKeyDown)
  } */
}
</script>

<style lang="scss">

.notify-tabs {
  // padding: 0 15px;
  .first-column {
    min-width: 64px;
    width: 64px;
  }
  .second-column {
    min-width: 90%;
    width: 80%;
  }
  .third-column {
    min-width: 80px;
    width: 80px;
  }
  .notification-item {
    span {
      color: var(--v-secondary-base)
    }
  }
  .v-tabs-bar {
    padding: 0 15px;
  }
  .v-tabs-slider-wrapper {
    height: 4px!important;
  }
  .v-tabs-slider {
    height: 4px;
  }
  .tab-badge {
    .v-badge__badge {
      color: #A7A8AB;
    }
  }
  .v-tab {
    align-items: flex-start;
    font-size: 16px;
    text-transform: capitalize;
    letter-spacing: normal;
    &.v-tab--active {
      color: #000026;
      .tab-badge {
        .v-badge__badge {
          color: #0061D9;
        }
      }
    }
  }
}

.no-data {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  p {
    text-align: center;
    flex-basis: 100%;
  }
}

.first-column, .second-column, .third-column {
  padding: 0 !important;
}
</style>
