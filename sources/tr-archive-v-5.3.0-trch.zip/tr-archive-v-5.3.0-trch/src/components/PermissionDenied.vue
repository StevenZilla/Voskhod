<template>
  <v-alert
    type="error"
    icon="mdi-alert"
    color="error"
  >Доступ запрещен</v-alert>
</template>
