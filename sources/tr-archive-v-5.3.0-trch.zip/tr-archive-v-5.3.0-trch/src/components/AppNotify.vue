<template>
  <v-card>
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    ><v-toolbar-title>{{ title }}</v-toolbar-title>
    </v-toolbar>

    <div class="popup-form">
      <div class="notification-block__content">
        <v-alert
          dense
          :type="type"
          :icon="icon"
          :color="type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'success' "
        >{{ text }}</v-alert>
      </div>
      <div class="d-flex justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          @click="$emit('close-popup')"
        >Понятно</v-btn>
      </div>
    </div>
  </v-card>
</template>

<script>

export default {
  name: 'AppNotify',
  props: ['title', 'text', 'type', 'icon']
}
</script>

<style>

</style>
