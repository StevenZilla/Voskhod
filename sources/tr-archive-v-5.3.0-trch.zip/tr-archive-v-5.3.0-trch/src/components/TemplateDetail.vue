<template>
  <div class="detail">
    <Breadcrumbs :close-icon="true"/>
    <LoadingComponentVue v-if="loading"/>
<!-- TODO поправить вывод ошибки-->
<!--    <v-alert v-if="!loading && error" icon="mdi-alert" type="error">Произошла ошибка при получении данных</v-alert>-->

    <div v-else class="detail__content">
      <slot name="content"></slot>
    </div>
  </div>
</template>

<script>

import Breadcrumbs from '@/components/Breadcrumbs.vue'

export default {
  components: { Breadcrumbs },
  props: {
    error: {
      type: Boolean
    },

    loading: {
      type: Boolean
    }
  },
  created () {
    this.changeDocumentOverflow('hidden')
  },
  beforeDestroy () {
    this.changeDocumentOverflow('')
  }
}
</script>

<style>

</style>
