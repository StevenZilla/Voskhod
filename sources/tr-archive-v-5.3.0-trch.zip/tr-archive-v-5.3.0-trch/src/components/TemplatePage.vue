<template>
  <div class="app-page">
    <Breadcrumbs/>

    <div class="d-flex justify-space-between">
      <h1 class="page-title"><slot name="title"></slot></h1>
      <slot name="title-additional"></slot>
    </div>

    <slot name="content"></slot>
  </div>
</template>

<script>

import Breadcrumbs from '@/components/Breadcrumbs.vue'

export default {
  components: { Breadcrumbs }
}
</script>

<style>

</style>
