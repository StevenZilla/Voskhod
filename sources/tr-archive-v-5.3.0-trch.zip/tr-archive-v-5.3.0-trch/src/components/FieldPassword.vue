<template>
  <LoadingComponentVue v-if="loading"/>

  <div v-else class="form-group">
    <p class="form-group__title">Пароль <span class="required-label">*</span></p>
    <v-alert
      dense
      type="info"
      icon="mdi-alert-circle"
      color="#E52E2E"
      class="alert-notification"
      v-if="errorData.password"
    >{{ errorData.password[0] }}
    </v-alert>
    <v-text-field
      data-qa="password-user-create"
      v-model="password"
      outlined
      clearable
      rounded
      required
      hide-details
      placeholder="Введите пароль для авторизации в системе"
      class="rounded-lg"
      @blur="$emit('set-password', password)"
    ></v-text-field>

    <div class="password-warning v-messages error--text">
      <span v-if="specialSymbols.value && !$v.password.haveSymbol">Пароль должен содержать минимум один специальный символ (!, $, %, &, ...)!</span>

      <span v-if="lowerCase.value && !$v.password.haveLowerCase">Пароль должен содержать минимум одну маленькую букву (a-z)!</span>

      <span v-if="upperCase.value && !$v.password.haveUpperCase">Пароль должен содержать минимум одну большую букву (A-Z)!</span>

      <span v-if="!$v.password.haveCyr">Пароль не должен содержать кириллицу!</span>

      <span v-if="numbers.value && !$v.password.haveNumber">Пароль должен содержать минимум одну цифру (0-9)!</span>

      <span v-if="password.length < characterCount.value">Минимальная длина пароля {{ characterCount.value }} символов!</span>
    </div>

    <v-btn
      data-qa="generate-password"
      class="mr-3 mt-3 mb-3 rounded-lg"
      outlined
      color="secondary"
      :loading="loadingPassword"
      @click="getTempPassword()"
    >Сгенерировать пароль
    </v-btn>
  </div>
</template>

<script>

import { required } from 'vuelidate/lib/validators'
import { GET_PASSWORD_REQUIREMENTS } from '@/services/app'
import { GET_TEMP_PASSWORD } from '@/modules/administration/users/services/api'

export default {
  props: {
    errorData: {
      type: Object,
      required: true
    }
  },

  validations: {
    password: {
      required,
      haveLowerCase (val) {
        if (this.lowerCase.value) {
          const regExp = /(?=.*[a-z])/g // проверка на маленькие буквы
          return regExp.test(val)
        }
        return true
      },
      haveUpperCase (val) {
        if (this.upperCase.value) {
          const regExp = /(?=.*[A-Z])/g // проверка на большие буквы
          return regExp.test(val)
        }
        return true
      },
      haveNumber (val) {
        if (this.numbers.value) {
          const regExp = /(?=.*[0-9])/g // проверка на цифры
          return regExp.test(val)
        }
        return true
      },
      haveSymbol (val) {
        if (this.specialSymbols.value) {
          val = val.replace(/[A-Za-zА-Яа-я0-9]+/gm, '') // убрать все разрешенные символы (проверка на наличие спецсимвола)
          if (val.length === 0) return false // значит не имеет сиволов
          else return true
        }
        return true
      },
      haveCyr (val) {
        const regExp = /(?=.*[А-Яа-я])/g // проверка на кириллицу (не должно быть)
        if (regExp.test(val)) return false
        else return true
      }
    }
  },

  data: () => ({
    loading: true,
    password: '',
    passwordRequirements: [],
    loadingPassword: false
  }),

  watch: {
    invalidPassword (newVal) {
      this.$emit('change-valid-password', newVal)
    }
  },

  computed: {
    numbers () {
      return this.passwordRequirements.find(param => param.code === 'numbers')
    },

    lowerCase () {
      return this.passwordRequirements.find(param => param.code === 'lower_case')
    },

    upperCase () {
      return this.passwordRequirements.find(param => param.code === 'upper_case')
    },

    specialSymbols () {
      return this.passwordRequirements.find(param => param.code === 'special_symbols')
    },

    characterCount () {
      return this.passwordRequirements.find(param => param.code === 'character_count')
    },

    invalidPassword () {
      return this.$v.$invalid || (this.password.length < this.characterCount.value)
    }
  },

  async created () {
    this.loading = true
    this.passwordRequirements = await GET_PASSWORD_REQUIREMENTS()
    this.loading = false
    await this.getTempPassword()
  },

  methods: {
    async getTempPassword () {
      this.loadingPassword = true
      try {
        this.password = await GET_TEMP_PASSWORD()
        this.$emit('set-password', this.password)
      } catch (error) {
        console.log(error)
      } finally {
        this.loadingPassword = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>

.password-warning {
  span {
    display: block;
  }
}
</style>
