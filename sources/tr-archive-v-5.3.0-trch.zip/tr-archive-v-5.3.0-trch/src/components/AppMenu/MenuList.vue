<template>
  <v-list dark class="primary py-0">
    <div v-for="(item, index) in items" :key="index">
      <v-list-group
        no-action
        class="main-menu__group"
        v-if="item.children && checkAvailableMenu(item.tech_name)"
      >
        <template v-slot:activator>
          <div class="group-title" :style="calcPaddingMenu(depth)">
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <div v-bind="attrs" v-on="on" class="link-item" role="link">
                  <v-list-item-icon class="main-menu__icon">
                    <v-icon dense>
                      {{ item.icon }}
                    </v-icon>
                  </v-list-item-icon>
                  <v-list-item-title v-on="on">
                    {{ item.name }}
                  </v-list-item-title>
                </div>
              </template>
              <span>{{ item.name }}</span>
            </v-tooltip>
          </div>
        </template>
        <MenuList :depth="depth + 1" :items="item.children"/>
      </v-list-group>

      <template v-else>
        <router-link
          v-if="checkAvailableMenu(item.tech_name)"
          custom
          v-slot="{ navigate }"
          :style="calcPaddingMenu(depth)"
          :to="item.path"
        >
          <v-list-item
            link
            class="main-menu__item main-menu__item-link"
            :class="{ 'secondary': item.path === currentRoute }"
            :ripple="false"
            @click="navigate"
          >
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <div v-bind="attrs" v-on="on" class="link-item" role="link">
                  <v-list-item-icon v-if="item.icon" class="main-menu__icon">
                    <v-icon dense>{{ item.icon }}</v-icon>
                  </v-list-item-icon>
                  <v-list-item-title>{{ item.name }}</v-list-item-title>
                </div>
              </template>
              <span v-if="drawer === false">{{ item.name }}</span>
            </v-tooltip>
          </v-list-item>
        </router-link>
      </template>
    </div>
  </v-list>
</template>

<script>
export default {
  name: 'MenuList',
  props: {
    items: {
      required: true
    },

    drawer: {
      type: Boolean
    },

    depth: {
      default: 1
    }
  },

  computed: {
    currentRoute () {
      return this.$route.path
    }
  },

  methods: {
    checkAvailableMenu (code) {
      if (!code) return true
      const res = code.split(':')
      return this.$can(res[1] ? res[1] : '', res[0])
    },

    calcPaddingMenu (depth) {
      const style = { paddingLeft: '20px' }
      this.$set(style, 'paddingLeft', depth * 20 + 'px')
      return style
    }
  }
}
</script>

<style lang="scss" scoped>
.v-list-item__title {
  word-wrap: break-word;
  overflow: visible;
  text-overflow: unset;
}
</style>
