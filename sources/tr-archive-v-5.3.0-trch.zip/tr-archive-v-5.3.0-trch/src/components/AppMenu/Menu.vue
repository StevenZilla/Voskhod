<template>
  <div class="main-menu primary menu-closed" :class="{ 'no-padding': !drawer }">
    <MenuList :items="mainNavigationList"/>

    <MenuList class="mt-8" :items="additionalNavigationList"/>

    <v-list-item
        class="main-menu__footer"
        :ripple="false"
    >
      <v-list-item-title class="mt-2">ТР-АРХИВ, {{ date }}</v-list-item-title>
      <div class="main-menu__divider mt-2"></div>
      <v-list-item-title class="mt-2">Версия {{ version }}</v-list-item-title>
      <div class="main-menu__alert">
        <v-alert
            v-if="isEsiaisAuthorized"
            class="mt-3"
            dense
            dismissible
            type="success"
        >
          Пользователь {{ userInfo.fio }} успешно авторизован
        </v-alert>
      </div>

    </v-list-item>
  </div>
</template>

<script>
import version from '../../../VERSION.txt'
import * as permissions from '@/permissions'
import MenuList from '@/components/AppMenu/MenuList.vue'
import { format } from 'date-fns'
import { mapState } from 'vuex'

export default {
  name: 'Menu',
  components: { MenuList },
  props: {
    drawer: {
      type: Boolean
    }
  },
  data: () => ({
    version,
    isActiveAdmin: false,
    mainNavigationList: [
      {
        name: 'Номенклатуры дел',
        tech_name: permissions.nomenclature.code,
        icon: 'mdi-view-list-outline',
        path: permissions.nomenclature.path
      },
      {
        name: 'Электронные документы',
        tech_name: permissions.ed.code,
        icon: 'mdi-note-edit-outline',
        path: permissions.ed.path
      },
      {
        name: 'Дела',
        tech_name: permissions.dossier.code,
        icon: 'mdi-folder-outline',
        path: permissions.dossier.path
      },
      {
        name: 'Описи',
        icon: 'mdi-file-document-outline',
        path: '',
        children: [
          {
            name: 'Сдаточные описи',
            icon: 'mdi-note-search-outline',
            path: 'permissions.acceptedProjects.path',
            children: [
              {
                name: 'Проекты',
                tech_name: permissions.acceptProjects.code,
                icon: 'mdi-note-check-outline',
                path: permissions.acceptProjects.path
              },
              {
                name: 'Утвержденные',
                tech_name: permissions.acceptRegisters.code,
                icon: 'mdi-note-check-outline',
                path: permissions.acceptRegisters.path
              }
            ]
          },
          {
            name: 'Сводные описи',
            icon: 'mdi-note-search-outline',
            path: 'permissions.project.path',
            children: [
              {
                name: 'Проекты',
                tech_name: permissions.project.code,
                icon: 'mdi-note-check-outline',
                path: permissions.project.path
              },
              {
                name: 'Утвержденные',
                tech_name: permissions.register.code,
                icon: 'mdi-note-check-outline',
                path: permissions.register.path
              }
            ]
          }
        ]
      },
      {
        name: 'Акты приема-передачи',
        tech_name: permissions.act.code,
        icon: 'mdi-note-check-outline',
        path: permissions.act.path
      },
      {
        name: 'Акты об уничтожении',
        icon: 'mdi-note-check-outline',
        path: '',
        children: [
          {
            name: 'Проекты',
            icon: 'mdi-note-check-outline',
            path: permissions.actDelete.path,
            tech_name: permissions.actDelete.code
          },
          {
            name: 'Утвержденные',
            icon: 'mdi-note-check-outline',
            path: permissions.approvedActsDelete.path,
            tech_name: permissions.approvedActsDelete.code
          }
        ]
      },
      {
        name: 'Транспортные контейнеры',
        tech_name: permissions.tk.code,
        icon: 'mdi-vector-polyline',
        path: permissions.tk.path
      },
      {
        name: 'Администрирование',
        icon: 'mdi-account-multiple-check-outline',
        path: '',
        tech_name: permissions.administration.code,
        children: [
          {
            name: 'Пользователи',
            path: permissions.users.path,
            icon: 'mdi-account-details'
            // tech_name: permissions.administration.code
          },
          {
            name: 'Журнал событий',
            path: permissions.events.path,
            icon: 'mdi-calendar-search'
            // tech_name: permissions.administration.code
          },
          {
            name: 'Системные роли',
            icon: 'mdi-drama-masks',
            path: permissions.systemRoles.path
            // tech_name: permissions.administration.code
          },
          {
            name: 'Обращения в ТП',
            icon: 'mdi-face-agent',
            path: permissions.supportMessage.path
            // tech_name: permissions.administration.code
          }
        ]
      },
      {
        name: 'НСИ',
        tech_name: permissions.nsi.code,
        icon: 'mdi-information-outline',
        path: permissions.nsi.path,
        children: [
          {
            name: 'Источники',
            icon: '',
            tech_name: permissions.sources.code,
            path: permissions.sources.path
          },
          {
            name: 'Архивы',
            icon: '',
            tech_name: permissions.archives.code,
            path: permissions.archives.path
          },
          {
            name: 'Фонды',
            icon: '',
            tech_name: permissions.funds.code,
            path: permissions.funds.path
          },
          {
            name: 'Участники согласований',
            icon: '',
            tech_name: permissions.participants.code,
            path: permissions.participants.path
          },
          {
            name: 'Скомпрометированные пароли',
            icon: '',
            tech_name: permissions.compromPasswords.code,
            path: permissions.compromPasswords.path
          },
          {
            name: 'Подразделения',
            icon: '',
            tech_name: permissions.subdivisions.code,
            path: permissions.subdivisions.path
          },
          {
            name: 'Реестр видов документов',
            icon: '',
            tech_name: permissions.classifiers.code,
            path: permissions.classifiers.path
          }
        ]
      }
    ],
    additionalNavigationList: [
      {
        name: 'Системные настройки',
        tech_name: permissions.settings.code,
        icon: 'mdi-cog-outline',
        path: permissions.settings.path
      }
    ]
  }),
  computed: {
    date () {
      return format(new Date(), 'yyyy')
    },
    ...mapState({
      userInfo: state => state.userInfo,
      isEsiaisAuthorized: state => state.isEsiaisAuthorized
    })
  }
}
</script>

<style lang="scss">
.children-icon {
  transition: all 0.8s;
}

.children-open {
  transform: rotate(90deg);
}

.main-menu {
  position: fixed;
  top: 64px;
  width: 64px;
  height: calc(100% - 64px);
  overflow-y: auto;
  overflow-x: hidden;
  transition: 0.3s;
  z-index: 5;

  .group-title {
    display: flex;
    flex-basis: 100%;
    transition: .3s;
  }

  &__divider {
    background-color: #A7A8AB;
    height: 1px;
    width: 100%;

    visibility: hidden;
    opacity: 0;
    transition: .3s;
  }

  &__alert{
    visibility: hidden;
    opacity: 0;
    transition: .3s;
  }

  &.no-padding {
    .group-title,
    .main-menu__item {
      padding-left: 20px!important;
    }
  }

  &__group {
    .v-list-item {
      padding: 4px 10px 4px 0;
    }
  }

  .v-list-group__header__append-icon {
    min-width: 24px!important;
  }

  &.active {
    width: 280px;

    .v-list-item__title {
      visibility: visible;
      opacity: 1;
    }

    .main-menu__alert{
      visibility: visible;
      opacity: 1;
    }

    & .main-menu__divider {
      visibility: visible;
      opacity: 1;
    }
  }

  .v-list-item__title {
    visibility: hidden;
    opacity: 0;
    transition: .3s;
  }

  .v-list-group__header {
    .v-list-group__header__append-icon .v-icon {
      transform: rotate(-90deg);
      transition: .3s;
    }
    &.v-list-item--active {
      & > .v-list-group__header__append-icon .v-icon {
        transform: rotate(0deg);
      }
    }
  }

  .link-item {
    display: flex;
    flex-basis: 100%;
  }

  &__icon {
    margin-right: 10px !important;
  }

  .v-list-item--active {
    color: #FFF !important;
  }

  &__item {
    transition: .3s;
    padding: 4px 10px 4px 22px;
  }

  &__footer {
    display: block;
    flex-direction: column;
    color: #A7A8AB !important;
  }

  .theme--dark.v-list-item--active::before {
    opacity: 0;
  }
}
</style>
