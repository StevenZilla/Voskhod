<template>
  <div class="breadcrumbs">
    <div class="d-flex align-center">
      <v-icon @click="goToPrevRouter">mdi-arrow-left</v-icon>
      <v-breadcrumbs :items="breadcrumbs" class="pl-8" divider="/"/>
    </div>
    <v-btn v-if="closeIcon" icon dark @click="close">
      <v-icon color="element">mdi-close</v-icon>
    </v-btn>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  props: {
    closeIcon: {
      type: Boolean,
      required: false
    },

    closeDialog: {
      type: Boolean,
      required: false
    }
  },

  computed: {
    ...mapState({
      breadcrumbs: state => state.breadcrumbs
    })
  },

  methods: {
    close () {
      if (this.closeDialog) this.$emit('close')
      else this.goToPrevRouter()
    },

    goToPrevRouter () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss">
.breadcrumbs {
  display: flex;
  align-items: center;
  justify-content: space-between;
  .v-breadcrumbs__item {
    color: #76767A !important;
  }
}
</style>
