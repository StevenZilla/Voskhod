<template>
  <v-dialog
    v-model="dialog"
    persistent
    max-width="500"
    content-class="dialog-auto-height"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        data-qa="save"
        v-bind="attrs"
        v-on="on"
        class="mr-3 rounded-lg"
        color="secondary"
        :loading="loading"
        :disabled="disabled"
      >{{ text }}</v-btn>
    </template>

    <v-card>
      <v-card-title>Вы уверены, что хотите сохранить изменения?</v-card-title>
      <v-card-actions class="justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          outlined
          @click="dialog = false"
        >Нет</v-btn>
        <v-btn
          data-qa="accept-save"
          class="rounded-lg"
          color="secondary"
          @click="confirm"
        >Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>

export default {
  props: {
    text: {
      type: String,
      default: 'Сохранить изменения'
    },
    loading: {
      type: Boolean,
      required: false
    },
    disabled: {
      type: Boolean,
      required: false
    }
  },

  data: () => ({
    dialog: false
  }),

  methods: {
    confirm () {
      this.dialog = false
      this.$emit('save')
    }
  }
}
</script>

<style>
</style>
