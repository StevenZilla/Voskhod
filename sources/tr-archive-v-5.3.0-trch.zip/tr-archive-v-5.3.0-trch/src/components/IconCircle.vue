<template>
  <span class="icon-circle" :style="{ 'background-color': color }" ></span>
</template>
<script>
export default {
  name: 'icon-circle',
  props: ['color']
}
</script>
<style>
.icon-circle {
  display: inline-block;
  height: 9px;
  width: 9px;
  border-radius: 50%;
  margin-right: 8px;
  margin-bottom: 1px;
}
</style>
