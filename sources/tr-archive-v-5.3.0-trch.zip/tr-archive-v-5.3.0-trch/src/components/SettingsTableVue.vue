<template>
  <div class="settings-inner" v-click-outside-custom="closeSettings">
    <v-btn
      icon
      outlined
      :ripple="false"
      color="secondary"
      class="rounded-xl bg-white"
      @click="isShowSettingsTable = !isShowSettingsTable"
    >
      <v-icon
        large
      >mdi-cog-outline
      </v-icon>
    </v-btn>
    <div class="settings-list" v-if="isShowSettingsTable">
      <div
        class="settings-list__item"
        @click="toggleAllColumnMix(code, headersSettingsOutside, headersList), getHeaders()"
      >
        <v-icon v-if="isAllShow">mdi-check</v-icon>
        <span>Все</span>
      </div>
      <div
        class="settings-list__item"
        v-for="(col, index) in headersList"
        :key="index"
        @click="toggleColumnMix(code, col.value), getHeaders()"
        v-show="!headersSettingsOutside.includes(col.value)"
      >
        <v-icon v-if="isShowColumnMix(headers, col.value)">mdi-check</v-icon>
        <span>{{ col.text }}</span>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  props: ['code', 'headersSettingsOutside', 'headersList', 'headers'],

  data: () => ({
    headersVue: [],
    isShowSettingsTable: false
  }),

  computed: {
    isAllShow () {
      return this.headers.length === this.headersList.length
    }
  },

  methods: {
    closeSettings (e) {
      // console.log('e', e)
      this.isShowSettingsTable = false
    },

    getHeaders () {
      const namePage = this.getColumnsInTableMix(this.code) // коды скрытых колонок
      this.headersVue = [...this.headersList]
      this.$emit('updateHeaders', this.headersVue)
      namePage.forEach(colValue => {
        const columnIndex = this.headersVue.findIndex(column => {
          return colValue === column.value
        })
        if (columnIndex !== -1) {
          this.$delete(this.headersVue, columnIndex)
          this.$emit('updateHeaders', this.headersVue)
        }
      })
    }
  },

  mounted () {
    this.getHeaders()
  }
}
</script>

<style lang="scss">

.settings-inner {
  position: relative;
}

.settings-list {
  position: absolute;
  right: 0;
  top: 60px;
  padding: 10px 0;
  box-shadow: 0px 0px 4px rgba(0, 0, 0, 0.25);
  background-color: #fff;
  width: 290px;
  border-radius: 8px;
  font-size: 18px;
  z-index: 2;

  &__item {
    position: relative;
    padding-left: 40px;
    padding-right: 10px;
    margin-bottom: 10px;
    cursor: pointer;
    transition: .3s;

    &:last-child {
      margin-bottom: 0;
    }

    &:hover {
      color: var(--v-secondary-base) !important
    }
  }

  .v-icon {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #000;
  }
}
</style>
