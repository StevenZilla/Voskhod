<template>
  <div class="detail">
    <div class="detail__content">
      <Breadcrumbs
        :close-icon="true"
        :close-dialog="true"
        @close="$emit('close')"
      />

      <slot name="content"></slot>
    </div>

    <TemplateButtons>
      <template #buttons-left>
        <BtnSaveSlot
          :loading="loading"
          :disabled="disabled"
          @save="$emit('save')"
        />
      </template>

      <template #buttons-right>
        <BtnCancelSlot
          @close="$emit('close')"
        />
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import Breadcrumbs from '@/components/Breadcrumbs.vue'

export default {
  components: { Breadcrumbs },
  props: {
    loading: {
      type: Boolean
    },

    disabled: {
      type: Boolean
    }
  },
  created () {
    this.changeDocumentOverflow('hidden')
  },
  beforeDestroy () {
    this.changeDocumentOverflow('')
  }
}
</script>

<style>

</style>
