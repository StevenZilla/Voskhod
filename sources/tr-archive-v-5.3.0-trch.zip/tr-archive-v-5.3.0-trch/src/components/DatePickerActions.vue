<template>
  <div style="margin-left: auto">
    <v-btn
      color="secondary"
      class="rounded-lg mr-4"
      outlined
      @click="$emit('cancel')"
    >Сбросить
    </v-btn>
    <v-btn
      color="secondary"
      class="rounded-lg"
      :disabled="disabled"
      @click="$emit('apply')"
    >Применить
    </v-btn>
  </div>
</template>

<script>
export default {
  props: {
    disabled: {
      type: Boolean,
      required: false
    }
  }
}
</script>

<style lang="scss">

</style>
