<template>
  <v-dialog
    v-model="dialog"
    persistent
    max-width="500"
    content-class="dialog-auto-height"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        v-bind="attrs"
        v-on="on"
        class="rounded-lg"
        :icon="icon"
        :color="icon ? '' : 'secondary'"
        :outlined="!icon"
      >
        <v-icon v-if="icon" color="element">mdi-close</v-icon>
        <span v-else>{{ text }}</span>
      </v-btn>
    </template>

    <ConfirmCancel
      @cancel="dialog = false"
      @confirm="confirm"
    />
  </v-dialog>
</template>
<script>

import ConfirmCancel from '@/components/ConfirmCancel.vue'

export default {
  components: { ConfirmCancel },
  props: {
    icon: {
      type: Boolean,
      default: false
    },
    text: {
      type: String,
      default: 'Закрыть'
    }
  },

  data: () => ({
    dialog: false
  }),

  methods: {
    confirm () {
      this.dialog = false
      this.$emit('close')
    }
  }
}
</script>

<style>
</style>
