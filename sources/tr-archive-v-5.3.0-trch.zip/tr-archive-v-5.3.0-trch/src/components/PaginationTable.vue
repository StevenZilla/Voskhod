<template>
  <div class="table-footer">
    <div class="table-footer__left">
      <span>Выведено {{ pagination.pageStop }} из {{ pagination.itemsLength }} записей.</span>
    </div>

    <div class="table-footer__right" v-if="page">
      <div class="pagination">
        <v-btn
          class="pagination__btn"
          color="secondary"
          outlined
          :disabled="isFirstPage"
          @click="onClickFirstPage()"
        >
          <v-icon class="rounded-lg" color="secondary">
            mdi-chevron-double-left
          </v-icon>
        </v-btn>

        <v-pagination
          v-if="!hidePage"
          v-model="localPage"
          color="secondary"
          total-visible="7"
          :length="pagination.pageCount"
        ></v-pagination>

        <v-btn
          class="pagination__btn"
          color="secondary"
          outlined
          :disabled="isLastPage"
          @click="onClickLastPage()"
        >
          <v-icon class="rounded-lg" color="secondary">
            mdi-chevron-double-right
          </v-icon>
        </v-btn>
      </div>
    </div>
  </div>
  <!-- </div> -->
</template>

<script>
export default {
  name: 'PaginationTable',
  props: {
    page: {
      type: Number
    },

    pagination: {
      type: Object
    },

    hidePage: {
      type: Boolean
    }
  },

  computed: {
    localPage: {
      get () {
        return this.page
      },
      set (localPage) {
        this.$emit('update:page', localPage)
      }
    },

    isFirstPage () {
      return this.page === 1
    },

    isLastPage () {
      return this.page === this.pagination.pageCount
    }
  },

  methods: {
    onClickFirstPage () {
      this.localPage = 1
    },

    onClickLastPage () {
      this.localPage = this.pagination.pageCount
    }
  }
}
</script>

<style lang="scss">

// .theme--light.v-pagination .v-pagination__item {
//   color: #0050B2;
// }

.v-pagination {
  li {
    min-width: max-content;
    display: flex !important;
    align-items: center;
    height: 44px;
    width: 44px;
  }

  & &__item {
    width: 100%;
    height: 100%;
    border: 1px solid #B5C9E5;
    border-radius: 0;
    margin: 0;
    //color: #0050B2;
    box-shadow: none;
    &--active {
      color: #FFFFFF;
    }
  }

  & &__navigation {
    width: 100%;
    height: 100%;
    border: 1px solid #B5C9E5;
    border-radius: 0;
    margin: 0;
    box-shadow: none;

    .v-icon {
      color: #0050B2;
    }
  }
}

.pagination {
  display: flex;
  align-items: baseline;

  .pagination__btn {
    height: 44px !important;
    width: 44px !important;
    min-width: 44px !important;
    border: 1px solid #B5C9E5;
    border-radius: 0;
    margin: 0;
    box-shadow: none;
  }
}
</style>
