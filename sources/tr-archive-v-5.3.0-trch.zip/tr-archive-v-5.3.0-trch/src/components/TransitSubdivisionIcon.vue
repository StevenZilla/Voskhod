<template>
  <v-tooltip top>
    <template v-slot:activator="{ on }">
      <span class="" v-on="on">
       <span class="wrap">
        <span class="subdivision-icon">i</span>
      </span>
      </span>
    </template>
    <p>Перешло от:</p>
    <div v-for="subdivision in subdivisions" :key="subdivision.code" class="d-flex justify-space-between align-center">
      <p class="marker">&uarr;</p>
      <p>{{ subdivision }}</p>
    </div>
  </v-tooltip>
</template>
<script>
export default {
  name: 'TransitSubdivisionIcon',
  props: ['transitInfo'],
  computed: {
    subdivisions () {
      return this.transitInfo.subdivisions.map(el => `${el.code} ${el.name} (год ликвидации: ${el.delete_year})`)
    }
  }
}
</script>

<style scoped lang="scss">
  .wrap {
    position: relative;
  }
  .subdivision-icon {
    width: 30px;
    height: 30px;
    display: inline-block;
    border: 1px solid #43a1f4;
    border-radius: 50%;
    font-size: 1.8rem;
    padding-left: 10px;
    padding-top: 3px;
    color: #43a1f4;
    position: absolute;
    top: -4px;
    left: 8px;
    cursor: alias;
  }
  .marker {
    margin-top: -2px;
    margin-right: 5px;
  }
</style>
