<template>
  <v-dialog
    v-model="dialog"
    persistent
    max-width="500"
    content-class="dialog-auto-height"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        v-bind="attrs"
        v-on="on"
        class="circle circle__btn circle--white"
        icon
        :disabled="loading"
        @click="$emit('cancel')"
      ><v-icon color="secondary">mdi-close</v-icon>
      </v-btn>
    </template>

    <v-card>
      <v-card-title>Вы уверены, что хотите выйти без сохранения изменений?</v-card-title>
      <v-card-actions class="justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          outlined
          @click="dialog = false"
        >Нет</v-btn>
        <v-btn
          class="rounded-lg"
          color="secondary"
          @click="confirm"
        >Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>

export default {
  props: {
    loading: {
      type: Boolean,
      required: false
    }
  },

  data: () => ({
    dialog: false
  }),

  methods: {
    confirm () {
      this.dialog = false
      this.$emit('close')
    }
  }
}
</script>

<style>
</style>
