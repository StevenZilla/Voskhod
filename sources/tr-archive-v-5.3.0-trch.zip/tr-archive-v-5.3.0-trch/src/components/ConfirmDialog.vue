<template>
  <v-card>
    <v-card-title class="d-block mb-0">
      {{ text }}
    </v-card-title>

    <v-card-actions class="justify-end">
      <v-btn
        class="rounded-lg"
        color="secondary"
        outlined
        @click="$emit('cancel')"
      >Нет
      </v-btn>
      <v-btn
        class="rounded-lg"
        color="secondary"
        @click="$emit('confirm')"
      >Да
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>

export default {
  props: {
    text: {
      type: String
    }
  }
}
</script>

<style>
</style>
