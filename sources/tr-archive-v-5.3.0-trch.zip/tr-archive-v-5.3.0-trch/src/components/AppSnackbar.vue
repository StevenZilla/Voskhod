<template>
  <div>
    <v-snackbar
      v-for="(error, idx) in errorList"
      v-model="error.show"
      color="error"
      :key="idx"
      :bottom="true"
      :style="{'margin-bottom': calcMargin(idx)}"
      @input="removeError(idx)"
    >
      {{ error.name }}<span v-if="error.url">: {{ error.url }}</span>

      <template v-slot:action>
        <v-icon
          color="white"
          @click="removeError(idx)"
        >mdi-close
        </v-icon>
      </template>
    </v-snackbar>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  computed: {
    ...mapState({
      errorList: state => state.errorList
    })
  },

  methods: {
    calcMargin (i) {
      return (i * 60) + 'px'
    },

    removeError (i) {
      this.$store.dispatch('REMOVE_ITEM', i)
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
