<template>
  <v-app class="app">
    <AppSnackbar/>
    <AppLoader v-if="loadingApp"/>

    <div class="main-container" v-else>
      <transition
        name="slide"
        @before-enter="beforeEnter"
        @enter="enter"
        @leave="leave"
        @before-leave="beforeLeave"
      >
        <LoginPage v-if="!isAuthorized"/>

        <Main v-else/>
      </transition>
    </div>
  </v-app>
</template>

<script>

import { mapState } from 'vuex'
import {
  CHECK_AUTH,
  LOGIN_AUTH_USER
} from '@/services/app'

import LoginPage from '@/modules/login/views/LoginPage.vue'
import AppSnackbar from '@/components/AppSnackbar.vue'
import Main from '@/components/Main.vue'
import AppLoader from '@/components/AppLoader.vue'
import Velocity from 'velocity-animate'

export default {
  name: 'App',

  components: {
    LoginPage,
    AppLoader,
    AppSnackbar,
    Main
  },

  data: () => ({
    loadingApp: true,
    slideDirection: null,
    currentComponent: 'LoginPage'
  }),

  computed: {
    ...mapState({
      isAuthenticated: state => state.isAuthenticated,
      isAuthorized: state => state.isAuthorized,
      // isEsiaAuthorization: state => state.isEsiaAuthorization,
      isEsiaisAuthorized: state => state.isEsiaisAuthorized
    })
  },

  watch: {
    isAuthorized (newV) {
      if (newV) {
        this.slideDirection = 'left'
      } else this.slideDirection = 'right'
    },
    isAuthenticated (newV) {
      if (!newV) this.$router.push('/login')
    },

    async $route (to) {
      if (to.path !== '/login' && to.path !== '/') { // Нужно для записи пути страниц в локальное хранилище
        const saveUrlObj = {
          code: to.meta.tech_name ? to.meta.tech_name : '',
          path: to.path
        }
        localStorage.setItem('pathObj', JSON.stringify(saveUrlObj))
      }
    }
  },

  async created () {
    this.loadingApp = true
    try {
      await CHECK_AUTH()
      if (this.isAuthenticated) {
        await LOGIN_AUTH_USER()
      }
      // GET_TK_STATUSES_LIST()
    } catch (error) {
      console.log(error)
    } finally {
      this.loadingApp = false
    }
  },

  mounted () {
    if (localStorage.getItem('columnTables') === null) {
      localStorage.setItem('columnTables', JSON.stringify({}))
    }
  },

  methods: {
    beforeEnter (el) {
      el.style.transform = this.slideDirection === 'right' ? 'translateX(-100%)' : 'translateX(100%)'
      // el.style.transform = 'translateX(100%)'
      el.style.opacity = 0
    },
    enter (el, done) {
      Velocity(el, { translateX: '0%', opacity: 1 }, { duration: 200, complete: done })
    },
    leave (el, done) {
      Velocity(el, { translateX: this.slideDirection === 'right' ? '100%' : '-100%', opacity: 0 }, {
        // Velocity(el, { translateX: '-100%', opacity: 0 }, {
        duration: 200,
        complete: () => {
          done()
          Velocity(el, { translateX: '0%', opacity: 1 }, { duration: 0 })
        }
      })
    },
    beforeLeave (el) {
      this.slideDirection = this.isAuthorized ? 'right' : 'left'
    }
  }
}
</script>

<style lang="scss">

.main-container {
  position: relative;
  width: 100%;
  height: 100%;
}

.slide-enter-active,
.slide-leave-active {
  transition: transform 0.5s ease-in-out;
}

.slide-enter,
.slide-leave-to {
  transform: translateX(100%);
}

.loader-page {
  position: absolute;
  top: 64px;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(255, 255, 255, .7);
  z-index: 99;
}
</style>
