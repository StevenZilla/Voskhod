export const archiveEvent = {
  code: 'archive'
}

export const actDeleteEvent = {
  code: 'delete_act'
}

export const passwordEvent = {
  code: 'comprom_password'
}

export const dossierEvent = {
  code: 'dossier'
}

export const eadEvent = {
  code: 'ead'
}

export const fundEvent = {
  code: 'fund'
}

export const nomenclatureEvent = {
  code: 'nomenclature'
}

export const subdivisionEvent = {
  code: 'subdivisions'
}

export const participantEvent = {
  code: 'participant'
}

export const projectRegister = {
  code: 'project_register'
}

export const approvedRegister = {
  code: 'approved_register'
}

export const sourceEvent = {
  code: 'source'
}
export const systemParamEvent = {
  code: 'system_param'
}

export const roleEvent = {
  code: 'role'
}

export const uploadEvent = {
  code: 'upload'
}
export const userEvent = {
  code: 'user'
}
