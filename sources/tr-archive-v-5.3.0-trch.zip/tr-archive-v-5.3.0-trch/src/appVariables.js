export const support = {
  email: 'eadsc_support@voskhod.ru'
}
