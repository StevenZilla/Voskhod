<template>
  <div class="v-window__container">
    <v-treeview
      class="structure__table-tree fixed-root"
      return-object
      expand-icon=""
      transition
      activatable
      :active-class="''"
      :items="nomenclaturesDossiers"
      :open="openNodes"
      :item-key="'id'"
    >
    <template slot="label" slot-scope="nodeItem">
        <p v-if="nodeItem.item.id !== -1"
          class="structure__table-name mb-0">
          {{ nodeItem.item.num ? `${nodeItem.item.num} ${nodeItem.item.name}` : nodeItem.item.name }}
        </p>

        <v-data-table
        v-if="nodeItem.item.id !== -1"
          item-key="id"
          hide-default-footer
          disable-pagination
          disable-sort
          no-data-text="Нет данных"
          class="scroll-table no-hover"
          :headers="headers"
          :items="nodeItem.item.dossiers"
          :item-class="getNodeClass"
        >
          <template v-slot:item.index="{ item, index }">
            <div class="form-group" :class="{'error-field': item.error}">
              <div class="d-flex">
                <div class="d-flex align-center">
                  <icon-circle :color="item.status && item.status.code === 'closed' ? '#e52e2e' : '#00a65a'"/>
                </div>
                <v-text-field
                    v-if="enableEditingDossier(item) && !nodeItem.item.is_copy"
                    class="rounded-lg"
                    outlined
                    return-object
                    hide-details
                    placeholder="Введите индекс"
                    :value="item.index"
                    @change="changeValueDossier(nodeItem.item, index, 'index', $event)"
                ></v-text-field>

                <p v-else>{{ item.index }}</p>
              </div>

              <!-- Вывод ошибки -->
              <span class="error--text" v-if="item.error && item.error.index">{{ item.error.index }}</span>
            </div>
          </template>

          <template v-slot:item.name="{ item, index }">
            <div class="form-group">
              <v-text-field
                v-if="enableEditingDossier(item) && !nodeItem.item.is_copy"
                class="rounded-lg"
                no-resize
                outlined
                rows="2"
                auto-grow
                hide-details
                clearable
                placeholder="Введите заголовок"
                :value="item.name"
                @change="changeValueDossier(nodeItem.item, index, 'name', $event)"
              ></v-text-field>

              <p v-else>{{ item.name }}</p>

              <span class="error--text" v-if="item.error && item.error.name">{{ item.error.name }}</span>
            </div>
          </template>

          <template v-slot:item.di_kinds="{ item, index }">
            <div class="form-group">
              <v-autocomplete
                v-if="enableEditingDossier(item) && !nodeItem.item.is_copy"
                data-qa="dossier-save-type"
                return-object
                multiple
                class="rounded-lg"
                outlined
                hide-details
                item-value="id"
                item-text="num_show"
                placeholder="Выберите статью"
                loader-height="5"
                color="secondary"
                :value="item.di_kinds"
                :loading="loadingKinds"
                :items="getClassifiersKinds(item)"
                :no-data-text="'Нет результатов'"
                @change="changeValueDossier(nodeItem.item, index, 'di_kinds', $event)"
              ></v-autocomplete>

              <p v-else v-for="elem in item.di_kinds" :key="elem.id">
                {{ elem.num_show }}
              </p>
            </div>
          </template>

          <template v-slot:item.save_type="{ item }">
            <span class="accent-item" v-if="item.di_kinds">
              {{ item.di_kinds.length ? item.di_kinds[0].save_info : 'Нет данных' }}
            </span>
            <span class="accent-item" v-else>
              {{ item.di_kind.length ? item.di_kind[0].save_info : 'Нет данных' }}
            </span>
          </template>

          <template v-slot:item.media_type="{ item }">
            <div class="form-group">
              <v-text-field
                data-qa="dossier-media-type"
                class="rounded-lg"
                outlined
                hide-details
                disabled
                filled
                :value="item.media_type ? item.media_type.value : 'Нет данных'"
              ></v-text-field>
            </div>
          </template>

          <template v-slot:item.actions="{ index, item }">
            <v-btn
              v-if="enableEditingDossier(item, nodeItem.item)"
              color="secondary"
              class="rounded-lg"
              icon
              @click.stop="deleteDossier(nodeItem.item, index, item)"
            >
              <v-icon>mdi-delete-outline</v-icon>
            </v-btn>
          </template>
        </v-data-table>

        <div v-if="nodeItem.item.id !== -1" class="mt-4 mb-4">
          <v-btn
            outlined
            color="secondary"
            class="rounded-lg mr-3"
            @click="createDossier(nodeItem.item)"
          >
            <v-icon class="mr-1">mdi-pencil-outline</v-icon>
            Создать дело
          </v-btn>
          <v-btn
            outlined
            color="secondary"
            class="rounded-lg"
            @click="openDialogAdd(nodeItem.item)"
          >
            <v-icon class="mr-2">mdi-folder-outline</v-icon>
            Добавить дело
          </v-btn>
        </div>
      </template>
    </v-treeview>

    <v-dialog
      v-model="isOpenDialog"
      max-width="1335px"
      content-class="dossier-popup"
      @click:outside="isOpenDialog = false"
    >
      <AddDossier
        :is-open="isOpenDialog"
        :exclude-dossier-ids="excludeDossierIds"
        @close-popup="isOpenDialog = false"
        @select-dossier="addSelectedDoss"
      />
    </v-dialog>
  </div>
</template>

<script>

import { GET_CLASSIFIER_KINDS } from '@/services/app'
import { mapActions } from 'vuex'
import IconCircle from '@/components/IconCircle.vue'
// import { required } from 'vuelidate/lib/validators'

const AddDossier = () => import('./add-dossier/AddDossier.vue')

export default {
  name: 'EditingDossiers',
  components: {
    IconCircle,
    AddDossier
  },

  props: {
    openNodes: {
      type: Array
    }
  },

  validations: {
    fullFlatTree: {
      fillDoss (val) {
        return val.every((node) => {
          if (node.id === -1) return true

          // Если нет дела, считаем, что валидация пройдена
          if (node.dossiers && node.dossiers.length === 0) return true

          // Если дело есть, нужно проверить свойства 'name' и 'index'
          const invalidDoss = node.dossiers.find((doss) => {
            console.log('doss', doss)
            return !doss.name || !doss.index
            //         //  || doss.di_kinds.length === 0
          })

          if (invalidDoss) return false

          return true
        })
      }
    }
  },

  data: () => ({
    isOpenDialog: false,
    pk: 0,
    classifiersKinds: [],
    loadingKinds: true,
    excludeDossierIds: [],
    selectedNodeId: null,
    headers: [
      {
        text: 'Индекс дела',
        value: 'index',
        width: '140px'
      },
      {
        text: 'Заголовок дела',
        value: 'name',
        width: '450px'
      },
      {
        text: 'Статья хранения',
        value: 'di_kinds',
        width: '200px'
      },
      {
        text: 'Срок хранения',
        value: 'save_type',
        width: '160px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type',
        align: 'center',
        width: '165px'
      },
      {
        text: '',
        value: 'actions',
        align: 'center',
        width: '64px'
      }
    ]
  }),

  computed: {
    nomenclaturesDossiers () {
      return this.$store.getters['nomenclatures/GET_INFO_TABLE']
    },

    fullFlatTree () {
      const viewFlatTree = []
      this.$_createFlatTree(this.nomenclaturesDossiers[0], viewFlatTree)
      viewFlatTree.shift() // убираем корень, так как он не очень то и валидный
      return viewFlatTree
    },

    invalidData () {
      return this.$v.$invalid
    }
  },

  watch: {
    invalidData: {
      handler (newVal) {
        this.$emit('change-valid', newVal)
      },
      immediate: true
    }
  },

  created () {
    this.$eventBus.$on('deleted-node', () => {
      this.excludeDossierIds = []
      this.addExcludeIds(this.nomenclaturesDossiers[0])
    })
  },

  beforeDestroy () {
    if (this.modeNomenclature !== 'view') {
      this.$eventBus.$off('deleted-node')
    }
  },

  async mounted () {
    this.classifiersKinds = await GET_CLASSIFIER_KINDS()
    this.loadingKinds = false
    this.addExcludeIds(this.nomenclaturesDossiers[0])
  },

  methods: {
    ...mapActions('nomenclatures', ['ADD_DOSSIER_IN_NODE', 'CHANGE_DOSSIER', 'REMOVE_DOSSIER']),

    addExcludeIds (node) {
      if (node.dossiers) {
        node.dossiers.forEach(dossier => {
          this.excludeDossierIds.push(dossier.id)
        })
      }

      node.children.forEach(child => {
        this.addExcludeIds(child)
      })
    },

    filterClassifierKinds (node, index, selectKinds) {
      const dossier = node.dossiers[index]
      if (selectKinds.length > 1 && dossier.classifiersKindsList) return
      // this.loadingKinds = true
      let filterParams = new URLSearchParams()
      // Точная фильтраця при выборе статьи по сроку хранения
      if (selectKinds.length === 1) filterParams.append('save_info', `${dossier.di_kinds[0].save_info}`)
      if (selectKinds.length === 0) filterParams = new URLSearchParams()
      GET_CLASSIFIER_KINDS(filterParams).then(resp => {
        this.CHANGE_DOSSIER({ nodeId: node.id, index, key: 'classifiersKindsList', value: resp })
      }).finally(() => {
        // this.loadingKinds = false
      })
    },

    getClassifiersKinds (item) {
      if (!item.classifiersKindsList) return this.classifiersKinds
      else return item.classifiersKindsList
    },

    enableEditingDossier (item) {
      // item.id < 0 проверка на то, что дело только что созданное
      return (item.status && item.status.code !== 'closed') || item.id < 0
    },

    getNodeClass (item) {
      if (item.status && item.status.code === 'closed') {
        return 'grey grey-text'
      }
    },

    createDossier (node) {
      console.log('node', node)
      // node.is_copy = false
      this.pk--

      const dossier = {
        id: this.pk,
        index: null,
        name: null,
        media_type: null,
        di_kinds: [],
        classifiersKindsList: [...this.classifiersKinds]
      }

      this.ADD_DOSSIER_IN_NODE({ dossierList: [dossier], selectedNodeId: node.id })
      // this.$set(node.dossiers, node.dossiers.length, dossier)
    },

    changeValueDossier (node, index, key, value) {
      this.CHANGE_DOSSIER({ nodeId: node.id, index, key, value })
      if (key === 'di_kinds') this.filterClassifierKinds(node, index, value)
    },

    addSelectedDoss (dossierList) {
      this.excludeDossierIds = [...this.excludeDossierIds, ...dossierList.map(dossier => dossier.id)]
      this.ADD_DOSSIER_IN_NODE({ dossierList, selectedNodeId: this.selectedNodeId })
      this.selectedNodeId = null
      // dossiers.forEach(doss => {
      //   if (typeof doss === 'number') return
      //   this.exclude_ids.push(doss.id)
      //   this.currentNode.is_copy = true
      //   this.currentNode.dossiers.push(doss)
      // })
    },

    deleteDossier (node, ind, dossier) {
      const dossierIndex = this.excludeDossierIds.findIndex(id => id === dossier.id)
      this.excludeDossierIds.splice(dossierIndex, 1)
      this.REMOVE_DOSSIER({ nodeId: node.id, indexDelete: ind })
    },

    openDialogAdd (node) {
      this.selectedNodeId = node.id
      this.isOpenDialog = true
    }
  }
}
</script>

<style lang="scss">

</style>
