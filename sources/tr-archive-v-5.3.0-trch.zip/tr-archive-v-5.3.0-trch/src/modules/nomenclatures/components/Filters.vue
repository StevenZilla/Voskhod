<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <Year
        class="w-22"
        ref="regDate"
        :multiple="false"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <NomStatus
        class="w-22"
        ref="nomStatus"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <TkStatus
        class="w-22"
        ref="tkStatus"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <ResendTk
        class="w-20"
        ref="resendTk"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import Year from '@/components/Filters/Fields/Year.vue'
import NomStatus from '@/components/Filters/Fields/Nomenclature/NomenclatureStatus.vue'
import TkStatus from '@/components/Filters/Fields/TkStatus.vue'
import ResendTk from '@/components/Filters/Fields/ResendTk.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'

export default {
  name: 'Filters',

  components: {
    FiltersTemplate,
    ChipsFilters,
    Year,
    NomStatus,
    TkStatus,
    ResendTk,
    FilterFooter
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []
      if (this.filterObj.regDate) {
        paramsFilter.append('year', this.filterObj.regDate.query)
        // paramsFilter.append('end_year', this.filterObj.regDate.query[1])
        chips.push(this.filterObj.regDate)
      }
      if (this.filterObj.nomStatus) {
        paramsFilter.append('nom_status_id', this.filterObj.nomStatus.query.value)
        chips.push(this.filterObj.nomStatus)
      }
      if (this.filterObj.tkStatus) {
        paramsFilter.append('tk_status_id', this.filterObj.tkStatus.query.value)
        chips.push(this.filterObj.tkStatus)
      }
      if (this.filterObj.resendTk) {
        paramsFilter.append('resend_tk', this.filterObj.resendTk.query.value)
        chips.push(this.filterObj.resendTk)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.resetFilter = false
        this.searchTouch = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
