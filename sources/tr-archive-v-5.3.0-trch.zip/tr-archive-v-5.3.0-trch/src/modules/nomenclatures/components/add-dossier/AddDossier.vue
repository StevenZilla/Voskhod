<template>
  <v-card class="select-popup">
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    ><v-toolbar-title>Выбор дел</v-toolbar-title>
      <v-btn icon class="rounded-lg" @click="$emit('close-popup')">
        <v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>

    <AddDossierFilters
      @set-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />

    <div class="main-table-inner">
      <v-data-table
        v-model="selectedDossiers"
        hide-default-footer
        no-data-text="Нет данных"
        show-select
        class="scroll-popup-table sortable-table no-hover"
        loading-text="Загрузка данных"
        :headers="headers"
        :items="dossiersList.dossiers"
        :fixed-header="true"
        :options.sync="options"
        :server-items-length="dossiersList.count"
        :loading="dossierLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :header-props="{
          'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
        }"
        @page-count="pageCount = $event"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.data-table-select="{ isSelected, select, item}">
          <v-simple-checkbox
            color="secondary"
            v-ripple
            :value="isSelected"
            @input="select($event)"
          ></v-simple-checkbox>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{ props }">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />

          <div class="main-table-inner__buttons">
            <v-btn
              color="secondary"
              class="mr-3 rounded-lg"
              :disabled="selectedDossiers.length === 0"
              @click="acceptDossier()"
            >Выбрать</v-btn>
            <v-btn
              outlined
              color="secondary"
              class="rounded-lg"
              @click="$emit('close-popup')"
            >Отменить</v-btn>
          </div>
        </template>
      </v-data-table>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import { GET_DOSSIERS_LIST } from '@/services/app'
const AddDossierFilters = () => import('./AddDossierFilters.vue')

export default {
  name: 'AddDossier',

  components: {
    AddDossierFilters
  },

  props: {
    isOpen: {
      type: Boolean,
      required: true
    },

    excludeDossierIds: {
      type: Array,
      required: false,
      default: () => []
    }
  },

  data: () => ({
    dossiersList: {},
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    selectedDossiers: [],
    headers: [
      {
        text: 'Индекс дела',
        width: '280px',
        value: 'index'
      },
      {
        text: 'Заголовок дела',
        width: '280px',
        value: 'name'
      },
      {
        text: 'Крайние даты',
        width: '280px',
        value: 'end_date'
      },
      {
        text: 'Срок хранения',
        width: '260px',
        value: 'save_period'
      }
    ]
  }),
  watch: {
    isOpen: {
      async handler (newV) {
        if (newV) {
          GET_DOSSIERS_LIST(this.sortParams).then(resp => { this.dossiersList = resp })
        }
      },
      immediate: true
    },

    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.dossiersList = await GET_DOSSIERS_LIST(this.sortParams)
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      dossierLoading: state => state.dossiers.dossierLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      paramsSort.append('status_code', 'removed_from_listings')
      if (this.excludeDossierIds.length) paramsSort.append('exclude_dossier_ids', `[${this.excludeDossierIds}]`)
      // if (this.include_dossier_ids.length) paramsSort.append('include_dossier_ids', `[${}]`)
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.dossiersList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source_name'
          } else if (sortBy[0].indexOf('status.name') !== -1) {
            par += 'status_value'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  methods: {
    async acceptFilters (evt) {
      this.dossiersList = await GET_DOSSIERS_LIST(evt, this.sortParams)
    },

    acceptDossier () {
      this.$emit('select-dossier', this.selectedDossiers)
      this.selectedDossiers = []
      this.$emit('close-popup')
    },

    clearFilters () {
      GET_DOSSIERS_LIST(this.sortParams).then(resp => { this.dossiersList = resp })
    }
  }
}
</script>

<style lang="scss">
</style>
