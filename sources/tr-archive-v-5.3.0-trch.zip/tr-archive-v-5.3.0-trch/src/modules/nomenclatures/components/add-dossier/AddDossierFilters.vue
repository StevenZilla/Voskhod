<template>
  <FiltersTemplate
    class="filter--dialog"
    :full-filter="true"
  >
    <template #filter-fields>
<!--      поиск по коду фильтра в filterObj-->
      <DossierName
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierIndex
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <SaveType
        class="w-49"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <SavePeriod
        class="w-49"
        :disabled="!isTemp"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import DossierName from '@/components/Filters/Fields/Dossier/DossierName.vue'
import DossierIndex from '@/components/Filters/Fields/Dossier/DossierIndex.vue'
import SaveType from '@/components/Filters/Fields/SaveType.vue'
import SavePeriod from '@/components/Filters/Fields/SavePeriod.vue'

export default {
  components: {
    FiltersTemplate,
    FilterFooter,
    DossierName,
    DossierIndex,
    SaveType,
    SavePeriod
  },

  data: () => ({
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.dossierName) {
        paramsFilter.append('name', this.filterObj.dossierName.query)
      }
      if (this.filterObj.index) {
        paramsFilter.append('index', this.filterObj.index.query)
      }
      if (this.filterObj.saveType) {
        paramsFilter.append('save_type', this.filterObj.saveType.query.value)
      }
      if (this.filterObj.savePeriod) {
        paramsFilter.append('save_period', this.filterObj.savePeriod.query)
      }
      return paramsFilter
    },

    isTemp () {
      return this.filterObj?.saveType?.query.code === 'temporarily'
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    acceptFilters () {
      this.searchTouch = true
      this.$emit('set-filters', this.filterParams)
      this.clear = true
    },

    clearFilters () {
      this.resetFilter = true
      this.$nextTick(() => {
        this.resetFilter = false
        this.$emit('clear-filters')
        this.searchTouch = false
      })
    }
  }
}
</script>

<style>
</style>
