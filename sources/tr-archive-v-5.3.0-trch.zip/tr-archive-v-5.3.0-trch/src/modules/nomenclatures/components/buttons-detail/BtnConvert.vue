<template>
  <v-dialog
    v-model="dialog"
    persistent
    max-width="500"
    content-class="dialog-auto-height"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        class="mr-3 rounded-lg"
        color="secondary"
        v-bind="attrs"
        v-on="on"
        outlined
      >
        Перевести в действующую
      </v-btn>
    </template>

    <v-card>
      <v-card-title>Вы уверены, что хотите перевести номенклатуру в статус "Действующая"?</v-card-title>
      <v-card-actions class="justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          outlined
          @click="dialog = false"
        >Нет</v-btn>
        <v-btn
          data-qa="accept-save"
          class="rounded-lg"
          color="secondary"
          @click="convertToCurrent"
        >Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>

import { CONVERT_NOM_STATUS_CURRENT } from '../../services/api'
import { mapGetters } from 'vuex'

export default {
  data: () => ({
    dialog: false
  }),

  computed: {
    ...mapGetters('nomenclatures', ['GET_NOMENCLATURE_KEY']),

    id () {
      return this.GET_NOMENCLATURE_KEY('id')
    }
  },

  methods: {
    async convertToCurrent () {
      const data = { status: 'current' }
      await CONVERT_NOM_STATUS_CURRENT(data, this.id)
      this.dialog = false
      this.$emit('refresh-data')
    }
  }
}
</script>

<style>
</style>
