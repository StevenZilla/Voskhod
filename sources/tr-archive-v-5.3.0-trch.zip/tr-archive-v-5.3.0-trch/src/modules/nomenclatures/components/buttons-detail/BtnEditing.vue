<template>
  <v-btn
    color="secondary"
    class="mr-3 rounded-lg"
    outlined
    @click="switchMode()"
  >
    <v-icon class="mr-2">mdi-pencil-outline</v-icon>
    Редактировать
  </v-btn>
</template>

<script>
export default {
  methods: {
    switchMode () {
      this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'edit' })
    }
  }
}
</script>

<style lang="scss">

</style>
