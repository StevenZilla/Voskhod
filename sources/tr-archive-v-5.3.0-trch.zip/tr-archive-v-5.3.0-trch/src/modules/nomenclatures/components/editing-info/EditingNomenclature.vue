<template>
  <div class="card">
    <v-alert
      v-if="isSame"
      icon="mdi-alert"
      type="error"
      class="mb-3 border-bottom rounded"
    >
      {{ errorData.message }}
    </v-alert>

    <EditingMainInfo
      :trigger="trigger"
      :error-data="errorData"
      @change-valid="invalidMainForm = $event"
      @fill-data="fillData($event)"
    />

    <EditingStructure
      :trigger="trigger"
      :error-data="errorData"
      @change-valid="invalidStructure = $event"
      @fill-data="fillData($event)"
    />

    <TemplateButtons>
      <template #buttons-left>
        <BtnSaveSlot
          :loading="loading"
          :disabled="invalidEditingInfo"
          @save="updateHandler()"
        />
      </template>

      <template #buttons-right>
        <BtnCancelSlot
          :text="'Отменить'"
          @close="cancelEdit()"
        />
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { UPDATE_NOMENCLATURE } from '../../services/api'
import { mapState } from 'vuex'

import EditingMainInfo from './EditingMainInfo.vue'
import EditingStructure from '../EditingStructure.vue'

export default {
  name: 'EditingNomenclature',
  components: {
    EditingMainInfo,
    EditingStructure
  },

  data: () => ({
    loadingComponent: true,
    trigger: 0,
    invalidMainForm: false,
    invalidStructure: false,
    loading: false,
    errorData: {},
    isLoadStructure: true,
    isSame: false,
    editDetailNom: {}
  }),

  computed: {
    ...mapState({
      detailNomenclature: state => state.nomenclatures.detailNomenclature
    }),

    invalidEditingInfo () {
      return this.invalidMainForm || this.invalidStructure
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.editDetailNom, evt)
        resolve()
      })
    },

    cancelEdit () {
      this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'view' })
      this.$emit('refresh-data')
    },

    async updateHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      try {
        await UPDATE_NOMENCLATURE(this.detailNomenclature.id, this.editDetailNom)
        this.$emit('refresh-data')
        this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'view' })
      } catch (error) {
        // if (error.response?.data) {
        //   this.errorData = error.response.data
        //   this.isSame = true
        // }
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
.fixed-root {
  & > .v-treeview-node {
    & > .v-treeview-node__root {
      display: none;
    }
  }
}
</style>
