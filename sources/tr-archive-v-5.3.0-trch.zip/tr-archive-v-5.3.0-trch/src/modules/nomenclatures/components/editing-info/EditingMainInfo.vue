<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mb-5">Общая информация</h2>
    </v-card-title>

    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="2">
          <YearsNom
            :param="editingObj.year"
            @set-property="$v.editingObj.year.$model = $event" />
        </v-col>
        <v-col cols="12" md="2">
          <NumberNom
            :param="editingObj.num"
            @set-property="editingObj.num = $event"/>
        </v-col>
        <v-col cols="12" md="2">
          <StatusNom
            @set-property="editingObj.nom_status_id = $event" />
        </v-col>

        <v-col cols="12" md="3">
          <CreateDateNom/>
        </v-col>

        <v-col cols="12" md="3">
          <UpdateDateNom/>
        </v-col>

        <v-col
          v-if="isChangeReason"
          cols="12"
          md="12"
        >
        <ChangeReasonNom
          :param="editingObj.change_reason"
          @set-property="$v.editingObj.change_reason.$model = $event" />
        </v-col>
      </v-row>

      <p class="mt-3 mb-5" style="font-size:14px"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_NOMENCLATURE_STATUS } from '../../services/api'
import { mapState } from 'vuex'
import { required } from 'vuelidate/lib/validators'

import NumberNom from '../fields-main-info/NumberNom.vue'
import CreateDateNom from '../fields-main-info/CreateDateNom.vue'
import UpdateDateNom from '../fields-main-info/UpdateDateNom.vue'
import YearsNom from '../fields-main-info/YearsNom.vue'
import StatusNom from '../fields-main-info/StatusNom.vue'
import ChangeReasonNom from '../fields-main-info/ChangeReasonNom.vue'

export default {
  components: {
    NumberNom,
    CreateDateNom,
    UpdateDateNom,
    YearsNom,
    StatusNom,
    ChangeReasonNom
  },

  name: 'EditingMainInfo',

  validations: {
    editingObj: {
      year: { required },
      change_reason: {
        // проверка, что значение не осталось прежним
        notSameAsPrevious (val) {
          if (this.detailNomenclature.nom_status.code === 'editing') return !!val
          return val !== this.detailNomenclature.change_reason || !val
        },
        requiredIfCurrentStatus (val) {
          return this.detailNomenclature.nom_status.code === 'current' ? !!val : true
        },
        checkEndSpace (val) {
          return !val.endsWith(' ')
        }
      }
    }
  },

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    editingObj: {
      num: null,
      year: null,
      // create_date: null,
      nom_status_id: null,
      change_reason: null
    },
    rows: 1,
    nomenclatureStatuses: [],
    loadingStatuses: true
  }),

  computed: {
    ...mapState({
      detailNomenclature: state => state.nomenclatures.detailNomenclature
    }),

    invalidData () {
      return this.$v.$invalid
    },

    // если поле заполнено и статус редактирование,
    // это поле скрывается. Обязательное его изменение, только, если редачим в статусе действующая
    isChangeReason () {
      return !!(this.detailNomenclature.nom_status.code === 'current' || !!this.detailNomenclature.change_reason)
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editingObj)
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  async created () {
    this.loadingStatuses = true
    GET_NOMENCLATURE_STATUS().then(resp => {
      this.nomenclatureStatuses = resp
      this.loadingStatuses = false
    })
  },

  mounted () {
    this.copyInfo()
    console.log('this.editingObj', this.editingObj)
  },

  methods: {
    expandTextarea () {
      if (this.editingObj.change_reason.length > 100) {
        this.rows = Math.ceil(this.editingObj.change_reason.length / 100) // Меняем количество строк в textarea
      }
    },

    trimReason () {
      this.editingObj.change_reason = this.editingObj.change_reason.trim()
    },

    copyInfo () {
      this.editingObj.num = this.detailNomenclature.num
      this.editingObj.year = this.detailNomenclature.year
      this.editingObj.create_date = this.detailNomenclature.create_date
      this.editingObj.nom_status_id = this.detailNomenclature.nom_status?.id
      this.editingObj.change_reason = this.detailNomenclature.change_reason
    }
  }
}
</script>

<style>

</style>
