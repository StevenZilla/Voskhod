<template>
  <v-card class="detail__main-info popup">
    <v-toolbar flat dense class="popup-toolbar">
      <v-toolbar-title>Укажите причину изменений в номенклатуре</v-toolbar-title>

      <BtnCancelSlot
        :icon="true"
        @close="$emit('close')"
      />
    </v-toolbar>

    <div class="form-group mx-3">
      <v-textarea
        v-model="reasonText"
        hide-details
        clearable
        rows="3"
        no-resize
        outlined
        class="rounded-lg pb-3"
        color="secondary"
        placeholder="Причина"
      ></v-textarea>
    </div>

    <div class="d-flex justify-end pb-3 pr-3">
      <v-btn
        class="mr-3 rounded-lg"
        color="secondary"
        :loading="loading"
        :disabled="!reasonText"
        @click="sendReasonUpload()"
      >Отправить
      </v-btn>
      <v-btn
        class="mr-3 rounded-lg"
        color="secondary"
        outlined
        @click="$emit('close')"
      >Отменить
      </v-btn>
    </div>
  </v-card>
</template>

<script>
import { SEND_REASON_UPLOAD } from '../services/api'
import store from '@/storages'

export default {
  name: 'DialogReason',

  props: {
    nomenclatureId: {
      type: String
    }
  },

  data: () => ({
    reasonText: '',
    loading: false
  }),

  methods: {
    async sendReasonUpload () {
      this.loading = true
      try {
        const reasonObj = {
          upload_id: this.nomenclatureId,
          change_reason: this.reasonText
        }
        await SEND_REASON_UPLOAD(reasonObj)
        this.$emit('close')
        this.$emit('refresh-data')
      } catch (error) {
        if (error.response.data.code >= 409) {
          await store.dispatch(
            'SET_VALUE',
            {
              key: 'errorList',
              value: [
                {
                  name: 'Обновление номенклатуры невозможно. Загрузка отклонена',
                  show: true
                }
              ]
            },
            { root: true }
          )
        } else {
          await store.dispatch(
            'SET_VALUE',
            {
              key: 'errorList',
              value: [{ name: error.response.data.message, show: true }]
            },
            { root: true }
          )
        }
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style>
</style>
