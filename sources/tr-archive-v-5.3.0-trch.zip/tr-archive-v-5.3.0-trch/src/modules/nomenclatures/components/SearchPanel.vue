<template>
  <div class="panel-search">
    <div class="d-flex justify-space-between align-center">
      <v-text-field
        v-model="filterObj.numNom"
        class="main-field"
        data-qa="main-field"
        placeholder="Введите номер номенклатуры"
        rounded
        outlined
        solo
        clearable
        hide-details
        flat
        @click:clear="filterObj.numNom = null, acceptFilters()"
        @keyup.enter="trigger++"
      >
        <template v-slot:append-outer>
          <v-btn
            class="rounded-xl ml-8 bg-white"
            outlined
            icon
            data-qa="filter"
            color="secondary"
            @click="toggleFilter()"
          >
            <v-icon>mdi-tune-vertical-variant</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
            v-if="filterObj.numNom"
            class="find-link secondary--text"
            @click="acceptFilters()"
          >Найти
          </span>
        </template>
        <template v-slot:prepend-inner>
          <v-btn
            plain
            icon
            color="secondary"
            @click="acceptFilters()"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>
      </v-text-field>

      <CreateNomenclature
        :key="clearComponent"
        @clear="clearComponent++"
        @refresh-data="$emit('refresh-data', $event)"
      />

      <label>
        <input
          type="file"
          hidden
          accept="*/*"
          @change="submit($event.target.files[0])"
        />
        <v-btn
          tag="span"
          style="cursor: pointer"
          color="secondary"
          class="justify-content-end rounded-lg"
        >Загрузить номенклатуру из файла
        </v-btn>
      </label>
    </div>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      :is-load="isLoad"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />

    <v-dialog
      v-model="isReason"
      transition="scroll-y-transition"
      max-width="630px"
      content-class="dialog-auto-height"
      @click:outside="isReason = false"
    >
      <DialogReason
        :nomenclature-id="nomenclatureId"
        @refresh-data="$emit('refresh-data')"
        @close="isReason = false"
      />
    </v-dialog>
  </div>
</template>

<script>

import { UPLOAD_NOMENCLATURE } from '@/modules/nomenclatures/services/api'
import store from '@/storages'

import CreateNomenclature from './create-info/CreateNomenclature.vue'
import DialogReason from '@/modules/nomenclatures/components/DialogReason.vue'

const Filters = () => import('./Filters.vue')

export default {
  name: 'SearchPanel',

  components: {
    DialogReason,
    CreateNomenclature,
    Filters
  },

  data: () => ({
    isReason: false,
    nomenclatureId: null,
    loading: false,
    clearComponent: 0,
    trigger: 0,
    isLoad: false,
    fullFilter: false,
    filterObj: {
      numNom: ''
    }
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.numNom) {
        paramsFilter.append('q', this.filterObj.numNom)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt ? evt.filter : undefined)
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    async submit (file) {
      this.loading = true
      try {
        const formData = new FormData()
        formData.append('files[]', file)
        const response = await UPLOAD_NOMENCLATURE(formData)
        if (response.data.code === 202) {
          const uploadId = response.data.upload_id
          if (uploadId) {
            this.nomenclatureId = uploadId
            this.isReason = true
            return
          }
        }
        this.$emit('refresh-data')
        this.$emit('update-success')
      } catch (error) {
        await store.dispatch('SET_VALUE',
          { key: 'errorList', value: [{ name: error.response.data.message, show: true }] },
          { root: true })
      } finally {
        this.loading = false
      }
    },

    clearFilters () {
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
