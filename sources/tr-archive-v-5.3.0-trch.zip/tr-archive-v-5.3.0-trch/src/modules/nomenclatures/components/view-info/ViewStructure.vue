<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Структура номенклатуры дел</h2>
    </v-card-title>

    <LoadingComponentVue v-if="loading"/>

    <div v-else class="structure d-flex">
      <!-- дерево -->
      <div class="structure__tree" data-qa="structure-nom-view">
        <TreeviewHeader
          :open-nodes="openNodes"
          @switch-nodes="switchNodes()"
        />

        <v-treeview
          ref="tree"
          color="secondary"
          return-object
          open-all
          transition
          activatable
          :items="nomenclatureParts"
          :open.sync="openNodes"
          @update:active="setSelectedNode"
        >
          <!-- eslint-disable-next-line -->
          <template v-slot:prepend="{ item }">
            <v-icon color="secondary">mdi-file-outline</v-icon>
          </template>

          <template v-slot:label="{ item }">
            <span v-if="item.id === -1">{{ item.name }}</span>

            <div v-else class="tree-node-view">
              <p>{{ `${item.num} ${item.name}` }}</p>
              <span v-if="hasChildrenRoot(item)">{{ item.subdivision ? item.subdivision.name : '' }}</span>
            </div>
          </template>
        </v-treeview>
      </div>

      <StructureInfo :open-nodes="openNodes"/>
    </div>
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'
import TreeviewHeader from '@/components/TreeviewHeader.vue'
import { GET_NOM_PARTS } from '../../services/api'
import StructureInfo from '@/modules/nomenclatures/components/StructureInfo.vue'

export default {
  name: 'ViewStructure',
  components: { StructureInfo, TreeviewHeader },

  data: () => ({
    openNodes: [],
    loading: true,
    selectedNode: null
  }),

  computed: {
    ...mapGetters('nomenclatures', ['GET_NOMENCLATURE_KEY']),

    nomenclatureParts () {
      return this.$store.getters['nomenclatures/GET_INFO_PARTS']
    },

    nomenclatureId () {
      return this.GET_NOMENCLATURE_KEY('id')
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    hasChildrenRoot (node) {
      return this.nomenclatureParts[0].children.find(item => item.id === node.id)
    },

    async getData () {
      this.loading = true
      console.log('detail', JSON.parse(JSON.stringify(this.$store.state.nomenclatures.detailNomenclature)))
      const resp = await GET_NOM_PARTS(this.nomenclatureId)
      const _tree = this.$_addParentIdInChildren(resp)
      const filledTree = this.$_changeTree(_tree, 'Номенклатура', -1, 'sortNum')
      console.log('filledTree', filledTree)
      // this.selectedNode = filledTree[0]
      //
      const nomParts = await GET_NOM_PARTS(this.nomenclatureId, true)
      nomParts.forEach(node => {
        const _currentNode = this.$_findNodeMix(node.id, filledTree[0])
        this.$set(_currentNode, 'dossiers', [])
        node.dossiers.forEach((dossier) => {
          _currentNode.dossiers.push(dossier)
        })
      })

      await this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'nomenclatureTree', value: filledTree })
      this.loading = false
    },

    switchNodes () {
      this.openNodes.length
        ? this.$refs.tree.updateAll(false)
        : this.$refs.tree.updateAll(true)
    },

    setSelectedNode (items) {
      if (items.length > 0) this.selectedNode = items[0]
    }
  }
}
</script>

<style lang="scss">
</style>
