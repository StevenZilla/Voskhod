<template>
  <v-card class="detail__main-info">
    <template>
      <v-alert
        v-if="detailNomenclature.resend_tk"
        icon="mdi-alert"
        class="warning-alert mb-3 border-bottom rounded"
      ><span>Необходимо переотправить номенклатуру в ЦХЭД</span>
    </v-alert>
    </template>
    <v-card-title>
      <h2>Общая информация</h2>
      <v-icon
        icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >mdi-chevron-down</v-icon>
    </v-card-title>
    <div class="main-info-block">
      <v-card-text
        class="detail__view-inner item-5"
        :class="{ open: isMainInfo }"
      >
        <div class="detail__item">
          <p class="detail__item-title">Год</p>
          <span data-qa="year" class="detail__value">{{ detailNomenclature.year }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Номер</p>
          <span data-qa="number-main" class="detail__value">{{ detailNomenclature.num }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Статус</p>
          <span
            data-qa="status"
            class="detail__value"
          >{{ detailNomenclature.nom_status ? detailNomenclature.nom_status.value : 'Нет данных'}}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Дата и время создания в системе</p>
          <span data-qa="create-date" class="detail__value">{{ $_formatDate(detailNomenclature.create_date, 'time') }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Дата последнего изменения</p>
          <span
            data-qa="edit-date"
            class="detail__value"
          >{{ detailNomenclature.update_date ? $_formatDate(detailNomenclature.update_date, 'time') : 'Нет данных' }}</span>
        </div>
        <div v-if="detailNomenclature.change_reason" class="detail__item short-value" style="flex-basis:100%">
          <p class="detail__item-title">Основание для изменения</p>
          <span class="detail__value">{{ detailNomenclature.change_reason }}</span>
        </div>
      </v-card-text>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'ViewMainInfo',

  data: () => ({
    isMainInfo: true
  }),

  computed: {
    ...mapState({
      detailNomenclature: state => state.nomenclatures.detailNomenclature
    })
  }
}
</script>

<style>

</style>
