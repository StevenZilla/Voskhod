<template>
  <div class="card">
    <ViewMainInfo/>
    <ViewStructure/>
    <ViewTk/>

    <TemplateButtons>
      <template #buttons-left>
        <BtnEditing v-if="$can('edit', 'nomenclature') && buttons.is_edit"/>

        <CreateNomenclature
          v-if="$can('edit', 'nomenclature') && buttons.is_clone"
          :is-copy="true"
        />

        <BtnConvert
          v-if="$can('edit', 'nomenclature') && buttons.is_current"
          @refresh-data="refreshData"
        />

        <BtnSend
          v-if="buttons.is_send_tk"
          :type-item="'nom'"
          :type-send="'tk'"
          :item-id-send="id"
          @refresh-data="refreshData"
        />
      </template>

      <template #buttons-right>
        <v-btn
          color="secondary"
          class="rounded-lg"
          @click="$_closeDetail()"
        >Закрыть
        </v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

import CreateNomenclature from '../create-info/CreateNomenclature.vue'
import { nomenclatureDetail } from '@/permissions'

import BtnSend from '@/components/Containers/BtnSend.vue'

import ViewMainInfo from './ViewMainInfo.vue'
import ViewStructure from './ViewStructure.vue'
import ViewTk from './ViewTk.vue'
import BtnConvert from '../buttons-detail/BtnConvert.vue'
import BtnEditing from '../buttons-detail/BtnEditing.vue'

export default {
  name: 'ViewNomenclatureInfo',

  components: {
    BtnEditing,
    CreateNomenclature,
    BtnConvert,
    BtnSend,
    ViewMainInfo,
    ViewStructure,
    ViewTk
  },

  data: () => ({
    clearComponent: 0
  }),

  computed: {
    ...mapGetters('nomenclatures', ['GET_NOMENCLATURE_KEY']),

    id () {
      return this.GET_NOMENCLATURE_KEY('id')
    },

    buttons () {
      return this.GET_NOMENCLATURE_KEY('view_buttons')
    }
  },

  methods: {
    async refreshData (id) {
      if (id) {
        this.copyId = id
        const path = `${nomenclatureDetail.path}/${id}`
        if (this.$route.path !== path) {
          this.$router.push(path)
        }
      }
      await this.getData()
      this.clearComponent++
    },

    async getData () {
      this.loading = true
      try {
        this.$emit('refresh-data')
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style>
</style>
