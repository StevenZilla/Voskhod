<template>
  <div class="v-window__container">
    <v-treeview
      class="structure__table-tree fixed-root"
      return-object
      expand-icon=""
      transition
      activatable
      :active-class="''"
      :items="nomenclaturesDossiers"
      :open="openNodes"
      :item-key="'id'"
    >
      <template slot="label" slot-scope="nodeItem">
        <p v-if="nodeItem.item.id !== -1" class="structure__table-name mb-0">
          {{ nodeItem.item.num ? `${nodeItem.item.num} ${nodeItem.item.name}` : nodeItem.item.name }}
        </p>

        <v-data-table
          v-if="nodeItem.item.id !== -1"
          item-key="id"
          hide-default-footer
          disable-pagination
          disable-sort
          no-data-text="Нет данных"
          class="scroll-table"
          :headers="headers"
          :items="nodeItem.item.dossiers"
          @click:row="showDetail($event)"
        >
          <template #item.index="{item}">
            <icon-circle :color="item.status && item.status.code === 'closed' ? '#e52e2e' : '#00a65a'"/>
            <span>{{ item.index }}</span>
          </template>
          <template v-slot:item.di_kinds="{ item }">
            <div
              v-for="(kind, idx) in item.di_kinds"
              :key="idx"
            >
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                <span
                  style="font-size: 12px"
                  v-bind="attrs"
                  v-on="on"
                >{{ kind.num_show }}</span>
                </template>
                <span>{{ kind.name }}</span>
              </v-tooltip>
            </div>
          </template>

          <template v-slot:item.save_type="{ item }">
            <span v-if="item.di_kinds.length" class="accent-item">
              {{ item.di_kinds[0].save_info || item.save_type.value }}
            </span>
          </template>

          <template v-slot:item.media_type="{ item }">
            <v-icon color="secondary">
              {{ item.media_type && item.media_type.code === "electronic"
                  ? "$vuetify.icons.electronic"
                  : "$vuetify.icons.hybrid"
              }}
            </v-icon>
          </template>
        </v-data-table>
      </template>
    </v-treeview>
  </div>
</template>

<script>
import IconCircle from '@/components/IconCircle.vue'

export default {
  components: {
    IconCircle
  },

  props: {
    openNodes: {
      type: Array
    }
  },

  data: () => ({
    words: ['год', 'года', 'лет'],
    headers: [
      {
        text: 'Индекс дела',
        value: 'index',
        width: '140px'
      },
      {
        text: 'Заголовок дела',
        value: 'name',
        width: '450px'
      },
      {
        text: 'Статья хранения',
        value: 'di_kinds',
        width: '200px'
      },
      {
        text: 'Срок хранения',
        value: 'save_type',
        width: '160px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type',
        align: 'center',
        width: '165px'
      }
    ]
  }),

  computed: {
    nomenclaturesDossiers () {
      return this.$store.getters['nomenclatures/GET_INFO_TABLE']
    }
  },

  methods: {
    showDetail (e) {
      this.$router.push({ name: 'detail-dossier', params: { id: e.id } })
    }

    // getNodeClass (item) {
    //   if (item.status && item.status.code === 'closed') {
    //     return 'grey grey-text'
    //   }
    // }
  }
}
</script>

<style lang="scss">
</style>
