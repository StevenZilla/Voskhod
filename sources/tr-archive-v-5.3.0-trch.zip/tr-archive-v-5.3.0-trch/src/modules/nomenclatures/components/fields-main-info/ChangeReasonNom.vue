<template>
  <div class="form-group">
    <p class="form-group__title">
      Основание для изменения <span class="required-label">*</span>
    </p>
    <v-textarea
      v-model="value"
      class="rounded-lg"
      outlined
      rounded
      rows="2"
      hide-details
      placeholder="Введите основание для изменения"
      @blur="value ? value.trim() : null"
    ></v-textarea>
  </div>
</template>

<script>
export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">
</style>
