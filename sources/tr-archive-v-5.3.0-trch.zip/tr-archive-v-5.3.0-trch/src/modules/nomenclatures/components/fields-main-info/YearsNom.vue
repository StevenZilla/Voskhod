<template>
  <div class="form-group">
    <p class="form-group__title">Год <span class="required-label">*</span></p>
    <v-autocomplete
      v-model="value"
      class="rounded-lg nomenclature-year"
      data-qa="year"
      outlined
      hide-details
      clearable
      append-icon="mdi-calendar-blank"
      placeholder="Год"
      :items="arrayYearsMix"
      :attach="'.nomenclature-year'"
      :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>
export default {
  props: {
    param: {
      type: Number,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'number'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.$emit('set-property', this.value)
  },

  methods: {
    setDate (date) {
      this.value = this.$_setDate(date, 'date')
      this.$emit('set-property', this.value)
    }
  }
}
</script>

<style lang="scss">
</style>
