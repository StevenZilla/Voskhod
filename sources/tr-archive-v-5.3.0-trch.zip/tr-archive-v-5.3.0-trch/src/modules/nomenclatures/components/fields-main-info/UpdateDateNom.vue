<template>
  <div class="form-group">
    <p class="form-group__title">Дата последнего изменения</p>
    <v-text-field
      class="rounded-lg"
      data-qa="nom-update"
      outlined
      disabled
      filled
      hide-details
      :value="$_formatDate(detailNomenclature.update_date, 'time')"
    ></v-text-field>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  computed: {
    ...mapState({
      detailNomenclature: state => state.nomenclatures.detailNomenclature
    })
  },

  mounted () {
    this.$emit('set-property', this.value)
  },

  methods: {
    setDate (date) {
      this.value = this.$_setDate(date, 'date')
      this.$emit('set-property', this.value)
    }
  }
}
</script>

<style lang="scss">
</style>
