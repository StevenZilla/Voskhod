<template>
  <div class="form-group">
    <p class="form-group__title">Статус</p>
    <v-autocomplete
      v-model="value"
      class="rounded-lg"
      return-object
      data-qa="nom-status-create"
      hide-details
      outlined
      filled
      disabled
      item-text="value"
      item-value="id"
      placeholder="Выберите статус"
      :items="nomenclatureStatuses"
      :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>
import { GET_NOMENCLATURE_STATUS } from '../../services/api'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    nomenclatureStatuses: [],
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    getData () {
      GET_NOMENCLATURE_STATUS().then((resp) => {
        this.nomenclatureStatuses = resp.filter(
          (item) => item.code === 'editing'
        )
        this.value = this.nomenclatureStatuses[0].id
      })
    }
  }
}
</script>

<style lang="scss">
</style>
