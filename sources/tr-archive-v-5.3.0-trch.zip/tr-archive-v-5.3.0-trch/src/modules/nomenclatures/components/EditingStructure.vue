<script src="../../../utils/mixins.js"></script>
<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Структура номенклатуры дел</h2>
    </v-card-title>
    <div class="structure d-flex">
      <div class="structure__tree">
        <TreeviewHeader
          :open-nodes="openNodes"
          @switch-nodes="switchNodes()"
        />

        <v-treeview
          data-qa="treeview-structure"
          color="secondary"
          ref="tree"
          return-object
          open-all
          transition
          activatable
          :items="nomenclatureParts"
          :open.sync="openNodes"
          :active="selectedNode"
          @update:active="setSelectedNode"
        >
          <!-- eslint-disable-next-line -->
          <template v-slot:prepend="{ item }">
            <v-tooltip v-if="item.error" right color="error">
              <template v-slot:activator="{ on, attrs }">
                <v-icon
                  color="error"
                  dark
                  v-bind="attrs"
                  v-on="on"
                >mdi-alert-circle</v-icon>
              </template>
              <span>{{ errorData.message }}</span>
            </v-tooltip>
            <v-icon
              v-else
              color="secondary"
            >mdi-file-outline</v-icon>
          </template>

          <template v-slot:label="{ item }">
            <div
              v-if="item.is_edit || item.id < -1"
              class="d-flex flex-wrap py-2"
            >
              <v-text-field
                class="w-33 rounded-lg mr-2"
                hide-details
                placeholder="Номер"
                outlined
                :value="item.num"
                @change="changeNodeNumber($event, item)"
              />

              <v-text-field
                class="rounded-lg"
                hide-details
                placeholder="Название"
                outlined
                :value="item.name"
                @change="changeNodeName($event, item)"
              />

              <v-autocomplete
                v-if="hasChildrenRoot(item)"
                return-object
                class="w-100 rounded-lg mt-2"
                outlined
                item-value="id"
                item-text="display_name"
                hide-details
                placeholder="Выберите подразделение"
                :no-data-text="'Нет данных'"
                :value="item.subdivision"
                :items="subdivisionsList"
                @change="autoInput(item, $event)"
              ></v-autocomplete>
            </div>

            <div v-else>
              <span v-if="item.id === -1">{{ item.name }}</span>

              <div v-else class="tree-node-view">
                <p>{{ `${item.num} ${item.name}` }}</p>
                <span v-if="hasChildrenRoot(item)">{{ item.subdivision ? item.subdivision.name : '' }}</span>
              </div>
            </div>

            <div v-if="item.is_copy" class="tree-node-view">
              <p>{{ `${item.num} ${item.name}` }}</p>
              <span v-if="item.parent_id === -1 && item.subdivision">{{
                item.subdivision.name
              }}</span>
            </div>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:append="{ item }">
            <v-menu content-class="structure__tree-menu" offset-y>
              <template v-slot:activator="{ on, attrs }">
                <v-icon v-bind="attrs" v-on="on" color="secondary">mdi-dots-vertical</v-icon>
              </template>
<!--              ЭТА СТРОКА ДОЛЖНА БЫТЬ-->

              <v-list>
                <v-list-item @click="addNode(item)">
                  <v-list-item-title data-qa="add-part-create">
                    {{ item.id === -1 ? "Добавить раздел" : "Добавить подраздел" }}
                  </v-list-item-title>
                </v-list-item>
                <v-list-item
                  v-if="item.is_edit || item.id < -1"
                  @click="deleteNode(item)"
                >
                  <v-list-item-title data-qa="delete_part-create">Удалить раздел</v-list-item-title>
                </v-list-item>
              </v-list>
            </v-menu>
          </template>
        </v-treeview>
      </div>

      <!-- таблица -->
      <StructureInfo :open-nodes="openNodes" @change-valid="invalidTable = $event"/>
    </div>

    <v-dialog
      v-model="isLimit"
      content-class="dialog-auto-height"
      transition="dialog-bottom-transition"
      max-width="520px"
      @click:outside="isLimit = false"
      ><NotificationPopup
        :title="'Номенклатуры дел'"
        @close-popup="isLimit = false"
      />
    </v-dialog>

    <v-dialog
      v-model="isDelete"
      persistent
      max-width="500"
      content-class="dialog-auto-height"
      ><AlertPopup
        @close-popup="isDelete = false"
        @confirm-delete="confirmDelete()"
      />
    </v-dialog>
  </v-card>
</template>

<script>

import { mapActions, mapState } from 'vuex'
import TreeviewHeader from '@/components/TreeviewHeader.vue'
import { GET_SUBDIVISIONS_LIST } from '@/services/app'
import StructureInfo from '@/modules/nomenclatures/components/StructureInfo.vue'
import { required } from 'vuelidate/lib/validators'
// import { required } from 'vuelidate/lib/validators'

const AlertPopup = () => import('@/components/AlertPopup.vue')
const NotificationPopup = () => import('@/components/NotificationPopup.vue')

const set = require('lodash.set')

export default {
  validations: {
    fullFlatTree: {
      $each: {
        name: { required },
        num: { required }
      }
    }
  },

  components: {
    StructureInfo,
    TreeviewHeader,
    AlertPopup,
    NotificationPopup
  },

  props: {
    errorData: {
      type: Object,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    },

    isCopy: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    editingObj: {
      nom_parts: []
    },
    invalidTable: true,
    errorObj: {},
    showDelete: false,
    pk: -2,
    isLimit: false,
    isDelete: false,
    nodeToDelete: null,
    openNodes: [],
    subdivisionsList: [],
    currentNode: null,
    selectedNode: []
  }),

  computed: {
    ...mapState({
      nomenclatureTree: state => state.nomenclatures.nomenclatureTree
    }),

    nomenclatureParts () {
      return this.$store.getters['nomenclatures/GET_INFO_PARTS']
    },

    fullFlatTree () {
      const viewFlatTree = []
      this.$_createFlatTree(this.nomenclatureTree[0], viewFlatTree)
      viewFlatTree.shift() // убираем корень, так как он не очень то и валидный
      return viewFlatTree
    },

    invalidData () {
      return this.$v.$invalid || this.invalidTable
    }
  },

  watch: {
    errorData (newV) {
      if (newV.message && newV.error) {
        Object.keys(this.errorData.error).forEach((key) => {
          set(this.errorObj, key, this.errorData.error[key])
        })

        // this.addedErrorInTree()
      }
    },

    invalidData: {
      handler (newVal) {
        this.$emit('change-valid', newVal)
      },
      immediate: true
    },

    trigger (newV) {
      if (newV) this.fillData()
    }
  },

  async mounted () {
    GET_SUBDIVISIONS_LIST().then((resp) => {
      this.subdivisionsList = resp
      this.subdivisionsList.forEach(el => {
        el.display_name = `${el.code} ${el.name}`
      })
    })
    // await this.prepareCopyData()
  },

  methods: {
    ...mapActions('nomenclatures', ['ADD_NODE', 'DELETE_NODE', 'CHANGE_NODE_NUMBER', 'CHANGE_NODE_NAME', 'CHANGE_NODE_SUBDIVISION']),

    changeNodeNumber (num, node) {
      this.CHANGE_NODE_NUMBER({ num, nodeId: node.id })
    },

    changeNodeName (name, node) {
      this.CHANGE_NODE_NAME({ name, nodeId: node.id })
    },

    hasChildrenRoot (node) {
      return this.nomenclatureTree[0].children.find(item => item.id === node.id)
    },

    autoInput (node, subdivision) {
      this.changeNodeNumber(subdivision.code, node)
      this.changeNodeName(subdivision.name, node)
      this.CHANGE_NODE_SUBDIVISION({ subdivision, nodeId: node.id })
    },

    switchNodes () {
      this.openNodes.length
        ? this.$refs.tree.updateAll(false)
        : this.$refs.tree.updateAll(true)
    },

    fillData () {
      const tree = JSON.parse(JSON.stringify(this.nomenclatureTree))
      this.changeAllChildrenTreeMix(tree[0], (node) => {
        if (node.subdivision) node.subdivision_id = node.subdivision.id
        delete node.subdivision
        if (node.id < 0) delete node.id

        if (node.dossiers) {
          node.dossiers.forEach(dossier => {
            dossier.di_kind_ids = dossier.di_kinds?.map(kind => kind.id)
            if (dossier.media_type) dossier.media_type_id = dossier.media_type.id
            delete dossier.media_type
            delete dossier.di_kinds
            if (dossier.id < 0) delete dossier.id
          })
        }
      })

      this.editingObj.nom_parts = tree[0].children

      this.$emit('fill-data', this.editingObj)
    },

    addedErrorInTree () {
      this.errorObj.nom_parts.forEach((err, ind) => {
        if (err.dossiers) {
          const errorNode = this.$_findNodeMix(
            this.fullFlatTree[ind + 1].id,
            this.tree[0]
          )
          this.$set(errorNode, 'error', err)
          err.dossiers.forEach((doss, index) => {
            this.$set(errorNode.dossiers[index], 'error', doss)
          })
        }
      })
    },

    addNode (node) {
      const depth = this.$_findDepthMix(node.id, this.nomenclatureTree)

      if (depth > 10) {
        this.isLimit = true
        return
      }

      this.pk--
      // добавление узла
      const newNode = {
        id: this.pk,
        num: '',
        name: '',
        children: [],
        subdivision: {},
        dossiers: []
      }
      this.ADD_NODE({ nodeId: node.id, newNode })
      this.$set(this.openNodes, this.openNodes.length, node)
    },

    deleteNode (nodeToDelete) {
      this.nodeToDelete = nodeToDelete
      this.isDelete = true
    },

    confirmDelete () {
      this.DELETE_NODE({ nodeToDelete: this.nodeToDelete })
      this.$eventBus.$emit('deleted-node')
      this.isDelete = false
    },

    setSelectedNode (items) {
      if (items.length > 0) this.$set(this.selectedNode, 0, items[0])
    }
  }
}
</script>

<style>
</style>
