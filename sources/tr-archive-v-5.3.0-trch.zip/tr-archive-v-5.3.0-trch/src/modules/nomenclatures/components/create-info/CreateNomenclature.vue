<template>
  <v-dialog
    v-model="isCreate"
    hide-overlay
    transition="scroll-y-transition"
    content-class="app-modal"
    attach=".content"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        data-qa="create-nom-manual"
        class="justify-content-end rounded-lg mr-3"
        :outlined="isCopy"
        color="secondary"
        v-bind="attrs"
        @click="switchMode()"
      >
        {{ isCopy ? 'Копировать номенклатуру' : "Добавить номенклатуру вручную" }}
      </v-btn>
    </template>

    <TemplateCreate
      :loading="loading"
      :disabled="invalidCreateInfo"
      @save="submitHandler()"
      @close="closeDialog()"
    >
      <template #content>
        <CreateMainInfo
          :trigger="trigger"
          :error-data="errorData"
          @change-valid="invalidMainForm = $event"
          @fill-data="fillData($event)"
        />

        <EditingStructure
          :trigger="trigger"
          :error-data="errorData"
          @change-valid="invalidStructure = $event"
          @fill-data="fillData($event)"
        />
      </template>
    </TemplateCreate>
  </v-dialog>
</template>

<script>

import { CREATE_NOMENCLATURE } from '../../services/api'
import { nomenclatureDetail } from '@/permissions'
import { mapActions } from 'vuex'

const CreateMainInfo = () =>
  import(/* webpackChunkName: 'create-main-nom' */ './CreateMainInfo.vue')
const EditingStructure = () => import(/* webpackChunkName: 'editing-structure-nom' */ '../EditingStructure.vue')

export default {
  props: {
    isCopy: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  components: {
    CreateMainInfo,
    EditingStructure
  },

  data: () => ({
    isCreate: false,
    invalidMainForm: true,
    invalidStructure: true,
    loading: false,
    errorData: {},
    trigger: 0,
    createDetailInfo: {}
  }),

  computed: {
    invalidCreateInfo () {
      return this.invalidMainForm || this.invalidStructure
    }
  },

  watch: {
    isCreate (newV) {
      if (newV && !this.isCopy) this.$store.commit('nomenclatures/resetNomenclatureTree')
    }
  },

  methods: {
    ...mapActions('nomenclatures', ['COPY_DOSSIERS']),

    async switchMode () {
      await this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'create' })
      if (this.isCopy) this.COPY_DOSSIERS()
      this.isCreate = true
      const a = document.querySelector('html')
      a.style.overflow = 'hidden'
      console.log(a.style)
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise((resolve) => {
        Object.assign(this.createDetailInfo, evt)
        resolve()
      })
    },

    async submitHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      console.log('createDetailInfo', this.createDetailInfo)
      try {
        const resp = await CREATE_NOMENCLATURE(this.createDetailInfo)
        const path = `${nomenclatureDetail.path}/${resp.data.message}`
        console.log('this.$route.path', this.$route.path)
        console.log('path', path)
        if (this.$route.path !== path) {
          this.$router.push(path)
        }
        // this.$emit('refresh-data', resp.data.message)
      } finally {
        this.loading = false
      }
    },

    async closeDialog () {
      if (this.isCopy) await this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'view' })
      else await this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: '' })
      this.isCreate = false
      this.$emit('clear')
    }
  }
}
</script>

<style lang="scss">
</style>
