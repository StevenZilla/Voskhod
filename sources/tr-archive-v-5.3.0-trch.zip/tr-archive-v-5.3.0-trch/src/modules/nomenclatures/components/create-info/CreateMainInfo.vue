<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mb-5">Общая информация</h2>
    </v-card-title>
    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="2">
          <NumberNom
            @set-property="editingObj.num = $event"
          />
        </v-col>

        <v-col cols="12" md="2">
          <YearsNom
            @set-property="$v.editingObj.year.$model = $event" />
        </v-col>

        <v-col cols="12" md="2">
          <StatusNom
            @set-property="editingObj.nom_status_id = $event" />
        </v-col>
      </v-row>
      <p class="mt-3">
        <span class="required-label">*</span> Обязательные поля
      </p>
    </v-card-text>
  </v-card>
</template>

<script>
import { required } from 'vuelidate/lib/validators'

import NumberNom from '../fields-main-info/NumberNom.vue'
import YearsNom from '../fields-main-info/YearsNom.vue'
import StatusNom from '../fields-main-info/StatusNom.vue'

// const _ = require('lodash')

export default {
  components: {
    NumberNom,
    YearsNom,
    StatusNom
  },
  name: 'CreateMainInfo',

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  validations: {
    editingObj: {
      year: { required }
    }
  },

  data: () => ({
    // isDirty: false,
    // originalObj: {}, // чтобы потом сравнить с ним
    editingObj: {
      num: null,
      year: null,
      nom_status_id: null
    }
  }),
  computed: {
    invalidData () {
      return this.$v.$invalid
    }
  },
  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editingObj)
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }

    // editingObj: {
    //   handler () {
    //     if (!_.isEqual(this.originalObj, this.editingObj)) this.isDirty = true
    //     else this.isDirty = false
    //   },
    //   deep: true
    // },

    // isDirty (newV) {
    //   if (newV) this.setDirty()
    //   else this.clearDirty()
    // }
  },

  // mounted () {
  //   this.copyInfo()
  // },

  methods: {
    // setDirty () {
    //   const obj = {
    //     name: 'Общая информация',
    //     code: 'main'
    //   }
    //   this.$store.dispatch('nomenclatures/SET_DIRTY', obj)
    // },

    // clearDirty () {
    //   this.$store.dispatch('nomenclatures/CLEAR_DIRTY', 'main')
    // },

    // copyInfo () {
    //   this.originalObj = _.pick(this.editingObj, [
    //     'num',
    //     'year',
    //     'nom_status_id'
    //   ])
    //   console.log('this.originalObj', this.originalObj)
    // }
  }
}
</script>

<style>
</style>
