<template>
  <div class="structure__table">
    <div class="structure__table-title detail-flex justify-space-between" style="min-width: 1000px;">
      <div>Номенклатура</div>
      <div class="d-flex">
        <div style="margin-right: 20px;">
          <icon-circle :color="'#00a65a'"/>
          <span>Дело активно</span>
        </div>
        <div>
          <icon-circle :color="'#e52e2e'"/>
          <span>Дело закрыто</span>
        </div>
      </div>
    </div>
    <ViewDossiers v-if="modeNomenclature === 'view'" :open-nodes="openNodes"/>
    <EditingDossiers v-else :open-nodes="openNodes" @change-valid="$emit('change-valid', $event)"/>
    <resize-width></resize-width>
  </div>
</template>

<script>

import ViewDossiers from './view-info/ViewDossiers.vue'
import EditingDossiers from './EditingDossiers.vue'
import { mapState } from 'vuex'
import IconCircle from '@/components/IconCircle.vue'
import ResizeWidth from '@/components/ResizeWidth.vue'

export default {
  components: {
    ResizeWidth,
    IconCircle,
    ViewDossiers,
    EditingDossiers
  },

  props: {
    openNodes: {
      type: Array
    }
  },

  computed: {
    ...mapState({
      modeNomenclature: state => state.nomenclatures.modeNomenclature
    })
  }
}
</script>

<style lang="scss">

</style>
