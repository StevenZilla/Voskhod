import { nomenclatureEvent } from '@/event-code'
import { nomenclature, nomenclatureDetail } from '@/permissions'
const NomenclaturesPage = () => import(/* webpackChunkName: 'nomenclatures-page' */ '../views/NomenclaturesPage.vue')
const DetailNomenclature = () => import(/* webpackChunkName: 'detail-nomenclature' */ '../views/DetailNomenclature.vue')

const nomenclatureRouter = [
  {
    name: 'NomenclaturesPage',
    path: nomenclature.path,
    component: NomenclaturesPage,
    meta: {
      breadcrumb: [
        {
          text: 'Номенклатуры дел',
          exact: true
        }
      ],
      tech_name: nomenclature.code
    }
  },
  {
    name: 'detail-nomenclature',
    path: `${nomenclatureDetail.path}/:id`,
    component: DetailNomenclature,
    meta: {
      breadcrumb: [
        {
          text: 'Номенклатуры дел',
          exact: true,
          to: nomenclature.path
        },
        {
          text: 'Просмотр номенклатуры'
        }
      ],
      parent: nomenclature.path,
      tech_name: nomenclatureDetail.code,
      code: nomenclatureEvent.code
    }
  }
]

export default router => {
  router.addRoutes(nomenclatureRouter)
}
