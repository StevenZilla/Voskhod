export default {
  namespaced: true,
  state: {
    modeNomenclature: 'view',
    nomenclatureList: {},
    nomenclatureLoading: false,
    nomenclatureTree: [],
    detailNomenclature: {}
  },

  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },

    resetNomenclatureTree (state) {
      state.nomenclatureTree = [
        {
          id: -1,
          name: 'Номенклатуры дел',
          num: '',
          children: [],
          subdivision: {},
          dossiers: []
        }
      ]
    },

    addNode (state, { node, newNode }) {
      if (!node) return
      node.children.push(newNode)
    },

    deleteNode (state, { parentNode, indexDelete }) {
      parentNode.children.splice(indexDelete, 1)
    },

    addDossier (state, { list, node }) {
      node.dossiers = [...node.dossiers, ...list]
    },

    removeDossier (state, { node, indexDelete }) {
      node.dossiers.splice(indexDelete, 1)
    },

    removeAllDossiers (state, { node }) {
      node.dossiers = []
    },

    changeNodeNumber (state, { num, node }) {
      node.num = num
    },

    changeNodeName (state, { name, node }) {
      node.name = name
    },

    changeNodeSubdivision (state, { subdivision, node }) {
      node.subdivision = subdivision
    },

    changeDossier (state, { node, index, key, value }) {
      node.dossiers[index][key] = value
    },

    copyDossier (state, { dossier }) {
      delete dossier.id
    }
  },
  actions: {
    ADD_NODE ({ commit, state }, { nodeId, newNode }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('addNode', { node, newNode })
        else if (node.children) {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    DELETE_NODE ({ commit, state }, { nodeToDelete }) {
      const findAndMutate = (node) => {
        if (node.children.length) {
          const indexDelete = node.children.findIndex(item => item.id === nodeToDelete.id)
          if (indexDelete !== -1) commit('deleteNode', { parentNode: node, indexDelete })
          else {
            node.children.forEach(child => {
              findAndMutate(child)
            })
          }
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    ADD_DOSSIER_IN_NODE ({ commit, state }, { dossierList, selectedNodeId }) {
      const findAndMutate = (node) => {
        if (node.id === selectedNodeId) commit('addDossier', { list: dossierList, node })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    REMOVE_DOSSIER ({ commit, state }, { nodeId, indexDelete }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('removeDossier', { node, indexDelete })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    REMOVE_ALL_DOSSIERS ({ commit, state }) {
      const findAndMutate = (node) => {
        commit('removeAllDossiers', { node })
        node.children.forEach(child => {
          findAndMutate(child)
        })
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    CHANGE_NODE_NUMBER ({ commit, state }, { num, nodeId }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('changeNodeNumber', { num, node })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    CHANGE_NODE_NAME ({ commit, state }, { name, nodeId }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('changeNodeName', { name, node })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    CHANGE_NODE_SUBDIVISION ({ commit, state }, { subdivision, nodeId }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('changeNodeSubdivision', { subdivision, node })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    CHANGE_DOSSIER ({ commit, state }, { nodeId, index, key, value }) {
      const findAndMutate = (node) => {
        if (node.id === nodeId) commit('changeDossier', { node, index, key, value })
        else {
          node.children.forEach(child => {
            findAndMutate(child)
          })
        }
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    COPY_DOSSIERS ({ commit, state }) {
      const findAndMutate = (node) => {
        if (node.dossiers) {
          node.dossiers.forEach(dossier => {
            commit('copyDossier', { dossier })
          })
        }
        node.children.forEach(child => {
          findAndMutate(child)
        })
      }

      findAndMutate(state.nomenclatureTree[0])
    },

    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }

    // SET_DIRTY ({ commit }, object) {
    //   commit('setDirty', object)
    // },

    // CLEAR_DIRTY ({ commit }, code) {
    //   commit('clearDirty', code)
    // }
  },
  getters: {
    GET_INFO_PARTS: state => {
      function extractData (node) {
        return {
          id: node.id,
          name: node.name,
          num: node.num,
          is_edit: node.is_edit,
          subdivision: node.subdivision,
          children: node.children.map(child => extractData(child))
        }
      }

      return state.nomenclatureTree.map(node => extractData(node))
    },

    GET_INFO_TABLE: state => {
      function extractData (node) {
        return {
          id: node.id,
          name: node.name,
          num: node.num,
          children: node.children.map(child => extractData(child)),
          dossiers: node.dossiers
        }
      }

      return state.nomenclatureTree.map(node => extractData(node))
    },

    GET_NOMENCLATURE_KEY: state => code => {
      if (!state.detailNomenclature) return {}
      return state.detailNomenclature[code]
    }
  }
}
