import api from '@/services/api'
import store from '@/storages'

export async function UPLOAD_NOMENCLATURE (formData) {
  const response = await api.post('/v3/ead/nomenclatures/upload', formData)
  return response
}

export async function SEND_REASON_UPLOAD (formData) {
  await api.post('/v3/ead/nomenclatures/upload-continue', formData)
}

export async function CREATE_NOMENCLATURE (nomObject) {
  try {
    const response = await api.post('/v3/ead/nomenclatures', nomObject)
    console.log(response)
    return response
  } catch (error) {
    console.log(error.response)
    const obj = {
      name: error.response.data.message,
      show: true
    }
    await store.dispatch('SET_VALUE', { key: 'errorList', value: [obj] }, { root: true })
    throw error
  }
}

export async function CONVERT_NOM_STATUS_CURRENT (nomObject, id) {
  return await api.patch('/v3/ead/nomenclatures/' + id + '/status', nomObject)
}

export async function GET_NOM_PARTS (id, aggregate) {
  let host = `/v3/ead/nom_parts/${id}`
  if (aggregate) host += '/aggregate?is_visible_dossiers'

  const resp = await api.get(host)
  return resp.data.nom_parts
}

export async function GET_DETAIL_NOMENCLATURE (id) {
  const resp = await api.get(`/v3/ead/nomenclatures/${id}`)
  await store.dispatch('nomenclatures/SET_VALUE', { key: 'detailNomenclature', value: resp.data.nomenclatures })
}

export async function UPDATE_NOMENCLATURE (id, nomObject) {
  // store.dispatch('nomenclatures/SET_VALUE', { key: 'nomenclatureLoading', value: true })
  try {
    await api.put(`/v3/ead/nomenclatures/${id}`, nomObject)
  } catch (error) {
    console.log(error.response)
    const obj = {
      name: error.response.data.message,
      show: true
    }
    await store.dispatch('SET_VALUE', { key: 'errorList', value: [obj] }, { root: true })
    throw (error)
  } finally {
    // store.dispatch('nomenclatures/SET_VALUE', { key: 'nomenclatureLoading', value: false })
  }
}

export async function GET_NOMENCLATURE_STATUS () {
  const res = await api.get('/ead/nsi/nom_statuses')
  // .map(item => ({ text: item.value, value: item.id }))
  return res.data.nom_statuses
}
