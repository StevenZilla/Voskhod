<template>
  <TemplateDetail :loading="loading">
    <template #content>
      <ViewNomenclatureInfo
        v-if="modeNomenclature === 'view' || modeNomenclature === 'create'"
        @refresh-data="refreshData"
      />

      <EditingNomenclature
        v-if="modeNomenclature === 'edit'"
        :key="clearComponent"
        @refresh-data="refreshData"
      />

      <v-dialog
        v-model="dialog"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
      >
        <ConfirmCancel @cancel="dialog = false" @confirm="confirmLeave"/>
      </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DETAIL_NOMENCLATURE } from '../services/api'
import { mapState } from 'vuex'
import ViewNomenclatureInfo from '../components/view-info/ViewNomenclatureInfo.vue'
import ConfirmCancel from '@/components/ConfirmCancel.vue'

const EditingNomenclature = () =>
  import('../components/editing-info/EditingNomenclature.vue')

export default {
  name: 'detail-nomenclature',
  components: {
    ConfirmCancel,
    ViewNomenclatureInfo,
    EditingNomenclature
  },

  data: () => ({
    confirmCallback: null,
    dialog: false,
    clearComponent: 0,
    loading: true
  }),

  computed: {
    ...mapState({
      modeNomenclature: (state) => state.nomenclatures.modeNomenclature
    })
  },

  async mounted () {
    await this.getData()
  },

  async beforeRouteUpdate (to, from, next) {
    await this.getData(to.params.id)
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    resetDataStore () {
      // возможно надо reset у nomenclatureTree сделать
      this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: '' })
      this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'detailNomenclature', value: {} })
      this.loading = true
    },

    checkEditingMode (next) {
      if (this.modeNomenclature === 'edit') {
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
        this.resetDataStore()
      }
    },

    confirmLeave () {
      this.dialog = false
      this.confirmCallback()
      this.resetDataStore()
    },

    async refreshData () {
      await this.getData()
      this.clearComponent++
    },

    async getData (id) {
      this.loading = true
      const _id = id || this.$route.params.id
      this.$store.dispatch('nomenclatures/SET_VALUE', { key: 'modeNomenclature', value: 'view' })
      await GET_DETAIL_NOMENCLATURE(_id)
      this.loading = false
    }
  }
}
</script>

<style lang="scss">
.tree-node-view {
  p {
    margin-bottom: 0;
  }
  span {
    font-style: italic;
    color: #a7a8ab;
  }
}

.grey-text {
  color: #a7a8ab;
}
</style>
