<template>
  <TemplatePage>
    <template #title>Номенклатуры дел</template>

    <template #content>
      <v-alert
        v-if="successUpload"
        icon="mdi-alert"
        type="success"
        dismissible
      >Архив отправлен на обработку
      </v-alert>

      <SearchPanel
        @set-filters="acceptFilters($event)"
        @clear-filters="refreshData()"
        @refresh-data="refreshData($event)"
        @update-success="successUpload = true"
      />

      <!-- ФУНКЦИОНАЛ СКРЫТИЯ КОЛОНОК -->
      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
        <SettingsTableVue
          :code="'nomPage'"
          :headers="headers"
          :headersSettingsOutside="headersSettingsOutside"
          :headersList="headersList"
          @updateHeaders="headers = [...$event]"
        />
      </div>

      <v-data-table
        class="main-table scroll-table sortable-table"
        item-key="id"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        hide-default-footer
        :headers="headers"
        :options.sync="options"
        :items="nomenclaturesResponse.nomenclatures"
        :loading="nomenclatureLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :server-items-length="nomenclaturesResponse.count"
        :header-props="{
        'sort-icon':
          options && options.sortDesc[0]
            ? 'mdi-sort-ascending'
            : 'mdi-sort-descending',
      }"
        @page-count="pageCount = $event"
        @click:row="showDetail"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.tk_status_value="{ item }">
          <span v-if="!item.tk" style="color: #cbcbcd">Нет данных</span>
          <span v-else>{{ item.tk.status.value }}</span>
        </template>

        <template #footer="{ props }">
          <PaginationTable :page.sync="page" :pagination="props.pagination" />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_NOMENCLATURES_RESPONSE } from '@/services/app'
import { mapState } from 'vuex'

import SearchPanel from '../components/SearchPanel.vue'
import SettingsTableVue from '@/components/SettingsTableVue.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'NomenclaturesPage',

  components: {
    TemplatePage,
    SearchPanel,
    SettingsTableVue
  },

  data: () => ({
    nomenclaturesResponse: {},
    filterParams: null,
    successUpload: false,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headersSettingsOutside: ['id', 'num', 'name'],
    headers: [],
    headersList: [
      {
        text: 'Год',
        value: 'year',
        width: '25%'
      },
      {
        text: 'Статус',
        value: 'nom_status.value',
        width: '25%'
      },
      {
        text: 'Статус отправки в ЦХЭД',
        value: 'tk_status_value',
        width: '25%'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '25%'
      }
    ]
  }),
  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          if (!newV.sortBy.length) newV.sortBy[0] = oldV.sortBy[0]
          GET_NOMENCLATURES_RESPONSE(this.filterParams, this.sortParams).then(
            (resp) => {
              this.nomenclaturesResponse = resp
            }
          )
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      nomenclatureLoading: (state) => state.nomenclatures.nomenclatureLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.nomenclaturesResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('nom_status') !== -1) {
            par += 'nom_status_id'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    GET_NOMENCLATURES_RESPONSE().then((resp) => {
      this.nomenclaturesResponse = resp
    })
  },

  methods: {
    acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      GET_NOMENCLATURES_RESPONSE(this.filterParams, this.sortParams).then(
        resp => { this.nomenclaturesResponse = resp }
      )
    },

    closeSettings () {
      this.isShowSettingsTable = false
    },

    refreshData (evt) {
      GET_NOMENCLATURES_RESPONSE().then(resp => { this.nomenclaturesResponse = resp })
      // если передали айдишник то перейти в карточку
      if (evt) this.showDetail(evt)
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-nomenclature', params: { id: _id } })
    }
  }
}
</script>

<style>
</style>
