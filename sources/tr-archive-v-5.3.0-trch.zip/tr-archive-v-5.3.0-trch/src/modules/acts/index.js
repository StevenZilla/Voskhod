import store from './store'
import router from './router'

export default {
  store,
  router
}
