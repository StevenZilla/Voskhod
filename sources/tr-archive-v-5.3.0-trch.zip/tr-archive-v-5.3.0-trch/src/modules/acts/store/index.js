export default {
  namespaced: true,
  state: {
    actsLoading: true
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  }
}
