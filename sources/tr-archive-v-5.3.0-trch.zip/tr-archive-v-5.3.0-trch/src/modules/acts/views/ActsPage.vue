<template>
  <TemplatePage>
    <template #title>Акты приема-передачи</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @clear-filters="refreshData()"
        @refresh-data="refreshData($event)"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
        <SettingsTableVue
          :code="'actsPage'"
          :headers="headers"
          :headersSettingsOutside="headersSettingsOutside"
          :headersList="headersList"
          @updateHeaders="headers = [...$event]"
        />
      </div>

      <v-data-table
        class="main-table scroll-table sortable-table"
        item-key="id"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        hide-default-footer
        :headers="headers"
        :options.sync="options"
        :items="actsList.acts"
        :loading="actsLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :server-items-length="actsList.count"
        :header-props="{
          'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
        }"
        @page-count="pageCount = $event"
      >
        <!-- @click:row="showDetail" -->
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.form_date="{item}">
          <span v-if="item.form_date">{{ item.form_date ? $_formatDate(item.form_date, 'time') : 'Нет данных' }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.register_num="{item}">
          <span v-if="item.register">{{ item.register.num }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.register_year="{item}">
          <span v-if="item.register">{{ item.register.year }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.tk="{ item }">
          <div v-if="item.tk" class="d-flex align-center">
            <v-btn
              color="secondary"
              class="rounded-lg"
              icon
              title="Скачать файл"
              @click.stop="downloadFile(item.tk.path)"
            ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
            </v-btn>
            <span class="active-link">Принят в ТР Архив</span>
          </div>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.pdf_path="{item}">
          <v-btn
            color="secondary"
            class="rounded-lg"
            icon
            title="Скачать файл"
            @click.stop="downloadFile(item.pdf_path)"
          >
            <v-icon color="secondary">mdi-download-circle-outline</v-icon>
          </v-btn>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_ACTS_RESPONSE } from '@/services/app'
import { mapState } from 'vuex'
import TemplatePage from '@/components/TemplatePage.vue'
import SearchPanel from '../components/SearchPanel.vue'

const SettingsTableVue = () => import('@/components/SettingsTableVue.vue')

export default {
  name: 'ActsPage',

  components: {
    TemplatePage,
    SearchPanel,
    SettingsTableVue
  },

  data: () => ({
    actsList: {},
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    fullFilter: false,
    options: null,
    headers: [],
    headersSettingsOutside: ['id', 'index', 'name'],
    headersList: [
      {
        text: 'Номер акта',
        value: 'num',
        width: '150px'
      },
      {
        text: 'Дата формирования акта в ЦХЭД',
        value: 'form_date',
        width: '340px'
      },
      {
        text: 'Номер сводной описи',
        value: 'register_num',
        width: '240px'
      },
      {
        text: 'Год сводной описи',
        value: 'register_year',
        width: '270px'
      },
      {
        text: 'ТК ЦХЭД',
        value: 'tk',
        sortable: false,
        width: '280px'
      },
      {
        text: 'Скачать акт',
        value: 'pdf_path',
        sortable: false,
        width: '100px',
        align: 'center'
      }
    ]
  }),
  watch: {
    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.actsList = await GET_ACTS_RESPONSE(this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      actsLoading: state => state.acts.actsLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.actsList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          par += sortBy
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    GET_ACTS_RESPONSE().then(resp => { this.actsList = resp })
  },

  methods: {
    downloadFile (path) {
      console.log(path)
      const url = this.$config.VUE_APP_HOST.replace('/api', '') + '/' + path
      window.open(url)
    },

    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      this.actsList = await GET_ACTS_RESPONSE(this.filterParams, this.sortParams)
    },

    refreshData (evt) {
      GET_ACTS_RESPONSE().then(resp => { this.actsList = resp })
      // если передали айдишник то перейти в карточку
      if (evt) this.showDetail(evt)
    },

    closeSettings () {
      this.isShowSettingsTable = false
    }
  }
}
</script>

<style>

</style>
