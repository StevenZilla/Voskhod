import { act } from '@/permissions'
const ActsPage = () => import(/* webpackChunkName: 'acts-page' */'../views/ActsPage.vue')

const actsRouter = [
  {
    name: 'ActsPage',
    path: act.path,
    component: ActsPage,
    meta: {
      breadcrumb: [
        {
          text: 'Акты приема-передачи'
        }
      ],
      tech_name: act.code
    }
  }
]

export default router => {
  router.addRoutes(actsRouter)
}
