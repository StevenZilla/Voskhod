<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <ActNumber
        class="w-20"
        ref="number"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <ActFormDate
        class="w-20"
        ref="actFormDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <RegisterNumber
        class="w-20"
        ref="registerNumber"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <ActRegisterYear
        class="w-20"
        ref="actRegisterYear"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import ActNumber from '@/components/Filters/Fields/ActNumber.vue'
import ActFormDate from '@/components/Filters/Fields/ActFormDate.vue'
import RegisterNumber from '@/components/Filters/Fields/Register/RegisterNumber.vue'
import ActRegisterYear from '@/components/Filters/Fields/ActRegisterYear.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'

export default {
  name: 'Filters',
  components: {
    ActNumber,
    ChipsFilters,
    FiltersTemplate,
    ActFormDate,
    RegisterNumber,
    ActRegisterYear,
    FilterFooter
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.number) {
        paramsFilter.append('num', this.filterObj.number.query)
        chips.push(this.filterObj.number)
      }
      if (this.filterObj.actFormDate) {
        paramsFilter.append('start_form_date', this.filterObj.actFormDate.query[0])
        paramsFilter.append('end_form_date', this.filterObj.actFormDate.query[1])
        chips.push(this.filterObj.actFormDate)
      }
      if (this.filterObj.registerNumber) {
        paramsFilter.append('register_num', this.filterObj.registerNumber.query)
        chips.push(this.filterObj.registerNumber)
      }
      if (this.filterObj.actRegisterYear) {
        paramsFilter.append('register_year', this.filterObj.actRegisterYear.query)
        chips.push(this.filterObj.actRegisterYear)
      }

      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.searchTouch = false
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
