<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewApprovedInfo/>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DELETE_ACTS_DETAIL } from '../services/api'

import ViewApprovedInfo from '../components/view-info/ViewApprovedInfo.vue'
import { mapState } from 'vuex'

export default {
  name: 'DetailApproved',

  components: {
    ViewApprovedInfo
  },

  data: () => ({
    confirmCallback: null,
    blocks: [],
    dialog: false,
    url: 'approved',
    clearComponent: 0,
    loading: true
  }),

  computed: {
    ...mapState({
      error: state => state.error
    })
  },

  async mounted () {
    this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: 'view' })
    await this.getData()
  },

  async beforeRouteUpdate (to, from, next) {
    this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: 'view' })
    // this.$store.dispatch('registers/accepted/SET_VALUE', { key: 'dirtyBlocks', value: [] })
    await this.getData(to.params.id)
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    checkEditingMode (next) {
      if (this.modeAct === 'edit') {
        // this.blocks = this.dirtyBlocks.map(item => item.name)
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
        this.resetDataStore()
      }
    },

    resetDataStore () {
      // возможно надо reset у registerTree сделать
      this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: '' })
      this.$store.dispatch('deleteActs/SET_VALUE', { key: 'detailAct', value: {} })
      this.loading = true
      // this.$store.dispatch('deleteActs/SET_VALUE', { key: 'registerStatistic', value: {} })
    },

    confirmLeave () {
      this.dialog = false
      // this.$store.dispatch('registers/accepted/PUSH_ARRAY', null)
      this.confirmCallback()
      this.resetDataStore()
    },

    async getData (id) {
      const _id = id || this.$route.params.id
      this.loading = true
      const url = `${this.url}/${_id}`
      try {
        await GET_DELETE_ACTS_DETAIL(url)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    },

    async refreshData () {
      await this.getData()
      this.clearComponent++
    }
  }
}
</script>

<style lang="scss">
</style>
