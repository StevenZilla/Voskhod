<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewProjectInfo
        v-if="modeAct === 'view'"
        @refresh-data="refreshData"
      />

      <EditingRegister
        v-else-if="modeAct === 'edit'"
        :key="clearComponent"
        @refresh-data="refreshData"
      />

      <v-dialog
        v-model="dialog"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
      >
        <ConfirmCancel
          @cancel="dialog = false"
          @confirm="confirmLeave"
        />
        <!--      :blocks="blocks"-->
      </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DELETE_ACTS_DETAIL } from '../services/api'
import { mapState } from 'vuex'

import ViewProjectInfo from '../components/view-info/ViewProjectInfo.vue'
import ConfirmCancel from '@/components/ConfirmCancel.vue'

const EditingRegister = () => import('../components/editing-info/EditingRegister.vue')

export default {
  name: 'DetailProject',

  components: {
    ConfirmCancel,
    ViewProjectInfo,
    EditingRegister
  },

  data: () => ({
    confirmCallback: null,
    blocks: [],
    dialog: false,
    url: 'project',
    clearComponent: 0,
    loading: true
  }),

  computed: {
    ...mapState({
      modeAct: state => state.deleteActs.modeAct,
      error: state => state.error
    })
  },

  async mounted () {
    this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: 'view' })
    await this.getData()
  },

  async beforeRouteUpdate (to, from, next) {
    this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: 'view' })
    // this.$store.dispatch('registers/accepted/SET_VALUE', { key: 'dirtyBlocks', value: [] })
    await this.getData(to.params.id)
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    checkEditingMode (next) {
      if (this.modeAct === 'edit') {
        // this.blocks = this.dirtyBlocks.map(item => item.name)
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
        this.resetDataStore()
      }
    },

    resetDataStore () {
      // возможно надо reset у registerTree сделать
      this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: '' })
      this.$store.dispatch('deleteActs/SET_VALUE', { key: 'detailAct', value: {} })
      this.loading = true
      // this.$store.dispatch('deleteActs/SET_VALUE', { key: 'registerStatistic', value: {} })
    },

    confirmLeave () {
      this.dialog = false
      // this.$store.dispatch('registers/accepted/PUSH_ARRAY', null)
      this.confirmCallback()
      this.resetDataStore()
    },

    async getData (id) {
      this.loading = true
      const _id = id || this.$route.params.id
      const url = `${this.url}/${_id}`
      try {
        await GET_DELETE_ACTS_DETAIL(url)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    },

    async refreshData () {
      await this.getData()
      this.clearComponent++
    }
  }
}
</script>

<style lang="scss">
</style>
