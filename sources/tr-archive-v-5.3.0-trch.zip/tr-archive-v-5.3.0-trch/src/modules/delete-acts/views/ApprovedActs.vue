<template>
  <TemplatePage>
    <template #title>Утвержденные акты об уничтожении</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @clear-filters="refreshData"
        @refresh-data="refreshData($event)"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
        <SettingsTableVue
          :code="'actsPage'"
          :headers="headers"
          :headersSettingsOutside="headersSettingsOutside"
          :headersList="headersList"
          @updateHeaders="headers = [...$event]"
        />
      </div>

      <v-data-table
        class="main-table scroll-table sortable-table"
        item-key="id"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        hide-default-footer
        :headers="headers"
        :options.sync="options"
        :items="actsList.delete_acts"
        :loading="actsLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :server-items-length="actsList.count"
        :header-props="{
          'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
        }"
        @page-count="pageCount = $event"
        @click:row="showDetail"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template #item.create_date="{ item }">
          {{`${$_formatDate(item.create_date, 'time') ||''}`}}
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import GET_ACTS from '../services/api'
import { mapState } from 'vuex'
import TemplatePage from '@/components/TemplatePage.vue'
import SearchPanel from '../components/SearchPanel.vue'

const SettingsTableVue = () => import('@/components/SettingsTableVue.vue')

export default {
  name: 'ProjectActs',

  components: {
    TemplatePage,
    SearchPanel,
    SettingsTableVue
  },

  data: () => ({
    actsList: {},
    filterParams: null,
    url: 'approved',
    clearForm: 1,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    fullFilter: false,
    options: null,
    headers: [],
    headersSettingsOutside: ['id', 'index', 'name'],
    headersList: [
      {
        text: 'Номер',
        value: 'num',
        width: '150px'
      },
      {
        text: 'Год',
        value: 'year',
        width: '270px'
      },
      {
        text: 'Дата формирования акта',
        value: 'create_date',
        width: '340px'
      }
    ]
  }),
  watch: {
    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.actsList = await GET_ACTS(this.url, this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      actsLoading: state => state.deleteActs.actsLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.actsList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          par += sortBy
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  methods: {
    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      this.actsList = await GET_ACTS(this.url, this.filterParams, this.sortParams)
    },

    refreshData (evt) {
      GET_ACTS(this.url).then(resp => { this.actsList = resp })
      if (evt) this.showDetail(evt)
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-approved-delete-act', params: { id: _id } })
    }
  },

  mounted () {
    GET_ACTS(this.url, this.filterParams).then(resp => { this.actsList = resp })

    if (this.$route.params.id) {
      this.showDetail(Number(this.$route.params.id))
    }
  }
}
</script>

<style>

</style>
