<template>
  <v-card class="select-popup">
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    ><v-toolbar-title>Выбор дел и электронных документов</v-toolbar-title>
      <v-btn icon class="rounded-lg" @click="$emit('close')">
        <v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>

    <AddDossierFilters
      @set-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />

    <div class="main-table-inner">
      <v-data-table
        v-model="selectedDossiers"
        show-select
        item-key="id"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        class="scroll-popup-table sortable-table no-hover"
        hide-default-footer
        show-expand
        :loading="dossierLoading"
        :headers="headersDossiers"
        :options.sync="options"
        :items="dossiersList.dossiers"
        :server-items-length="dossiersList.count"
        :fixed-header="true"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :header-props="{
          'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
        }"
        @page-count="pageCount = $event"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.data-table-select="{ isSelected,select }">
          <v-simple-checkbox
            color="secondary"
            v-ripple
            :value="isSelected"
            @input="select($event)"
          ></v-simple-checkbox>
        </template>

        <template v-slot:expanded-item="{ headers, item }">
          <td :colspan="headers.length">
            <v-data-table
              item-key="id"
              no-data-text="Нет данных"
              disable-sort
              class="expand-table no-hover"
              hide-default-footer
              :headers="headersEds"
              :items="item.eds"
            ></v-data-table>
          </td>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.temp_save_period="{ item }">
          <span v-if="item.save_type">
            {{ item.save_type.value }}<br>
            <font
              v-if="item.temp_save_period"
              class="subtext"
            >({{ `${item.temp_save_period} ${$_declOfNum(words, item.temp_save_period)}` }})</font>
          </span>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />

          <div class="main-table-inner__buttons">
            <v-btn
              data-qa="add-dossier-select"
              class="mr-3 rounded-lg"
              color="secondary"
              :disabled="selectedDossiers.length === 0"
              @click="acceptDossier()"
            >Выбрать</v-btn>
            <v-btn
              outlined
              class="rounded-lg"
              color="secondary"
              @click="$emit('close')"
            >Отменить</v-btn>
          </div>
        </template>
      </v-data-table>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import { GET_DOSSIERS_LIST } from '@/services/app'
const AddDossierFilters = () => import('./AddDossierFilters.vue')

export default {
  name: 'AddDossier',
  props: {
    isOpen: {
      type: Boolean,
      required: true
    },

    excludeDossierIds: {
      type: Array,
      required: false,
      default: () => {
        return []
      }
    },

    includeDossierIds: {
      type: Array,
      required: false,
      default: () => {
        return []
      }
    }
  },
  components: {
    AddDossierFilters
  },

  data: () => ({
    words: ['год', 'года', 'лет'],
    dossiersList: {},
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    selectedDossiers: [],
    headersDossiers: [
      {
        text: 'Индекс дела',
        value: 'index',
        width: '36%'
      },
      {
        text: 'Заголовок дела',
        value: 'name',
        width: '36%'
      },
      {
        text: 'Срок хранения',
        value: 'temp_save_period',
        width: '20%'
      },
      {
        text: '',
        value: 'data-table-expand'
      }
    ],
    headersEds: [
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '36%'
      },
      {
        text: 'Наименование документа',
        value: 'name',
        width: '36%'
      }
    ]
  }),

  watch: {
    isOpen: {
      async handler (newV) {
        if (newV) {
          GET_DOSSIERS_LIST(this.sortParams).then(resp => { this.dossiersList = resp })
        }
      },
      immediate: true
    },

    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.dossiersList = await GET_DOSSIERS_LIST(this.sortParams)
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      registerSubdivisionFilter: state => state.registers.accepted.registerSubdivisionFilter,
      dossierLoading: state => state.dossiers.dossierLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      paramsSort.append('sort', 'dossier_name,dossier_index')
      paramsSort.append('is_only_without_accept_register', 'true')
      paramsSort.append('dossier_status', 'closed')
      paramsSort.append('dossier_subdivision', this.registerSubdivisionFilter)
      if (this.excludeDossierIds.length) paramsSort.append('exclude_dossier_ids', `[${this.excludeDossierIds}]`)
      if (this.includeDossierIds.length) paramsSort.append('include_dossier_ids', `[${this.includeDossierIds}]`)
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.dossiersList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) par = '-'
          par += sortBy
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  methods: {
    async acceptFilters (evt) {
      // this.filterParams.set('exclude_dossier_ids', `[${this.excludeDossierIds}]`)
      // this.filterParams = this.combineSearchParamsMix(this.filterParams, evt)
      this.dossiersList = await GET_DOSSIERS_LIST(evt, this.sortParams)
    },

    clearFilters () {
      // this.filterParams.set('exclude_dossier_ids', `[${this.excludeDossierIds}]`)
      GET_DOSSIERS_LIST(this.sortParams).then(resp => { this.dossiersList = resp })
    },

    acceptDossier () {
      this.$emit('select-dossier', this.selectedDossiers)
      this.selectedDossiers = []
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss">
</style>
