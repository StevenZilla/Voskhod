<template>
  <FiltersTemplate
    class="filter--dialog"
    :full-filter="true"
  >
    <template #filter-fields>
      <EdName
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierName
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdNumber
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierIndex
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import FilterFooter from '@/components/Filters/FilterFooter.vue'
import EdName from '@/components/Filters/Fields/Ed/EdName.vue'
import DossierName from '@/components/Filters/Fields/Dossier/DossierName.vue'
import EdNumber from '@/components/Filters/Fields/Ed/EdNumber.vue'
import DossierIndex from '@/components/Filters/Fields/Dossier/DossierIndex.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

export default {
  components: {
    FiltersTemplate,
    FilterFooter,
    EdName,
    DossierName,
    EdNumber,
    DossierIndex
  },

  data: () => ({
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.edName) {
        paramsFilter.append('ed_name', this.filterObj.edName.query)
      }
      if (this.filterObj.edNumber) {
        paramsFilter.append('ed_num', this.filterObj.edNumber.query)
      }
      if (this.filterObj.dossierName) {
        paramsFilter.append('name', this.filterObj.dossierName.query)
      }
      if (this.filterObj.index) {
        paramsFilter.append('index', this.filterObj.index.query)
      }
      return paramsFilter
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    acceptFilters () {
      this.searchTouch = true
      this.$emit('set-filters', this.filterParams)
      this.clear = true
    },

    clearFilters () {
      this.resetFilter = true
      this.$nextTick(() => {
        this.resetFilter = false
        this.$emit('clear-filters')
        this.searchTouch = false
      })
    }
  }
}
</script>

<style>
</style>
