<template>
  <div class="structure__table-dossier">
    <v-progress-linear
      v-if="loading"
      indeterminate
      height="5"
      color="secondary"
    ></v-progress-linear>

    <v-treeview
      class="structure__table-tree"
      return-object
      expand-icon=""
      transition
      activatable
      :active-class="''"
      :items="registerDossiers"
      :open="openNodes"
      :item-key="'id'"
    >
      <!-- eslint-disable-next-line -->
      <template slot="label" slot-scope="nodeItem">
        <p
          v-if="nodeItem.item.id !== -1"
          class="structure__table-name"
          :ref="nodeItem.item.name"
          @click="showDetailRegister(nodeItem.item)"
        >{{ nodeItem.item.name }}</p>
        <v-data-table
          item-key="id"
          hide-default-footer
          disable-pagination
          disable-sort
          no-data-text="Нет данных"
          class="no-hover"
          :headers="headers"
          :items="nodeItem.item.dossiers"
          @click:row="showDetail($event)"
          da-dossier-right-tab
        >

          <!-- eslint-disable-next-line -->
          <template v-slot:item.temp_save_period="{ item }">
            <span v-if="item.save_type && item.save_type.code === 'temporarily'">
              {{ `${item.temp_save_period} ${$_declOfNum(words, item.temp_save_period)}` }}
            </span>
            <span v-else>Постоянно</span>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.date="{ item }">
            <span>{{ `${$_formatDate(item.start_date)} — ${$_formatDate(item.end_date)}` }}</span>
          </template>

          <template v-slot:item.di_kinds="{ item }">
            <div
              v-for="(kind, idx) in item.di_kinds"
              :key="idx"
            >
              <v-tooltip top>
                <template v-slot:activator="{ on, attrs }">
                <span
                  style="font-size: 12px"
                  v-bind="attrs"
                  v-on="on"
                >{{ kind.num_show }}</span>
                </template>
                <span>{{ kind.name }}</span>
              </v-tooltip>
            </div>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.actions="{ item, index }">
            <v-btn
                v-if="modeAct !== 'view'"
                color="secondary"
                class="rounded-lg"
                icon
                @click="deleteDossier(item, index)"
            >
              <v-icon color="secondary">mdi-trash-can-outline</v-icon>
            </v-btn>
          </template>
        </v-data-table>
      </template>
    </v-treeview>

    <v-dialog
        v-model="isDelete"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
    >
      <AlertPopup
          :title="'Удаление дела'"
          :text="'Все документы, входящие в данное дело, будут удалены из раздела.'"
          @close-popup="isDelete = false"
          @confirm-delete="confirmDelete()"
      />
    </v-dialog>
  </div>
</template>

<script>

import { dossierDetail } from '@/permissions'
import { mapActions, mapState } from 'vuex'
const AlertPopup = () => import('@/components/AlertPopup.vue')

export default {
  name: 'TabDossiers',
  props: {
    openNodes: {
      type: Array
    }
  },

  components: {
    AlertPopup
  },

  data: () => ({
    words: ['год', 'года', 'лет'],
    loading: false,
    isDelete: false,
    deleteInfo: {},
    includeDossierIds: [],
    excludeDossierIds: [],
    headers: [
      {
        text: '№',
        align: 'start',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Индекс дела',
        value: 'index',
        width: '140px'
      },
      {
        text: 'Заголовок дела',
        value: 'name',
        width: '400px',
        align: 'justify'
      },
      {
        text: 'Крайние даты',
        value: 'date',
        width: '150px'
      },
      {
        text: '№ в описи',
        value: 'order_in_register',
        width: '60px'
      },
      {
        text: 'Кол-во ед.хр.',
        value: 'number_storage_units',
        width: '100px'
      },
      {
        text: 'Статья хранения',
        value: 'di_kinds',
        width: '150px'
      },
      {
        text: 'Срок хранения',
        value: 'temp_save_period',
        width: '100px'
      },
      {
        text: 'Примечание',
        value: 'change_reason',
        width: '100px',
        align: 'justify'
      },
      {
        text: '',
        value: 'actions'
      }
    ]
  }),

  computed: {
    ...mapState({
      modeAct: state => state.deleteActs.modeAct
    }),

    registerDossiers () {
      return this.$store.getters['deleteActs/GET_INFO_TABLE']
    }
  },

  methods: {
    ...mapActions('deleteActs', ['REMOVE_DOSSIER']),

    showDetail (e) {
      if (this.modeAct !== 'view') return
      const path = `${dossierDetail.path}/${e.id}`

      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    },

    showDetailRegister (e) {
      if (e.register_status.code === 'approved') this.$router.push({ name: 'detail-approved-register', params: { id: e.id } })
      else this.$router.push({ name: 'detail-project-register', params: { id: e.id } })
    },

    deleteDossier (node, index) {
      this.deleteInfo.node = node
      this.deleteInfo.index = index
      this.isDelete = true
    },

    confirmDelete () {
      // добавляем любое удаленное дело в массив
      const dossier = this.deleteInfo.node
      this.includeDossierIds.push(dossier.id)
      const dossierIndex = this.excludeDossierIds.findIndex(id => id === dossier.id)
      this.excludeDossierIds.splice(dossierIndex, 1)
      this.REMOVE_DOSSIER({ nodeId: this.deleteInfo.node.id })
      this.isDelete = false
    }
  }
}
</script>

<style lang="scss">
@media screen and (min-width: 2200px) {
  [da-dossier-right-tab] table {
    col:nth-child(1),
    col:nth-child(2) {
      min-width: 100px;
    }
    col:nth-child(3) {
      min-width: 600px;
    }
    col:nth-child(4),
    col:nth-child(7) {
      min-width: 250px;
    }
    col:nth-child(4) {
      min-width: 100px;
      max-width: 300px;
    }
  }
}

</style>
