<template>
  <div class="card">
    <h2 data-qa="name-register-view" class="detail__title">{{ actName }}</h2>

    <ViewMainInfo/>

    <ViewStructure/>

    <Agreements
        @refresh-data="$emit('refresh-data')"
    />

    <TemplateButtons>
      <template #buttons-left>
        <BtnEditing v-if="$can('edit_project', 'delete_act') && actViewButtons.is_edit"/>

        <BtnCreateAgreement
          v-if="$can('send_ek', 'delete_act') && actViewButtons.send_ec_agreement"
          @refresh-data="$emit('refresh-data')"
        />

        <BtnDecide
          v-if="$can('decision', 'delete_act') && agreementViewButtons && (agreementViewButtons.can_affirmative || agreementViewButtons.can_agreeing)"
          @refresh-data="$emit('refresh-data')"
        />

        <BtnApprove
          v-if="agreementViewButtons && agreementViewButtons.can_approve"
          @refresh-data="$emit('refresh-data')"
        />
      </template>

      <template #buttons-right>
        <v-btn
          data-qa="close"
          color="secondary"
          class="rounded-lg"
          @click="$_closeDetail()"
        >
          Закрыть
        </v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import ViewMainInfo from './ViewMainInfo.vue'
import ViewStructure from './ViewStructure.vue'
import Agreements from '../agreements/Agreements.vue'
import BtnEditing from '../buttons-detail/BtnEditing.vue'
import BtnCreateAgreement from '../buttons-detail/BtnCreateAgreement.vue'
import BtnDecide from '../buttons-detail/BtnDecide.vue'
import BtnApprove from '../buttons-detail/BtnApprove.vue'

export default {
  components: {
    BtnCreateAgreement,
    BtnEditing,
    ViewMainInfo,
    ViewStructure,
    Agreements,
    BtnDecide,
    BtnApprove
  },

  data: () => ({
    isSelectCertificate: false
  }),

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY', 'GET_REGISTER_AGREEMENT_KEY']),
    ...mapGetters('deleteActs/agreements', ['GET_VIEW_AGREEMENT_BUTTONS']),

    actName () {
      return this.GET_REGISTER_KEY('num')
    },

    actViewButtons () {
      return this.GET_REGISTER_KEY('view_buttons')
    },
    agreementViewButtons () {
      return this.GET_VIEW_AGREEMENT_BUTTONS
    }
  }
}
</script>

<style>

</style>
