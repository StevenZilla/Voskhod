<template>
  <div class="card">
    <h2 data-qa="name-register-view" class="detail__title">{{ actName }}</h2>

    <ViewMainInfo/>

    <ViewStructure/>

    <Agreements/>

    <TemplateButtons>
      <template #buttons-right>
        <v-btn
          data-qa="close"
          color="secondary"
          class="rounded-lg"
          @click="$_closeDetail()"
        >
          Закрыть
        </v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import ViewMainInfo from './ViewMainInfo.vue'
import ViewStructure from './ViewStructure.vue'
import Agreements from '../agreements/Agreements.vue'

export default {
  components: {
    ViewMainInfo,
    ViewStructure,
    Agreements
  },

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    actName () {
      return this.GET_REGISTER_KEY('num')
    }
  }
}
</script>

<style>

</style>
