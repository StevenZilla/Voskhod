<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Информация о делах/документах</h2>
    </v-card-title>

    <LoadingComponentVue v-if="loading"/>

    <div v-else class="structure d-flex">
      <!-- дерево -->
      <div data-qa="structure-register-view" class="structure__tree" da-left>
        <TreeviewHeader
          :open-nodes="openNodes"
          @switch-nodes="switchNodes()"
          :disable="!registerTree[0].children.length"
        />

        <v-treeview
          color="secondary"
          return-object
          ref="tree"
          transition
          activatable
          open-all
          :items="registerTree"
          :item-key="'id'"
          :open.sync="openNodes"
          @update:active="setSelectedNode"
        ><!-- eslint-disable-next-line -->
          <template v-slot:prepend="{ item }">
            <v-icon color="secondary">mdi-{{ item.id === -1 ? 'note-edit-outline' : 'note-outline' }}</v-icon>
          </template>
        </v-treeview>
      </div>

      <StructureInfo :open-nodes="openNodes" ref="structureInfo"/>
    </div>
  </v-card>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import TreeviewHeader from '@/components/TreeviewHeader.vue'
import { GET_PROJECT_PARTS } from '../../services/api'

const StructureInfo = () => import('../StructureInfo.vue')

export default {
  name: 'ViewStructure',

  components: {
    StructureInfo,
    TreeviewHeader
  },

  data: () => ({
    openNodes: [],
    loading: true,
    selectedNode: null
  }),

  computed: {
    ...mapState({
      registerTree: state => state.deleteActs.registerTree
    }),

    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    id () {
      return this.GET_REGISTER_KEY('id')
    },

    num () {
      return this.GET_REGISTER_KEY('num')
    }

    // url () {
    //   let _url = ''
    //   if (this.$route.path.includes('/accept/project')) _url = `project_register/${this.id}`
    //   if (this.$route.path.includes('/accept/approved')) _url = `approved_register/${this.id}`
    //   return _url
    // }
  },

  mounted () {
    this.getData()
  },

  methods: {
    createTree (resp) {
      if (resp.dossiers.length || resp.eds.length) resp.registers.push({ name: 'Без описи', dossiers: resp.dossiers, eds: resp.eds })
      return [{
        id: -1,
        name: 'Акт об уничтожении №' + this.num,
        children: resp.registers
      }]
    },

    addDossiers (registerPart, node) {
      if (!registerPart.id) node.dossiers = registerPart.dossiers
      if (registerPart.id === node.id) node.dossiers = registerPart.dossiers
      else {
        node.children.forEach(child => {
          this.addDossiers(registerPart, child)
        })
      }
    },

    async getData () {
      this.loading = true

      const resp = await GET_PROJECT_PARTS(`${this.$route.params.id}`)
      const tree = this.createTree(resp)
      await this.$store.dispatch('deleteActs/SET_VALUE', { key: 'registerTree', value: tree })
      this.loading = false
    },

    switchNodes () {
      this.openNodes.length ? this.$refs.tree.updateAll(false) : this.$refs.tree.updateAll(true)
    },

    // showDetail (e) {
    //   const path = `${dossierDetail.path}/${e.id}`
    //
    //   if (this.$route.path !== path) {
    //     this.$router.push(path)
    //   }
    // },

    setSelectedNode (items) {
      if (items.length > 0) this.selectedNode = items[0]
      this.$refs.structureInfo.$refs.tabDossiers.$refs[items[0].name].scrollIntoView({ behavior: 'smooth', block: 'center' })
      this.$refs.structureInfo.$refs.tabEds.$refs[items[0].name].scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }
}
</script>

<style lang="scss">
  @media screen and (max-width: 2200px) {
    [da-left] {
      width: 370px;
    }
  }
  @media screen and (min-width: 2201px) {
    [da-left] {
      width: 410px;
    }
  }
</style>
