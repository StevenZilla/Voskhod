<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mb-0">Общая информация</h2>
      <v-icon
        icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >{{ chevron }}</v-icon>
    </v-card-title>

    <transition name="fade" mode="out-in">
      <v-card-text class="detail__view-inner item-5" :class="{open: isMainInfo}" v-if="isMainInfo">
        <div class="detail__item">
          <p class="detail__item-title">Номер</p>
          <span data-qa="num-register-view" class="detail__value">{{ detailAct.num }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Год</p>
          <span data-qa="year-register-view" class="detail__value">{{ detailAct.year }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Дата формирования</p>
          <span data-qa="create-date-register-view" class="detail__value">{{ $_formatDate(detailAct.create_date, 'time') }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Статус</p>
          <span
              data-qa="status-register-view"
              class="detail__value"
          >{{ checkStatus }}
        </span>
        </div>
      </v-card-text>
    </transition>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'ViewMainInfo',

  data: () => ({
    isMainInfo: true
  }),

  computed: {
    ...mapState({
      detailAct: state => state.deleteActs.detailAct
    }),

    checkStatus () {
      if (this.detailAct.status) return this.detailAct.status.value
      return 'Нет данных'
    },

    chevron () {
      return this.isMainInfo ? 'mdi-chevron-up' : 'mdi-chevron-down'
    }
  },

  methods: {

  }
}
</script>

<style>

</style>
