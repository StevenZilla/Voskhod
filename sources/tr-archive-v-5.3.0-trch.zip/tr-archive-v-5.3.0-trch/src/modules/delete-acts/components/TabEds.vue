<template>
  <v-treeview
    class="structure__table-tree"
    return-object
    open-all
    expand-icon=""
    transition
    activatable
    :active-class="''"
    :items="registerDossiers"
    :open="openNodes"
  ><!-- eslint-disable-next-line -->
    <template v-slot:label="{ item }">
      <p
        v-if="item.id !== -1"
        class="structure__table-name"
        :ref="item.name"
        @click="showDetailRegister(item)">{{ item.name }}</p>
      <v-data-table
        item-key="id"
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        :class="{'no-hover': modeAct !== 'view'}"
        :headers="headersEd"
        :items="item.eds"
        @click:row="showDetail($event)"
      >
        <template v-slot:item.num="{ item }">
          <span class="d-flex">
            <v-icon v-if="item.has_act" class="mr-2" color="success">mdi-check-circle-outline</v-icon>
            {{ item.num }}
          </span>
        </template>

        <template v-slot:item.tk="{item}">
          <span v-if="!item.tk" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.tk.status.value }}</span>
        </template>

        <template v-slot:item.reg_date="{item}">
          <span v-if="item.reg_date">{{ $_formatDate(item.reg_date) }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.actions="{ item, index }">
          <v-btn
              v-if="modeAct !== 'view'"
              color="secondary"
              class="rounded-lg"
              icon
              @click="deleteDossier(item, index)"
          >
            <v-icon color="secondary">mdi-trash-can-outline</v-icon>
          </v-btn>
        </template>
      </v-data-table>
    </template>
  </v-treeview>
</template>

<script>

import { edDetail } from '@/permissions'
import { mapActions, mapState } from 'vuex'

export default {
  name: 'TabEds',

  props: {
    openNodes: {
      type: Array
    }
  },

  data: () => ({
    headersEd: [
      {
        text: '№',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Индекс дела',
        value: 'dossier_index',
        width: '200px'
      },
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '250px'
      },
      {
        text: 'Наименование документа',
        value: 'name',
        width: '500px'
      },
      {
        text: 'Дата рег-ции документа',
        value: 'reg_date',
        width: '250px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type.value',
        width: '250px'
      },
      {
        text: 'Примечание',
        value: 'change_reason',
        width: '250px'
      },
      {
        text: '',
        value: 'actions'
      }
    ]
  }),

  computed: {
    ...mapState({
      modeAct: state => state.deleteActs.modeAct
    }),

    registerDossiers () {
      return this.$store.getters['deleteActs/GET_INFO_TABLE']
    }
  },

  methods: {
    ...mapActions('deleteActs', ['REMOVE_EDS']),

    collectArrayEds (dossiersArray) {
      console.log(dossiersArray)
      const edsArray = []

      dossiersArray.forEach(dossier => {
        dossier.eds.forEach(ed => {
          ed.dossier_index = dossier.index
          edsArray.push(ed)
        })
      })
      return edsArray
    },

    showDetail (e) {
      if (this.modeAct !== 'view') return
      const path = `${edDetail.path}/${e.id}`

      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    },

    deleteDossier (node) {
      this.deleteInfo = node
      this.REMOVE_EDS({ nodeId: this.deleteInfo.id, key: 'id' })
    },

    showDetailRegister (e) {
      if (e.register_status.code === 'approved') this.$router.push({ name: 'detail-approved-register', params: { id: e.id } })
      else this.$router.push({ name: 'detail-project-register', params: { id: e.id } })
    }
  }
}
</script>

<style>

</style>
