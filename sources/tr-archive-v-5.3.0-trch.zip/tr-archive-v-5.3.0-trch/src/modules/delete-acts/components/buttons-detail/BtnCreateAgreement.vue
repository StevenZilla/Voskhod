<template>
  <v-btn
    color="secondary"
    class="mr-3 rounded-lg"
    outlined
    :loading="loading"
    @click="createAgreement"
  >
    <v-icon class="mr-2">mdi-send-circle-outline</v-icon>
    Отправить на согласование ЭК
  </v-btn>
</template>

<script>

import { SEND_AGREEMENT } from '../../services/api'
import { mapGetters } from 'vuex'

export default {
  data: () => ({
    loading: false
  }),

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    actId () {
      return this.GET_REGISTER_KEY('id')
    }
  },

  methods: {
    async createAgreement () {
      this.loading = true
      await SEND_AGREEMENT(this.actId)
      this.loading = false
      // await GET_ACCEPT_AGREEMENTS(this.registerId)
      this.$emit('refresh-data')
    }
  }
}
</script>

<style lang="scss">

</style>
