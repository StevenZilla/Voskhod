<template>
  <v-dialog
    v-model="isDecide"
    max-width="1280"
    transition="scroll-y-transition"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        color="secondary"
        data-qa="make-decision"
        class="mr-3 rounded-lg"
        outlined
        v-bind="attrs"
        v-on="on"
      >
        <v-icon class="mr-1">$vuetify.icons.solution</v-icon>
        Вынести решение
      </v-btn>
    </template>

    <v-card class="dialog-component">
      <v-toolbar-title>Решение</v-toolbar-title>

      <div class="dialog-component__content">
        <span>Тип решения</span>
        <div class="dialog-block">
          <div class="decision-block">
            <template v-if="loading">
              <v-skeleton-loader
                v-for="(n, idx) in 3"
                type="heading"
                height="40px"
                :key="idx"
              ></v-skeleton-loader>
            </template>

            <v-radio-group v-else v-model="decisionObj.decision_type">
              <v-radio
                v-for="(decision, ind) in decisionTypesList"
                color="secondary"
                data-qa="decision-radio"
                :value="decision"
                :key="ind"
                :label="decision.value"
              ></v-radio>
            </v-radio-group>

            <v-textarea
              v-model="decisionObj.comment"
              maxlength="2000"
              data-qa="decision-comment"
              class="rounded-lg"
              rounded
              outlined
              rows="4"
              hide-details
              placeholder="Введите комментарий"
              clearable
              no-resize
            >
              <template v-slot:append-outer>
                <v-counter :value="decisionObj.comment ? decisionObj.comment.length : 0" :max="2000"/>
              </template>
            </v-textarea>

            <label class="file-load">
              <v-file-input
                v-model="decisionObj.files_comment"
                truncate-length="60"
                prepend-icon=""
                class="rounded-lg"
                rounded
                multiple
                outlined
                placeholder="Прикрепите файл"
              >
                <template #append>
                  <v-btn
                    style="cursor:pointer"
                    tag="span"
                    color="secondary"
                    class="rounded-lg"
                  >
                    <v-icon size="20" class="mr-1">mdi-folder-outline</v-icon>
                    Выбрать файл...
                  </v-btn>
                </template>
              </v-file-input>
            </label>
          </div>
        </div>
      </div>

      <div class="dialog-component__actions">
        <v-btn
          outlined
          class="rounded-lg mr-4"
          color="secondary"
          @click="isDecide = false"
        >Отменить
        </v-btn>
        <v-btn
          v-if="!isAwaitRequest"
          data-qa="make-decision-dialog"
          class="rounded-lg"
          color="secondary"
          :loading="loading"
          :disabled="!decisionObj.decision_type"
          @click="accessCheck"
        >Вынести решение
        </v-btn>
        <v-btn
          v-else
          data-qa="make-decision-dialog"
          class="rounded-lg"
          color="secondary"
          :loading="loading"
          disabled
        >Вынести решение - идет отправка
        </v-btn>
      </div>
    </v-card>

    <v-dialog
      v-model="isSelectCertificate"
      content-class="dialog-auto-height"
      max-width="520px"
    >
      <WrapperProjectContainers
        :title="'Утверждение'"
        :filter="'code=eds_register'"
        @submit="fillFormData($event)"
        @close-popup="isSelectCertificate = false"
      />
    </v-dialog>
  </v-dialog>
</template>

<script>

import { GET_DECISION_TYPES, SEND_AFFIRMATIVE_DECISION, SEND_AGREEING_DECISION } from '../agreements/services/api'
import { mapGetters } from 'vuex'

const WrapperProjectContainers = () => import('../agreements/components/WrapperProjectContainers.vue')

export default {
  name: 'BtnDecide',

  components: {
    WrapperProjectContainers
  },

  data: () => ({
    isDecide: false,
    loading: false,
    isAwaitRequest: false,
    loadingStatuses: false,
    decisionTypesList: [],
    isSelectCertificate: false,
    decisionObj: {
      files_comment: [],
      decision_type: null,
      comment: '',
      thumbprint: []
    }
  }),

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    ...mapGetters('deleteActs/agreements', ['GET_VIEW_AGREEMENT_BUTTONS']),

    id () {
      return this.GET_REGISTER_KEY('id')
    }
  },

  async mounted () {
    this.loadingStatuses = true
    this.decisionTypesList = await GET_DECISION_TYPES()
    this.loadingStatuses = false
  },

  methods: {
    accessCheck () {
      if (this.GET_VIEW_AGREEMENT_BUTTONS.can_affirmative) this.isSelectCertificate = true
      else if (this.GET_VIEW_AGREEMENT_BUTTONS.can_agreeing) this.fillFormData()
    },

    async fillFormData (evt = '') {
      this.loading = true
      this.isSelectCertificate = false
      const formData = new FormData()
      this.decisionObj.files_comment.forEach(file => {
        formData.append('files_comment[]', file)
      })
      formData.append('comment', this.decisionObj.comment)
      formData.append('decision_type_id', this.decisionObj.decision_type.id)
      formData.append('thumbprint', String(evt))
      formData.append('_method', 'patch')

      await this.submitHandler(formData)
      this.loading = false
    },

    async submitHandler (formData) {
      try {
        this.loading = true
        if (this.GET_VIEW_AGREEMENT_BUTTONS.can_affirmative) await SEND_AFFIRMATIVE_DECISION(this.id, formData)
        else if (this.GET_VIEW_AGREEMENT_BUTTONS.can_agreeing) await SEND_AGREEING_DECISION(this.id, formData)
        this.$emit('refresh-data')
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">

.dialog-component {
  display: flex;
  padding: 16px;
  flex-direction: column;

  .popup-toolbar {
    flex: none;
  }

  &__content {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    margin-top: 16px;

    & > span {
      display: inline-block;
      font-size: 14px;
      margin-bottom: 8px;
      color: #76767A;
    }
  }

  &__actions {
    padding-top: 16px;
    display: flex;
    justify-content: flex-end;
  }

  .dialog-block {
    height: 100%;

    .decision-block {
      height: 100%;
      display: flex;
      flex-direction: column;

      .v-skeleton-loader {
        flex: none;
      }

      .v-input--radio-group {
        margin-bottom: 16px;
      }

      .v-radio {
        padding: 6px 12px;
        background: #F5F5F7;
        border: 2px solid #F5F5F7;
        border-radius: 8px;
        transition: .3s;

        .v-label {
          color: #000
        }

        .v-icon {
          color: var(--v-secondary-base);
        }

        &.v-item--active {
          background: #FFFFFF;
          border-color: #9DBDED;
        }
      }

      .v-textarea {
        flex: 1 1 auto;
        height: 100%;

        .v-input__control {
          height: 100%;

          .v-input__slot {
            height: 100%;
          }
        }
      }

      .file-load {
        display: block;
        margin-top: 16px;

        .v-input__slot {
          min-height: 40px !important;
          padding-right: 5px;
        }

        .v-btn {
          height: 32px !important;
          font-size: 14px !important;
        }
      }
    }
  }
}
</style>
