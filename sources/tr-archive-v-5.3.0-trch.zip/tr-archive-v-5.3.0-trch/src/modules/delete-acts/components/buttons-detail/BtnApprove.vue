<template>
  <v-dialog
    v-model="isSend"
    max-width="425px"
    transition="scroll-y-transition"
    content-class="dialog-auto-height"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        color="secondary"
        class="rounded-lg"
        outlined
        :loading="loading"
        v-bind="attrs"
        v-on="on"
      >
        <v-icon class="mr-2">mdi-check</v-icon>
        Утвердить
      </v-btn>
    </template>

<!--TODO ПЕРЕПИСАТЬ!!!!!!!! -->
    <WrapperProjectContainers
      :title="'Утверждение'"
      :filter="filter"
      :thumb-count="1"
      :is-act="true"
      @submit="fillFormData($event)"
    />
  </v-dialog>
</template>

<script>

import WrapperProjectContainers from '@/modules/registers/submodules/summary/components/WrapperProjectContainers.vue'
import { APPROVE_AGREEMENT } from '../agreements/services/api'
import { mapGetters } from 'vuex'

export default {
  components: { WrapperProjectContainers },

  data: () => ({
    filter: 'code=eds_register',
    loading: false,
    isSend: false
  }),

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    id () {
      return this.GET_REGISTER_KEY('id')
    }
  },

  methods: {
    async fillFormData (thumb) {
      this.loading = true
      const sendData = {
        thumbprint: thumb[0]
      }
      await APPROVE_AGREEMENT(this.id, sendData)
      // this.$emit('refresh-data')
      this.loading = false
      this.isSend = false
    }
  }
}
</script>

<style lang="scss">
</style>
