<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <RegisterYear
        class="w-20"
        ref="year"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <ActFormDate
        class="w-20"
        ref="actFormDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DeleteActStatus
          v-if="isProjects"
          class="w-22"
          ref="deleteActStatus"
          :reset-filter="resetFilter"
          :is-load="isLoad"
          @set-filter="setFilter($event)"
      />

      <Signer
        class="w-22"
        ref="signer"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import RegisterYear from '@/components/Filters/Fields/Register/RegisterYear.vue'
import DeleteActStatus from '@/components/Filters/Fields/DeleteActStatus.vue'
import ActFormDate from '@/components/Filters/Fields/ActFormDate.vue'
import Signer from '@/components/Filters/Fields/Signer.vue'

export default {
  name: 'Filters',
  components: {
    ActFormDate,
    RegisterYear,
    Signer,
    DeleteActStatus,
    FilterFooter,
    ChipsFilters,
    FiltersTemplate
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },
    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.year) {
        paramsFilter.append('year', this.filterObj.year.query)
        chips.push(this.filterObj.year)
      }
      if (this.filterObj.actFormDate) {
        paramsFilter.append('start_date', this.filterObj.actFormDate.query[0])
        paramsFilter.append('end_date', this.filterObj.actFormDate.query[1])
        chips.push(this.filterObj.actFormDate)
      }
      if (this.filterObj.deleteActStatus) {
        paramsFilter.append('status', this.filterObj.deleteActStatus.query.value)
        chips.push(this.filterObj.deleteActStatus)
      }
      if (this.filterObj.signer) {
        paramsFilter.append('participant_in_agreement', this.filterObj.signer.query.value)
        chips.push(this.filterObj.signer)
      }

      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    },

    isProjects () {
      return this.$route.path === '/acts-delete/projects'
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.resetFilter = false
        this.searchTouch = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
