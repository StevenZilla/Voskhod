<template>
  <div class="structure__table">
    <div class="structure__info justify-end align-end">
      <v-tabs class="tabs-pills" v-model="tabItem">
        <v-tab :ripple="false">Дела</v-tab>
        <v-tab :ripple="false">Документы</v-tab>
      </v-tabs>
    </div>

    <div class="structure__table-title">
      <span>{{ registerTree[0].name }}</span>
    </div>

    <v-tabs-items class="tabs-pills" right v-model="tabItem">
      <v-tab-item :eager="true">
        <TabDossiers :open-nodes="openNodes" @change-valid="$emit('change-valid', $event)" ref="tabDossiers"/>
      </v-tab-item>

      <v-tab-item :eager="true">
        <TabEds :open-nodes="openNodes" ref="tabEds"/>
      </v-tab-item>
    </v-tabs-items>
    <resize-width></resize-width>
  </div>
</template>

<script>

import TabEds from './TabEds.vue'
import ResizeWidth from '@/components/ResizeWidth.vue'
import { mapState } from 'vuex'
const TabDossiers = () => import('./TabDossiers.vue')

export default {
  components: {
    TabDossiers,
    TabEds,
    ResizeWidth
  },

  props: {
    openNodes: {
      type: Array
    }
  },

  data: () => ({
    tabItem: 0
  }),

  computed: {
    ...mapState({
      registerTree: state => state.deleteActs.registerTree
    })
  }
}
</script>

<style lang="scss">

</style>
