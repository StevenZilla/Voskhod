<template>
  <div class="card">
    <v-alert v-if="isSame" icon="mdi-alert" type="error">
      {{ errorData.message }}
    </v-alert>

    <EditingMainInfo
      :trigger="trigger"
      :error-data="errorData"
      @change-valid="invalidMainForm = $event"
      @fill-data="fillData($event)"
    />

    <EditingStructure
      :trigger="trigger"
      :error-data="errorData"
      @change-valid="invalidStructure = $event"
      @fill-data="fillData($event)"
    />

    <TemplateButtons>
      <template #buttons-left>
        <BtnSaveSlot
          :loading="loading"
          :disabled="invalidInfo"
          @save="updateHandler()"
        />
      </template>

      <template #buttons-right>
        <BtnCancelSlot
          :text="'Отменить'"
          @close="cancelEdit()"
        />
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import { UPDATE_ACT } from '../../services/api'
import EditingMainInfo from './EditingMainInfo.vue'
import EditingStructure from './EditingStructure.vue'

export default {
  name: 'EditingRegister',
  components: {
    EditingMainInfo,
    EditingStructure
  },

  data: () => ({
    loadingComponent: true,
    trigger: 0,
    invalidMainForm: false,
    invalidStructure: false,
    loading: false,
    errorData: {},
    isLoadStructure: true,
    isSame: false,
    editDetailRegister: {},
    isDeleteEd: false
  }),

  computed: {
    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    id () {
      return this.GET_REGISTER_KEY('id')
    },

    invalidInfo () {
      return this.invalidMainForm || this.invalidStructure
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.editDetailRegister, evt)
        resolve()
      })
    },

    cancelEdit () {
      this.$store.dispatch('deleteActs/SET_VALUE', { key: 'modeAct', value: 'view' })
      this.$emit('refresh-data')
    },

    async updateHandler () {
      this.loading = true
      this.trigger++
      await this.fillData()
      const resp = await UPDATE_ACT(this.id, this.editDetailRegister)
      if (resp?.status >= 200 && resp?.status < 300) this.cancelEdit()
      this.loading = false
    }
  }
}
</script>

<style lang="scss">
</style>
