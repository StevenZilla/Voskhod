<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Структура описи</h2>
    </v-card-title>

    <div class="structure d-flex">
      <!-- дерево -->
      <div class="structure__tree">
        <TreeviewHeader
          :open-nodes="openNodes"
          @switch-nodes="switchNodes()"
          disable
        />

        <v-treeview
          ref="tree"
          color="secondary"
          return-object
          open-all
          transition
          activatable
          :items="registerParts"
          :item-key="'id'"
          :open.sync="openNodes"
          @update:active="setSelectedNode"
        >
          <!-- eslint-disable-next-line -->
          <template v-slot:prepend="{ item }">
            <v-icon color="secondary">mdi-{{ item.id === -1 ? 'note-edit-outline' : 'note-outline' }}</v-icon>
          </template>
        </v-treeview>
      </div>

      <!-- таблица -->
      <StructureInfo :open-nodes="openNodes" @change-valid="invalidTable = $event"/>
    </div>

    <v-dialog
      v-model="isLimit"
      @click:outside="isLimit = false"
      content-class="dialog-auto-height"
      max-width="520px"
    >
      <NotificationPopup
        :title="'Опись'"
        @close-popup="isLimit = false"
      />
    </v-dialog>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import TreeviewHeader from '@/components/TreeviewHeader.vue'
import StructureInfo from '@/modules/delete-acts/components/StructureInfo.vue'
import { required } from 'vuelidate/lib/validators'
const set = require('lodash.set')
const NotificationPopup = () => import('@/components/NotificationPopup.vue')

export default {
  name: 'EditingStructure',

  components: {
    StructureInfo,
    TreeviewHeader,
    NotificationPopup
  },

  validations: {
    registerParts: {
      $each: {
        name: { required }
      }
    }
  },

  props: {
    errorData: {
      type: Object,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    errorObj: {},
    editObj: {
      eds: []
    },
    invalidTable: false,
    isLimit: false,
    isDelete: false,
    pk: -1,
    openNodes: [],
    selectedNode: {}
  }),

  computed: {
    ...mapState({
      registerTree: state => state.deleteActs.registerTree
    }),

    registerParts () {
      return this.$store.getters['deleteActs/GET_INFO_PARTS']
    },

    getInfoTable () {
      return this.$store.getters['deleteActs/GET_INFO_TABLE']
    },

    invalidData () {
      return this.$v.$invalid || this.invalidTable
    }
  },

  watch: {
    errorData (newV) {
      if (newV.message && newV.error) {
        Object.keys(this.errorData.error).forEach(key => {
          set(this.errorObj, key, this.errorData.error[key])
        })

        this.addedErrorInTree()
      }
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.fillData()
    }
  },

  methods: {
    switchNodes () {
      this.openNodes.length ? this.$refs.tree.updateAll(false) : this.$refs.tree.updateAll(true)
    },

    async fillData () {
      this.editObj.eds = this.getInfoTable.flatMap(register => {
        if (register.eds.length) return register.eds.map(ed => ed.id)
        return []
      })
      this.$emit('fill-data', this.editObj)
    },

    setSelectedNode (items) {
      if (items.length > 0) this.selectedNode = items[0]
    }
  }
}
</script>

<style>

</style>
