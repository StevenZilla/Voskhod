<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2>Общая информация</h2>
    </v-card-title>
    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Номер <span class="required-label">*</span></p>
            <v-text-field
              v-model="$v.editMainInfo.number.$model"
              class="rounded-lg"
              outlined
              clearable
              placeholder="Номер"
              hide-details
              required
              @change="filterInputMix(editMainInfo, 'num')"
            ></v-text-field>
          </div>
        </v-col>
        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Год <span class="required-label">*</span></p>
            <v-autocomplete
              v-model="detailAct.year"
              hide-details
              append-icon="mdi-calendar-blank"
              class="rounded-lg"
              outlined
              placeholder="Год"
              :items="arrayYearsMix"
              :no-data-text="'Нет результатов'"
              filled
              disabled
            ></v-autocomplete>
          </div>
        </v-col>
        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Дата формирования</p>
            <v-text-field
              class="rounded-lg"
              outlined
              hide-details
              :value="$_formatDate(detailAct.create_date, 'time')"
              filled
              append-icon="mdi-calendar-blank"
              disabled
            ></v-text-field>
          </div>
        </v-col>
        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Статус</p>
            <v-text-field
              class="rounded-lg"
              outlined
              hide-details
              placeholder="Статус обработки"
              filled
              disabled
              :value="detailAct.status.value"
            ></v-text-field>
          </div>
        </v-col>
      </v-row>
      <p class="mt-3"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapActions, mapState } from 'vuex'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'EditingMainInfo',

  validations: {
    editMainInfo: {
      number: { required }
    }
  },

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    isDialog: false,
    editMainInfo: {
      number: null
    }
  }),

  computed: {
    ...mapState({
      detailAct: state => state.deleteActs.detailAct,
      registerTree: state => state.deleteActs.registerTree
    }),

    invalidData () {
      return this.$v.$invalid
    },

    isDirty () {
      return this.$v.editMainInfo.$anyDirty
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editMainInfo)
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  mounted () {
    this.copyInfo()
  },

  methods: {
    ...mapActions('registers/accepted', ['CHANGE_NODE_NAME', 'REMOVE_ALL_DOSSIERS']),

    copyInfo () {
      this.editMainInfo.number = this.detailAct.num
      this.editMainInfo.year = this.detailAct.year
    }
  }
}
</script>

<style>

</style>
