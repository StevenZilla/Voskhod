<template>
  <v-expansion-panel ref="expansionOik">
    <v-expansion-panel-header>
      <div class="accordion__header">
        <span class="accordion__title">Экспертная комиссия ОИК</span>
        <v-chip
          v-if="GET_ACTUAL_EXPERT_COMMISSION && GET_ACTUAL_EXPERT_COMMISSION.status"
          class="accordion__status"
          :color="getStatusColor(GET_ACTUAL_EXPERT_COMMISSION)"
        >
          {{ GET_ACTUAL_EXPERT_COMMISSION.status.value }}
        </v-chip>
      </div>
    </v-expansion-panel-header>
    <v-expansion-panel-content>
      <ViewAgreements
        v-if="modeAgreements === 'view'"
        :headers="headers"
      />

      <EditingAgreements
        v-else
        :headers="headers"
        @change-valid="$emit('change-valid', $event)"
      />
    </v-expansion-panel-content>
  </v-expansion-panel>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import ViewAgreements from './components/view-info/ViewAgreements.vue'

const EditingAgreements = () => import('./components/editing-info/EditingAgreements.vue')
export default {
  components: { ViewAgreements, EditingAgreements },
  data: () => ({
    headers: [
      {
        text: 'ФИО',
        value: 'user.fio',
        width: '440px'
      },
      {
        text: 'Решение',
        value: 'decision_type.value',
        width: '245px'
      },
      {
        text: 'Комментарий',
        value: 'comment',
        width: '440px'
      },
      {
        text: 'Файлы',
        value: 'comment_files',
        align: 'center',
        width: '130px'
      },
      {
        text: 'Дата и время',
        value: 'date',
        width: '200px'
      },
      {
        value: 'actions',
        width: '100px'
      }
    ]
  }),

  mounted () {
    if (this.expCommissionLen) this.$refs.expansionOik.toggle()
  },

  computed: {
    ...mapState({
      modeAgreements: state => state.deleteActs.agreements.modeAgreements,
      expCommissionLen: state => Object.keys(state.deleteActs.agreements).length
    }),
    ...mapGetters('deleteActs/agreements', ['GET_ACTUAL_EXPERT_COMMISSION', 'GET_ACT_AGREEMENT_KEY'])
  },

  methods: {
    getStatusColor (obj) {
      if (obj) {
        switch (obj.status?.code) {
          case 'agreed':
            return '#00A65A'

          case 'new':
            return '#A7A8AB '

          case 'pending_agreed':
            return '#9DBDED'

          case 'rejected':
            return '#E52E2E'

          case 'agreed_with_comments':
            return '#FE9F19'

          default:
            return ''
        }
      }
    }
  }
}
</script>

<style>

</style>
