export default {
  namespaced: true,
  state: {
    detailAgreements: {},
    triggerUpdate: 0,
    modeAgreements: 'view',
    agreementsLoading: false,
    registerProject: null,
    registerApproved: null
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },

  getters: {
    GET_ACT_AGREEMENT_KEY: state => code => {
      if (!state.detailAgreements[code]) return {}
      return state.detailAgreements[code]
    },

    GET_VIEW_AGREEMENT_BUTTONS: state => {
      if (!state.detailAgreements.view_buttons) return

      return state.detailAgreements.view_buttons
    },

    GET_ACTUAL_EXPERT_COMMISSION: state => {
      if (!state.detailAgreements.expert_commission) return

      const obj = state.detailAgreements.expert_commission.find(item => item.is_actual)
      if (obj) return obj
      else return null
    },

    GET_ACTUAL_OIK_HEAD: state => {
      if (!state.detailAgreements.oik_head) return

      const obj = state.detailAgreements.oik_head.find(item => item.is_actual)
      if (obj) return obj
      else return null
    },

    GET_CHIEF: state => {
      if (!state.detailAgreements.affirmative) return {}

      const obj = state.detailAgreements.affirmative.find(item => item.is_actual)
      if (obj) return obj
      else return null
    },

    GET_TRIGGER_VALUE: state => state.triggerUpdate
  }
}
