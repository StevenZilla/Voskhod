<template>
  <v-card data-qa="block-agreement-register-view" class="detail__additional-info mt-5">
    <LoadingComponentVue v-if="agreementsLoading"/>

    <template v-else>
      <v-card-title class="align-center justify-space-between">
        <div class="d-flex">
          <h2 class="mb-0">Согласование</h2>
          <v-icon
            icon
            class="ml-2"
            color="secondary"
            @click="isClosed = !isClosed"
          >{{ chevron }}
          </v-icon>
        </div>

        <div v-if="modeAgreements === 'view'">
          <v-btn
            v-if="viewButtons.is_new_agreement"
            data-qa="add-agreement"
            color="secondary"
            class="rounded-lg mr-3"
            outlined
            @click="switchMode('create')"
          >
            <v-icon>mdi-plus</v-icon>
            Создать согласование
          </v-btn>

          <v-btn
            v-if="$can('agreement_edit', 'delete_act') && viewButtons.is_edit_agreement"
            color="secondary"
            data-qa="edit-agreement"
            class="rounded-lg"
            outlined
            @click="switchMode('edit')"
          >
            <v-icon class="mr-2">mdi-pencil-outline</v-icon>
            Редактировать согласование
          </v-btn>
        </div>
      </v-card-title>
      <transition name="fade" mode="out-in">
        <v-card-text
          v-if="!isClosed"
          v-model="panel"
          class="detail__view-inner"
        >
          <div class="agreements-block">
            <v-expansion-panels
                v-if="!isClosed"
                multiple
                class="accordion"
                accordion
            >
              <AgreementsAgreeing
                  @change-valid="isInvalidAgreement = $event"
              />
              <AgreementsChief/>
            </v-expansion-panels>
          </div>
        </v-card-text>
      </transition>

      <div v-if="modeAgreements !== 'view'" class="mt-4">
        <BtnSaveSlot
          data-qa="save"
          :text="'Сохранить'"
          :loading="agreementsLoading"
          :disabled="isInvalidAgreement"
          @save="updateHandlerTrigger()"
        />
        <BtnCancelSlot
          :text="'Отменить'"
          @close="backToView()"
        />
      </div>
    </template>
  </v-card>
</template>

<script>
import { mapGetters, mapState } from 'vuex'
import AgreementsAgreeing from './AgreementsAgreeing.vue'
import AgreementsChief from './AgreementsChief.vue'
import { GET_ACT_AGREEMENTS } from '@/modules/delete-acts/components/agreements/services/api'

export default {
  components: {
    AgreementsAgreeing,
    AgreementsChief
  },

  data: () => ({
    trigger: 0,
    isInvalidAgreement: false,
    updatedObjAgreement: null,
    panel: [],
    isClosed: true
  }),

  computed: {
    ...mapState({
      agreementsLoading: state => state.deleteActs.agreements.agreementsLoading,
      modeAgreements: state => state.deleteActs.agreements.modeAgreements,
      isApproveStatus: state => state.deleteActs.detailAct.status.code === 'approved' || false
    }),

    ...mapGetters('deleteActs', ['GET_REGISTER_KEY']),

    actId () {
      return this.GET_REGISTER_KEY('id')
    },

    viewButtons () {
      return this.GET_REGISTER_KEY('view_buttons')
    },

    chevron () {
      return this.isClosed ? 'mdi-chevron-down' : 'mdi-chevron-up'
    }
  },

  mounted () {
    GET_ACT_AGREEMENTS(this.actId)
    this.isClosed = this.isApproveStatus
  },

  methods: {
    backToView () {
      this.$store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'modeAgreements', value: 'view' })
    },

    switchMode (mode) {
      this.$store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'modeAgreements', value: mode }, { root: true })
      this.panel.push(0)
    },

    updateHandlerTrigger () {
      this.$store.dispatch('deleteActs/agreements/SET_VALUE', {
        key: 'triggerUpdate',
        value: ++this.trigger
      }, { root: true })
    }
  }
}
</script>

<style lang="scss">
</style>
