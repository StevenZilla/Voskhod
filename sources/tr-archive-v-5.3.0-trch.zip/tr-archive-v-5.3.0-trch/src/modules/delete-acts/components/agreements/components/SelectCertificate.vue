<template>
  <div class="popup-form">
    <div class="form-group mt-2 mb-5">
      <p class="form-group__title">Сертификат подписи для подписания акта</p>
      <v-autocomplete
          v-model="thumbprint"
          placeholder="Выберите сертификат"
          class="rounded-lg"
          data-qa="certificate"
          outlined
          hide-details
          rounded
          required
          color="secondary"
          clearable
          :items="signaturesList"
          :no-data-text="'Нет результатов'"
          :disabled="loading"
          :filled="loading"
          :loading="loading"
          :loader-height="5"
          @change="submitHandler"
      >
        <template v-slot:item="{item}">
          <span>{{ item.text }} <font class="caption" style="color:#CBCBCD">(до {{ item.end_date }})</font></span>
          <span v-if="item.mchd_end_date"><font class="caption" style="color:#CBCBCD">&nbsp;МЧД до {{ item.mchd_end_date }}</font></span>
        </template>
      </v-autocomplete>
    </div>
  </div>
</template>

<script>
import { GET_CERTIFICATES } from '../services/api'

export default {
  props: {
    filter: {
      type: String,
      default: ''
    }
  },

  data: () => ({
    isSelectCertificate: false,
    thumbprint: '',
    signaturesList: [],
    loading: true
  }),
  watch: {
    thumb: {
      handler (newV) {
        this.thumbprint = newV
      },
      immediate: true
    }
  },

  async mounted () {
    await this.getSignatures()
    this.loading = false
  },

  methods: {
    submitHandler () {
      this.$emit('set-thumbprint', this.thumbprint)
    },

    async getSignatures () {
      const res = await GET_CERTIFICATES(new URLSearchParams(this.filter))
      this.signaturesList = res.map(item => {
        return {
          text: item.name,
          value: item.thumbprint,
          end_date: item.end_date,
          mchd_end_date: item.mchd_end_date
        }
      })
    }
  }
}
</script>

<style lang="scss">
</style>
