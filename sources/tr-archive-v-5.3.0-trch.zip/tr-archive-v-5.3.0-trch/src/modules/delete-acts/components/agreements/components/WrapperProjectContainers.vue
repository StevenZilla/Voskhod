<template>
  <div class="wrapper-containers">
    <v-card>
      <v-toolbar
        dense
        flat
        class="popup-toolbar"
      >
        <v-toolbar-title class="font-weight-bold">{{ title }}</v-toolbar-title>
        <v-btn dark icon @click="$emit('close-popup')">
          <v-icon color="element">mdi-close</v-icon>
        </v-btn>
      </v-toolbar>

      <SelectCertificate
        :filter="filter"
        @set-thumbprint="setThumbprint($event)"
        @click:clear="removeThumbprint()"
      />

      <div class="wrapper-containers__actions">
        <v-btn
          class="mr-3 rounded-lg"
          color="secondary"
          outlined
          @click="backAction()"
        >Отменить
        </v-btn>
        <v-btn
          data-qa="send"
          class="rounded-lg"
          color="secondary"
          :disabled="invalidThumbprint"
          @click="$emit('submit', thumbprint)"
        >Отправить
        </v-btn>
      </div>
    </v-card>
  </div>
</template>

<script>

import SelectCertificate from './SelectCertificate.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'WrapperProjectContainers',

  components: {
    SelectCertificate
  },

  props: {
    title: {
      type: String,
      required: true,
      default: ''
    },

    filter: {
      type: String,
      required: true
    }
  },

  data: () => ({
    key: 0,
    thumbprint: ''
  }),

  computed: {
    ...mapGetters('deleteActs/agreements', ['GET_VIEW_AGREEMENT_BUTTONS']),

    invalidThumbprint () {
      return (!this.thumbprint)
    }
  },

  methods: {
    backAction () {
      if (this.key === 0) this.$emit('close-popup')
      else this.key--
    },

    setThumbprint (evt) {
      this.thumbprint = evt
    },

    removeThumbprint () {
      this.thumbprint = []
    }
  }
}
</script>

<style lang="scss">
</style>
