import api from '@/services/api'
import store from '@/storages'

export async function CREATE_AGREEMENT (id, agreementObject) {
  await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'agreementsLoading', value: true })
  try {
    await api.post(`/delete_act/${id}/agreements`, agreementObject)
    await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'modeAgreements', value: 'view' }, { root: true })
  } catch (error) {
    console.log(error.response)
  } finally {
    await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'agreementsLoading', value: false })
  }
}

export async function EDITING_AGREEMENT (id, participantsObject) {
  try {
    await api.put(`/delete_act/${id}/agreements/signers`, participantsObject)
    store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'modeAgreements', value: 'view' })
  } catch (error) {
    console.log(error.response)
  }
}

export async function GET_ACT_AGREEMENTS (id) {
  await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'agreementsLoading', value: true })
  try {
    const host = `/delete_act/${id}/agreements`

    const resp = await api.get(host)
    await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'detailAgreements', value: resp.data })
  } finally {
    await store.dispatch('deleteActs/agreements/SET_VALUE', { key: 'agreementsLoading', value: false })
  }
}

export async function DOWNLOAD_TK (url) {
  try {
    const response = await api.get(url)
    const blob = await response.blob()
    const downloadUrl = window.URL.createObjectURL(new Blob([blob]))
    const link = document.createElement('a')

    link.href = downloadUrl
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  } catch (err) {
    console.error(err)
  }
}

export async function GET_CERTIFICATES () {
  const res = await api.get('/ead/usersigns/?code=eds_register')
  return res.data.serts
}

export async function GET_DECISION_TYPES () {
  const res = await api.get('/delete_act/nsi/delete_act_decision')
  return res.data
}

export async function SEND_AGREEING_DECISION (id, formData) {
  await api.post(`/delete_act/${id}/agreements/agreeing/decision`, formData)
}

export async function SEND_AFFIRMATIVE_DECISION (id, formData) {
  await api.post(`/delete_act/${id}/agreements/affirmative/decision`, formData)
}

export async function APPROVE_AGREEMENT (id, formData) {
  return await api.patch(`/delete_act/${id}/agreements/decision`, formData)
}
