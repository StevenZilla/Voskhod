<template>
  <div class="tree-accordion-wrapper">
    <div v-for="(agreement, index) in expertCommission" :key="index"
         :class="{'panel-hide': isHideAgreement(agreement)}">
      <div class="tree-accordion">
        <div class="tree-accordion__left">
          <p
            :class="{'cursor-default': agreement.is_actual}"
            class="tree-accordion__title"
            @click="!agreement.is_actual ? toggleItem(agreement) : () => {}"
          >
            <v-icon v-if="!agreement.is_actual" color="secondary mr-2">mdi-menu-down</v-icon>
            Согласование {{ agreement.order }}</p>
          <div
            v-if="agreement.agreement_files && (agreement.agreement_files.ep || agreement.agreement_files.xml_act)"
            class="tree-accordion__left-action"
          >
            <v-btn
              color="secondary"
              class="mr-1 rounded-lg"
              icon
              :ripple="false"
              @click="downloadAgreementsZip([agreement.agreement_files.ep, agreement.agreement_files.xml_act], 'Файлы утверждения Экспертной комиссии')"
            >
              <v-icon color="secondary">mdi-download-circle-outline</v-icon>
            </v-btn>
            <span class="secondary--text">Файлы утв.</span>
          </div>
        </div>

        <div class="tree-accordion__right">
          <v-data-table
            hide-default-footer
            disable-sort
            group-by="Согласующие"
            no-data-text="Нет данных"
            item-key="id"
            class="mixin-table no-hover row-default-cursor"
            :headers="headers"
            :items="agreement.agreeing"
          >
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Согласующие</div>
              </td>
            </template>
            <template #item.date="{ item }">
              <div>
                {{ `${$_formatDate(item.date, 'time') || ''}` }}
              </div>
            </template>
            <template v-slot:item.comment_files="{ item }">
              <v-btn
                v-if="item.comment_files && item.comment_files.length"
                color="secondary"
                class="rounded-lg"
                icon
                :ripple="false"
                @click="downloadAgreementsZip(item.comment_files, 'Файлы комментария')"
              >
                <v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
            </template>
          </v-data-table>

          <v-data-table
            hide-default-footer
            disable-sort
            group-by="Председатель комиссии"
            no-data-text="Нет данных"
            item-key="id"
            class="mixin-table no-hover row-default-cursor"
            :headers="headers"
            :items="agreement.affirmative"
          >
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Председатель комиссии</div>
              </td>
            </template>
            <template #item.date="{ item }">
              <div>
                {{ `${$_formatDate(item.date, 'time') || ''}` }}
              </div>
            </template>
            <template v-slot:item.comment_files="{ item }">
              <v-btn
                v-if="item.comment_files && item.comment_files.length"
                color="secondary"
                class="rounded-lg"
                icon
                :ripple="false"
                @click="downloadAgreementsZip(item.comment_files, 'Файлы комментария')"
              >
                <v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

export default {
  props: {
    headers: {
      type: Array,
      required: true
    }
  },

  computed: {
    ...mapGetters('deleteActs/agreements', ['GET_ACTUAL_EXPERT_COMMISSION', 'GET_ACT_AGREEMENT_KEY']),

    expertCommission () {
      const exCommission = this.GET_ACT_AGREEMENT_KEY('expert_commission')
      if (exCommission.length) exCommission[exCommission.length - 1].lastItem = true
      return exCommission
    }
  },

  methods: {
    getStatusColor (obj) {
      if (obj) {
        switch (obj.status?.code) {
          case 'agreed':
            return '#00A65A'

          case 'new':
            return '#A7A8AB '

          case 'pending_agreed':
            return '#9DBDED'

          case 'rejected':
            return '#E52E2E'

          case 'agreed_with_comments':
            return '#FE9F19'

          default:
            return ''
        }
      }
    },

    toggleItem (item) {
      if (item.hide) this.$set(item, 'hide', false)
      else this.$set(item, 'hide', true)
    },

    isHideAgreement (item) {
      const needHide = item.hide || (item.hide === undefined && !item.is_actual && !item.lastItem)
      if (needHide) this.$set(item, 'hide', true)
      else this.$set(item, 'hide', false)
      return needHide
    },

    downloadAgreementsZip (items, nameZip) {
      console.log('items', items)
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()
      let count = 0
      const errors = []

      items.forEach(item => {
        JSZipUtils.getBinaryContent((this.$config.VUE_APP_HOST.replace('api', '') + item.href), async (err, data) => {
          if (err) errors.push(err)
          zip.file(item.name, data, { binary: true })
          count++
          if (count === items.length) { // если скачаны все файлы(или получили ошибку), то сохранить архив
            const content = await zip.generateAsync({ type: 'blob' })
            FileSaver.saveAs(content, nameZip)
          }
        })
      })
      count = 0
    }
  }
}
</script>

<style lang="scss">

.panel-hide {
  .tree-accordion__title {
    .v-icon {
      transform: rotate(-90deg);
    }
  }
  .tree-accordion__right {
    max-height: 1px!important;
    opacity: 0;
    overflow: hidden;
  }
  .tree-accordion-date {
    padding: 0;
    max-height: 0;
    opacity: 0;
    overflow: hidden;
  }
}
</style>
