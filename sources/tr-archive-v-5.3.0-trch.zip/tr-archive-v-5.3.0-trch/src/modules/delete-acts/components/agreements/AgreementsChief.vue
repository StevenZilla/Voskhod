<template>
  <v-expansion-panel ref="expansionPanelChief">
    <v-expansion-panel-header>
      <div class="accordion__header">
        <span class="accordion__title">Руководитель архива ОИК</span>
        <v-chip
            v-if="GET_ACTUAL_OIK_HEAD && GET_ACTUAL_OIK_HEAD.status"
            data-qa="status-agreement-view"
            class="accordion__status"
            :color="getStatusColor(GET_ACTUAL_OIK_HEAD)"
        >
          {{ GET_ACTUAL_OIK_HEAD.status.value }}
        </v-chip>
      </div>
    </v-expansion-panel-header>
    <v-expansion-panel-content>
      <div class="tree-accordion-wrapper">
        <div v-for="(chief, index) in oikHead" :key="index">
          <div class="tree-accordion">
            <div class="tree-accordion__left">
              <p class="tree-accordion__title" :class="{'cursor-default': chief.is_actual}">Согласование {{ chief.order }}</p>
              <div
                v-if="chief.agreement_files && (chief.agreement_files.ep || chief.agreement_files.xml_act)"
                class="tree-accordion__left-action"
              >
                <v-btn
                  color="secondary"
                  class="mr-1 rounded-lg"
                  icon
                  :ripple="false"
                  @click="downloadAgreementsZip([chief.agreement_files.ep, chief.agreement_files.xml_act], 'Файлы утверждения Руководителя ОИК')"
                ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
                </v-btn>
                <span class="secondary--text">Файлы утв.</span>
              </div>
            </div>

            <div class="tree-accordion__right">
              <v-data-table
                hide-default-footer
                disable-sort
                no-data-text="Нет данных"
                item-key="id"
                class="mixin-table no-hover row-default-cursor"
                :headers="headersChief"
                :items="[chief]"
              >
                <template #item.create_date="{ item }">
                  <div>
                    {{`${$_formatDate(item.create_date, 'time') ||''}`}}
                  </div>
                </template>
              </v-data-table>
            </div>
          </div>
        </div>
      </div>
    </v-expansion-panel-content>
  </v-expansion-panel>
</template>

<script>

import { mapGetters } from 'vuex'

export default {
  data: () => ({
    headersChief: [
      {
        text: 'Дата и время',
        value: 'create_date',
        width: '195px'
      },
      {
        text: 'ФИО',
        value: 'signer.fio',
        width: '100%'
      }
    ]
  }),

  mounted () {
    if (this.oikHead.length) this.$refs.expansionPanelChief.toggle()
  },

  computed: {
    ...mapGetters('deleteActs/agreements', ['GET_ACTUAL_OIK_HEAD', 'GET_ACT_AGREEMENT_KEY']),

    oikHead () {
      return this.GET_ACT_AGREEMENT_KEY('oik_head')
    }
  },

  methods: {
    downloadAgreementsZip (items, nameZip) {
      console.log('items', items)
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()
      let count = 0
      const errors = []

      items.forEach(item => {
        JSZipUtils.getBinaryContent((this.$config.VUE_APP_HOST.replace('api', '') + item.href), async (err, data) => {
          if (err) errors.push(err)
          zip.file(item.name, data, { binary: true })
          count++
          if (count === items.length) { // если скачаны все файлы(или получили ошибку), то сохранить архив
            const content = await zip.generateAsync({ type: 'blob' })
            FileSaver.saveAs(content, nameZip)
          }
        })
      })
      count = 0
    },

    getStatusColor (obj) {
      if (obj) {
        switch (obj.status?.code) {
          case 'approved':
            return '#00A65A'

          case 'new':
            return '#A7A8AB '

          case 'pending_approved':
            return '#9DBDED'

          case 'rejected':
            return '#E52E2E'

          case 'agreed_with_comments':
            return '#FE9F19'

          default:
            return ''
        }
      }
    }
  }
}
</script>

<style>

</style>
