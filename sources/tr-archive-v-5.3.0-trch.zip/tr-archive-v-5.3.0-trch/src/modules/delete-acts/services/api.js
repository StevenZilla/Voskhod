import mixin from '@/utils/mixins'
import store from '@/storages'
import api from '@/services/api'

export default async function GET_ACTS (url, params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('deleteActs/SET_VALUE', { key: 'actsLoading', value: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get(`/delete_act/${url}`, { params: searchParams })
    return resp.data
  } finally {
    store.dispatch('deleteActs/SET_VALUE', { key: 'actsLoading', value: false })
  }
}

export async function GET_DELETE_ACT_STATUS () {
  const res = await api.get('/delete_act/nsi/delete_act_status')
  // .map(item => ({ text: item.value, value: item.id }))
  return res.data
}

export async function GET_DELETE_ACTS_DETAIL (url) {
  const resp = await api.get(`/delete_act/${url}`)
  store.dispatch('deleteActs/SET_VALUE', { key: 'detailAct', value: resp.data })
}

export async function GET_PROJECT_PARTS (id) {
  const host = `/delete_act/project/${id}/parts`
  const resp = await api.get(host)
  return resp.data
}

export async function SEND_AGREEMENT (id) {
  const host = `/delete_act/${id}/agreements`
  const resp = await api.patch(host)
  return resp.data
}

export async function UPDATE_ACT (id, regObject) {
  return await api.put(`/delete_act/project/${id}`, regObject)
}
