import agreements from '../components/agreements/store/index'
export default {
  namespaced: true,
  modules: {
    agreements
  },
  state: {
    actsLoading: true,
    detailAct: {},
    registerTree: {},
    detailAgreements: {},
    agreementsLoading: false,
    modeAct: 'view'
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },

    removeDossier (state, { parent, index }) {
      parent.dossiers.splice(index, 1)
    },

    removeEds (state, { parent, index }) {
      parent.eds.splice(index, 1)
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    },

    REMOVE_DOSSIER ({ commit, state }, { nodeId }) {
      const findAndMutate = (node, parent, index) => {
        if (node.id === nodeId) {
          commit('removeDossier', { parent, index })
          this.dispatch('deleteActs/REMOVE_EDS', { nodeId, key: 'dossier_id' })
        } else {
          if (node.children) node.children.forEach((child, index) => findAndMutate(child, node, index))
          else if (node.dossiers) node.dossiers.forEach((child, index) => findAndMutate(child, node, index))
        }
      }

      findAndMutate(state.registerTree[0], null, null)
    },

    REMOVE_EDS ({ commit, state }, { nodeId, key }) {
      const findAndMutate = (node, parent, index) => {
        if (node[key] === nodeId) commit('removeEds', { parent, index })
        else {
          if (node.children) node.children.forEach((child, index) => findAndMutate(child, node, index))
          else if (node.eds) node.eds.forEach((child, index) => findAndMutate(child, node, index))
        }
      }

      findAndMutate(state.registerTree[0], null)
    }
  },
  getters: {
    GET_REGISTER_KEY: state => code => {
      if (!state.detailAct[code]) return {}
      return state.detailAct[code]
    },

    GET_VIEW_BUTTONS: state => {
      if (!state.detailAct.view_buttons) return

      return state.detailAct.view_buttons
    },

    GET_INFO_PARTS: state => {
      function extractData (node) {
        return {
          id: node.id,
          name: node.name,
          children: node.children?.map(child => extractData(child))
        }
      }

      return state.registerTree.map(node => extractData(node))
    },

    GET_INFO_TABLE: state => {
      function extractData (node) {
        return {
          id: node.id,
          name: node.name,
          eds: node.eds,
          dossiers: node.dossiers,
          register_status: node.register_status
        }
      }

      return state.registerTree[0].children.map(node => extractData(node))
    }
  }
}
