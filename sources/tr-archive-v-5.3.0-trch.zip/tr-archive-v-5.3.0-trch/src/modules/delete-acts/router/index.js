import { actDelete, actDeleteDetail, approvedActsDelete, approvedActsDeleteDetail } from '@/permissions'
import { actDeleteEvent } from '@/event-code'
const DeleteActsPage = () => import(/* webpackChunkName: 'projects-acts-page' */'../views/ProjectActs.vue')
const DetailProject = () => import(/* webpackChunkName: 'detail-project' */'../views/DetailProject.vue')
const ApprovedActs = () => import(/* webpackChunkName: 'approved-acts-page' */'../views/ApprovedActs.vue')
const DetailApproved = () => import(/* webpackChunkName: 'detail-approved' */'../views/DetailApproved.vue')

const deleteActsRouter = [
  {
    name: 'DeleteActsPage',
    path: actDelete.path,
    component: DeleteActsPage,
    meta: {
      breadcrumb: [
        {
          text: 'Акты об уничтожении'
        },
        {
          text: 'Проекты актов об уничтожении'
        }
      ],
      tech_name: actDelete.code
    }
  },
  {
    name: 'detail-project-delete-act',
    path: `${actDeleteDetail.path}/:id`,
    component: DetailProject,
    meta: {
      breadcrumb: [
        {
          text: 'Акты об уничтожении',
          to: actDeleteDetail.path
        },
        {
          text: 'Просмотр проекта акта'
        }
      ],
      parent: actDelete.path,
      tech_name: actDeleteDetail.code,
      code: actDeleteEvent.code
    }
  },
  {
    name: 'ApprovedActs',
    path: approvedActsDelete.path,
    component: ApprovedActs,
    meta: {
      breadcrumb: [
        {
          text: 'Акты об уничтожении'
        },
        {
          text: 'Утвержденные акты об уничтожении'
        }
      ],
      tech_name: approvedActsDelete.code
    }
  },
  {
    name: 'detail-approved-delete-act',
    path: `${approvedActsDelete.path}/:id`,
    component: DetailApproved,
    meta: {
      breadcrumb: [
        {
          text: 'Акты об уничтожении',
          to: approvedActsDelete.path
        },
        {
          text: 'Просмотр утвержденного акта'
        }
      ],
      parent: approvedActsDelete.path,
      tech_name: approvedActsDeleteDetail.code,
      code: approvedActsDeleteDetail.code
    }
  }
]

export default router => {
  router.addRoutes(deleteActsRouter)
}
