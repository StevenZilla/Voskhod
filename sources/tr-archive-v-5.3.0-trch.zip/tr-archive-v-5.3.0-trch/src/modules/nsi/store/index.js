import archives from '../submodules/archives/store'
import classifiers from '../submodules/classifiers/store'
import funds from '../submodules/funds/store'
import subdivisions from '../submodules/subdivisions/store'
import passwords from '../submodules/passwords/store'
import signers from '../submodules/signers/store'
import sources from '../submodules/sources/store'
import classifierTable from '../submodules/classifiers/components/classifier-table/store'

export default {
  namespaced: true,
  modules: {
    archives,
    classifiers,
    funds,
    sources,
    subdivisions,
    signers,
    passwords,
    classifierTable
  }
}
