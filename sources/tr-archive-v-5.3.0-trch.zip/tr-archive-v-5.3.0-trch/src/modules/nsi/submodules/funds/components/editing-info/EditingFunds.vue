<template>
  <v-dialog
    v-model="isEditing"
    transition="scroll-y-transition"
    max-width="530px"
    content-class="dialog-auto-height"
    @click:outside="closeDialog"
  >
    <v-card
      class="detail__main-info popup"
    >
      <v-toolbar
        flat
        dense
        class="popup-toolbar"
      >
        <v-toolbar-title>Редактирование фонда</v-toolbar-title>
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <div
        class="popup__content"
      >
        <div class="form-group">
          <p class="form-group__title">Наименование <span class="required-label">*</span></p>
          <v-text-field
            v-model="editingObj.value"
            class="rounded-lg"
            clearable
            required
            outlined
            placeholder="Введите наименование"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Номер <span class="required-label">*</span></p>
          <v-text-field
            v-model="editingObj.num"
            class="rounded-lg"
            clearable
            required
            rounded
            outlined
            placeholder="Введите номер"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Описание <span class="required-label">*</span></p>
          <v-text-field
            v-model="editingObj.descr"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Введите описание"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Архив <span class="required-label">*</span></p>
          <v-autocomplete
            v-model="editingObj.archive.id"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Выберите архив"
            :no-data-text="'Нет данных'"
            :items="archives"
          ></v-autocomplete>
        </div>
        <div class="form-group">
          <p class="form-group__title">Код <span class="required-label">*</span></p>
          <v-text-field
            v-model="editingObj.code"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Введите код"
          ></v-text-field>
        </div>
        <div class="form-group d-flex justify-center">
          <p class="form-group__title">По умолчанию <span class="required-label">*</span></p>
          <v-radio-group hide-details v-model="editingObj.is_default">
            <v-radio
              color="secondary"
              :value="editingObj !== false"
            />
          </v-radio-group>
        </div>

        <div class="form-group d-flex justify-center">
          <p class="form-group__title">Актуальность <span class="required-label">*</span></p>
          <v-simple-checkbox
            color="secondary"
            v-ripple
            v-model="editingObj.is_actual"
          ></v-simple-checkbox>
        </div>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
          data-qa="save"
          :text="'Сохранить'"
          :loading="loading"
          :disabled="invalidFunds"
          @save="updateHandler()"
        />
        <BtnCancelSlot
          :text="'Отменить'"
          @close="closeDialog()"
        />
      </div>

      <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px"
      >
        <AppNotify
          :title="'Редактирование'"
          :text="error"
          :type="'error'"
          :icon="'mdi-alert'"
          @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as funds from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'

export default {
  name: 'EditingFunds',

  validations: {
    editingObj: {
      funds: {
        $each: {
          value: { required },
          num: { required },
          descr: { required },
          archive: {
            id: { required }
          },
          code: { required }
        }
      }
    }
  },

  props: {
    fund: {
      type: Object
    },
    mode: {
      type: Boolean,
      default: false
    }
  },

  data: () => ({
    editingObj: {
      archive: {
        id: ''
      },
      archive_id: '',
      value: '',
      num: '',
      descr: '',
      code: '',
      is_default: false,
      is_actual: false
    },
    loading: false,
    isNotify: false,
    isEditing: false,
    pk: 0
  }),

  computed: {
    ...mapState({
      archivesList: state => state.nsi.funds.archivesList,
      fundsLoading: state => state.nsi.funds.fundsLoading,
      error: state => state.error
    }),

    archives () {
      return this.archivesList.map(item => ({ text: item.value, value: item.id }))
    },

    invalidFunds () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.$emit('close')
    },

    async updateHandler () {
      this.loading = true
      this.fillData()
      this.error = ''
      try {
        await funds.UPDATE_FUNDS(this.editingObj, this.editingObj.id)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    },

    fillData () {
      this.editingObj.archive_id = this.editingObj.archive.id
    }
  },

  watch: {
    fund: function () {
      this.editingObj = { ...this.fund }
    },
    mode: function (val) {
      this.isEditing = val
    }
  }
}
</script>
<style lang="scss">
</style>
