import { fundEvent } from '@/event-code'
import { funds } from '@/permissions'
const FundsPage = () => import('../views/FundsPage.vue')

const fundsRouter = [
  {
    name: 'FundsPage',
    path: funds.path,
    component: FundsPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Фонды' }
      ],
      tech_name: funds.code,
      code: fundEvent.code
    }
  }
]

export default fundsRouter
