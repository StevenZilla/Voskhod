<template>
  <v-dialog
    v-model="isCreating"
    transition="scroll-y-transition"
    max-width="530px"
    content-class="dialog-auto-height"
    @click:outside="closeDialog"
  >
    <template
      v-slot:activator="{ on, attrs }"
    >
      <div class="detail__buttons detail__buttons-left">
        <v-btn
          v-if="$can('fund_edit', 'nsi')"
          class="rounded-lg"
          outlined
          color="secondary"
          v-bind="attrs"
          v-on="on"
        >Добавить фонд
        </v-btn>
      </div>
    </template>

    <v-card
      class="detail__main-info popup"
    >
      <v-toolbar
        flat
        dense
        class="popup-toolbar"
      >
        <v-toolbar-title>Добавление фонда</v-toolbar-title>
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <div
        class="popup__content"
      >
        <Name @set-property="editingObj.value = $event"/>

        <Number @set-property="editingObj.num = $event"/>

        <Description @set-property="editingObj.descr = $event"/>

        <Archive @set-property="editingObj.archive_id = $event"/>

        <Code @set-property="editingObj.code = $event"/>

        <ByDefault @set-property="editingObj.is_default = $event"/>

        <Actuality @set-property="editingObj.is_actual = $event"/>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
          :text="'Добавить'"
          :loading="loading"
          :disabled="invalidFunds"
          @save="createHandler()"
        />
        <BtnCancelSlot
          :text="'Отменить'"
          @close="closeDialog()"
        />
      </div>

      <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px"
      >
        <AppNotify
          :title="'Редактирование'"
          :text="error"
          :type="'error'"
          :icon="'mdi-alert'"
          @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as funds from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'
import Name from '@/modules/nsi/submodules/funds/components/fields-main-info/Name.vue'
import Number from '@/modules/nsi/submodules/funds/components/fields-main-info/Number.vue'
import Description from '@/modules/nsi/submodules/funds/components/fields-main-info/Description.vue'
import Archive from '@/modules/nsi/submodules/funds/components/fields-main-info/Archive.vue'
import Code from '@/modules/nsi/submodules/funds/components/fields-main-info/Code.vue'
import ByDefault from '@/modules/nsi/submodules/funds/components/fields-main-info/ByDefault.vue'
import Actuality from '@/modules/nsi/submodules/funds/components/fields-main-info/Actuality.vue'

export default {
  name: 'CreatingFunds',
  components: { Actuality, ByDefault, Code, Archive, Description, Number, Name },

  validations: {
    editingObj: {
      value: { required },
      num: { required },
      descr: { required },
      archive_id: { required },
      code: { required }
    }
  },

  data: () => ({
    loading: false,
    isNotify: false,
    isCreating: false,
    pk: 0,
    editingObj: {
      value: '',
      num: '',
      descr: '',
      archive_id: '',
      code: '',
      is_default: false,
      is_actual: false
    }
  }),

  computed: {
    ...mapState({
      error: state => state.error
    }),

    invalidFunds () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.isCreating = false
      this.$emit('close')
    },

    async createHandler () {
      this.loading = true
      this.error = ''
      try {
        await funds.CREATE_FUND(this.editingObj)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
