import api from '@/services/api'
import store from '@/storages'

export async function GET_FUNDS_RESPONSE (combined) {
  store.dispatch('nsi/funds/SET_VALUE', { key: 'fundsLoading', value: true }, { root: true })
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/v2/admin/nsi/funds', { params: combined })
    store.dispatch('nsi/funds/SET_VALUE', { key: 'fundsResponse', value: resp.data })
  } catch (error) {
    store.dispatch('nsi/funds/SET_VALUE', { key: 'fundsResponse', value: { key: 'error', value: true } })
    throw (error)
  } finally {
    store.dispatch('nsi/funds/SET_VALUE', { key: 'fundsLoading', value: false }, { root: true })
  }
}

export async function GET_ARCHIVES_LIST (combined) {
  store.dispatch('nsi/funds/SET_VALUE', { key: 'archivesLoading', value: true }, { root: true })
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/v2/admin/nsi/archives', { params: combined })
    store.dispatch('nsi/funds/SET_VALUE', { key: 'archivesList', value: resp.data.archives })
  } catch (error) {
    store.dispatch('nsi/funds/SET_VALUE', { key: 'archivesList', value: { key: 'error', value: true } })
    throw (error)
  } finally {
    store.dispatch('nsi/funds/SET_VALUE', { key: 'archivesLoading', value: false }, { root: true })
  }
}

export async function UPDATE_FUNDS (fundObject, id) {
  try {
    await api.patch('/v2/admin/nsi/funds/' + id, fundObject)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_FUND (fundObject) {
  try {
    await api.post('/v2/admin/nsi/funds/', fundObject)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
