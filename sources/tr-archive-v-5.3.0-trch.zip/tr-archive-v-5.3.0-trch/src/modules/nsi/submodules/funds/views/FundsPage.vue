<template>
  <div class="fund-page">
    <div class="d-flex align-center">
      <span class="page-title">Фонды</span>
    </div>

    <div class="main-line">
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @clear-filters="acceptFilters"
      />
    </div>

    <div class="mb-5 d-flex justify-space-between align-center">
      <h2 class="results-title">Результаты поиска</h2>
    </div>

    <v-data-table
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      item-key="id"
      class="main-table scroll-table sortable-table row-default-cursor"
      hide-default-footer
      :items="fundsResponse.funds"
      :headers="headers"
      :options.sync="options"
      :loading="fundsLoading"
      :page.sync="page"
      :items-per-page="itemsPerPage"
      :server-items-length="fundsResponse.count"
      :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
      @page-count="pageCount = $event"
    >
      <!-- eslint-disable-next-line -->
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.archive="{ item }">
        {{ item.archive.short_name }}
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_default="{ item, select }">
        <div class="d-flex justify-center radio-btn-color">
          <v-radio-group hide-details v-model="item.is_default">
            <v-radio color="secondary" class="doss-radio" disabled :value="item !== false"/>
          </v-radio-group>
        </div>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_actual="{ item }">
        <div class="d-flex justify-center checkbox-color">
          <v-simple-checkbox
            v-if="item.is_actual === true"
            v-ripple
            :value="item.is_actual === true"
            disabled
          ></v-simple-checkbox>
          <v-simple-checkbox v-ripple disabled v-else></v-simple-checkbox>
        </div>
      </template>

      <!-- eslint-disable-next-line -->
      <template #footer="{props}">
        <PaginationTable
          :page.sync="page"
          :pagination="props.pagination"
        />
      </template>

      <template v-slot:item.actions="{ item }">
        <v-icon
          v-if="$can('fund_edit', 'nsi')"
          color="secondary"
          @click="tableEditClick(item)"
        >
          mdi-pencil
        </v-icon>
      </template>
    </v-data-table>

    <EditingFunds
      @refresh="refresh"
      @close="isEditing = false"
      :mode="isEditing"
      :fund="selectedFund"
    />

    <CreatingFunds
      @refresh="refresh"
      @close="clearModalKey"
      :key="modalKey"
    />
  </div>
</template>

<script>

import * as funds from '../services/api'
import { mapState } from 'vuex'
import SearchPanel from '../components/SearchPanel.vue'
const CreatingFunds = () => import('../components/creating-info/CreatingFunds.vue')
const EditingFunds = () => import('../components/editing-info/EditingFunds.vue')
export default {
  name: 'FundsPage',

  components: {
    CreatingFunds,
    SearchPanel,
    EditingFunds
  },

  data: () => ({
    filterParams: null,
    selectedFund: {},
    modalKey: 0,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    isEditing: false,
    headers: [
      {
        text: 'Наименование',
        value: 'value',
        width: '455px'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '140px'
      },
      {
        text: 'Описание',
        value: 'descr',
        sortable: false,
        width: '675px'
      },
      {
        text: 'Наименование архива',
        value: 'archive',
        width: '220px'
      },
      {
        text: 'Код',
        value: 'code',
        width: '195px'
      },
      {
        text: 'По умолчанию',
        align: 'center',
        value: 'is_default',
        sortable: false,
        width: '190px'
      },
      {
        text: 'Актуальность',
        align: 'center',
        value: 'is_actual',
        sortable: false,
        width: '165px'
      },
      {
        text: 'Редактировать',
        align: 'center',
        sortable: false,
        class: 'cell-class',
        width: '165px',
        value: 'actions'
      }
    ]
  }),

  provide () {
    return {
      headers: this.headers
    }
  },

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          funds.GET_FUNDS_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      fundsResponse: state => state.nsi.funds.fundsResponse,
      fundsLoading: state => state.nsi.funds.fundsLoading,
      error: state => state.error
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.fundsResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('archive') !== -1) {
            par += 'arch_name'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    tableEditClick (data) {
      this.isEditing = true
      this.selectedFund = data
    },
    clearModalKey () {
      this.isEditing = false
      this.modalKey++
    },
    async refresh () {
      await funds.GET_FUNDS_RESPONSE()
    },
    async acceptFilters (evt) {
      this.filterParams = evt
      await funds.GET_FUNDS_RESPONSE(this.filterParams, this.sortParams)
    }
  },
  async created () {
    await funds.GET_FUNDS_RESPONSE()
    await funds.GET_ARCHIVES_LIST()
  }
}
</script>

<style lang="scss">
.radio-btn-color {
  .theme--light.v-radio--is-disabled .v-icon {
    color: #e5e5eb !important;
  }
}
</style>
