<template>
  <div class="form-group">
    <p class="form-group__title">Архив <span class="required-label">*</span></p>
    <v-autocomplete
        v-model="value"
        class="rounded-lg"
        rounded
        outlined
        placeholder="Выберите архив"
        :no-data-text="'Нет данных'"
        :items="archives"
    ></v-autocomplete>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  computed: {
    ...mapState({
      archivesList: state => state.nsi.funds.archivesList
    }),

    archives () {
      return this.archivesList.map(item => ({ text: item.value, value: item.id }))
    }
  },

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
