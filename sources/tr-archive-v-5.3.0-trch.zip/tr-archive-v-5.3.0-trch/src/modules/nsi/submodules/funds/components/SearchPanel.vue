<template>
  <div class="panel-search" style="max-width: 70%">
    <v-text-field
      v-model="filterObj.fundName"
      data-qa="main-field"
      class="main-field"
      placeholder="Введите полное или краткое наименование"
      rounded
      outlined
      solo
      clearable
      hide-details
      flat
      @click:clear="(filterObj.fundName = null), acceptFilters()"
      @keyup.enter="trigger++"
    >
      <template v-slot:append-outer>
        <v-btn
          data-qa="filter"
          outlined
          icon
          color="secondary"
          class="rounded-xl ml-7 bg-white"
          @click="toggleFilter()"
        >
          <v-icon> mdi-tune-vertical-variant</v-icon>
        </v-btn>
      </template>
      <template v-slot:prepend-inner>
        <v-btn
          plain
          icon
          @click="acceptFilters()"
          color="secondary"
          >
          <v-icon> mdi-magnify</v-icon>
        </v-btn>
      </template>

      <template v-slot:append>
        <span
          v-if="filterObj.fundName"
          @click="acceptFilters()"
          class="find-link secondary--text"
          >Найти
        </span>
      </template>
    </v-text-field>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      :is-load="isLoad"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />
  </div>
</template>

<script>
const Filters = () => import('./Filters.vue')

export default {
  name: 'SearchPanel',
  components: {
    Filters
  },
  data: () => ({
    trigger: 0,
    reset: 0,
    fullFilter: false,
    isLoad: false,
    filterObj: {
      fundName: null
    }
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.fundName) {
        paramsFilter.append('search', this.filterObj.fundName)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(
        this.filterParams,
        evt ? evt.filter : undefined
      )
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    clearFilters () {
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
