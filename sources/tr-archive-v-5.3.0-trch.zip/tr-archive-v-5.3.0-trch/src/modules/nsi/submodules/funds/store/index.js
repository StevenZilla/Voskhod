export default {
  namespaced: true,
  state: {
    fundsResponse: {},
    archivesList: [{ value: 'Загрузка' }],
    fundsLoading: false,
    archivesLoading: false
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },
  getters: {
    GET_ARCHIVES_LIST: state => {
      return state.archives.map(item => ({ text: item.value, value: null }))
    }
  }
}
