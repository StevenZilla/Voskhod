<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
    >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>
    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <FundNumber
        class="w-20"
        ref="numFund"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Actual
        class="w-20"
        ref="actual"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Archive
        class="w-20"
        ref="archive"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>
import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import FundNumber from '@/components/Filters/Fields/FundNumber.vue'
import Actual from '@/components/Filters/Fields/Actual.vue'
import Archive from '@/components/Filters/Fields/Archive.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

import { mapState } from 'vuex'

export default {
  name: 'Filters',
  components: { FiltersTemplate, ChipsFilters, FundNumber, Actual, Archive, FilterFooter },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    filterObj: {}
  }),

  computed: {
    ...mapState({
      archivesList: state => state.nsi.funds.archivesList,
      fundsLoading: state => state.nsi.funds.fundsLoading,
      archivesLoading: state => state.nsi.funds.archivesLoading,
      error: state => state.error
    }),

    archives () {
      return this.archivesList.map(item => ({ text: item.value, value: item.id }))
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      if (this.filterObj.actual?.query.value === null) {
        return false
      }
      return keys.length
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []
      if (this.filterObj.actual) {
        paramsFilter.append('is_actual', this.filterObj.actual.query.value)
        chips.push(this.filterObj.actual)
      }
      if (this.filterObj.archive) {
        paramsFilter.append('archive_id', this.filterObj.archive.query.value)
        chips.push(this.filterObj.archive)
      }
      if (this.filterObj.numFund) {
        paramsFilter.append('search', this.filterObj.numFund.query)
        chips.push(this.filterObj.numFund)
      }
      return { filter: paramsFilter, chips }
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.chipsList = this.filterParams.chips.map((chip) => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>

</style>
