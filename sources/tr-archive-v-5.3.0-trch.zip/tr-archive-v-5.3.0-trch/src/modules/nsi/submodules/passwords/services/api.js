import api from '@/services/api'
import store from '@/storages'

export async function GET_PASSWORDS_LIST (combined) {
  store.dispatch('nsi/passwords/SET_VALUE', { key: 'passwordsLoading', value: true }, { root: true })
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/v2/admin/nsi/passwords', { params: combined })
    store.dispatch('nsi/passwords/SET_VALUE', { key: 'passwordsList', value: resp.data.passwords })
  } catch (error) {
    store.dispatch('nsi/passwords/SET_VALUE', { key: 'passwordsList', value: { key: 'error', value: true } })
    throw (error)
  } finally {
    store.dispatch('nsi/passwords/SET_VALUE', { key: 'passwordsLoading', value: false }, { root: true })
  }
}

export async function UPDATE_PASSWORD (id, passwordObject) {
  try {
    await api.put('/v2/admin/nsi/passwords/' + id, passwordObject)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_PASSWORD (passwordObject) {
  try {
    await api.post('/v2/admin/nsi/passwords', passwordObject)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
