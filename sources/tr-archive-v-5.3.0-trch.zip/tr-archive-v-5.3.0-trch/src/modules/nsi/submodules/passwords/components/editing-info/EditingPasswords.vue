<template>
  <v-dialog
      v-model="isEditing"
      transition="scroll-y-transition"
      max-width="530px"
      content-class="dialog-auto-height"
      @click:outside="closeDialog"
  >
    <v-card
        class="detail__main-info popup"
    >
      <v-toolbar
          flat
          dense
          class="popup-toolbar"
      >
        <v-toolbar-title>Редактирование скомпрометированных паролей</v-toolbar-title>
        <BtnCancelSlot
            :icon="true"
            @close="closeDialog()"
        />
      </v-toolbar>

      <div
          class="popup__content"
      >
        <div class="form-group">
          <p class="form-group__title">Идентификатор</p>
          <v-text-field
              v-model="editingObj.id"
              class="rounded-lg"
              clearable
              required
              disabled
              outlined
              placeholder="Нет данных"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Пароль <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.password"
              class="rounded-lg"
              clearable
              required
              outlined
              placeholder="Введите пароль"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Hash</p>
          <v-text-field
              v-model="editingObj.hash"
              class="rounded-lg"
              clearable
              disabled
              required
              outlined
              placeholder="Нет данных"
          ></v-text-field>
        </div>

        <div class="main-table-inner__buttons d-flex justify-end">
          <BtnSaveSlot
              data-qa="save"
              :text="'Сохранить'"
              :loading="loading"
              :disabled="validComPasswordEdit"
              @save="updateHandler()"
          />
          <BtnCancelSlot
              :text="'Отменить'"
              @close="closeDialog()"
          />
        </div>
      </div>
    </v-card>
  </v-dialog>
</template>

<script>
import { required } from 'vuelidate/lib/validators'
import * as passwords from '../../services/api'

export default {
  name: 'EditingPasswords',

  props: {
    password: {
      type: Object
    },
    mode: {
      type: Boolean,
      default: false
    }
  },
  validations: {
    editPassword: {
      $each: {
        value: { required }
      }
    }
  },
  data: () => ({
    editingObj: {
      id: '',
      password: ''
    },
    loading: false,
    options: null,
    isEditing: false
  }),
  watch: {
    password: function () {
      this.editingObj = { ...this.password }
    },
    mode: function (val) {
      this.isEditing = val
    }
  },
  computed: {
    validComPasswordEdit () {
      return this.$v.$invalid
    }
  },
  methods: {
    closeDialog () {
      this.$emit('close')
    },
    async updateHandler () {
      this.loading = true
      this.error = ''
      try {
        await passwords.UPDATE_PASSWORD(this.editingObj.id, this.editingObj)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
