import { passwordEvent } from '@/event-code'
import { compromPasswords } from '@/permissions'
const PasswordsPage = () => import('../views/PasswordsPage.vue')

const pathPasswords = '/nsi/com-password'

const passwordsRouter = [
  {
    name: 'PasswordsPage',
    path: pathPasswords,
    component: PasswordsPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Скомпрометированные пароли' }
      ],
      tech_name: compromPasswords.code,
      code: passwordEvent.code
    }
  }
]

export default passwordsRouter
