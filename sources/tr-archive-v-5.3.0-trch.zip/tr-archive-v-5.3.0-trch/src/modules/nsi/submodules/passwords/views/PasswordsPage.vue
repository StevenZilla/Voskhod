<template>
  <div class="com_pass-page">
    <div class="d-flex align-center">
      <span class="page-title">Скомпрометированные пароли</span>
    </div>

    <div class="main-line">
      <SearchPanel
          @set-filters="acceptFilters($event)"
      />
    </div>

    <div class="mb-5 d-flex justify-space-between align-center">
      <h2 class="results-title">Результаты поиска</h2>
    </div>

    <v-progress-linear
      indeterminate
      height="7"
      v-if="passwordsList === null"
      color="secondary"
    ></v-progress-linear>

    <v-data-table
      v-else
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      class="main-table scroll-table sortable-table"
      item-key="id"
      hide-default-footer
      :items="passwordsList"
      :headers="headers"
      :options.sync="options"
      :loading="passwordsLoading"
      :page.sync="page"
      :items-per-page="itemsPerPage"
      :server-items-length="passwordsList.count"
      @page-count="pageCount = $event"
      password_page
      :header-props="{
        'sort-icon':
          options && options.sortDesc[0]
            ? 'mdi-sort-ascending'
            : 'mdi-sort-descending',
      }"
    >
      <template #footer="{ props }">
        <PaginationTable
          :page.sync="page"
          :pagination="props.pagination"
        />
      </template>
      <!-- eslint-disable-next-line -->
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-icon
            v-if="$can('comprom_password_edit', 'nsi')"
            color="secondary"
            @click="tableEditClick(item)"
        >
          mdi-pencil
        </v-icon>
      </template>
    </v-data-table>

    <EditingPasswords
        @refresh="refresh"
        @close="isEditing = false"
        :mode="isEditing"
        :password="selectedPassword"
    />

    <CreatingPasswords
        @refresh="refresh"
        @close="clearModalKey"
        :key="modalKey"
    />
  </div>
</template>

<script>
import SearchPanel from '../components/SearchPanel.vue'
import { mapState } from 'vuex'
import * as passwords from '../services/api'

const EditingPasswords = () => import('../components/editing-info/EditingPasswords.vue')
const CreatingPasswords = () => import('../components/creating-info/CreatingPasswords.vue')

export default {
  name: 'PasswordsPage',
  components: {
    SearchPanel,
    EditingPasswords,
    CreatingPasswords
  },
  data: () => ({
    selectedPassword: {},
    filterParams: null,
    isEditing: false,
    modalKey: 0,
    startDateRaw: [],
    endDateRaw: [],
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    clear: false,
    headers: [
      {
        text: 'Идентификатор',
        value: 'id',
        sortable: true,
        width: '33%'
      },
      {
        text: 'Пароль',
        value: 'password',
        sortable: true,
        width: '33%'
      },
      {
        text: 'Hash',
        value: 'hash',
        sortable: true,
        width: '33%'
      },
      {
        text: 'Редактировать',
        align: 'center',
        sortable: false,
        class: 'cell-class',
        width: '165px',
        value: 'actions'
      }
    ]
  }),
  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          passwords.GET_PASSWORDS_LIST(this.combineSearchParamsMix(this.filterParams, this.sortParams))
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      passwordsList: state => state.nsi.passwords.passwordsList,
      passwordsLoading: state => state.nsi.passwords.passwordsLoading,
      error: state => state.error
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.totalRegisters)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('value') !== -1) {
            par += 'source'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    tableEditClick (data) {
      this.isEditing = true
      this.selectedPassword = data
    },
    clearModalKey () {
      this.isEditing = false
      this.modalKey++
    },
    async refresh () {
      await passwords.GET_PASSWORDS_LIST()
    },
    async acceptFilters (evt) {
      this.filterParams = evt
      await passwords.GET_PASSWORDS_LIST(this.filterParams, this.sortParams)
    },
    onKeyDown (e) {
      if (e.code === 'Enter') {
        this.acceptFilters()
      }
    }
  },
  async created () {
    await passwords.GET_PASSWORDS_LIST(this.combineSearchParamsMix(this.filterParams, this.sortParams))
  },
  beforeMount () {
    document.addEventListener('keydown', this.onKeyDown)
  },
  beforeDestroy () {
    document.removeEventListener('keydown', this.onKeyDown) // здесь я его удаляю.
  }
}
</script>

<style lang="scss">
[password_page] td {
  cursor: default;
}
</style>
