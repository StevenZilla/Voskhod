<template>
  <div class="panel-search" style="max-width:70%">
    <v-text-field
      v-model="filterObj.passwordValue"
      data-qa="main-field"
      class="main-field"
      placeholder="Введите наименование"
      rounded
      outlined
      solo
      clearable
      hide-details
      flat
      @click:clear="(filterObj.passwordValue = null), acceptFilters()"
      @keyup.enter="trigger++"
    >
      <template v-slot:prepend-inner>
        <v-btn plain icon @click="acceptFilters()" color="secondary">
          <v-icon> mdi-magnify</v-icon>
        </v-btn>
      </template>

      <template v-slot:append>
        <span
          v-if="filterObj.passwordValue !== null"
          @click="acceptFilters()"
          class="find-link secondary--text"
        >Найти</span>
      </template>
    </v-text-field>
  </div>
</template>

<script>
export default {
  name: 'SearchPanel',
  data: () => ({
    archivesList: [],
    filterObj: {
      passwordValue: null
    },
    fullFilter: false,
    chipsList: [],
    clear: false
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.passwordValue) {
        paramsFilter.append('q', this.filterObj.passwordValue)
      }
      return paramsFilter
    }
  },

  methods: {
    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt?.filter)
      this.chipsList = evt?.chips.map(chip => {
        return { title: chip.title, value: chip.query.text ? chip.query.text : chip.query, code: chip.code }
      })
      this.$emit('set-filters', params)
      this.fullFilter = false
    }
  }
}
</script>

<style>
</style>
