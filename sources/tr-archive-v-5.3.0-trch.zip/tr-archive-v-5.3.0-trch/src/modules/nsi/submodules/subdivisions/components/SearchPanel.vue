<template>
  <div class="panel-search d-flex">
    <v-text-field
      v-model="filterObj.subdivisionName"
      data-qa="main-field"
      class="main-field"
      placeholder="Введите наименование"
      rounded
      outlined
      solo
      clearable
      hide-details
      flat
      @click:clear="filterObj.subdivisionName = null, acceptFilters()"
      @keyup.enter="trigger++"
    >
      <template v-slot:prepend-inner>
        <v-btn plain icon @click="acceptFilters()" color="secondary">
          <v-icon> mdi-magnify </v-icon>
        </v-btn>
      </template>

      <template v-slot:append>
        <span
          v-if="filterObj.subdivisionName"
          @click="acceptFilters()"
          class="find-link secondary--text"
          >Найти
        </span>
      </template>
    </v-text-field>

    <!-- <div class="d-flex">
        <v-checkbox
          v-model="filterObj.inactive"
          class="pl-3"
          color="secondary"
          hide-details
          label="Отображать неактивные записи"
        ></v-checkbox>
      </div> -->
  </div>
</template>

<script>
import * as subdivisions from '../services/api'

export default {
  name: 'SearchPanel',
  components: {
  },
  data: () => ({
    page: 1,
    archivesList: [],
    filterObj: {
      subdivisionName: null,
      inactive: false
    },
    clear: false
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.subdivisionName) {
        paramsFilter.append('q', this.filterObj.subdivisionName)
      }
      return paramsFilter
    }
  },

  watch: {
    'filterObj.inactive': {
      handler () {
        this.getData()
      }
    }
  },

  methods: {
    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt?.filter)
      this.chipsList = evt?.chips.map(chip => {
        return { title: chip.title, value: chip.query.text ? chip.query.text : chip.query, code: chip.code }
      })
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    getData () {
      const filter = this.combineSearchParamsMix(
        this.filterParams,
        new URLSearchParams(`is_active=${!this.filterObj.inactive}`)
      )
      subdivisions.GET_SUBDIVISIONS_RESPONSE(filter)
    }
  }
}
</script>

<style>
</style>
