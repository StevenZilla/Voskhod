<template>
  <div class="editing-wrapper">
    <LoadingComponentVue class="mt-10" v-if="loading"/>
    <v-data-table
      v-else
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      item-key="id"
      class="main-table scroll-table sortable-table"
      hide-default-footer
      :items="subdivisionsItems"
      :headers="headers"
      @page-count="pageCount = $event"
      :items-per-page="-1"
    >
      <!-- eslint-disable-next-line -->
      <template #item.name="{ item }">
        <div
          v-if="isSelected(item.id)"
          class="form-group"
        >
          <v-text-field
            v-model="item.name"
            class="rounded-lg"
            rounded
            outlined
            hide-details
            clearable
            placeholder="Введите наименование подразделения"
          ></v-text-field>
        </div>
        <span v-else>{{ item.name }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template #item.code="{ item }">
        <div
          v-if="isSelected(item.id)"
          class="form-group"
        >
          <v-text-field
            v-model="item.code"
            class="rounded-lg"
            rounded
            outlined
            hide-details
            clearable
            placeholder="Введите код подразделения"
          >
          </v-text-field>
        </div>
        <span v-else>{{ item.code }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template #item.contacts="{ item }">
        <div
            v-if="isSelected(item.id)"
            class="form-group"
        >
          <v-text-field
              v-model="item.contacts"
              class="rounded-lg"
              rounded
              outlined
              hide-details
              clearable
              placeholder="Введите контакты"
          >
          </v-text-field>
        </div>
        <span v-else>{{ item.contacts }}</span>
      </template>

      <!-- @click="item.is_active=!item.is_active" -->
      <template #item.is_active="{ item }">
        <div class="d-flex justify-center checkbox-color" v-if="!item.is_org">
          <v-simple-checkbox
              v-ripple
              :value="item.is_active"
              color="secondary"
              :disabled="!item.can_liquidate || !isSelected(item.id) || !item.is_active"
              @click="$emit('liquidateHelper', item)"
          ></v-simple-checkbox>
        </div>
      </template>

      <!-- eslint-disable-next-line -->
      <template #item.create_year="{ item }">
        <template v-if="!item.is_org">
          <div
              v-if="isSelected(item.id)"
              class="form-group"
          >
            <v-autocomplete
                v-model="item.create_year"
                class="rounded-lg"
                data-qa="reg-date"
                hide-details
                clearable
                outlined
                rounded
                solo
                append-icon="mdi-calendar-blank"
                placeholder="Укажите год создания"
                color="secondary"
                item-color="secondary"
                :items="arrayYearsMix"
                :no-data-text="'Нет результатов'"
            ></v-autocomplete>
          </div>

          <span v-else>{{ item.create_year }}</span>
        </template>
      </template>
      <!-- eslint-disable-next-line -->
      <template #item.delete_year="{ item }">
        <div class="form-group" v-if="!item.is_org">
          <span v-if="item.delete_year">{{ item.delete_year }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </div>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.actions_edit="{ item }">
        <div class="control-buttons">
          <!-- <v-btn
            v-if="!isSelected(item.id)"
            color="secondary"
            class="rounded-lg"
            disabled
            icon
          >
            <v-icon>mdi-pencil-outline</v-icon>
          </v-btn> -->
          <template>
            <div class="d-flex" v-if="isSelected(item.id)">
              <BtnIconSaveSlot
                :loading="loading"
                :disabled="invalidSubdivision"
                @save="updateHandler(item)"
              />
              <div class="mr-3"></div>

              <BtnIconCancelSlot :loading="loading" @close="$emit('close')"/>
            </div>
          </template>
        </div>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import * as subdivisions from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import store from '@/storages'

const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'EditingSubdivisions',

  validations: {
    selectedItems: {
      name: { required },
      code: { required },
      is_active: { required },
      create_year: { required }
    }
  },
  props: {
    headers: {
      type: Array
    },
    subdivisionsItems: {
      type: Array
    },
    selectedItems: {
      type: Object
    }
  },
  components: {
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },
  data: () => ({
    editingObj: {
      name: '',
      code: '',
      contact: '',
      is_active: false,
      create_year: ''
    },
    loading: false,
    isNotify: false
  }),

  computed: {
    isSelected () {
      return (id) => id === this.selectedItems.id
    },

    invalidSubdivision () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.$emit('close')
    },

    async updateHandler (item) {
      this.loading = true
      await this.fillData(item)
      this.error = ''
      try {
        await subdivisions.UPDATE_SUBDIVISION(this.editingObj, item.id)
        this.$store.commit('nsi/subdivisions/setValue', { key: 'liquidateSubdivisionId', value: null })
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        await store.dispatch(
          'SET_VALUE',
          {
            key: 'errorList',
            value: [{ name: error.response.data.message, show: true }]
          },
          { root: true }
        )
        this.isNotify = true
      } finally {
        this.loading = false
      }
    },

    fillData (item) {
      this.editingObj.name = item.name
      this.editingObj.code = item.code
      this.editingObj.contact = item.contacts
      this.editingObj.is_active = item.is_active
      this.editingObj.create_year = item.create_year
    }
  }
}
</script>

<style>
.required-label-files {
  color: #c81919;
  position: absolute;
  top: -5px;
  right: -10px;
}
</style>
