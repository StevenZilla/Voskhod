<template>
  <v-dialog
    v-model="showDeleteModal"
    persistent
    max-width="800"
    height="600px"
    content-class="dialog-auto-height"
    @click:outside="$emit('close')"
  >
    <v-card>
      <div class="d-flex align-center justify-space-between subdivision-title">
        <v-card-title class="mb-0">
          <h5 class="m-1">Удаление подразделения</h5>
        </v-card-title>
        <v-tooltip left>
          <template v-slot:activator="{ on }">
            <div class="" v-on="on">
              <v-btn icon dark @click="$emit('close')">
                <v-icon color="element">mdi-close</v-icon>
              </v-btn>
            </div>
          </template>
          <span>Закрыть</span>
        </v-tooltip>
      </div>
      <div class="card-body px-4 py-4">
        <h4 class="">
          Вы уверены, что хотите удалить подразделение "
          <span :style="{ color: 'red' }">{{ subdivisionName }}</span>"?
        </h4>
      </div>
      <v-card-actions class="justify-end pt-3 subdivision-footer">
        <v-btn class="default-btn" color="secondary" outlined @click="$emit('close')">Нет</v-btn>
        <v-btn class="default-btn" color="secondary" @click="submitHandler" :loading="loading">Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import { DELETE_SUBDIVISION } from '@/modules/nsi/submodules/subdivisions/services/api'

export default {
  name: 'DeleteSubdivision',
  props: ['subdivisionInfo'],
  data: () => ({
    showDeleteModal: true,
    newSubdivision: '',
    loading: false
  }),
  computed: {
    subdivisionName () {
      return this.subdivisionInfo?.code + ' ' + this.subdivisionInfo?.name || ''
    }
  },
  methods: {
    async submitHandler () {
      this.loading = true
      try {
        await DELETE_SUBDIVISION(this.subdivisionInfo.id)
        this.$emit('deleted')
      } catch (e) {
        console.log(e)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style scoped>
  .subdivision-title {
    border-bottom: 1px solid #cbcbcd;
  }
  .subdivision-footer {
    border-top: 1px solid #cbcbcd;
  }
</style>
