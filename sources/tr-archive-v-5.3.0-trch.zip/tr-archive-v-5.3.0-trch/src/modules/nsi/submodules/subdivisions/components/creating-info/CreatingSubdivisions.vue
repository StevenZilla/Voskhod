<template>
  <v-dialog
    v-model="isCreating"
    transition="scroll-y-transition"
    max-width="530px"
    content-class="dialog-auto-height"
    @click:outside="closeDialog"
  >
    <template v-slot:activator="{ on, attrs }">
      <div class="detail__buttons detail__buttons-left">
        <v-btn
          class="rounded-lg"
          outlined
          color="secondary"
          v-bind="attrs"
          v-on="on"
          >Добавить подразделение
        </v-btn>
      </div>
    </template>

    <v-card class="detail__main-info popup">
      <v-toolbar flat dense class="popup-toolbar">
        <v-toolbar-title>Добавление подразделения</v-toolbar-title>
        <BtnCancelSlot :icon="true" @close="closeDialog()" />
      </v-toolbar>

      <div class="popup__content">
        <div class="form-group">
          <p class="form-group__title">
            Наименование подразделения <span class="required-label">*</span>
          </p>
          <v-text-field
            v-model="createObj.name"
            class="rounded-lg"
            clearable
            required
            outlined
            placeholder="Введите наименование подразделения"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">
            Код подразделения <span class="required-label">*</span>
          </p>
          <v-text-field
            v-model="createObj.code"
            class="rounded-lg"
            clearable
            required
            rounded
            outlined
            placeholder="Введите код подразделения"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Контактные данные</p>
          <v-text-field
            v-model="createObj.contact"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Введите контактные данные"
          ></v-text-field>
        </div>
        <!-- <div class="form-group d-flex justify-center">
          <p class="form-group__title">Действующее</p>
          <v-simple-checkbox
            color="secondary"
            v-ripple
            v-model="createObj.is_active"
          ></v-simple-checkbox>
        </div> -->

        <div class="form-group">
          <p class="form-group__title">
            Год создания подразделения <span class="required-label">*</span>
          </p>
          <v-autocomplete
            v-model="createObj.create_year"
            class="rounded-lg"
            data-qa="reg-date"
            hide-details
            clearable
            outlined
            rounded
            solo
            append-icon="mdi-calendar-blank"
            placeholder="Укажите год создания"
            color="secondary"
            item-color="secondary"
            :items="arrayYearsMix"
            :no-data-text="'Нет результатов'"
          ></v-autocomplete>
        </div>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
          :text="'Добавить'"
          :loading="loading"
          :disabled="invalidSubdivisions"
          @save="createHandler()"
        />
        <BtnCancelSlot :text="'Отменить'" @close="closeDialog()" />
      </div>

      <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px"
      >
        <AppNotify
          :title="'Создание'"
          :text="error"
          :type="'error'"
          :icon="'mdi-alert'"
          @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>
import * as subdivisions from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'

export default {
  name: 'CreatingSubdivisions',

  validations: {
    createObj: {
      name: { required },
      code: { required },
      create_year: { required }
    }
  },

  data: () => ({
    loading: false,
    isNotify: false,
    isCreating: false,
    createObj: {
      name: '',
      code: '',
      contact: '',
      is_active: true,
      create_year: null
    }
  }),

  computed: {
    ...mapState({
      error: (state) => state.error
    }),

    invalidSubdivisions () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.isCreating = false
      this.$emit('close')
    },

    async createHandler () {
      this.loading = true
      this.error = ''
      try {
        await subdivisions.CREATE_SUBDIVISION(this.createObj)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
