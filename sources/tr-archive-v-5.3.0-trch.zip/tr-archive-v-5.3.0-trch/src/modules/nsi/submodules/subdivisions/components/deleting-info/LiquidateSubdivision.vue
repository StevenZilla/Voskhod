<template>
  <v-dialog
    v-model="showDeleteModal"
    persistent
    max-width="800"
    height="600px"
    content-class="dialog-auto-height"
    @click:outside="$emit('close')"
  >
    <v-card>
      <div class="d-flex align-center justify-space-between subdivision-title">
        <v-card-title class="mb-0">
          <h5 class="m-1">Ликвидация подразделения</h5>
        </v-card-title>
        <v-tooltip left>
          <template v-slot:activator="{ on }">
            <div class="" v-on="on">
              <v-btn icon dark @click="$emit('close')">
                <v-icon color="element">mdi-close</v-icon>
              </v-btn>
            </div>
          </template>
          <span>Закрыть</span>
        </v-tooltip>
      </div>
      <div class="card-body px-4 py-4">
        <h4 class="">
          Вы уверены, что хотите ликвидировать подразделение "
          <span :style="{ color: 'red' }">{{ subdivisionName }}</span>"?
        </h4>
        <template v-if="needMove">
          <h4 class="py-3">Укажите подразделение, на которое назначить все объекты ликвидируемого подразделения:</h4>
          <SelectSubdivision @new-subdivision="newSubdivision = $event"/>
        </template>
      </div>
      <v-card-actions class="justify-end pt-3 subdivision-footer">
        <v-btn class="default-btn" color="secondary" outlined @click="$emit('close')">{{ cancelText }}</v-btn>
        <v-btn v-if="!needMove" class="default-btn" color="secondary" @click="submitHandler" :loading="loading">Да</v-btn>
        <v-btn v-else class="default-btn" color="secondary" @click="submitHandler" :disabled="invalidData" :loading="loading">Сохранить</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import SelectSubdivision from '@/modules/nsi/submodules/subdivisions/components/deleting-info/SelectSubdivision.vue'
import { LIQUIDATE_SUBDIVISION } from '@/modules/nsi/submodules/subdivisions/services/api'
import { required } from 'vuelidate/lib/validators'

export default {
  name: 'LiquidateSubdivision',
  props: ['subdivisionInfo'],
  components: { SelectSubdivision },
  validations: {
    newSubdivision: { required }
  },
  data: () => ({
    showDeleteModal: true,
    newSubdivision: '',
    loading: false
  }),
  computed: {
    subdivisionName () {
      return this.subdivisionInfo?.code + ' ' + this.subdivisionInfo?.name || ''
    },
    cancelText () {
      return !this.subdivisionInfo?.can_liquidate ? 'Отменить' : 'Нет'
    },
    invalidData () {
      return this.$v.$invalid
    },
    needMove () {
      return this.subdivisionInfo?.can_liquidate?.need_move || false
    }
  },
  methods: {
    async submitHandler () {
      this.loading = true
      try {
        await LIQUIDATE_SUBDIVISION(this.subdivisionInfo.id, this.newSubdivision)
        this.$emit('liquidated')
      } catch (e) {
        console.log(e)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style scoped>
  .subdivision-title {
    border-bottom: 1px solid #cbcbcd;
  }
  .subdivision-footer {
    border-top: 1px solid #cbcbcd;
  }
</style>
