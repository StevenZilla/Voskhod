<template>
  <div class="form-group">
    <v-autocomplete
      v-model="value"
      class="rounded-lg"
      return-object
      hide-details
      solo
      outlined
      clearable
      placeholder="Выберите подразделение"
      :items="subdivisionList"
      :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'SelectSubdivision',

  data: () => ({
    subdivisionList: [],
    value: ''
  }),
  computed: {
    ...mapState({
      subdivisions: state => state.nsi.subdivisions.subdivisionsResponse.subdivisions,
      liquidateSubdivisionId: state => state.nsi.subdivisions.liquidateSubdivisionId
    })
  },
  mounted () {
    this.subdivisions.forEach(el => {
      if (el.is_active && el.id !== this.liquidateSubdivisionId && !el.is_org) {
        this.subdivisionList.push(el.code + ' ' + el.name)
      }
    })
  },
  watch: {
    value (newV) {
      const selectedEl = this.subdivisions.find(el => el.code + ' ' + el.name === newV)
      this.$emit('new-subdivision', selectedEl?.id)
    }
  }
}
</script>

<style lang="scss">
</style>
