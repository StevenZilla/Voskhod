import { subdivisionEvent } from '@/event-code'
// import { subdivisions } from '@/permissions'
const SubdivisionsPage = () => import('../views/SubdivisionsPage.vue')

const pathSubdivision = '/nsi/subdivisions'

const subdivisionsRouter = [
  {
    name: 'SubdivisionsPage',
    path: pathSubdivision,
    component: SubdivisionsPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Подразделения' }
      ],
      // tech_name: subdivisions.code,
      code: subdivisionEvent.code
    }
  }
]

export default subdivisionsRouter
