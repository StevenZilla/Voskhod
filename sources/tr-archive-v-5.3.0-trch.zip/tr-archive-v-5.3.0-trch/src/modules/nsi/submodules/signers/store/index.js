export default {
  namespaced: true,
  state: {
    signersResponse: null,
    signersLoading: true,
    signersRole: [],
    signersList: [],
    usersResponse: null,
    usersList: []
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },
  getters: {
    SIGNERS_LIST: state => {
      if (!state.signersResponse) return []

      return state.signersResponse.signers.map(item => {
        return { fio: item.fio, id: item.id, role: item.role }
      })
    },

    SIGNERS_ROLE: state => {
      if (!state.signersResponse) return []

      return state.signersResponse.signers.map(item => {
        return { fio: item.fio, id: item.id, role: item.role }
      })
    },

    USERS_LIST: state => {
      if (!state.usersList.length) return []

      return state.usersList.map(item => {
        return { text: item.fio, value: item.id }
      })
    },

    FILTER_SIGNERS_LIST: state => {
      if (!state.signersResponse) return []

      return state.signersResponse.signers.filter(item => {
        return item.role.code === 'approver' || item.role.code === 'inventory_compiler'
      })
    }
  }
}
