<template>
  <div class="signers-page">
    <div class="d-flex align-center">
      <span class="page-title">Участники согласований</span>
    </div>

    <div class="main-line">
      <SearchPanel
        @set-filters="acceptFilters($event)"
      />
    </div>

    <div class="mb-5 d-flex justify-space-between align-center">
      <h2 class="results-title">Результаты поиска</h2>
    </div>

    <v-progress-linear
      indeterminate
      height="7"
      v-if="signersResponse === null"
      color="secondary"
    ></v-progress-linear>

    <v-alert
      v-else-if="signersResponse === ''"
      icon="mdi-alert"
      type="error"
    >Произошла ошибка при получении данных
    </v-alert>

    <v-data-table
      v-else
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      item-key="id"
      class="main-table scroll-table sortable-table row-default-cursor"
      hide-default-footer
      :headers="headers"
      :options.sync="options"
      :items="signersResponse.signers"
      :loading="signersLoading"
      :page.sync="page"
      :items-per-page="itemsPerPage"
      :server-items-length="signersResponse.count"
      :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
      @page-count="pageCount = $event"
    >
      <!-- eslint-disable-next-line -->
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.role="{ item }">
        {{ item.role.value }}
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_actual="{ item }">
        <div class="d-flex justify-center checkbox-color">
          <v-simple-checkbox
            :value="item.is_actual"
            disabled
          ></v-simple-checkbox>
        </div>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-icon
          v-if="$can('participant_edit', 'nsi')"
          color="secondary"
          @click="tableEditClick(item)"
        >
          mdi-pencil
        </v-icon>
      </template>

      <!-- eslint-disable-next-line -->
      <template #footer="{props}">
        <PaginationTable
          :page.sync="page"
          :pagination="props.pagination"
        />
      </template>
    </v-data-table>

    <EditingSigner
      :mode="isEditing"
      :signer="selectedSigner"
      :loading="loading"
      @close="isEditing = false"
      @refresh="refresh"
    />

    <CreatingSigner
      :key="modalKey"
      :loading="loading"
      @close="clearModal"
      @refresh="refresh"
    />
  </div>
</template>

<script>
import * as signers from '../services/api'
import { mapState } from 'vuex'
import SearchPanel from '../components/SearchPanel.vue'
const EditingSigner = () => import('../components/editing-info/EditingSigner.vue')
const CreatingSigner = () => import('../components/creating-info/CreatingSigner.vue')

export default {
  name: 'SignersPage',
  components: {
    SearchPanel,
    EditingSigner,
    CreatingSigner
  },
  data: () => ({
    filterParams: null,
    selectedSigner: {},
    clearComponent: 0,
    isEditing: false,
    fullFilter: false,
    errorMsg: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    modalKey: 0,
    options: null,
    clear: false,
    loading: false,
    headers: [
      {
        text: 'ФИО',
        value: 'fio',
        width: '20%'
      },
      {
        text: 'Должность',
        value: 'position',
        width: '25%'
      },
      {
        text: 'Роль',
        value: 'role',
        width: '20%'
      },

      {
        text: 'Актуальность',
        align: 'center',
        value: 'is_actual',
        width: '15%'
      },
      {
        text: 'Редактировать',
        align: 'center',
        sortable: false,
        class: 'cell-class',
        width: '165px',
        value: 'actions'
      }
    ]
  }),
  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          signers.GET_SIGNERS_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      signersResponse: state => state.nsi.signers.signersResponse,
      signersLoading: state => state.nsi.signers.signersLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.signersResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('role.value') !== -1) {
            par += 'role_value'
          } else if (sortBy[0].indexOf('user.value') !== -1) {
            par += 'user_login'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    tableEditClick (data) {
      this.isEditing = true
      this.selectedSigner = data
    },

    clearModal () {
      this.modalKey++
    },
    async refresh () {
      await signers.GET_SIGNERS_RESPONSE()
    },

    async acceptFilters (evt) {
      this.filterParams = evt
      await signers.GET_SIGNERS_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
      this.fullFilter = false
    },

    async updateHandler (e) {
      this.errorMsg = null
      try {
        await signers.GET_SIGNERS_RESPONSE()
        this.isEditing = false
      } catch (error) {
        this.errorMsg = error.response?.data.message
      }
    },

    switchMode () {
      this.clearComponent++
      this.isEditing = true
    },

    async clearFilters () {
      this.clear = false
      this.filterObj.signerName = null
      this.filterObj.is_actual = null
      await signers.GET_SIGNERS_RESPONSE()
    },

    async onKeyDown (e) {
      if (e.code === 'Enter') {
        await signers.GET_SIGNERS_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
      }
    }
  },

  async created () {
    await signers.GET_SIGNERS_RESPONSE()

    this.loading = true
    Promise.all([
      signers.GET_USERS_LIST(),
      signers.GET_SIGNERS_ROLE(),
      signers.GET_USERS_LIST
    ]).finally(() => {
      this.loading = false
    })
  },

  async mounted () {
    this.$eventBus.$on('closeCreate', () => {
      this.isEditing = false
    })
    this.$eventBus.$on('updatedData', async updateObj => {
      await this.updateHandler(updateObj.update)
    })
  },
  beforeMount () {
    document.addEventListener('keydown', this.onKeyDown)
  },
  beforeDestroy () {
    document.removeEventListener('keydown', this.onKeyDown)
    this.$eventBus.$off('updatedData')
  }
}
</script>

<style lang="scss">
</style>
