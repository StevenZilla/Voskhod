<template>
  <v-dialog
      v-model="isEditing"
      transition="scroll-y-transition"
      max-width="530px"
      content-class="dialog-max-height editing-signers-dialog"
      @click:outside="closeDialog"
  >
    <v-card
        class="detail__main-info popup"
    >
      <v-toolbar
          flat
          dense
          class="popup-toolbar"
      >
        <v-toolbar-title>Редактирование подписантов</v-toolbar-title>
        <BtnCancelSlot
            :icon="true"
            @close="closeDialog()"
        />
      </v-toolbar>

      <div
          class="popup__content"
      >
        <div class="form-group">
          <p class="form-group__title">Должность <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.position"
              class="rounded-lg"
              clearable
              required
              outlined
              placeholder="Введите должность"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Роль <span class="required-label">*</span></p>
          <v-select
              v-model="editingObj.role"
              class="rounded-lg"
              outlined
              color="secondary"
              item-text="value"
              item-value="id"
              clearable
              return-object
              placeholder="Выберите роль"
              :no-data-text="'Нет данных'"
              :loading="loading"
              :loader-height="5"
              :items="signersRole"
          ></v-select>
        </div>
        <div class="form-group">
          <p class="form-group__title">ФИО <span class="required-label">*</span></p>
          <v-autocomplete
              v-model="editingObj.user.user_id"
              class="rounded-lg"
              outlined
              color="secondary"
              clearable
              placeholder="Выберите пользователя"
              :no-data-text="'Нет данных'"
              :items="USERS_LIST"
              :loader-height="5"
              :loading="loadingUsers"
              @update:search-input="searchInput"
          ></v-autocomplete>
        </div>

        <div class="form-group d-flex justify-center">
          <p class="form-group__title">Актуальность <span class="required-label">*</span></p>
          <v-simple-checkbox
              color="secondary"
              v-ripple
              v-model="editingObj.is_actual"
          ></v-simple-checkbox>
        </div>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
            :text="'Сохранить'"
            :loading="loadingDonut"
            :disabled="invalidSigners"
            @save="updateHandler()"
        />
        <BtnCancelSlot
            :text="'Отменить'"
            @close="closeDialog()"
        />
      </div>

      <v-dialog
          v-model="isNotify"
          content-class="dialog-auto-height"
          max-width="615px"
      >
        <AppNotify
            :title="'Редактирование'"
            :text="error"
            :type="'error'"
            :icon="'mdi-alert'"
            @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as signers from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapGetters, mapState } from 'vuex'
import { debounce } from 'lodash'
export default {
  name: 'EditingSigners',

  validations: {
    editingObj: {
      position: { required },
      role: {
        id: { required }
      },
      user: {
        user_id: { required }
      }
    }
  },

  props: {
    signer: {
      type: Object
    },
    mode: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean
    }
  },

  data: () => ({
    editingObj: {
      user: {
        user_id: ''
      },
      fio: '',
      position: '',
      role: '',
      is_actual: false
    },
    isNotify: false,
    isEditing: false,
    loadingDonut: false,
    loadingUsers: false,
    error: ''
  }),

  computed: {
    ...mapState({
      signersRole: state => state.nsi.signers.signersRole,
      signersResponse: state => state.nsi.signers.signersResponse,
      signersLoading: state => state.nsi.signers.signersLoading,
      usersLoading: state => state.nsi.signers.usersLoading
    }),

    ...mapGetters('nsi/signers', ['USERS_LIST']),

    invalidSigners () {
      return this.$v.$invalid
    }
  },

  methods: {
    searchInput: debounce(async function (val) {
      const paramsSort = new URLSearchParams()
      if (val) paramsSort.append('q', val)

      this.loadingUsers = true
      await signers.GET_USERS_LIST(paramsSort).finally(() => { this.loadingUsers = false })
    }, 500),

    closeDialog () {
      this.$emit('close')
    },

    async updateHandler () {
      this.loadingDonut = true
      const data = this.fillData()

      try {
        await signers.UPDATE_SIGNER(data, data.id)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loadingDonut = false
      }
    },

    fillData () {
      const editObj = { ...this.editingObj }
      editObj.user_id = editObj.user.user_id
      editObj.role_id = editObj.role.id
      return editObj
    }
  },

  watch: {
    signer: function () {
      this.editingObj = { ...this.signer }
    },
    mode: function (val) {
      this.isEditing = val
    }
  }
}
</script>
<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
