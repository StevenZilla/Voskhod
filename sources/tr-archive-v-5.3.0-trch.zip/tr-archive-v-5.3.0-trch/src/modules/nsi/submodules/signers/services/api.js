import api from '@/services/api'
import store from '@/storages'

export async function GET_SIGNERS_RESPONSE (combined) {
  store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: true }, { root: true })
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/v2/admin/nsi/signers/', { params: combined })
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersResponse', value: resp.data })
  } catch (error) {
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersList', value: { key: 'error', value: true } })
    throw (error)
  } finally {
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: false }, { root: true })
  }
}

export async function CREATE_SIGNER (data) {
  store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: true }, { root: true })
  try {
    await api.post('/v2/admin/nsi/signers', data)
  } catch (error) {
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersList', value: { key: 'error', value: true } })
    throw (error)
  } finally {
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: false }, { root: true })
  }
}

export async function UPDATE_SIGNER (data, id) {
  store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: true }, { root: true })
  try {
    console.log('/v2/admin/nsi/signers/' + id, data)
    await api.put('/v2/admin/nsi/signers/' + id, data)
  } catch (error) {
    console.log(error)
    throw (error)
  } finally {
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: false }, { root: true })
  }
}

export async function GET_SIGNERS_ROLE (combined) {
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/ead/nsi/signer_roles', { params: combined })
    store.dispatch('nsi/signers/SET_VALUE', { key: 'signersRole', value: resp.data })
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function GET_USERS_LIST (combined) {
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/ead/users', { params: combined })
    store.dispatch('nsi/signers/SET_VALUE', { key: 'usersList', value: resp.data.users })
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
