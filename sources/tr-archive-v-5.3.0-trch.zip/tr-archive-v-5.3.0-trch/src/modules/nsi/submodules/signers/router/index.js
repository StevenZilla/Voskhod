import { participantEvent } from '@/event-code'
import { participants } from '@/permissions'
const SignersPage = () => import('../views/SignersPage.vue')

const signersRouter = [
  {
    name: 'SignersPage',
    path: participants.path,
    component: SignersPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Участники согласований' }
      ],
      tech_name: participants.code,
      code: participantEvent.code
    }
  }
]

export default signersRouter
