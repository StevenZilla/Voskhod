<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
    >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
        />
    </template>
    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <Actual
        class="w-20"
        ref="actual"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>
import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import Actual from '@/components/Filters/Fields/Actual.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

import { mapState } from 'vuex'

export default {
  name: 'Filters',
  components: { FiltersTemplate, ChipsFilters, Actual, FilterFooter },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    filterObj: {}
  }),

  computed: {
    ...mapState({
      error: (state) => state.error
    }),

    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []
      if (this.filterObj.actual) {
        paramsFilter.append('is_actual', this.filterObj.actual.query.value)
        chips.push(this.filterObj.actual)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      if (this.filterObj.actual?.query.value === null) {
        return false
      }
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },
    acceptFilters () {
      this.chipsList = this.filterParams.chips.map((chip) => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },
    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style></style>
