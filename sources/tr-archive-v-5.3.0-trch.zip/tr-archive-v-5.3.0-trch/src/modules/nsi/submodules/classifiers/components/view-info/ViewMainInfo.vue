<template>
  <div class="wrapper">
    <div class="d-flex" style="gap: 8px">
      <div class="form-group">
        <label for="inputField">Наименование</label>
        <p>{{ classifierCard.name }}</p>
      </div>
      <div class="form-group">
        <label for="inputField">Краткое наименование</label>
        <p>{{ classifierCard.short_name }}</p>
      </div>
      <div class="form-group">
        <label for="inputField">Описание</label>
        <p>{{ classifierCard.description }}</p>
      </div>
    </div>
    <div class="d-flex" style="gap: 8px">
      <div class="form-group">
        <label for="inputField">Организация владелец</label>
        <p>{{ classifierCard.is_ched ? 'ЦХЭД' : 'ОИК' }}</p>
      </div>
      <div class="form-group">
        <label for="inputField">Версия</label>
        <p>{{ classifierCard.version }}</p>
      </div>
      <div class="form-group">
        <label for="inputField">Дата последнего изменения</label>
        <p >{{ $_formatDate(classifierCard.update_date, 'time') }}</p>
      </div>
    </div>
    <div class="form-group" style="gap: 8px">
      <label for="inputField">Основной</label>
      <div>
        <v-checkbox
            color="secondary"
            hide-details
            :value="classifierCard.is_main"
            disabled
        ></v-checkbox>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'ViewMainInfo',
  computed: {
    ...mapState({
      classifierCard: state => state.nsi.classifiers.classifierCard
    })
  }
}
</script>

<style lang="scss" scoped>
.wrapper {
  border: 1px solid #cbcbcd;
  padding: 40px;
  background: white;
  border-radius: 5px;
  margin-top: 30px;
}
textarea {
  width: 100%;
  height: 8rem;
  padding: 5px;
  border: 1px solid #cbcbcd;
  outline-color: #cbcbcd;
  border-radius: 10px;
  text-align: justify;
  margin-top: 5px;
  min-height: 8rem;
}
.form-group {
  margin-bottom: 40px;
  flex: 1;
}

.form-group label {
  display: block;
  color: #76767A;
}

.form-group .divider {
  border-bottom: 3px solid #c9c9c9;
  margin: 5px 0;
}

.form-group input[type="text"],
.form-group textarea {
  width: 100%;
  padding: 5px;
  font-size: 16px;
}
.form-group input[type="text"]:focus {
  border-bottom: 1px solid #cbcbcd;
  outline: none; /* Убираем стандартное синее подчеркивание */
}
</style>
