<template>
  <div class="card">
    <ViewMainInfo/>

  </div>
</template>

<script>

import ViewMainInfo from './ViewMainInfo.vue'

export default {
  components: { ViewMainInfo }
}
</script>

<style lang="scss">
</style>
