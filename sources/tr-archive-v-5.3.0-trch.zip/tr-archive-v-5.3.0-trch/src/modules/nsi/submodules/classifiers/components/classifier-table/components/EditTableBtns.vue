<template>
  <div class="main-table-inner__buttons d-flex justify-start" v-if="!loading">
    <template v-if="!tabItem">
      <v-btn
          v-if="$can('di_classifier_edit', 'nsi') && modeClassifierTable !== 'edit' && !isChed"
          color="secondary"
          class="rounded-lg"
          outlined
          @click="openDataEditor"
          :loading="loading"
      ><v-icon class="mr-2">mdi-pencil-outline</v-icon>
        Открыть редактирование
      </v-btn>
      <template v-if="modeClassifierTable==='edit'">
        <BtnCancelSlot
            v-if="unSavedChanges"
            :text="'Закрыть редактирование'"
            @close="closeEditMode"
        />
        <v-btn
            v-else
            color="secondary"
            class="rounded-lg"
            outlined
            @click="closeEditMode"
        ><v-icon class="mr-2">mdi-pencil-outline</v-icon>
          Закрыть редактирование
        </v-btn>
      </template>
    </template>
    <template v-if="!!tabItem">
      <v-btn
          v-if="$can('di_classifier_edit', 'nsi') && modeClassifier !== 'edit' && !isChed"
          color="secondary"
          class="rounded-lg"
          outlined
          @click="switchMode"
          :loading="loading"
      ><v-icon class="mr-2">mdi-pencil-outline</v-icon>
        Открыть редактирование
      </v-btn>
      <BtnCancelSlot
          v-if="$can('di_classifier_edit', 'nsi') && modeClassifier === 'edit' && !isChed"
          :text="'Закрыть редактирование'"
          @close="cancelEdit"
      />
    </template>
  </div>
</template>

<script>

import { GET_KINDS_SAVE_TYPE_LIST_V2 } from '@/modules/nsi/submodules/classifiers/services/api'
import { mapState } from 'vuex'
export default {
  props: ['tabItem'],
  computed: {
    ...mapState({
      mainInfo: state => state.nsi.classifierTable.mainInfo,
      saveTypeList: state => state.nsi.classifierTable.saveTypeList,
      modeClassifierTable: state => state.nsi.classifiers.modeClassifierTable,
      modeClassifier: state => state.nsi.classifiers.modeClassifier,
      isChed: state => state.nsi.classifiers.classifierCard.is_ched,
      loading: state => state.nsi.classifiers.loading
    }),
    unSavedChanges () {
      return Object.keys(this.mainInfo).length !== 0
    }
  },

  methods: {

    openDataEditor () {
      if (!this.saveTypeList && !this.tabItem) {
        GET_KINDS_SAVE_TYPE_LIST_V2().then(resp => { this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'saveTypeList', value: resp.save_types }) })
      }
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifierTable', value: 'edit' })
    },

    closeEditMode () {
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifierTable', value: 'view' })
      this.$store.commit('nsi/classifierTable/getInitialState')
    },

    switchMode () {
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'edit' })
    },

    cancelEdit () {
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'view' })
    }
  }
}
</script>
