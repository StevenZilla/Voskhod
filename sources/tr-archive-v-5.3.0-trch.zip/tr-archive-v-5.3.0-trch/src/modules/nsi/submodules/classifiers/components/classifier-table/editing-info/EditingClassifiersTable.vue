<template>
  <div class="my-5">
    <SubmitModal
      :isWarning="isWarning"
      @cancel-changes="cancelChanges"
      @submit="submitRequest"
    />
    <error-modal :isError="isError" @close-error="isError=false"></error-modal>
    <div class="my-5">
      <table>
        <tbody>
          <tr>
            <th style="background: #e6e6e6; width: 7% !important;">№ статьи</th>
            <th style="background: #e6e6e6; width: 35% !important;">Вид документа</th>
            <th style="background: #e6e6e6; width: 10% !important;">Срок хранения документа</th>
            <th style="background: #e6e6e6; width: 30% !important;">Примечания</th>
            <th style="background: #e6e6e6; width: 15% !important;">{{ isChed ? 'Код типового перечня' : 'Код' }}</th>
            <th style="width: 5% !important; background: #e6e6e6">Активно</th>
            <th style="width: 5% !important; background: #e6e6e6"></th>
            <th style="width: 5% !important; background: #e6e6e6"></th>
          </tr>
        </tbody>
        <tbody class='m-0' v-for="(group) in groups" :key="group.id" @click="handlerClick($event)">
          <tr>
            <th style="width: 5% !important;">
              <AddTitleMenu :group="group" v-if="!mainInfo.actionAttr"/>
            </th>
            <template v-if="group.actionAttr === 'edit_group'">
              <th colspan="3">
                <div class="d-flex justify-end">
                  <div style="padding-right: 10px;"><span style="color: indianred">*</span></div>
                </div>
                <input
                    placeholder="Введите название группы/подгруппы"
                    v-model="name"
                />
              </th>
              <th >
                <div class="d-flex justify-end">
                  <div style="padding-right: 10px;"><span style="color: darkseagreen">**</span></div>
                </div>
                <input
                    placeholder="Введите код"
                    v-model="code"
                />
              </th>
            </template>
            <th colspan="4" v-else>{{ group.name }}</th>
            <th style="width: 5% !important;">
              <div class="checkbox-container">
                <input
                    type="checkbox"
                    class="checkbox"
                    :checked="group.is_active"
                    :id="group.id"
                    :actionAttr="'change_active_status_group'"
                    :disabled="mainInfo.actionAttr || group.empty"
                />
              </div>
            </th>
            <template>
              <th style="width: 5% !important;"  v-if="group.actionAttr!=='edit_group'">
                <v-btn
                    color="secondary"
                    class="rounded-lg"
                    icon
                    :disabled="group.is_block_edit || !!mainInfo.actionAttr || group.empty"
                    :id="group.id"
                    :actionAttr="'edit_group'"
                    :code="group.code"
                >
                  <v-icon>mdi-pencil-outline</v-icon>
                </v-btn>
              </th>
              <th v-else>
                <v-btn
                    color="secondary"
                    class="rounded-lg"
                    icon
                    @click="cancelChanges"
                ><v-icon>mdi-close</v-icon>
                </v-btn>
              </th>
            </template>
            <template>
              <th style="width: 5% !important;" v-if="group.actionAttr!=='edit_group'">
                <v-btn
                  color="secondary"
                  class="rounded-lg"
                  icon
                  :disabled="group.is_block_delete || !!mainInfo.actionAttr || group.empty"
                  :id="group.id"
                  :actionAttr="'delete_group'"
                ><v-icon>mdi-delete-outline</v-icon></v-btn>
              </th>
              <th style="width: 5% !important;" v-else>
                <v-btn
                    color="secondary"
                    class="rounded-lg"
                    icon
                    :actionAttr="'submit_edit_group'"
                ><v-icon>mdi-check</v-icon>
                </v-btn>
              </th>
            </template>
          </tr>
          <tr v-if="group.actionAttr==='edit_group'">
            <td style="border-right: none; background-color: #d7e3f1;"></td>
            <td style="width: 10% !important; border-left: none; background-color: #d7e3f1;" colspan="7">
              <p style="margin-bottom: 0"><span style="color: indianred">*</span> Поле обязательно к заполнению</p>
              <p><span style="color: darkseagreen">**</span> Не обязательное поле, в случае отсутствия значение будет сгенерированно автоматически</p>
            </td>
          </tr>
          <tr v-for="article in group.di_kinds" :key="article.id">
            <td style="width: 7% !important;">
              <textarea class="text-area" v-if="article.actionAttr === 'edit_article'" v-model="num"></textarea>
              <span v-else>{{ article.num}}</span>
            </td>
            <td style="width: 35% !important;">
              <textarea class="text-area" v-if="article.actionAttr === 'edit_article'" v-model="name"></textarea>
              <span v-else>{{ article.name}}</span>
            </td>
            <SaveType
              v-if="article.actionAttr === 'edit_article'"
              @saveTypeObj="setSaveInfo($event)"
            />
            <td v-else style="width: 10% !important;">{{ article.save_info }}</td>
            <td style="width: 30% !important;">
              <textarea class="text-area" v-if="article.actionAttr === 'edit_article'" v-model="descr"></textarea>
              <span v-else>{{ article.descr}}</span>
            </td>
            <td style="width: 15% !important;">
              <textarea class="text-area" v-if="article.actionAttr === 'edit_article'" v-model="code" disabled style="background-color: #f0f0f0;"></textarea>
              <span v-else>{{ article.code}}</span>
            </td>
            <td style="width: 5% !important;">
              <div class="checkbox-container">
                <input
                 type="checkbox"
                 class="checkbox"
                 :checked="article.is_active"
                 :id="article.id"
                 :actionAttr="'change_active_status'"
                 :disabled="mainInfo.actionAttr"
                />
              </div>
            </td>
            <td style="width: 3% !important;" v-if="article.actionAttr!=='edit_article'">
              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                :disabled="article.is_block_edit || !!mainInfo.actionAttr"
                :actionAttr="'edit_article'"
                :code="article.code"
                :id="article.id"
              >
                <v-icon>mdi-pencil-outline</v-icon>
              </v-btn>
            </td>
            <td v-else>
              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                @click="cancelChanges"
              ><v-icon>mdi-close</v-icon>
              </v-btn>
            </td>
            <td style="width: 5% !important;" v-if="article.actionAttr!=='edit_article'">
              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                :disabled="article.is_block_delete || !!mainInfo.actionAttr"
                :actionAttr="'delete_article'"
                :id="article.id"
              >
                <v-icon>mdi-delete-outline</v-icon>
              </v-btn>
            </td>
            <td style="width: 5% !important;" v-else>
              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                :actionAttr="'submit_edit'"
              ><v-icon>mdi-check</v-icon>
              </v-btn>
            </td>
          </tr>
          <NewArticleSection
            :group="group" v-if="group.code === mainInfo.code && mainInfo.actionAttr === 'create_article'"
            @cancel-changes="cancelChanges"
            @creating-article="createItem($event)"
          />
          <template v-if="group.code === mainInfo.code && mainInfo.actionAttr === 'create_group'">
            <td style="width: 5% !important; background: #d7e3f1;" colspan="8"></td>
            <NewGroupSection @cancel-changes="cancelChanges" @creating-group="createItem"/>
            <tr>
              <td style="width: 7% !important;"></td>
              <td style="width: 10% !important;" colspan="4">
                <p style="margin-bottom: 0"><span style="color: indianred">*</span> Поле обязательно к заполнению</p>
                <p><span style="color: darkseagreen">**</span> Не обязательное поле, в случае отсутствия значение будет сгенерированно автоматически</p>
              </td>
              <td style="width: 5% !important;"></td>
              <td style="width: 3% !important;"></td>
              <td style="width: 5% !important;"></td>
            </tr>
            <td style="width: 5% !important; background: #d7e3f1;" colspan="8"></td>
          </template>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>

import { mapState } from 'vuex'
import {
  CHANGE_ACTIVE_STATUS,
  CHANGE_TITLE_NAME,
  CREATE_ARTICLE, CREATE_CLASSIFIER_GROUP_V2, DELETE_ARTICLE, DELETE_GROUP, UPDATE_CLASSIFIER_KINDS
} from '@/modules/nsi/submodules/classifiers/services/api'
import SubmitModal from '../components/modal/Submit.vue'
import AddTitleMenu from '../components/NewItemMenu.vue'
import NewArticleSection from '../components/NewArticleSection.vue'
import NewGroupSection from '../components/NewGroupSection.vue'
import SaveType from '../components/SaveType.vue'
import ErrorModal from '@/modules/nsi/submodules/classifiers/components/classifier-table/components/modal/Error.vue'
export default {
  name: 'EditingClassifiersTable',
  components: { ErrorModal, SaveType, NewGroupSection, NewArticleSection, AddTitleMenu, SubmitModal },
  props: ['groups', 'loading', 'isChed'],
  data: () => ({
    isWarning: false,
    isError: false,
    warningText: '',
    dataTransfer: {},
    num: null,
    name: null,
    descr: null,
    code: null,
    isNeedEk: false,
    isNeedEpk: false,
    tempSavePeriod: null,
    saveTypeId: null,
    saveTypeObj: {},
    isActive: false
  }),
  computed: {
    ...mapState({
      saveTypeList: state => state.nsi.classifierTable.saveTypeList,
      mainInfo: state => state.nsi.classifierTable.mainInfo,
      payload: state => state.nsi.classifierTable.payload,
      visibleRow: state => state.nsi.classifierTable.visibleRow,
      allItems: state => state.nsi.classifierTable.allItems
    })
  },
  methods: {
    handlerClick (evt) {
      const element = evt.target.closest('.v-btn') || evt.target
      const actionAttr = element?.getAttribute('actionAttr') || element.getAttribute('actionAttr')
      if (!actionAttr) return

      if (actionAttr === 'delete_article' || actionAttr === 'delete_group') {
        const warningText = `Вы подтверждаете удаление ${actionAttr === 'delete_article' ? 'статьи' : 'группы/подгруппы'}?`
        const mainInfo = { id: element.getAttribute('id'), actionAttr, warningText }
        this.$store.commit('nsi/classifierTable/setValue', { key: 'mainInfo', value: mainInfo })
        this.isWarning = true
      } else if (actionAttr === 'edit_article') {
        const code = element.getAttribute('code')
        this.$store.commit('nsi/classifierTable/setProperty', { code, key: 'actionAttr', value: 'edit_article', copyObj: true })
        this.num = this.mainInfo.num
        this.code = this.mainInfo.code
        this.name = this.mainInfo.name
        this.descr = this.mainInfo.descr
        this.isNeedEk = this.mainInfo.is_need_ek
        this.isNeedEpk = this.mainInfo.is_need_epk
        this.isActive = this.mainInfo.is_active
      } else if (actionAttr === 'submit_edit') {
        this.isWarning = true
        const { num, name, descr, isNeedEk, isNeedEpk, tempSavePeriod, saveTypeId, code } = this
        const payload = {
          id: this.mainInfo.id,
          num,
          name,
          description: descr,
          save_type_id: saveTypeId,
          is_need_ek: isNeedEk,
          is_need_epk: isNeedEpk,
          temp_save_period: tempSavePeriod,
          code
        }
        this.$store.commit('nsi/classifierTable/setValue', { key: 'payload', value: payload })
      } else if (actionAttr === 'edit_group') {
        const code = element.getAttribute('code')
        this.$store.commit('nsi/classifierTable/setProperty', { code, key: 'actionAttr', value: 'edit_group', copyObj: true })
        this.name = this.mainInfo.name
        this.code = this.mainInfo.code.trim()
      } else if (actionAttr === 'submit_edit_group') {
        const payload = {
          name: this.name,
          code: this.code.trim(),
          is_active: true
        }
        this.$store.commit('nsi/classifierTable/setValue', { key: 'payload', value: payload })
        this.isWarning = true
      } else if (actionAttr === 'change_active_status' || actionAttr === 'change_active_status_group') {
        const payload = {
          is_active: element.checked
        }
        this.$store.commit('nsi/classifierTable/setValue', { key: 'mainInfo', value: { actionAttr, id: element.id } })
        this.$store.commit('nsi/classifierTable/setValue', { key: 'payload', value: payload })
        this.submitRequest()
      }
    },
    createItem () {
      this.warningText = this.payload.actionAttr === 'create_group' ? 'Вы действительно хотите создать новую группу/подгруппу' : 'Вы действительно хотите создать новую статью?'
      this.isWarning = true
    },
    cancelChanges () {
      this.$store.commit('nsi/classifierTable/getInitialState')
      this.isWarning = false
    },
    async submitRequest () {
      try {
        this.$store.commit('nsi/classifiers/setValue', { key: 'loading', value: true })

        let res
        if (this.mainInfo.actionAttr === 'delete_article') {
          res = await DELETE_ARTICLE(this.mainInfo.id)
        } else if (this.mainInfo.actionAttr === 'delete_group') {
          res = await DELETE_GROUP(this.mainInfo.id)
        } else if (this.mainInfo.actionAttr === 'create_article') {
          res = await CREATE_ARTICLE(this.payload)
        } else if (this.mainInfo.actionAttr === 'create_group') {
          res = await CREATE_CLASSIFIER_GROUP_V2(this.payload)
        } else if (this.mainInfo.actionAttr === 'edit_article') {
          res = await UPDATE_CLASSIFIER_KINDS(this.payload)
        } else if (this.mainInfo.actionAttr === 'edit_group') {
          res = await CHANGE_TITLE_NAME(this.mainInfo.id, this.payload)
        } else if (this.mainInfo.actionAttr === 'change_active_status') {
          res = await CHANGE_ACTIVE_STATUS(this.mainInfo.id, this.payload, true)
        } else if (this.mainInfo.actionAttr === 'change_active_status_group') {
          res = await CHANGE_ACTIVE_STATUS(this.mainInfo.id, this.payload, false)
        }

        if (res.status && res.status < 400) {
          this.$store.commit('nsi/classifierTable/getInitialState')
          this.$emit('refresh')
        } else {
          this.$store.commit('nsi/classifierTable/setValue', { key: 'error', value: res.data })
          this.isError = true
        }
      } catch (e) {
        console.log(e)
      } finally {
        this.$store.commit('nsi/classifierTable/setValue', { key: 'loading', value: false })
        this.isWarning = false
      }
    },
    setSaveInfo (evt) {
      this.isNeedEk = evt.isNeedEk
      this.isNeedEpk = evt.isNeedEpk
      this.saveTypeId = evt.saveType?.id
      this.tempSavePeriod = evt.tempSavePeriod
    }
  }
}
</script>
<style scoped lang="scss">
.t-title {
  border: 1px solid #e0e0e0;
  background-color: #d7e3f1;
  margin-bottom: 0;
  padding: 1rem 14rem;
  font-weight: 600;
}
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid #dadada;
  padding: 8px;
  text-align: left;
}
th {
  text-align: center;
}
td {
  text-align: justify;
}
.checkbox-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
textarea {
  width: 100%;
  height: 8rem;
  padding: 5px;
  border: 1px solid #cbcbcd;
  outline-color: #cbcbcd;
  border-radius: 10px;
  text-align: justify;
  margin-top: 5px;
  min-height: 8rem;
}
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
  width: 100%;
}
.checkbox {
  width: 1.2rem;
  cursor: pointer;
}
</style>
