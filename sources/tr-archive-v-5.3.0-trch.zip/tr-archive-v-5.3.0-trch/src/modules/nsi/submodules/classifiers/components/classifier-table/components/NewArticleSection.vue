<template>
  <tr :id="group.code">
    <td style="width: 7% !important;"><textarea class="text-area" v-model="num"></textarea></td>
    <td style="width: 35% !important;"><textarea class="text-area" v-model="name"></textarea></td>
    <SaveType @saveTypeObj="setSaveInfo($event)"/>
    <td style="width: 30% !important;"><textarea class="text-area" v-model="description"></textarea></td>
    <td style="width: 15% !important;"><textarea class="text-area" v-model="code" disabled  style="background-color: #f0f0f0;"></textarea></td>
    <td style="width: 5% !important;">
      <div class="checkbox-container">
        <v-simple-checkbox
            v-ripple
            color="secondary"
            disabled
            :value="true"
        ></v-simple-checkbox>
      </div>
    </td>
    <td style="width: 3% !important;">
      <v-btn
          color="secondary"
          class="rounded-lg"
          icon
          @click="$emit('cancel-changes')"
      ><v-icon>mdi-close</v-icon>
      </v-btn>
    </td>
    <td style="width: 5% !important;">
      <v-btn
          color="secondary"
          class="rounded-lg"
          icon
          @click="submitHandler"
      ><v-icon>mdi-check</v-icon>
      </v-btn>
    </td>
  </tr>
</template>

<script>
import { mapState } from 'vuex'
import SaveType from '../components/SaveType.vue'
export default {
  name: 'NewArticleSection',
  components: { SaveType },
  props: ['group'],
  data: () => ({
    num: '',
    name: '',
    code: '',
    description: '',
    saveTypeObj: {}
    // payload: {}
  }),
  computed: {
    ...mapState({
      saveTypeList: state => state.nsi.classifierTable.saveTypeList,
      groupId: state => state.nsi.classifierTable.mainInfo.groupId
    })
  },
  mounted () {
    this.$nextTick(() => {
      const element = document.getElementById(this.group.code)
      if (!element) return
      element.scrollIntoView({ behavior: 'smooth', block: 'center' })
    })
  },
  methods: {
    setSaveInfo (evt) {
      Object.assign(this.saveTypeObj, evt)
    },
    submitHandler () {
      const { num, name, code, description, groupId, saveTypeObj } = this
      const payload = {
        num,
        name,
        code,
        description,
        group_id: groupId,
        save_type_id: saveTypeObj?.saveType?.id,
        is_need_ek: saveTypeObj?.isNeedEk,
        is_need_epk: saveTypeObj?.isNeedEpk,
        temp_save_period: +saveTypeObj.tempSavePeriod
      }
      this.$store.commit('nsi/classifierTable/setValue', { key: 'payload', value: payload })
      this.$emit('creating-article')
    }
  }
}
</script>
<style scoped>
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid #dadada;
  padding: 8px;
  text-align: left;
}
th {
  text-align: center;
}
td {
  text-align: justify;
}
.checkbox-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
.text-area {
  width: 100%;
  height: 8rem;
  padding: 5px;
  border: 1px solid #cbcbcd;
  outline-color: #cbcbcd;
  border-radius: 10px;
  text-align: justify;
  margin-top: 5px;
  min-height: 8rem;
}
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
}
.save-info-box-second {
  margin-top: 6px;
}
.input-term {
  width: 100%;
}
.check-box{
  margin-top: 6px;
  justify-content: space-around;
}

</style>
