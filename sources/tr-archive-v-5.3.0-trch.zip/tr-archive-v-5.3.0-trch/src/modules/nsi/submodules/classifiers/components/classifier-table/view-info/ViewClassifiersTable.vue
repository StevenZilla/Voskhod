<template>
  <div class="my-5">
    <table>
      <tbody>
          <tr>
            <th style="background: #e6e6e6">№ статьи</th>
            <th style="background: #e6e6e6">Вид документа</th>
            <th style="background: #e6e6e6">Срок хранения документа</th>
            <th style="background: #e6e6e6">Примечания</th>
            <th style="background: #e6e6e6">{{ isChed ? 'Код типового перечня' : 'Код' }}</th>
            <th style="width: 5% !important; background: #e6e6e6">Активно</th>
          </tr>
      </tbody>
      <tbody class='m-0' v-for="(group) in groups" :key="group.id">
          <tr>
            <th colspan="5">{{ group.name }}</th>
            <th style="">
              <div class="checkbox-container">
                <v-simple-checkbox
                    v-ripple
                    color="secondary"
                    :value="group.is_active"
                    disabled
                ></v-simple-checkbox>
              </div>
            </th>
          </tr>
          <tr v-for="article in group.di_kinds" :key="article.id">
            <td style="width: 5% !important;">{{ article.num}}</td>
            <td style="width: 35% !important;">{{ article.name}}</td>
            <td style="width: 10% !important;">{{ article.save_info}}</td>
            <td style="width: 30% !important;">{{ article.descr}}</td>
            <td style="width: 15% !important;">{{ article.code}}</td>
            <td style="width: 5% !important;">
              <div class="checkbox-container">
                <v-simple-checkbox
                  v-ripple
                  color="secondary"
                  :value="article.is_active"
                  disabled
                ></v-simple-checkbox>
              </div>
            </td>
          </tr>
      </tbody>
    </table>
  </div>
</template>
<script>

import { mapState } from 'vuex'

export default {
  name: 'ViewClassifiersTable',
  props: ['groups', 'loading', 'isChed'],
  computed: {
    ...mapState({
      allItems: state => state.nsi.classifierTable.allItems
    })
  }
}
</script>
<style scoped lang="scss">
  .t-title {
    border: 1px solid #e0e0e0;
    background-color: #d7e3f1;
    margin-bottom: 0;
    padding: 1rem 14rem;
    font-weight: 600;
  }
  table {
    border-collapse: collapse;
    width: 100%;
  }
  th, td {
    border: 1px solid #dadada;
    padding: 8px;
    text-align: left;
  }
  th {
    text-align: center;
  }
  td {
    text-align: justify;
  }
  .checkbox-container {
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
