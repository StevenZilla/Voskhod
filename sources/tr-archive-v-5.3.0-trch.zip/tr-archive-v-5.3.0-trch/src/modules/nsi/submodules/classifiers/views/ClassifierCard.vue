<template>
  <div>
    <ViewClassifierInfo v-if="modeClassifier === 'view'"/>

    <EditingClassifier @refresh-data="refreshData" v-else/>

    <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px"
    >
      <AppNotify
          :title="'Копирование реестра'"
          :text="notifyText"
          :type="type"
          :icon="icon"
          @close-popup="isNotify = false"
      />
    </v-dialog>
  </div>
</template>

<script>

import { GET_CLASSIFIER_CARD } from '../services/api'
import { mapState } from 'vuex'
import EditingClassifier from '@/modules/nsi/submodules/classifiers/components/editing-info/EditingClassifier.vue'

const ViewClassifierInfo = () => import(/* webpackChunkName: 'main-info-classifier' */ '../components/view-info/ViewClassifierInfo.vue')

export default {
  name: 'ClassifierCard',

  components: {
    EditingClassifier,
    ViewClassifierInfo
  },

  beforeRouteUpdate (to, from, next) {
    this.getData()
    next()
  },

  data: () => ({
    loading: true,
    isNotify: false
  }),

  watch: {
    cloneStatus (newV) {
      if (newV !== null) this.isNotify = true
    },
    selectedClassifierId (newV) {
      this.getData()
    }
  },

  computed: {
    ...mapState({
      error: state => state.error,
      modeClassifier: state => state.nsi.classifiers.modeClassifier,
      selectedClassifierId: state => state.nsi.classifiers.selectedClassifierId,
      cloneStatus: state => state.nsi.classifiers.cloneStatus
    }),

    type () {
      let _type = 'warning'
      if (this.cloneStatus === 'queued') _type = 'warning'
      if (this.cloneStatus === 'finished') _type = 'success'
      return _type
    },

    icon () {
      let _icon = 'mdi-alert'
      if (this.cloneStatus === 'queued') _icon = 'mdi-alert'
      if (this.cloneStatus === 'finished') _icon = 'mdi-check'
      return _icon
    },

    notifyText () {
      let text = 'Производится копирование типового реестра, ожидайте уведомления о завершении'
      if (this.cloneStatus === 'queued') text = 'Производится копирование типового реестра, ожидайте уведомления о завершении'
      if (this.cloneStatus === 'finished') text = 'Копирование типового реестра завершено'
      return text
    }
  },

  async mounted () {
    await this.getData()
  },

  methods: {
    refreshData () {
      this.getData()
    },

    async getData () {
      this.loading = true
      try {
        if (this.selectedClassifierId) await GET_CLASSIFIER_CARD(this.selectedClassifierId)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
