<template>
  <div>
    <template v-if="!item.is_edit">{{ item[fieldName] }}</template>
    <template v-else>
    <textarea
      class="text-area"
      v-model="value"
      @change="$emit('set-payload', { [fieldName === 'descr' ? 'description' : fieldName]: value })"
    ></textarea>
    </template>
  </div>
</template>

<script>
export default {
  name: 'TextAreaField',
  props: ['item', 'fieldName'],
  mounted () {
    this.value = this.item[this.fieldName]
  },
  data: () => ({
    value: ''
  })
}
</script>
<style>
.text-area {
  width: 100%;
  height: 8rem;
  padding: 5px;
  border: 1px solid #cbcbcd;
  outline-color: #cbcbcd;
  border-radius: 10px;
  text-align: justify;
  margin-top: 5px;
  min-height: 8rem;
}
</style>
