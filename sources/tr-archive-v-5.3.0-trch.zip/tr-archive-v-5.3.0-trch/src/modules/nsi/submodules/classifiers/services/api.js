import api from '@/services/api'
import store from '@/storages'
import { EventSourcePolyfill } from '@/plugins/EventSourcePolyfill'
// import store from '@/storages'

export async function GET_CLASSIFIERS_LIST (combined) {
  // store.dispatch('nsi/cla/SET_VALUE', { key: 'signersLoading', value: true }, { root: true })
  try {
    !combined ? new URLSearchParams() : combined.toString()
    const resp = await api.get('/v2/admin/nsi/di_classifier/', {
      params: combined
    })
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'classifierList', value: resp.data })
    return resp.data
  } catch (error) {
    console.log(error)
    // store.dispatch('nsi/signers/SET_VALUE', { key: 'signersList', value: { key: 'error', value: true } })
    throw error
  } finally {
    // store.dispatch('nsi/signers/SET_VALUE', { key: 'signersLoading', value: false }, { root: true })
  }
}

export async function GET_CLASSIFIER_ARTICLES (id, filter) {
  try {
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: true })
    const resp = await api.get(
      `/v2/admin/nsi/di_classifier/${id}/di_groups/aggregate`,
      { params: filter }
    )
    store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'articleList', value: resp.data.di_groups })
    return resp
  } catch (error) {
    return error.response
  } finally {
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: false })
  }
}

export async function GET_CLASSIFIER_ARTICLES_V2 (id, filter) {
  try {
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: true })
    const resp = await api.get(`/v2/admin/nsi/di_classifier/${id}/di_groups/aggregate`, { params: filter })
    store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'articleList', value: resp.data })
  } catch (error) {
    return error.response
  } finally {
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: false })
  }
}

export async function GET_CLASSIFIER_CARD (id) {
  try {
    const resp = await api.get(`/v2/admin/nsi/di_classifier/${id}`)
    store.dispatch('nsi/classifiers/SET_VALUE', {
      key: 'classifierCard',
      value: resp.data
    })
  } catch (error) {
    console.log(error)
    throw error
  }
}

export async function CREATE_CLASSIFIER (data) {
  try {
    return await api.post('/v2/admin/nsi/di_classifier', data)
  } catch (error) {
    console.log(error)
    throw error
  }
}

// export async function DELETE_CLASSIFIER (id) {
//   try {
//     return await api.delete(`/v2/admin/nsi/di_classifier/kind/${id}`)
//   } catch (error) {
//     return error.response
//   }
// }

export async function DELETE_GROUP (id) {
  try {
    return await api.delete(`v2/admin/nsi/di_classifier/group/${id}`)
  } catch (error) {
    return error.response
  }
}

export async function CLONE_CLASSIFIER (id) {
  try {
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'view' })
    return await api.get(`/v2/admin/nsi/di_classifier/clone/?to=${id}`)
  } catch (error) {
    console.log(error)
    throw error
  }
}

export async function GET_CLONE_STATUS (id) {
  try {
    return await api.get(`v2/admin/nsi/di_classifier/clone/${id}/status`)
  } catch (error) {
    console.log(error)
    throw error
  }
}

export async function SETUP_CLONE_STREAM (id) {
  const uid = localStorage.getItem('uid')
  const es = new EventSourcePolyfill(`${api.defaults.baseURL}/v2/admin/nsi/di_classifier/clone/${id}/status/stream`, {
    withCredentials: true,
    headers: { uid }
  })

  es.addEventListener('message', async event => {
    console.log('clone event.parsed', event.parsed)
    const status = event.parsed.messages[0].status
    store.dispatch('nsi/classifiers/SET_VALUE', { key: 'cloneStatus', value: status })
    if (status === 'finished') {
      // store.dispatch('nsi/classifiers/SET_VALUE', { key: 'cloneStatus', value: null })
      es.close()
    }
  })

  es.addEventListener('error', event => {
    console.log('Event clone was closed')
    if (event.readyState === EventSource.CLOSED) {
      console.log(EventSource)
    }
  })
  return status
}

// export async function GET_KINDS_SAVE_TYPE_LIST () {
//   const res = await api.get('/ead/nsi/save_types')
//   return res.data.save_types
//   // return res.data.save_types.map(item => ({ text: item.value, value: item.id }))
// }

export async function GET_KINDS_SAVE_TYPE_LIST_V2 () {
  try {
    const res = await api.get('/ead/nsi/save_types')
    return res.data
  } catch (error) {
    console.log(error)
    throw error
  }
}

export async function UPDATE_CLASSIFIER (id, payload) {
  try {
    return await api.put(`/v2/admin/nsi/di_classifier/${id}`, payload)
  } catch (error) {
    return error.response
  }
}

export async function UPDATE_CLASSIFIER_KINDS (kindObject) {
  try {
    return await api.put(`/v2/admin/nsi/di_classifier/kind/${kindObject.id}`, kindObject)
  } catch (error) {
    return error.response
  }
}

export async function CREATE_ARTICLE (articleParam) {
  try {
    return await api.post('/v2/admin/nsi/di_classifier/kind', articleParam)
  } catch (error) {
    return error.response
  }
}

export async function DELETE_ARTICLE (id) {
  try {
    return await api.delete(`/v2/admin/nsi/di_classifier/kind/${id}`)
  } catch (error) {
    return error.response
  }
}

// export async function CREATE_CLASSIFIER_GROUP (param) {
//   try {
//     const response = await api.post(
//       '/v2/admin/nsi/di_classifier/group',
//       param
//     )
//     return response
//   } catch (error) {
//     return error.response
//   }
// }
export async function CREATE_CLASSIFIER_GROUP_V2 (param) {
  try {
    return await api.post('/v2/admin/nsi/di_classifier/group', param)
  } catch (error) {
    return error.response
  }
}

export async function CHANGE_ACTIVE_STATUS (id, payload, isArticle) {
  try {
    let response
    if (isArticle) {
      response = await api.patch(`/v2/admin/nsi/di_classifier/kind/${id}`, payload)
    } else {
      response = await api.patch(`/v2/admin/nsi/di_classifier/group/${id}`, payload)
    }
    return response
  } catch (error) {
    return error.response
  }
}
export async function CHANGE_TITLE_NAME (id, payload) {
  try {
    return await api.put(`/v2/admin/nsi/di_classifier/group/${id}`, payload)
  } catch (error) {
    return error.response
  }
}
