<template>
  <div class="page">
    <div class="loading-container">
      <LoadingComponentVue class="loading" v-if="loading"/>
    </div>
    <div class="d-flex align-center">
      <span class="page-title">Реестр видов документов</span>
    </div>

    <template v-if="classifierObject.di_classifiers">
      <div class="classifier" v-if="!isEditTable">
        <div
            v-for="(classifier, index) in classifierObject.di_classifiers"
            class="classifier__item"
            :class="{ 'classifier__item-active': selectedClassifierId === classifier.id }"
            :key="index"
            @click="selectItem(classifier)"
        >
          <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
              <v-icon
                  class="mt-1 mr-2"
                  color="secondary"
                  v-bind="attrs"
                  v-on="on"
              >mdi-{{ classifier.is_main ? 'star' : 'chat-question-outline' }}
              </v-icon>
            </template>
            <span>{{ classifier.is_main ? 'Основной' : 'Дополнительный' }}</span>
          </v-tooltip>

          <div class="classifier__item-info">
            <p class="mb-0">{{ classifier.name }}</p>

            <span v-if="classifier.update_date">(последнее изменение {{
                $_formatDate(classifier.update_date, 'time')
              }})</span>

            <v-btn
                v-if="classifier.old_version.length"
                class="mt-2 mb-1"
                small
                outlined
                color="secondary"
                @click="toggleVersion(classifier)"
            >
              <v-icon>{{ classifier.view_old ? 'mdi-menu-up' : 'mdi-menu-down' }}</v-icon>
              {{ classifier.view_old ? 'Скрыть' : 'Показать' }} предыдущие версии
            </v-btn>

            <div class="old-list" :class="{ 'old-list--open': classifier.view_old }">
              <div
                  class="old-list__item"
                  v-for="(old, idx) in classifier.old_version"
                  :key="idx"
                  :class="{ 'classifier__item-active': selectedClassifierId === old.id }"
                  @click.stop="selectItem(classifier.old_version[idx])"
              >
                <p class="mb-1">{{ old.name }}</p>
                <span>(последнее изменение {{ $_formatDate(old.update_date, 'time') }})</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="d-flex justify-space-between">
        <div class="d-flex justify-start gap-1 mb-5 mt-5">
          <CreateClassifier
              v-if="$can('di_classifier_edit', 'nsi') && view_buttons.clone_button"
              :id="selectedClassifierId"
              :text="'Скопировать типовой реестр'"
              @refresh-data="refreshData"
          />

          <CreateClassifier
              v-if="$can('di_classifier_edit', 'nsi') && (!classifierObject.di_classifiers.length || view_buttons.create_button)"
              :text="'Создать реестр'"
              @refresh-data="refreshData"
          />
        </div>
      </div>
    </template>

    <div class="classifier-box">
      <div class="d-flex justify-space-between">
        <div class="d-flex wrapper-btn">
          <button
              class="button-tab"
              @click="tabItem=0"
              style="margin-right: 2px"
              :class="{ 'button-tab-active': tabItem === 0, 'disabled-button': isEditCard }"
              :disabled="isEditCard"
          >Таблица</button>
          <button
              class="button-tab"
              @click="tabItem=1"
              :class="{ 'button-tab-active': tabItem === 1, 'disabled-button': isEditTable }"
              :disabled="isEditTable"
          >Карточка</button>
        </div>
        <EditTableBtns :tabItem="tabItem" v-if="view_buttons.is_edit"/>
      </div>
      <v-tabs-items class="tabs-pills" right v-model="tabItem">
        <v-tab-item :eager="true">
          <ClassifiersTable
              v-if="selectedClassifierId"
              :isEdit="isEditTable"
          />
        </v-tab-item>

        <v-tab-item :eager="true">
          <ClassifierCard />
        </v-tab-item>
      </v-tabs-items>
    </div>
  </div>
</template>

<script>

import { mapState } from 'vuex'
import { GET_CLASSIFIERS_LIST } from '@/modules/nsi/submodules/classifiers/services/api'
import CreateClassifier from '@/modules/nsi/submodules/classifiers/components/create-info/CreateClassifier.vue'
import { classifierCard } from '@/permissions'
import EditTableBtns from '../components/classifier-table/components/EditTableBtns.vue'
const ClassifiersTable = () => import('../components/classifier-table/ClassifiersTable.vue')
const ClassifierCard = () => import('@/modules/nsi/submodules/classifiers/views/ClassifierCard.vue')

export default {
  name: 'ClassifiersPage',
  components: { ClassifierCard, ClassifiersTable, CreateClassifier, EditTableBtns },

  data: () => ({
    filterParams: new URLSearchParams('is_history=true&is_active=true'),
    classifierObject: {},
    isCard: false,
    tabItem: 0,
    activeIndex: 0,
    view_buttons: {}
  }),

  computed: {
    ...mapState({
      selectedClassifierId: state => state.nsi.classifiers.selectedClassifierId,
      loading: state => state.nsi.classifiers.loading,
      isEditCard: state => state.nsi.classifiers.modeClassifier === 'edit',
      isEditTable: state => state.nsi.classifiers.modeClassifierTable === 'edit'
    })
  },

  mounted () {
    this.getData()
  },

  beforeDestroy () {
    this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'selectedClassifierId', value: null })
    this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'view' })
    this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifierTable', value: 'view' })
  },

  methods: {
    async getData () {
      try {
        this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: true })
        this.classifierObject = await GET_CLASSIFIERS_LIST(this.filterParams)
        this.getSelectedItem()
      } catch (err) {
        console.log(err)
      } finally {
        this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'loading', value: false })
      }
    },

    refreshData (evt) {
      this.getData()
      if (evt) this.showDetail(evt)
    },

    toggleVersion (classifier) {
      this.$set(classifier, 'view_old', !classifier.view_old)
    },

    showDetail (evt) {
      const _id = evt || this.selectedClassifierId
      const path = `${classifierCard.path}/${_id}`
      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    },

    selectItem (item) {
      // this.activeIndex = item.id
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'selectedClassifierId', value: item.id })
      this.view_buttons = item.view_buttons || {}
    },

    getSelectedItem () {
      if (!this.classifierObject.di_classifiers) return
      const actualClassifier = this.classifierObject.di_classifiers.find(item => item.is_main)
      if (actualClassifier) {
        this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'selectedClassifierId', value: actualClassifier.id })
        this.view_buttons = actualClassifier.view_buttons
      }
    }
  }
}
</script>

<style lang="scss">

  .classifier {
    //width: 80%;

    &__item {
      display: flex;
      align-items: flex-start;
      margin-bottom: 30px;
      cursor: pointer;
      color: #9d9ea1;
      transition: .3s;

      &:hover {
        color: var(--v-secondary-base);
      }

      &-active {
        border-radius: 8px;
        background-color: rgba(0, 97, 217, .12);
        color: var(--v-secondary-base);
        padding: 5px 10px;
      }
    }
  }

  .old-list {
    max-height: 0;
    overflow: hidden;
    transition: .3s;
    margin-left: -2rem;
    padding: 0.4rem;
    border-radius: 10px;

    &--open {
      max-height: none;
      overflow: visible;
      background-color: #f5f5f5;
    }

    &__item {
      padding-top: 15px;
      border-bottom: 1px solid #9d9ea1;

      &:last-child {
        border-bottom: none;
      }

      border-radius: 0px !important;
      transition: .3s;
    }
  }

  tr {
    position: relative;
    border: 1px solid black;
  }

  .pencilArticle {
    position: absolute;
    top: 0.15rem;
    right: 2.7rem;
  }

  .v-input__slot {
    padding: 0;
  }

  .v-data-table > .v-data-table__wrapper > table > tbody > tr > td {
    padding: 8px;
    font-size: 15px;
  }
  .custom-group-title > div > .v-input__slot > .v-input__append-inner {
    margin-top: 9px !important;
  }
  .classifier-box div:nth-child(2) {
    background: transparent;
  }
  .classifier-box .v-tabs-slider-wrapper .v-tabs-slider{
    height: 0;
  }
  .loading {
    position: fixed;
    top: 50%;
    left: 50%;
  }
  .wrapper-btn {
    background-color: white;
    min-height: 50px;
    padding: 3px;
    align-items: center;
    border-radius: 5px;
  }
  .button-tab {
    background-color: white;
    padding: 0 15px;
    height: 100%;
    user-select: none;
  }
  .button-tab-active {
    background-color: #f5f5f5;
  }
  .disabled-button {
    opacity: 0.5;
    pointer-events: none;
  }
  .loading-container .loading {
    top: 30%;
  }
</style>
