export default {
  namespaced: true,
  state: {
    articleList: {},
    mainInfo: {},
    error: {},
    payload: null
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },
    getInitialState (state) {
      const newState = JSON.parse(JSON.stringify(state))
      newState.mainInfo = {}
      newState.error = {}
      newState.payload = {}
      newState.saveInfo = {}
      Object.assign(state, newState)
      this.commit('nsi/classifierTable/setAllProperty', { key: 'actionAttr', value: false })
    },
    setProperty (state, { code, key, value, copyObj }) {
      const newState = JSON.parse(JSON.stringify(state))
      newState.articleList.di_groups.forEach(diGroup => {
        if (diGroup.code === code) {
          diGroup[key] = value
          if (copyObj) newState.mainInfo = { ...diGroup, di_kinds: null }
          return
        }
        diGroup.di_kinds.forEach(article => {
          if (article.code === code) {
            article[key] = value
            if (copyObj) newState.mainInfo = article
          }
        })
      })
      Object.assign(state, newState)
    },
    setAllProperty (state, keyValue) {
      const newState = JSON.parse(JSON.stringify(state))
      newState.articleList.di_groups.forEach(diGroup => {
        diGroup[keyValue.key] = keyValue.value
        diGroup.di_kinds?.forEach(article => {
          article[keyValue.key] = keyValue.value
        })
      })
      Object.assign(state, newState)
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  }
}
