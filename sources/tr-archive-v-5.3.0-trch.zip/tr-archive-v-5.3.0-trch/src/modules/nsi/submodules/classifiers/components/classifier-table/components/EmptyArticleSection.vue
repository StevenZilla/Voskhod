<template>
  <tr>
    <td style="width: 7% !important;"></td>
    <td style="width: 35% !important;"></td>
    <td style="width: 10% !important;"></td>
    <td style="width: 30% !important;"></td>
    <td style="width: 15% !important;"></td>
    <td style="width: 5% !important;"></td>
    <td style="width: 3% !important;"></td>
    <td style="width: 5% !important;"></td>
  </tr>
</template>

<script>
export default {
  name: 'EmptyArticleSection'
}
</script>
<style scoped>
.t-title {
  border: 1px solid #e0e0e0;
  background-color: #d7e3f1;
  margin-bottom: 0;
  padding: 1rem 14rem;
  font-weight: 600;
}
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid #dadada;
  padding: 8px;
  text-align: left;
}
th {
  text-align: center;
}
td {
  text-align: justify;
}
.checkbox-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
.text-area {
  width: 100%;
  height: 8rem;
  padding: 5px;
  border: 1px solid #cbcbcd;
  outline-color: #cbcbcd;
  border-radius: 10px;
  text-align: justify;
  margin-top: 5px;
  min-height: 8rem;
}
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
}
.save-info-box-second {
  margin-top: 6px;
}
.input-term {
  width: 100%;
}
.check-box{
  margin-top: 6px;
  justify-content: space-around;
}

</style>
