<template>
  <div class="save-info">
    <div class="save-info-box-first">
      <v-autocomplete
          v-if="item.is_edit"
          class="rounded-lg save-info-box"
          outlined
          return-object
          item-value="id"
          item-text="value"
          hide-details
          placeholder="Выберите вид хранения"
          :items="saveTypeList"
          :no-data-text="'Нет результатов'"
          v-model="saveType"
          @change="setSaveType"
      >
      </v-autocomplete>
      <span v-else>{{ item.save_info}}</span>
    </div>
    <div v-if="temporarily && item.is_edit">
      <div class="save-info-box-second">
        <input
          class="input-term"
          type="number"
          maxlength="3"
          min="0"
          max="500"
          oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
          v-model="tempSavePeriod"
          @change="$emit('set-payload', { temp_save_period: +tempSavePeriod })"
        />
        <div class="d-flex check-box">
          <div class="d-flex">
            <v-simple-checkbox
                v-ripple
                color="secondary"
                v-model="isNeedEk"
                @click="$emit('set-payload', { is_need_ek: isNeedEk })"
            ></v-simple-checkbox>
            <span>ЭК</span>
          </div>
          <div class="d-flex">
            <v-simple-checkbox
                v-ripple
                color="secondary"
                v-model="isNeedEpk"
                @click="$emit('set-payload', { is_need_epk: isNeedEpk })"
            ></v-simple-checkbox>
            <span>ЭПК</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'SaveInfo',
  props: ['item'],
  data: () => ({
    saveType: '',
    temporarily: false,
    tempSavePeriod: 0,
    isNeedEk: null,
    isNeedEpk: null
  }),
  computed: {
    ...mapState({
      saveTypeList: state => state.nsi.classifierTable.saveTypeList
    })
  },
  mounted () {
    this.isNeedEk = this.item.is_need_ek
    this.isNeedEpk = this.item.is_need_epk
    this.tempSavePeriod = this.item.temp_save_period
    this.saveType = this.item.save_type
  },
  methods: {
    setSaveType () {
      this.$emit('set-payload', { save_type_id: this.saveType?.id })
      if (this.saveType.code === 'temporarily') {
        this.temporarily = true
      } else {
        this.temporarily = false
        this.tempSavePeriod = null
        this.$emit('set-payload', { temp_save_period: null })
      }
    }
  }
}
</script>

<style scoped>
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
}
.save-info {
  //border: 2px solid;
  position: relative;
}
.save-info-box-first {
  margin-top: 0;
}
.save-info-box-second {
  margin-top: 6px;
}
.input-term {
  width: 100%;
}
.check-box{
  margin-top: 6px;
}
</style>
