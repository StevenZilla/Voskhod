<template>
  <v-dialog
      v-model="isWarning"
      persistent
      max-width="500"
      content-class="dialog-auto-height"
      @click:outside="$emit('cancel-changes')"
  >
    <v-card>
      <v-card-title :style="{'text-align': 'center'}">{{ warningText }}</v-card-title>
      <v-card-actions class="justify-end">
        <v-btn
            class="rounded-lg"
            color="secondary"
            outlined
            @click="$emit('cancel-changes')"
        >Нет</v-btn>
        <v-btn
            data-qa="accept-save"
            class="rounded-lg"
            color="secondary"
            @click="$emit('submit')"
        >Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'SubmitModal',
  props: ['isWarning'],
  computed: {
    ...mapState({
      warningText: state => state.nsi.classifierTable.mainInfo.warningText || 'Сохранить изменения?'
    })
  }
}
</script>

<style scoped>
</style>
