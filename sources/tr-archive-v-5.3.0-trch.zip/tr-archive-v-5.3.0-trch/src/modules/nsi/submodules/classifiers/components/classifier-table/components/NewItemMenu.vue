<template>
  <div class="group-box">
    <div class="group-box__menu">
      <v-menu
          offset-y
          content-class="structure__tree-menu"
      >
        <template v-slot:activator="{ on, attrs }">
          <v-icon
            v-bind="attrs" v-on="on"
            color="secondary"
            class="add-title-icon"
          >
            mdi-plus
          </v-icon>
        </template>
        <v-list>
          <v-list-item class="list-item" @click="addGroup">
            <v-list-item-title>Добавить группу</v-list-item-title>
          </v-list-item>
          <v-list-item class="list-item" @click="addSubGroup">
            <v-list-item-title>Добавить подгруппу</v-list-item-title>
          </v-list-item>
          <v-list-item class="list-item" @click="addArticle">
            <v-list-item-title>Добавить статью</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </div>
  </div>
</template>
<script>
export default {
  name: 'AddTitleMenu',
  props: ['group'],
  methods: {
    addArticle () {
      this.$store.commit('nsi/classifierTable/setValue', { key: 'mainInfo', value: { groupId: this.group.id, code: this.group.code, actionAttr: 'create_article' } })
    },
    addSubGroup () {
      this.$store.commit('nsi/classifierTable/setValue', { key: 'mainInfo', value: { groupId: this.group.id, code: this.group.code, actionAttr: 'create_group' } })
    },
    addGroup () {
      this.$store.commit('nsi/classifierTable/setValue', { key: 'mainInfo', value: { groupId: null, code: this.group.code, actionAttr: 'create_group' } })
    }
  }
}
</script>
<style scoped>
.list-item:hover {
  background-color: #d7e3f1;
  cursor: pointer;
}
</style>
