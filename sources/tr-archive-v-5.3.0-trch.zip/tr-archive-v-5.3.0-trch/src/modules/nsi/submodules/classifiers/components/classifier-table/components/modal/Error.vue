<template>
  <v-dialog
      v-model="isError"
      persistent
      max-width="500"
      content-class="dialog-auto-height"
      @click:outside="$emit('close-error')"
  >
    <div class="card">
      <div class="card_title">Возникла непредвиденная ошибка</div>
      <div class="card_body">
        <ul v-for="(error, i) in errors" :key="i">
          <li>{{ error }}</li>
        </ul>
      </div>
      <div class="card_footer d-flex">
        <div>
          <button @click="$emit('close-error')">Закрыть</button>
        </div>
      </div>

    </div>
  </v-dialog>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'error-modal',
  props: ['isError'],
  data: () => ({
    isVisible: true
  }),
  computed: {
    ...mapState({
      error: state => state.nsi.classifierTable.error
    }),
    errors () {
      if (this.error.error) {
        let errors = Object.values(this.error.error)
        errors = errors.map(el => {
          console.log(el)
          return el[0].replace(/\[|\]|"/g, '')
        })
        return errors
      }
      return []
    }
  },
  watch: {
    'error.massage': {
      handler (newV) {
        console.log('error.massage:', newV)
        this.isVisible = true
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.card {
  display: flex;
  flex-direction: column;
  letter-spacing: 2px;
  font-size: 14pt;
  background: #fff;
  min-height: 300px;
  min-width: 700px;

  &_title {
    background: #e52e2e;
    padding: 1rem;
    font-weight: 600;
    color: #f7f6f7;
    flex: 0 0 20%;
  }

  &_body {
    flex: 1;
    padding: 1rem;
  }

  &_footer {
    background: #e6e6e6;
    padding: 1rem;
    flex: 0 0 20%;
    justify-content: end;
  }
}
</style>
