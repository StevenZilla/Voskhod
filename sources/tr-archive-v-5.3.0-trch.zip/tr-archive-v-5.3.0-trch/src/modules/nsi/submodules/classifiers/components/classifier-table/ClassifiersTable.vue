<template>
  <div class="my-5">
    <div class="panel-search">
      <v-text-field
          v-model="filterObj.search"
          data-qa=""
          class="main-field mb-2"
          placeholder="Введите номер статьи или вид документа"
          solo
          outlined
          rounded
          clearable
          hide-details
          flat
          @click:clear="(filterObj.search = null), acceptFilters()"
      >
        <template v-slot:prepend-inner>
          <v-btn plain icon color="secondary" @click="acceptFilters()"
          ><v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
              v-if="filterObj.search"
              class="find-link secondary--text"
              @click="acceptFilters()"
          >Найти</span
          >
        </template>
      </v-text-field>

      <div class="d-flex justify-end">
        <v-checkbox
            v-model="filterObj.inactive"
            color="secondary"
            hide-details
            label="Отображать неактивные записи"
        ></v-checkbox>
      </div>
    </div>
    <ViewClassifiersTable
      v-if="!isEdit"
      :groups="articleList.di_groups"
      :isChed="isChed"
      :loading="loading"
    />
    <EditingClassifiersTable
      v-else
      :groups="articleList.di_groups"
      :isChed="isChed"
      @refresh="getData(selectedClassifierId)"
    />
  </div>
</template>
<script>
import { GET_CLASSIFIER_ARTICLES_V2 } from '@/modules/nsi/submodules/classifiers/services/api'
import { mapState } from 'vuex'
import ViewClassifiersTable from '../classifier-table/view-info/ViewClassifiersTable.vue'
const EditingClassifiersTable = () => import('../classifier-table/editing-info/EditingClassifiersTable.vue')

export default {
  name: 'ClassifiersTable',
  props: ['isEdit'],
  components: { EditingClassifiersTable, ViewClassifiersTable },
  data: () => ({
    isChed: null,
    filterObj: {
      search: null,
      inactive: true
    }
  }),
  computed: {
    ...mapState({
      selectedClassifierId: state => state.nsi.classifiers.selectedClassifierId,
      articleList: state => state.nsi.classifierTable.articleList,
      loading: state => state.nsi.classifiers.loading,
      classifierList: state => state.nsi.classifiers.classifierList.di_classifiers
    }),
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.search) {
        paramsFilter.append('q', this.filterObj.search)
      }
      return paramsFilter
    }
  },
  watch: {
    async selectedClassifierId (newV) {
      this.disableScroll()
      await this.getData(newV)
      this.isChed = this.classifierList.some(el => el.id === newV)
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifierTable', value: 'view' })
      this.enableScroll()
    },
    'filterObj.inactive': {
      handler () {
        this.getData(this.selectedClassifierId)
      }
    }
  },
  async mounted () {
    this.disableScroll()
    if (this.selectedClassifierId) await this.getData(this.selectedClassifierId)
    this.isChed = this.classifierList.some(el => el.id === this.selectedClassifierId)
    this.enableScroll()
  },
  beforeDestroy () {
    this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'articleList', value: [] })
    this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'mainInfo', value: {} })
    this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'error', value: {} })
    this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'payload', value: null })
    this.$store.dispatch('nsi/classifierTable/SET_VALUE', { key: 'visibleRow', value: 0 })
  },
  methods: {
    async getData (id) {
      const filter = this.combineSearchParamsMix(
        this.filterParams,
        new URLSearchParams(`inactive_di_kind=${this.filterObj.inactive}`)
      )
      await GET_CLASSIFIER_ARTICLES_V2(id, filter)
    },

    acceptFilters () {
      this.getData(this.selectedClassifierId)
    },
    disableScroll () {
      document.body.style.position = 'fixed'
      document.body.style.width = '100%'
      document.body.style.pointerEvents = 'none'
      document.body.style.opacity = 0.9
    },
    enableScroll () {
      document.body.style.pointerEvents = 'auto'
      document.body.style.position = ''
      document.body.style.opacity = 1
    }
  }
}
</script>
<style scoped lang="scss">
  .loading-box {
    position: fixed;
    top: 50%;
    left: 50%;
  }
  .panel-search > div {
    margin-right: 0 !important;
  }

</style>
