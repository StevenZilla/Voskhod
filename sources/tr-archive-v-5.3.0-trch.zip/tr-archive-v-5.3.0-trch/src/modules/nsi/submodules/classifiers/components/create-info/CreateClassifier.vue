<template>
  <v-dialog
    v-model="isOpenDialog"
    hide-overlay
    transition="scroll-y-transition"
    content-class="app-modal"
    :attach="true"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        class="justify-content-end rounded-lg"
        color="secondary"
        outlined
        v-bind="attrs"
        v-on="on"
      >{{ text }}
      </v-btn>
    </template>

    <v-card>
      <v-toolbar
        flat
        dense
        class="app-toolbar d-flex justify-end"
      >
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <div class="detail">
        <div class="detail__content">
          <CreateMainInfo
            :trigger="trigger"
            @fill-data="fillData($event)"
          />
        </div>

        <div class="detail__buttons">
          <div class="detail__buttons-left">
            <BtnSaveSlot
              :loading="false"
              :disabled="false"
              @save="submitHandler"
            />
          </div>

          <div class="detail__buttons-right">
            <BtnCancelSlot
              @close="closeDialog()"
            />
          </div>
        </div>
      </div>
    </v-card>
  </v-dialog>
</template>

<script>

import CreateMainInfo from './CreateMainInfo.vue'
import {
  CLONE_CLASSIFIER,
  CREATE_CLASSIFIER,
  GET_CLASSIFIER_CARD,
  SETUP_CLONE_STREAM
} from '../../services/api'
import { mapState } from 'vuex'

export default {
  components: { CreateMainInfo },

  props: {
    id: {
      type: Number,
      required: false,
      validator: function (value) {
        return value === null || typeof value === 'number'
      }
    },

    text: {
      type: String,
      required: false,
      default: ''
    }
  },

  data: () => ({
    isOpenDialog: false,
    trigger: 0,
    createDetailInfo: {}
  }),

  watch: {
    async isOpenDialog (newV) {
      if (newV && this.id) await this.getData()
    }
  },

  computed: {
    ...mapState({
      modeClassifier: state => state.nsi.classifiers.modeClassifier
    })
  },

  methods: {
    async getData () {
      await GET_CLASSIFIER_CARD(this.id)
    },

    closeDialog () {
      this.isOpenDialog = false
      this.clearComponentVar++
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.createDetailInfo, evt)
        resolve()
      })
    },

    async submitHandler () {
      this.trigger++
      await this.fillData()
      try {
        const resp = await CREATE_CLASSIFIER(this.createDetailInfo)
        console.log('resp', resp)
        if (this.modeClassifier === 'clone') {
          const jobId = await CLONE_CLASSIFIER(resp.data.message)
          await SETUP_CLONE_STREAM(jobId.data.job_id)
          // await GET_CLONE_STATUS(jobId.data.job_id)
        }
        this.$store.commit('nsi/classifiers/setValue', { key: 'modeClassifier', value: 'view' })
        this.$emit('refresh-data', resp.data.message)
        this.isOpenDialog = false
      } catch (e) {
        console.log(e)
      }
    }
  }
}
</script>

<style lang="scss">
</style>
