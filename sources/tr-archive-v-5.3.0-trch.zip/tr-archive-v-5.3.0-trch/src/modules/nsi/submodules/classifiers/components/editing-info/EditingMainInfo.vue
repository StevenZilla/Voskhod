<template>
  <div class="wrapper">
    <h2>Общая информация</h2>

    <div class="form-group">
      <div class="d-flex" style="gap: 8px">
        <div class="form-group">
          <label for="inputField">Наименование <span class="required-label">*</span></label>
          <v-text-field
              v-model="editMainInfo.name"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Наименование"
              hide-details
              required
              :filled="classifierCard.is_ched"
              :disabled="classifierCard.is_ched"
          ></v-text-field>
        </div>
        <div class="form-group">
          <label for="inputField">Краткое наименование <span class="required-label">*</span></label>
          <v-text-field
              v-model="editMainInfo.short_name"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Краткое наименование"
              hide-details
              required
              :disabled="classifierCard.is_ched"
              :filled="classifierCard.is_ched"
          ></v-text-field>
        </div>
        <div class="form-group">
          <label for="inputField">Описание <span class="required-label">*</span></label>
          <v-text-field
              v-model="editMainInfo.description"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Краткое наименование"
              hide-details
              required
              :disabled="classifierCard.is_ched"
              :filled="classifierCard.is_ched"
          ></v-text-field>
        </div>
      </div>
      <div class="d-flex" style="gap: 8px">
        <div class="form-group">
          <label for="inputField">Организация владелец</label>
          <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="classifierCard.is_ched ? 'ЦХЭД' : 'ОИК'"
          ></v-text-field>
        </div>
        <div class="form-group">
          <label for="inputField">Версия</label>
          <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="classifierCard.version"
          ></v-text-field>
        </div>
        <div class="form-group">
          <label for="inputField" style="color: #76767a;">Дата последнего изменения</label>
          <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="classifierCard.update_date"
          ></v-text-field>
        </div>
      </div>
      <div class="form-group">
        <label for="inputField">Основной</label>
        <div>
          <v-checkbox
              v-model="editMainInfo.is_main"
              hide-details
              color="secondary"
              v-ripple
              :disabled="classifierCard.is_ched"
              :filled="classifierCard.is_ched"
          ></v-checkbox>
        </div>
      </div>
      <p class="mt-3" style="font-size:14px"><span class="required-label">*</span> Обязательные поля</p>
    </div>
  </div>
</template>

<script>

import { mapState } from 'vuex'
import { required } from 'vuelidate/lib/validators'

export default {
  name: 'EditingMainInfo',

  validations: {
    editMainInfo: {
      name: { required },
      short_name: { required },
      description: { required }
    }
  },

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    loadingSaveTypes: false,
    editMainInfo: {
      name: null,
      short_name: null,
      description: null,
      is_main: false
    }
  }),

  computed: {
    ...mapState({
      classifierCard: state => state.nsi.classifiers.classifierCard
    }),

    invalidData () {
      return this.$v.$invalid
    }
  },

  watch: {
    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editMainInfo)
    }
  },

  async created () {
    this.copyInfo()
  },

  methods: {
    copyInfo () {
      this.editMainInfo.name = this.classifierCard.name
      this.editMainInfo.short_name = this.classifierCard.short_name
      this.editMainInfo.description = this.classifierCard.description
      this.editMainInfo.is_main = this.classifierCard.is_main
    }
  }
}
</script>

<style lang="scss" scoped>
.wrapper {
  border: 1px solid #cbcbcd;
  padding: 40px;
  background: white;
  border-radius: 5px;
  margin-top: 30px;
}
.form-group {
  margin-bottom: 40px;
  flex: 1;
}

.form-group label {
  display: block;
  color: #76767A;
}

.form-group .divider {
  border-bottom: 3px solid #c9c9c9;
  margin: 5px 0;
}

.form-group input[type="text"],

.form-group input[type="text"]:focus {
  border-bottom: 1px solid #cbcbcd;
  outline: none; /* Убираем стандартное синее подчеркивание */
}
</style>
