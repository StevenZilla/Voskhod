export default {
  namespaced: true,
  state: {
    selectedNode: null,
    error: { isOpen: false, data: {} },
    cloneStatus: null,
    classifierCard: {},
    classifierList: {},
    loading: true,
    selectedClassifierId: null,
    modeClassifier: 'view',
    modeClassifierTable: 'view'
  },

  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },
    setLoading (state, value) {
      state.loading = value
    },
    setEditingStatus (state) {
      state.canUpdate = false
      // state.editing_id = value
    },
    setCustomProperty (state, item, prop) {
      const newState = JSON.parse(JSON.stringify(state))
      if (!item.title) {
        newState.articleList.forEach(array => {
          array.di_kinds.forEach(elem => {
            if (elem.id === item.id && elem.descr === item.descr) {
              elem[prop] = true
            }
          })
        })
      } else {
        newState.articleList.forEach(element => {
          if (element.id === item.id) {
            element.currentElement = true
          }
        })
      }
      state.articleList = newState.articleList
    }
  },

  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },
  getters: {
    GET_CLASSIFIER_ID: state => {
      if (!state.classifierCard.id) return

      return state.classifierCard.id
    }
  }
}
