<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mb-5 mt-5">Общая информация</h2>
    </v-card-title>

    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Наименование</p>
            <v-text-field
              v-model="createMainInfo.name"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Наименование"
              hide-details
              required
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Краткое наименование</p>
            <v-text-field
              v-model="createMainInfo.short_name"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Краткое наименование"
              hide-details
              required
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Описание</p>
            <v-text-field
              v-model="createMainInfo.description"
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Описание"
              hide-details
              required
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Организация-владелец</p>
            <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="'ОИК'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Версия</p>
            <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="'1'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Основной</p>
            <v-checkbox
              v-model="createMainInfo.is_main"
              hide-details
              color="secondary"
              v-ripple
            ></v-checkbox>
          </div>
        </v-col>

        <v-col cols="12" md="3">
          <div class="form-group">
            <p class="form-group__title">Дата последнего обновления</p>
            <v-text-field
              class="rounded-lg"
              rounded
              outlined
              filled
              disabled
              hide-details
              :value="'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>
      </v-row>
      <p class="mt-3"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'CreateMainInfo',

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    createMainInfo: {
      name: null,
      short_name: null,
      description: null,
      is_main: false
    }
  }),

  computed: {
    ...mapState({
      classifierCard: state => state.nsi.classifiers.classifierCard
    })
  },

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.createMainInfo)
    },

    classifierCard: {
      handler (newV) {
        if (newV) {
          this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'clone' })
          this.copyInfo()
        }
      },
      deep: true
    }
  },

  methods: {
    copyInfo () {
      this.createMainInfo = (
        // eslint-disable-next-line
        ({ name, short_name, description, is_main }) => ({ name, short_name, description, is_main })
      )(this.classifierCard) // КОПИРОВАНИЕ СВОЙСТВ
    }
  }
}
</script>

<style>

</style>
