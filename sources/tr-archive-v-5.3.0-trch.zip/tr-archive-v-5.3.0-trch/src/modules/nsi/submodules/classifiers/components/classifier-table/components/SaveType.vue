<template>
  <td style="width: 10% !important;">
    <v-autocomplete
        class="rounded-lg "
        outlined
        return-object
        item-value="id"
        item-text="value"
        hide-details
        placeholder="Выберите вид хранения"
        :items="saveTypeList"
        :no-data-text="'Нет результатов'"
        :style="{ cursor: 'pointer'}"
        v-model="saveTypeObj.saveType"
        @change="setSaveType"
    >
    </v-autocomplete>
    <div class="save-info-box-second" v-if="temporarily">
      <input
        class="input-term"
        type="number"
        maxlength="3"
        min="0"
        max="500"
        oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
        v-model="saveTypeObj.tempSavePeriod"
      />
      <div class="d-flex check-box">
        <div class="d-flex">
          <v-simple-checkbox
            v-ripple
            color="secondary"
            v-model="saveTypeObj.isNeedEk"
          ></v-simple-checkbox>
          <span>ЭК</span>
        </div>
        <div class="d-flex">
          <v-simple-checkbox
            v-ripple
            color="secondary"
            v-model="saveTypeObj.isNeedEpk"
          ></v-simple-checkbox>
          <span>ЭПК</span>
        </div>
      </div>
    </div>
  </td>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'SaveType',
  created () {
    // eslint-disable-next-line
    const { is_need_epk, is_need_ek, save_type, temp_save_period } = this.mainInfo
    this.saveTypeObj = { isNeedEpk: is_need_epk, isNeedEk: is_need_ek, saveType: save_type, tempSavePeriod: temp_save_period }
    this.setSaveType()
  },
  data: () => ({
    temporarily: true,
    saveTypeObj: {
      saveType: {},
      isNeedEk: null,
      isNeedEpk: null,
      tempSavePeriod: null
    }
  }),
  computed: {
    ...mapState({
      saveTypeList: state => state.nsi.classifierTable.saveTypeList,
      mainInfo: state => state.nsi.classifierTable.mainInfo
    })
  },
  watch: {
    saveTypeObj: {
      handler (newV, oldV) {
        this.$emit('saveTypeObj', newV)
        this.$store.commit('nsi/classifierTable/setValue', { key: 'saveInfo', value: newV })
      },
      deep: true
    }
  },
  methods: {
    setSaveType () {
      if (this.saveTypeObj.saveType?.code === 'temporarily') {
        this.temporarily = true
      } else {
        this.temporarily = false
        this.saveTypeObj.isNeedEpk = false
        this.saveTypeObj.isNeedEk = false
        this.saveTypeObj.tempSavePeriod = null
        this.$emit('set-payload')
      }
    }
  }
}
</script>
<style scoped>
th, td {
  border: 1px solid #dadada;
  padding: 8px;
  text-align: left;
}
th {
  text-align: center;
}
td {
  text-align: justify;
}
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
}
.save-info-box-second {
  margin-top: 6px;
}
.input-term {
  width: 100%;
}
.check-box{
  margin-top: 6px;
  justify-content: space-around;
}
</style>
