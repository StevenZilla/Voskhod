<template>
  <div class="">
    <v-alert v-if="isSame" icon="mdi-alert" type="error">
      {{ errorData }}
    </v-alert>

    <div data-qa="detail" class="">
      <div class="detail__content">
        <EditingMainInfo
          :trigger="trigger"
          @change-valid="invalidMainForm = $event"
          @fill-data="fillData($event)"
        />
      </div>

      <div class="detail__buttons">
        <div class="detail__buttons-left">
          <BtnSaveSlot
            :loading="loading"
            :disabled="invalidMainForm"
            @save="updateHandler()"
          />
        </div>
        <div class="detail__buttons-right">
          <BtnCancelSlot
            :text="'Отменить'"
            @close="cancelEdit"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { UPDATE_CLASSIFIER } from '../../services/api'
import EditingMainInfo from './EditingMainInfo.vue'

export default {
  name: 'EditingClassifier',
  components: {
    EditingMainInfo
  },

  data: () => ({
    loadingComponent: true,
    trigger: 0,
    invalidMainForm: false,
    loading: false,
    errorData: {},
    isSame: false,
    editingClassifierCard: {}
  }),

  computed: {
    id () {
      return this.$store.getters['nsi/classifiers/GET_CLASSIFIER_ID']
    },

    invalidEditingInfo () {
      return this.invalidMainForm
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.editingClassifierCard, evt)
        resolve()
      })
    },

    cancelEdit () {
      this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'view' })
    },

    async updateHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      const res = await UPDATE_CLASSIFIER(this.id, this.editingClassifierCard)
      if (res.status === 204) {
        this.$store.dispatch('nsi/classifiers/SET_VALUE', { key: 'modeClassifier', value: 'view' })
        this.$emit('refresh-data')
      } else {
        this.errorData = res.response?.data.message || 'Произошла непредвиденная ошибка'
        this.isSame = true
      }
      this.loading = false
    }
  }
}
</script>

<style lang="scss">
</style>
