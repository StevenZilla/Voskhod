import { classifiers } from '@/permissions'
const ClassifiersPage = () => import(/* webpackChunkName: 'classifier-page' */ '../views/ClassifiersPage.vue')

const classifiersRouter = [
  {
    name: 'ClassifiersPage',
    path: classifiers.path,
    component: ClassifiersPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Реестр видов документов' }
      ],
      tech_name: classifiers.code
    }
  }
]

export default classifiersRouter
