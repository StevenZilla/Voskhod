<template>
  <tr id="newGroupId">
    <th style="width: 5% !important;"></th>
    <th colspan="3">
      <div class="d-flex justify-end">
        <div style="padding-right: 10px;"><span style="color: indianred">*</span></div>
      </div>
      <input
        placeholder="Введите название группы/подгруппы"
        v-model="name"
      />
    </th>
    <th >
      <div class="d-flex justify-end">
        <div style="padding-right: 10px;"><span style="color: darkseagreen">**</span></div>
      </div>
      <input
          placeholder="Введите код"
          v-model="code"
      />
    </th>
    <th style="width: 5% !important;">
      <div class="checkbox-container">
        <v-simple-checkbox
            v-ripple
            color="secondary"
            :value="true"
        ></v-simple-checkbox>
      </div>
    </th>
    <th style="width: 5% !important;">
      <v-btn
          color="secondary"
          class="rounded-lg"
          icon
          @click="$emit('cancel-changes')"
      ><v-icon>mdi-close</v-icon>
      </v-btn>
    </th>
    <th style="width: 5% !important;">
      <v-btn
          color="secondary"
          class="rounded-lg"
          icon
          @click="submitHandler"
      ><v-icon>mdi-check</v-icon>
      </v-btn>
    </th>
  </tr>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'NewGroupSection',
  data: () => ({
    code: null,
    name: ''
  }),
  mounted () {
    this.$nextTick(() => {
      const element = document.getElementById('newGroupId')
      if (!element) return
      element.scrollIntoView({ behavior: 'smooth', block: 'center' })
    })
  },

  computed: {
    ...mapState({
      selectedClassifierId: state => state.nsi.classifiers.selectedClassifierId,
      groupId: state => state.nsi.classifierTable.mainInfo.groupId || null
    })
  },
  methods: {
    submitHandler () {
      const payload = {}
      payload.name = this.name
      payload.code = this.code
      payload.parent_id = this.groupId
      payload.di_classifier_id = this.selectedClassifierId
      this.$store.commit('nsi/classifierTable/setValue', { key: 'payload', value: payload })
      this.$emit('creating-group')
    }
  }
}
</script>

<style scoped lang="scss">
.t-title {
  border: 1px solid #e0e0e0;
  background-color: #d7e3f1;
  margin-bottom: 0;
  padding: 1rem 14rem;
  font-weight: 600;
}
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid #dadada;
  padding: 8px;
  text-align: left;
}
th {
  text-align: center;
}
td {
  text-align: justify;
}
.checkbox-container {
  display: flex;
  justify-content: center;
  align-items: center;
}
input {
  height: 2.6rem;
  border:1px solid #cbcbcd;
  outline: none;
  border-radius: 5px;
  padding-left: 10px;
  background-color: white;
  width: 100%;
}
</style>
