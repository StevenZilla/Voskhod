import api from '@/services/api'
import store from '@/storages'
import mixin from '@/utils/mixins'

export async function GET_SOURCES_RESPONSE (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('nsi/sources/SET_VALUE', { key: 'sourcesLoading', value: true }, { root: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/v2/admin/nsi/sources', { params: searchParams })
    store.dispatch('nsi/sources/SET_VALUE', { key: 'sourcesResponse', value: resp.data }, { root: true })
  } catch (error) {
    store.dispatch('nsi/sources/SET_VALUE', { key: 'sourcesError', value: true })
    throw (error)
  } finally {
    store.dispatch('nsi/sources/SET_VALUE', { key: 'sourcesLoading', value: false }, { root: true })
  }
}

export async function UPDATE_SOURCE (object, id) {
  try {
    await api.patch('/v2/admin/nsi/sources/' + id, object)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_SOURCE (sourcesArray) {
  try {
    await api.post('/v2/admin/nsi/sources/', sourcesArray)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
