<template>
  <div class="sources-page">
    <div class="d-flex align-center">
      <span class="page-title">Источники</span>
    </div>

    <div class="main-line">
      <SearchPanel
        @set-filters="acceptFilters($event)"
      />
    </div>

    <div class="mb-5 d-flex justify-space-between align-center">
      <h2 class="results-title">Результаты поиска</h2>
    </div>

    <v-data-table
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      item-key="id"
      class="main-table scroll-table sortable-table row-default-cursor"
      hide-default-footer
      disable-sort
      :headers="headers"
      :options.sync="options"
      :items="sourcesResponse.sources"
      :loading="sourcesLoading"
      :page.sync="page"
      :items-per-page="itemsPerPage"
      :server-items-length="sourcesResponse.count"
      :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
      @page-count="pageCount = $event"
    >
      <!-- eslint-disable-next-line -->
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>
      <template #item.actual_date="{ item }">
        <div>
          {{`${$_formatDate(item.actual_date, 'time') ||''}`}}
        </div>
      </template>
      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_actual="{ item }">
        <div class="d-flex justify-center checkbox-color">
          <v-simple-checkbox
            v-ripple
            :value="item.is_actual"
            disabled
          ></v-simple-checkbox>
        </div>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-icon
            color="secondary"
            @click="tableEditClick(item)"
        >
          mdi-pencil
        </v-icon>
      </template>

      <!-- eslint-disable-next-line -->
      <template #footer="{ props }">
        <PaginationTable
          :page.sync="page"
          :pagination="props.pagination"
        />
      </template>
    </v-data-table>

    <EditingSource
        @close="isEditing = false"
        @refresh="refresh"
        :mode="isEditing"
        :source="selectedSource"
    />

    <CreatingSource
        @refresh="refresh"
        @close="clearModalKey"
        :key="modalKey"
    />
  </div>
</template>

<script>

import { mapState } from 'vuex'
import SearchPanel from '../components/SearchPanel.vue'
import * as sources from '../services/api'
const EditingSource = () => import('../components/editing-info/EditingSource.vue')
const CreatingSource = () => import('../components/creating-info/CreatingSource.vue')
export default {
  name: 'SourcesPage',

  components: {
    CreatingSource,
    EditingSource,
    SearchPanel
  },

  data: () => ({
    filterParams: null,
    selectedSource: {},
    modalKey: 0,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    isEditing: false,
    headers: [
      {
        text: 'Наименование',
        value: 'value',
        width: '640px'
      },
      {
        text: 'Описание',
        value: 'descr',
        width: '640px'
      },
      {
        text: 'Последнее обновление данных ',
        value: 'actual_date',
        width: '290px'
      },
      {
        text: 'Актуальность',
        align: 'center',
        value: 'is_actual',
        width: '150px'
      },
      {
        text: 'Редактировать',
        align: 'center',
        sortable: false,
        class: 'cell-class',
        width: '165px',
        value: 'actions'
      }
    ]
  }),

  provide () {
    return {
      headers: this.headers
    }
  },

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          sources.GET_SOURCES_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      error: state => state.error,
      sourcesLoading: state => state.nsi.sources.sourcesLoading,
      sourcesResponse: state => state.nsi.sources.sourcesResponse
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.sourcesResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  methods: {
    tableEditClick (data) {
      this.isEditing = true
      this.selectedSource = data
    },
    clearModalKey () {
      this.isEditing = false
      this.modalKey++
    },
    async refresh () {
      await sources.GET_SOURCES_RESPONSE()
    },
    async acceptFilters (evt) {
      this.filterParams = evt
      await sources.GET_SOURCES_RESPONSE(this.filterParams, this.sortParams)
    }
  },
  async created () {
    await sources.GET_SOURCES_RESPONSE()
  }
}
</script>

<style lang="scss">
</style>
