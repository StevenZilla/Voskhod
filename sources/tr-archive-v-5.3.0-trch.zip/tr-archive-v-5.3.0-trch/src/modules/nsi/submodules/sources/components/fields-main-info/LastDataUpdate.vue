<template>
  <div class="form-group">
    <p class="form-group__title">Последнее обновление данных </p>
    <v-text-field
        v-model="value"
        hide-details
        readonly
        class="rounded-lg"
        outlined
        rounded
        disabled
        filled
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
