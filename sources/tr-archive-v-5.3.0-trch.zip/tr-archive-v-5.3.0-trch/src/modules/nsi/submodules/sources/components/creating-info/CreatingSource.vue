<template>
  <v-dialog
      v-model="isCreating"
      transition="scroll-y-transition"
      max-width="530px"
      content-class="dialog-auto-height"
      @click:outside="closeDialog"
  >
    <template
        v-slot:activator="{ on, attrs }"
    >
      <div class="detail__buttons detail__buttons-left">
        <v-btn
            v-if="$can('source_edit', 'nsi')"
            class="rounded-lg"
            outlined
            color="secondary"
            v-bind="attrs"
            v-on="on"
        >Добавить источник</v-btn>
      </div>
    </template>

    <v-card
        class="detail__main-info popup"
    >
      <v-toolbar
          flat
          dense
          class="popup-toolbar"
      >
        <v-toolbar-title>Добавление источника</v-toolbar-title>
        <BtnCancelSlot
            :icon="true"
            @close="closeDialog()"
        />
      </v-toolbar>

      <div
          class="popup__content"
      >
        <Name @set-property="editingObj.value = $event"/>

        <Description @set-property="editingObj.descr = $event"/>

        <Code @set-property="editingObj.code = $event"/>

        <LastDataUpdate @set-property="editingObj.actual_date = $event"/>

        <Actuality @set-property="editingObj.is_actual = $event"/>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
            :text="'Добавить'"
            :loading="loading"
            :disabled="invalidFunds"
            @save="createHandler()"
        />
        <BtnCancelSlot
            :text="'Отменить'"
            @close="closeDialog()"
        />
      </div>

      <v-dialog
          v-model="isNotify"
          content-class="dialog-auto-height"
          max-width="615px"
      >
        <AppNotify
            :title="'Редактирование'"
            :text="error"
            :type="'error'"
            :icon="'mdi-alert'"
            @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as source from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'
import Name from '@/modules/nsi/submodules/sources/components/fields-main-info/Name.vue'
import Description from '@/modules/nsi/submodules/sources/components/fields-main-info/Description.vue'
import Code from '@/modules/nsi/submodules/sources/components/fields-main-info/Code.vue'
import LastDataUpdate from '@/modules/nsi/submodules/sources/components/fields-main-info/LastDataUpdate.vue'
import Actuality from '@/modules/nsi/submodules/sources/components/fields-main-info/Actuality.vue'
export default {
  name: 'CreatingSource',
  components: { Actuality, LastDataUpdate, Code, Description, Name },

  validations: {
    editingObj: {
      value: { required },
      descr: { required }
    }
  },

  data: () => ({
    editingObj: {
      value: '',
      code: '',
      descr: '',
      actual_date: '',
      is_actual: false
    },
    error: '',
    loading: false,
    isNotify: false,
    isCreating: false,
    pk: 0
  }),

  computed: {
    ...mapState({
      sourcesList: state => state.nsi.sources.sourcesList,
      sourceLoading: state => state.nsi.sources.sourceLoading
    }),

    invalidFunds () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.isCreating = false
      this.$emit('close')
    },

    async createHandler () {
      this.loading = true
      this.error = ''
      try {
        await source.CREATE_SOURCE(this.editingObj)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
