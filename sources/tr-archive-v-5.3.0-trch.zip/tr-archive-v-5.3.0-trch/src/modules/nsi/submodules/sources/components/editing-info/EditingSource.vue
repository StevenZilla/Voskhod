<template>
  <v-dialog
      v-model="isEditing"
      transition="scroll-y-transition"
      max-width="530px"
      content-class="dialog-auto-height"
      @click:outside="closeDialog"
  >
    <v-card
        class="detail__main-info popup"
    >
      <v-toolbar
          flat
          dense
          class="popup-toolbar"
      >
        <v-toolbar-title>Редактирование источника</v-toolbar-title>
        <BtnCancelSlot
            :icon="true"
            @close="closeDialog()"
        />
      </v-toolbar>

      <div
          class="popup__content"
      >
        <div class="form-group">
          <p class="form-group__title">Наименование <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.value"
              class="rounded-lg"
              clearable
              required
              outlined
              placeholder="Введите наименование"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Описание <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.descr"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите описание"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Код <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.code"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите код"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Последнее обновление данных <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.actual_date"
              hide-details
              readonly
              class="rounded-lg"
              outlined
              rounded
              disabled
              filled
          ></v-text-field>
        </div>
        <div class="form-group d-flex justify-center">
          <p class="form-group__title">Актуальность <span class="required-label">*</span></p>
          <v-simple-checkbox
              color="secondary"
              v-ripple
              v-model="editingObj.is_actual"
          ></v-simple-checkbox>
        </div>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
            data-qa="save"
            :text="'Сохранить'"
            :loading="loading"
            :disabled="invalidSources"
            @save="updateHandler()"
        />
        <BtnCancelSlot
            :text="'Отменить'"
            @close="closeDialog()"
        />
      </div>

      <v-dialog
          v-model="isNotify"
          content-class="dialog-auto-height"
          max-width="615px"
      >
        <AppNotify
            :title="'Редактирование'"
            :text="error"
            :type="'error'"
            :icon="'mdi-alert'"
            @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as source from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'
export default {
  name: 'EditingSource',

  validations: {
    editingObj: {
      source: {
        $each: {
          value: { required },
          descr: { required }
        }
      }
    }
  },

  props: {
    source: {
      type: Object
    },
    mode: {
      type: Boolean,
      default: false
    }
  },

  data: () => ({
    editingObj: {
      id: '',
      value: '',
      descr: '',
      actual_date: '',
      is_actual: false
    },
    error: '',
    loading: false,
    isNotify: false,
    isEditing: false,
    pk: 0
  }),

  computed: {
    ...mapState({
      sourcesList: state => state.nsi.sources.sourcesList,
      sourceLoading: state => state.nsi.sources.sourceLoading
    }),

    invalidSources () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.$emit('close')
    },

    async updateHandler () {
      this.loading = true
      this.error = ''
      try {
        await source.UPDATE_SOURCE(this.editingObj, this.editingObj.id)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  },

  watch: {
    source: function () {
      this.editingObj = { ...this.source }
    },
    mode: function (val) {
      this.isEditing = val
    }
  }
}
</script>
<style lang="scss">
</style>
