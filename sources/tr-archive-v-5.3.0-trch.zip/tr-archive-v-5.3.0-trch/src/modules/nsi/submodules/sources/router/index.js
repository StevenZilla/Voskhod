import { sourceEvent } from '@/event-code'
import { sources } from '@/permissions'
const SourcesPage = () => import('../views/SourcesPage.vue')

const sourcesRouter = [
  {
    name: 'SourcesPage',
    path: sources.path,
    component: SourcesPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Источники' }
      ],
      tech_name: sources.code,
      code: sourceEvent.code
    }
  }
]

export default sourcesRouter
