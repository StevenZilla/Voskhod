export default {
  namespaced: true,
  state: {
    sourcesList: null,
    sourcesLoading: false,
    sourcesResponse: {}
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  }
}
