<template>
  <div class="form-group d-flex justify-center">
    <p class="form-group__title">
      Актуальность <span class="required-label">*</span>
    </p>
    <v-simple-checkbox
      color="secondary"
      v-ripple
      v-model="value"
    ></v-simple-checkbox>
  </div>
</template>

<script>
export default {
  props: {
    param: {
      type: Boolean,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">
</style>
