<template>
  <v-dialog
    v-model="isCreating"
    transition="scroll-y-transition"
    max-width="530px"
    content-class="dialog-max-height"
    @click:outside="closeDialog"
  >
    <template v-slot:activator="{ on, attrs }">
      <div class="detail__buttons detail__buttons-left">
        <v-btn
          v-if="$can('archive_edit', 'nsi')"
          class="rounded-lg"
          outlined
          color="secondary"
          v-bind="attrs"
          v-on="on"
        >Добавить архив
        </v-btn>
      </div>
    </template>

    <v-card
      class="detail__main-info popup"
    >
      <v-toolbar
        flat
        dense
        class="popup-toolbar"
      >
        <v-toolbar-title>Добавление архива</v-toolbar-title>
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <div
        class="popup__content"
      >
        <ShortNameArchive
          @set-property="editingObj.value = $event"/>
        <FullNameArchive
          @set-property="editingObj.full_name = $event"/>
        <DescrArchive
          @set-property="editingObj.descr = $event"/>
        <CodeArchive
          @set-property="editingObj.code = $event"/>
        <EmailArchive
          @set-property="editingObj.email = $event"/>
        <AddressArchive
          @set-property="editingObj.address = $event"/>
        <SupervisorArchive
          @set-property="editingObj.head = $event"/>
        <PhoneSupervisorArchive
          @set-property="editingObj.head_phone = $event"/>
        <ActualeArchive
          @set-property="editingObj.is_actual = $event"/>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
          :text="'Добавить'"
          :loading="loading"
          :disabled="invalidData"
          @save="createHandler()"
        />
        <BtnCancelSlot
          :text="'Отменить'"
          @close="closeDialog()"
        />
      </div>

      <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px"
      >
        <AppNotify
          :title="'Редактирование'"
          :text="error"
          :type="'error'"
          :icon="'mdi-alert'"
          @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as archives from '../../services/api'
import { required } from 'vuelidate/lib/validators'

import ShortNameArchive from '../fields-main-info/ShortNameArchive.vue'
import FullNameArchive from '../fields-main-info/FullNameArchive.vue'
import DescrArchive from '../fields-main-info/DescrArchive.vue'
import CodeArchive from '../fields-main-info/CodeArchive.vue'
import EmailArchive from '../fields-main-info/EmailArchive.vue'
import AddressArchive from '../fields-main-info/AddressArchive.vue'
import SupervisorArchive from '../fields-main-info/SupervisorArchive.vue'
import PhoneSupervisorArchive from '../fields-main-info/PhoneSupervisorArchive.vue'
import ActualeArchive from '../fields-main-info/ActualeArchive.vue'

export default {
  name: 'CreatingArchives',
  validations: {
    editingObj: {
      archives: {
        $each: {
          value: { required },
          full_name: { required },
          code: { required }
        }
      }
    }
  },
  components: {
    ShortNameArchive,
    FullNameArchive,
    DescrArchive,
    CodeArchive,
    EmailArchive,
    AddressArchive,
    SupervisorArchive,
    PhoneSupervisorArchive,
    ActualeArchive
  },

  data: () => ({
    loading: false,
    isNotify: false,
    isCreating: false,
    error: '',
    pk: 0,
    editingObj: {
      value: '',
      full_name: '',
      descr: '',
      code: '',
      is_actual: false,
      email: '',
      head: '',
      head_phone: ''
    }
  }),
  computed: {
    invalidData () {
      return this.$v.$invalid
    }
  },
  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editingObj)
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  methods: {
    closeDialog () {
      this.isCreating = false
      this.$emit('close')
    },
    async createHandler () {
      this.loading = true
      this.error = ''
      try {
        await archives.CREATE_ARCHIVE(this.editingObj)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
<style lang="scss">
.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
