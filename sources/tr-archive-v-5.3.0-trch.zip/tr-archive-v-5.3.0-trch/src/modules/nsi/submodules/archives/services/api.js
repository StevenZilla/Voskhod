import api from '@/services/api'
import store from '@/storages'
import mixin from '@/utils/mixins'

export async function GET_ARCHIVES_RESPONSE (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('nsi/archives/SET_VALUE', { key: 'archivesLoading', value: true }, { root: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/v2/admin/nsi/archives/', { params: searchParams })
    store.dispatch('nsi/archives/SET_VALUE', { key: 'archivesResponse', value: resp.data })
  } catch (error) {
    store.dispatch('nsi/archives/SET_VALUE', { key: 'archivesError', value: true })
    throw (error)
  } finally {
    store.dispatch('nsi/archives/SET_VALUE', { key: 'archivesLoading', value: false }, { root: true })
  }
}

export async function UPDATE_ARCHIVES (archivesArray, id) {
  try {
    await api.patch('/v2/admin/nsi/archives/' + id, archivesArray)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_ARCHIVE (fundObject) {
  try {
    await api.post('/v2/admin/nsi/archives/', fundObject)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
