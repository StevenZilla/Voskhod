import { archiveEvent } from '@/event-code'
import { archives } from '@/permissions'
const ArchivesPage = () => import('../views/ArchivesPage.vue')

const archivesRouter = [
  {
    name: 'ArchivesPage',
    path: archives.path,
    component: ArchivesPage,
    meta: {
      breadcrumb: [
        { text: 'НСИ' },
        { text: 'Архивы' }
      ],
      tech_name: archives.code,
      code: archiveEvent.code
    }
  }
]

export default archivesRouter
