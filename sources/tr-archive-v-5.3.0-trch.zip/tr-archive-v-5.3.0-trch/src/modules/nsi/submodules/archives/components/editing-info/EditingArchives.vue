<template>
  <v-dialog
      v-model="isEditing"
      transition="scroll-y-transition"
      max-width="530px"
      content-class="dialog-max-height"
      @click:outside="closeDialog"
  >
    <v-card
        class="detail__main-info popup"
    >
      <v-toolbar
          flat
          dense
          class="popup-toolbar"
      >
        <v-toolbar-title>Редактирование архива</v-toolbar-title>
        <BtnCancelSlot
            :icon="true"
            @close="closeDialog()"
        />
      </v-toolbar>

      <div
          class="popup__content"
      >
        <div class="form-group">
          <p class="form-group__title">Краткое наименование <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.value"
              class="rounded-lg"
              clearable
              required
              outlined
              placeholder="Введите наименование"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Полное наименование <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.full_name"
              class="rounded-lg"
              clearable
              required
              rounded
              outlined
              placeholder="Полное наименование"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Описание <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.descr"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите описание"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Код <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.code"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите код"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Email <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.email"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите email"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Адрес <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.address"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите адрес"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Руководитель <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.head"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Введите руководителя"
          ></v-text-field>
        </div>
        <div class="form-group">
          <p class="form-group__title">Телефон руководителя <span class="required-label">*</span></p>
          <v-text-field
              v-model="editingObj.head_phone"
              class="rounded-lg"
              rounded
              outlined
              placeholder="Телефон руководителя"
          ></v-text-field>
        </div>
        <div class="form-group d-flex justify-center">
          <p class="form-group__title">Актуальность <span class="required-label">*</span></p>
          <v-simple-checkbox
              color="secondary"
              v-ripple
              v-model="editingObj.is_actual"
          ></v-simple-checkbox>
        </div>
      </div>

      <div class="main-table-inner__buttons popup__actions d-flex justify-end">
        <BtnSaveSlot
            data-qa="save"
            :text="'Сохранить'"
            :loading="loading"
            :disabled="invalidArchives"
            @save="createHandler()"
        />
        <BtnCancelSlot
            :text="'Отменить'"
            @close="closeDialog()"
        />
      </div>

      <v-dialog
          v-model="isNotify"
          content-class="dialog-auto-height"
          max-width="615px"
      >
        <AppNotify
            :title="'Редактирование'"
            :text="error"
            :type="'error'"
            :icon="'mdi-alert'"
            @close-popup="isNotify = false"
        />
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import * as archives from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'

export default {
  name: 'EditingArchives',

  validations: {
    editingObj: {
      value: { required },
      full_name: { required },
      code: { required }
    }
  },

  props: {
    archive: {
      type: Object
    },
    mode: {
      type: Boolean,
      default: false
    }
  },

  data: () => ({
    editingObj: {
      value: '',
      full_name: '',
      descr: '',
      code: '',
      is_actual: false,
      email: '',
      head: '',
      head_phone: ''
    },
    loading: false,
    isNotify: false,
    isEditing: false,
    error: ''
  }),

  computed: {
    ...mapState({
      archivesList: state => state.nsi.archives.archivesList
    }),

    invalidArchives () {
      return this.$v.$invalid
    }
  },

  methods: {
    closeDialog () {
      this.$emit('close')
    },

    async createHandler () {
      this.loading = true
      this.error = ''
      try {
        await archives.UPDATE_ARCHIVES(this.editingObj, this.editingObj.id)
        this.$emit('refresh')
        this.closeDialog()
      } catch (error) {
        this.error = error.response?.data.message
        this.isNotify = true
      } finally {
        this.loading = false
      }
    }
  },

  watch: {
    archive: function () {
      this.editingObj = { ...this.archive }
    },
    mode: function (val) {
      this.isEditing = val
    }
  }
}
</script>

<style>
</style>
