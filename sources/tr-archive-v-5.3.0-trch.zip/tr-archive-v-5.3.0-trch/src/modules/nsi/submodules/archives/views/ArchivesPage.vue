<template>
  <div class="archive-page">
    <div class="d-flex align-center">
      <span class="page-title">Архивы</span>
    </div>

    <div class="main-line">
      <SearchPanel
        @set-filters="acceptFilters($event)"
      />
    </div>

    <div class="mb-5 d-flex justify-space-between align-center">
      <h2 class="results-title">Результаты поиска</h2>
    </div>

    <v-alert
      v-if="error"
      icon="mdi-alert"
      type="error"
    >Произошла ошибка при получении данных
    </v-alert>

    <v-progress-linear
      v-if="archivesResponse === null"
      indeterminate
      height="7"
      color="secondary"
    ></v-progress-linear>

    <v-data-table
      v-else
      no-data-text="Нет данных"
      loading-text="Загрузка данных"
      item-key="id"
      class="main-table scroll-table sortable-table row-default-cursor"
      hide-default-footer
      :headers="headers"
      :options.sync="options"
      :items="archivesResponse.archives"
      :loading="archivesLoading"
      :page.sync="page"
      :items-per-page="itemsPerPage"
      :server-items-length="archivesResponse.count"
      :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
      @page-count="pageCount = $event"
    >
      <!-- eslint-disable-next-line -->
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.head="{item}">
        <span :style="!item.head ? 'color:#CBCBCD' : ''">{{ item.head ? item.head : `Нет данных` }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.head_phone="{item}">
        <span :style="!item.head_phone ? 'color:#CBCBCD' : ''">{{ item.head_phone ? item.head_phone : `Нет данных`
          }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_actual="{ item }">
        <div class="d-flex justify-center">
          <v-simple-checkbox
            v-ripple
            color="secondary"
            :value="item.is_actual"
            disabled
          ></v-simple-checkbox>
        </div>
      </template>

      <template v-slot:item.actions="{ item }">
        <v-icon
          v-if="$can('archive_edit', 'nsi')"
          @click="tableEditClick(item)"
          color="secondary"
        >
          mdi-pencil
        </v-icon>
      </template>

      <!-- eslint-disable-next-line -->
      <template #footer="{props}">
        <PaginationTable
          :page.sync="page"
          :pagination="props.pagination"
        />
      </template>
    </v-data-table>

    <EditingArchives
      :mode="isEditing"
      :archive="selectedArchive"
      @close="isEditing = false"
      @refresh="refresh"
    />

    <CreatingArchives
      :key="modalKey"
      @close="clearModalKey"
      @refresh="refresh"
    />
  </div>
</template>

<script>

import * as archives from '../services/api'
import { mapState } from 'vuex'

import SearchPanel from '../components/SearchPanel.vue'
import EditingArchives from '@/modules/nsi/submodules/archives/components/editing-info/EditingArchives.vue'
import CreatingArchives from '@/modules/nsi/submodules/archives/components/creating-info/CreatingArchives.vue'

export default {
  name: 'ArchivesPage',

  components: {
    CreatingArchives,
    EditingArchives,
    SearchPanel
  },

  data: () => ({
    archivesList: {
      archives: []
    },
    modalKey: 0,
    filterParams: null,
    selectedArchive: {},
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    isEditing: false,
    headers: [
      {
        text: 'Полное наименование',
        value: 'full_name',
        width: '195px'
      },
      {
        text: 'Краткое наименование',
        value: 'value',
        sortable: false,
        width: '195px'
      },
      {
        text: 'Код',
        value: 'code',
        width: '195px'
      },
      {
        text: 'Описание',
        value: 'descr',
        sortable: false,
        width: '420px'
      },
      {
        text: 'E-mail',
        value: 'email',
        width: '195px'
      },
      {
        text: 'Адрес',
        value: 'address',
        sortable: false,
        width: '265px'
      },
      {
        text: 'Руководитель',
        value: 'head',
        width: '195px'
      },
      {
        text: 'Телефон руководителя',
        value: 'head_phone',
        sortable: false,
        width: '195px'
      },
      {
        text: 'Актуальность',
        align: 'center',
        value: 'is_actual',
        sortable: false,
        width: '150px'
      },
      {
        text: 'Редактировать',
        align: 'center',
        sortable: false,
        class: 'cell-class',
        width: '165px',
        value: 'actions'
      }
    ]
  }),

  provide () {
    return {
      headers: this.headers
    }
  },

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          archives.GET_ARCHIVES_RESPONSE(this.combineSearchParamsMix(this.filterParams, this.sortParams))
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      archivesResponse: state => state.nsi.archives.archivesResponse,
      archivesLoading: state => state.nsi.archives.archivesLoading,
      error: state => state.error
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.archivesList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    tableEditClick (data) {
      this.isEditing = true
      this.selectedArchive = data
    },
    clearModalKey () {
      this.modalKey++
    },
    async refresh () {
      await archives.GET_ARCHIVES_RESPONSE()
    },
    async acceptFilters (evt) {
      this.filterParams = evt
      await archives.GET_ARCHIVES_RESPONSE(this.filterParams, this.sortParams)
    }
  },
  async created () {
    await archives.GET_ARCHIVES_RESPONSE()
  }
}
</script>

<style lang="scss">
</style>
