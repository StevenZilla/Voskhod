import archivesRouter from '../submodules/archives/router'
import fundsRouter from '../submodules/funds/router'
import passwordsRouter from '../submodules/passwords/router'
import signersRouter from '../submodules/signers/router'
import subdivisionsRouter from '../submodules/subdivisions/router'
import sourcesRouter from '../submodules/sources/router'
import classifiersRouter from '../submodules/classifiers/router'
import { nsi } from '@/permissions'

const NsiPage = () => import('../views/NsiPage.vue')

const nsiRouter = [
  {
    name: 'NsiPage',
    path: nsi.path,
    component: NsiPage,
    meta: {
      breadcrumb: [
        {
          text: 'НСИ'
        }
      ]
    },
    children: [
      ...sourcesRouter,
      ...signersRouter,
      ...subdivisionsRouter,
      ...passwordsRouter,
      ...fundsRouter,
      ...archivesRouter,
      ...classifiersRouter
    ]
  }
]

export default router => {
  router.addRoutes(nsiRouter)
}
