export default {
  namespaced: true,
  state: {
    triggerUpdate: 0,
    modeAgreements: 'view',
    detailAgreements: {},
    agreementsLoading: true,
    registerProject: null,
    registerApproved: null
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },

  getters: {
    GET_ACTUAL_EK: state => {
      if (!state.detailAgreements.ek) return {}

      const obj = state.detailAgreements.ek.find(item => item.is_actual)
      if (obj) return obj
      else return null
    },

    GET_EK_LIST: state => {
      if (!state.detailAgreements.ek) return []

      return state.detailAgreements.ek
    },

    GET_ACTUAL_EPK: state => {
      if (!state.detailAgreements.epk) return {}

      const obj = state.detailAgreements.epk.find(item => item.is_actual)
      if (obj) return obj
      else return null
    },

    GET_CHIEF: state => {
      if (!state.detailAgreements.chief) return {}

      return state.detailAgreements.chief
    },

    GET_VIEW_BUTTONS: state => {
      if (!state.detailAgreements.view_buttons) return

      return state.detailAgreements.view_buttons
    },

    GET_TRIGGER_VALUE: state => state.triggerUpdate
  }
}
