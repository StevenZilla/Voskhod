import api from '@/services/api'
import store from '@/storages'

export async function CREATE_AGREEMENT (agreementObject) {
  await store.dispatch('agreements/SET_VALUE', { key: 'agreementsLoading', value: true })
  try {
    await api.post('/ead/agreements', agreementObject)
    await store.dispatch('agreements/SET_VALUE', { key: 'modeAgreements', value: 'view' }, { root: true })
  } catch (error) {
    console.log(error.response)
  } finally {
    await store.dispatch('agreements/SET_VALUE', { key: 'agreementsLoading', value: false })
  }
}

export async function EDITING_AGREEMENT (id, participantsObject) {
  try {
    await api.patch(`/v2/ead/registers/project_register/${id}/actual_agreement/participants`, participantsObject)
    store.dispatch('agreements/SET_VALUE', { key: 'modeAgreements', value: 'view' })
  } catch (error) {
    console.log(error.response)
  }
}

export async function GET_REGISTER_AGREEMENTS (id) {
  await store.dispatch('agreements/SET_VALUE', { key: 'agreementsLoading', value: true })
  try {
    const host = `/ead/agreements?is_group&register_id=${id}`

    const resp = await api.get(host)
    await store.dispatch('agreements/SET_VALUE', { key: 'detailAgreements', value: resp.data })
    // store.dispatch('agreements/SET_VALUE', { key: 'errorAgreements', value: null })
  } catch (error) {
    // store.dispatch('agreements/SET_VALUE', { key: 'errorAgreements', value: error })
  } finally {
    await store.dispatch('agreements/SET_VALUE', { key: 'agreementsLoading', value: false })
  }
}

export async function DOWNLOAD_TK (url) {
  try {
    const response = await api.get(url, { responseType: 'blob' })
    const blob = await response.data
    const downloadUrl = window.URL.createObjectURL(blob)
    const link = document.createElement('a')

    link.href = downloadUrl
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  } catch (err) {
    console.error(err)
  }
}
