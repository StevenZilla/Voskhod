<template>
  <v-expansion-panel ref="expansionPanelEpk">
    <v-expansion-panel-header>
      <div class="accordion__header">
        <span class="accordion__title">ЭПК</span>
        <v-chip data-qa="agreement-status" class="accordion__status" v-if="GET_ACTUAL_EPK" :color="getStatusColor(GET_ACTUAL_EPK)">{{ GET_ACTUAL_EPK.status.value }}</v-chip>
      </div>
    </v-expansion-panel-header>

    <v-expansion-panel-content>
      <div v-if="!detailAgreements.epk.length" class="tree-accordion-wrapper">
        <div class="tree-accordion">
          <div class="tree-accordion__left">
            <p>Согласование 1</p>
          </div>

          <div class="tree-accordion__right">
            <v-data-table
                hide-default-footer
                disable-sort
                no-data-text="Нет данных"
                item-key="id"
                class="mixin-table no-hover row-default-cursor"
                :headers="headersEpk"
                :items="[]"
            ></v-data-table>
          </div>
        </div>
      </div>

      <div class="tree-accordion-wrapper" v-for="(epkItem, index) in detailAgreements.epk" :key="index">
        <div class="tree-accordion">
          <div class="tree-accordion__left">
            <p>Согласование {{ epkItem.order }}</p>
          </div>

          <div class="tree-accordion__right">
            <v-data-table
                hide-default-footer
                disable-sort
                no-data-text="Нет данных"
                item-key="id"
                class="mixin-table no-hover row-default-cursor"
                :headers="headersEpk"
                :items="[epkItem]"
            >
              <!-- eslint-disable-next-line -->
              <template v-slot:item.epk_files_comments="{ item }">
                <v-btn
                    v-show="item.epk_files_comments.length !== 0"
                    color="secondary"
                    class="rounded-lg"
                    icon
                    :ripple="false"
                    @click="downloadZip(item.epk_files_comments)"
                ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
                </v-btn>
              </template>

              <!-- eslint-disable-next-line -->
              <template v-slot:item.epk_comment="{ item }">
                <div style="max-height: 150px; overflow-y: auto;">
                  {{ item.epk_comment }}
                </div>
              </template>

              <!-- eslint-disable-next-line -->
              <template v-slot:item.tks.tk_out="{ item }">
                <v-btn
                    color="secondary"
                    class="mr-1 rounded-lg"
                    icon
                    :ripple="false"
                    @click="downloadTk(item.tks.tk_out)"
                ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
                </v-btn>
                <span v-if="item.tks.tk_out" class="secondary--text">{{ item.tks.tk_out.status.value }}</span>
              </template>

              <!-- eslint-disable-next-line -->
              <template v-slot:item.tks.tk_in="{ item }">
                <v-btn
                    color="secondary"
                    class="mr-1 rounded-lg"
                    icon
                    :ripple="false"
                    @click="downloadTk(item.tks.tk_in)"
                ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
                </v-btn>
                <span v-if="item.tks.tk_in" class="secondary--text">{{ item.tks.tk_in.status.value }}</span>
              </template>
            </v-data-table>
          </div>
        </div>
      </div>
    </v-expansion-panel-content>
  </v-expansion-panel>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import * as agreements from '../services/api'
import store from '@/storages'
export default {
  data: () => ({
    headersEpk: [
      {
        text: 'Дата и время',
        value: 'create_date',
        width: '195px'
      },
      {
        text: 'Решение',
        value: 'status.value',
        width: '245px'
      },
      {
        text: 'Комментарий',
        value: 'epk_comment',
        width: '435px'
      },
      {
        text: 'Файлы',
        value: 'epk_files_comments',
        align: 'center',
        width: '130px'
      },
      {
        text: 'ТК ОИК',
        value: 'tks.tk_out',
        width: '200px'
      },
      {
        text: 'ТК ЦХЭД',
        value: 'tks.tk_in',
        width: '200px'
      }
    ]
  }),

  mounted () {
    this.$refs.expansionPanelEpk.toggle()
  },

  computed: {
    ...mapState({
      detailAgreements: state => state.agreements.detailAgreements
    }),

    ...mapGetters('agreements', ['GET_ACTUAL_EPK'])
  },

  methods: {
    async downloadTk (urlPart) {
      if (!urlPart.path) {
        await store.dispatch('SET_VALUE', { key: 'errorList', value: [{ name: 'Ссылка неверная или отсутствует', show: true }] }, { root: true })
      } else {
        const url = this.$config.VUE_APP_HOST.replace('/api', '/') + urlPart.path
        await agreements.DOWNLOAD_TK(url)
      }
    },

    downloadZip (files) {
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()
      let count = 0
      const errors = []

      files.forEach((item, index) => {
        JSZipUtils.getBinaryContent((`${this.$config.VUE_APP_HOST.replace('/api', '')}/${item.path}`), async (err, data) => {
          if (err) errors.push(err)
          zip.file(`file${index}`, data, { binary: true })
          count++
          if (count === files.length) { // если скачаны все файлы(или получили ошибку), то сохранить архив
            const content = await zip.generateAsync({ type: 'blob' })
            FileSaver.saveAs(content, 'epk_file_comment')
          }
        })
      })
      count = 0
    },

    getStatusColor (obj) {
      if (obj) {
        switch (obj.status.code) {
          case 'approved':
            return '#00A65A'

          case 'new':
            return '#A7A8AB '

          case 'pending_approval':
            return '#9DBDED'

          case 'rejected':
            return '#E52E2E'

          case 'approved_with_comments':
            return '#FE9F19'

          default:
            return ''
        }
      }
    }
  }
}
</script>

<style>

</style>
