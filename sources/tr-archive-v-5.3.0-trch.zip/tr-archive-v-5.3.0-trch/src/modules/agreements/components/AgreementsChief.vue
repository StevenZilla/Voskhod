<template>
  <v-expansion-panel ref="expansionPanelChief">
    <v-expansion-panel-header>
      <div class="accordion__header">
        <span class="accordion__title">Руководитель архива ОИК</span>
      </div>
    </v-expansion-panel-header>
    <v-expansion-panel-content>
      <div class="tree-accordion-wrapper">
        <div class="tree-accordion">
          <div class="tree-accordion__left">
            <p class="tree-accordion__title cursor-default">Согласование</p>
            <div class="tree-accordion__left-action" v-if="GET_ACTUAL_EK && GET_ACTUAL_EK.status.code === 'approved'">
              <v-btn
                v-if="GET_CHIEF.uri_path_ep || GET_CHIEF.uri_path_xml_act || GET_CHIEF.uri_path_mchd"
                color="secondary"
                class="mr-1 rounded-lg"
                icon
                :ripple="false"
                @click="downloadAgreementsZip([approvingFiles], 'Файлы утверждения Руководителя ОИК')"
              ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
              <span class="secondary--text">Файлы утв.</span>
            </div>
          </div>

          <div class="tree-accordion__right">
            <v-data-table
              hide-default-footer
              disable-sort
              no-data-text="Нет данных"
              item-key="id"
              class="mixin-table no-hover row-default-cursor"
              :headers="headersChief"
              :items="[GET_CHIEF]"
            >
              <template #item.sign_date="{ item }">
                <div>
                  {{`${$_formatDate(item.sign_date, 'time') ||''}`}}
                </div>
              </template>
            </v-data-table>
          </div>
        </div>
      </div>
    </v-expansion-panel-content>
  </v-expansion-panel>
</template>

<script>

import { mapGetters } from 'vuex'
import mixin from '../utils/mixins.js'

export default {
  mixins: [mixin],
  data: () => ({
    headersChief: [
      {
        text: 'Дата и время',
        value: 'sign_date',
        width: '195px'
      },
      {
        text: 'ФИО',
        value: 'fio',
        width: '100%'
      }
    ]
  }),

  mounted () {
    this.$refs.expansionPanelChief.toggle()
  },

  computed: {
    ...mapGetters('agreements', ['GET_CHIEF', 'GET_ACTUAL_EK']),

    approvingFiles () {
      const files = []
      if (!this.GET_CHIEF.uri_path_ep || !this.GET_CHIEF.path_xml_register) return []
      files.push(this.GET_CHIEF.uri_xml_register)
      files.push(this.GET_CHIEF.uri_path_ep)
      files.push(this.GET_CHIEF.uri_path_mchd)
      return files
    }
  },

  methods: {
    async downloadAgreementsZip (items, nameZip) {
      console.log('items', items)
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()

      const errors = []

      for (const item of items) {
        try {
          const data = await JSZipUtils.getBinaryContent((this.$config.VUE_APP_HOST.replace('api', '') + (item.href ? item.href : item)))
          zip.file(item.name, data, { binary: true })
        } catch (err) {
          errors.push(err)
        }
      }

      const content = await zip.generateAsync({ type: 'blob' })
      FileSaver.saveAs(content, nameZip)

      if (errors.length > 0) {
        console.error('Ошибка загрузки файла:', errors)
      }
    }
  }
}
</script>

<style>

</style>
