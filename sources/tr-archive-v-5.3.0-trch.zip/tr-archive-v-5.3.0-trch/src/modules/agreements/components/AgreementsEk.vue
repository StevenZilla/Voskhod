<template>
  <v-expansion-panel ref="expansionOik">
    <v-expansion-panel-header>
      <div class="accordion__header">
        <span class="accordion__title">Экспертная комиссия ОИК</span>
        <v-chip v-if="GET_ACTUAL_EK" data-qa="status-agreement-view" class="accordion__status" :color="getStatusColor(GET_ACTUAL_EK)">{{ GET_ACTUAL_EK.status.value }}</v-chip>
      </div>
    </v-expansion-panel-header>
    <v-expansion-panel-content>
      <ViewEk
        v-if="modeAgreements === 'view'"
        :headers="headers"
      />

      <EditingEk
        v-else
        :headers="headers"
        @change-valid="$emit('change-valid', $event)"
      />
    </v-expansion-panel-content>
  </v-expansion-panel>
</template>

<script>
import { mapGetters, mapState } from 'vuex'

import ViewEk from './view-info/ViewEk'

const EditingEk = () => import('./editing-info/EditingEk')

export default {
  components: {
    ViewEk,
    EditingEk
  },

  data: () => ({
    headers: [
      {
        text: 'ФИО',
        value: 'participant_fio',
        width: '440px'
      },
      {
        text: 'Решение',
        value: 'decision.value',
        width: '245px'
      },
      {
        text: 'Комментарий',
        value: 'comment',
        width: '440px'
      },
      {
        text: 'Файлы',
        value: 'files_comment',
        align: 'center',
        width: '130px'
      },
      {
        text: 'Дата и время',
        value: 'date',
        width: '200px'
      },
      {
        value: 'actions',
        width: '100px'
      }
    ]
  }),

  mounted () {
    if (this.detailAgreementsEkLen) this.$refs.expansionOik.toggle()
  },

  computed: {
    ...mapState({
      modeAgreements: state => state.agreements.modeAgreements,
      detailAgreementsEkLen: state => state.agreements.detailAgreements?.ek.length
    }),

    ...mapGetters('agreements', ['GET_ACTUAL_EK'])
  },

  methods: {
    getStatusColor (obj) {
      if (obj) {
        switch (obj.status.code) {
          case 'approved':
            return '#00A65A'

          case 'new':
            return '#A7A8AB '

          case 'pending_approval':
            return '#9DBDED'

          case 'rejected':
            return '#E52E2E'

          case 'approved_with_comments':
            return '#FE9F19'

          default:
            return ''
        }
      }
    }
  }
}
</script>

<style>

</style>
