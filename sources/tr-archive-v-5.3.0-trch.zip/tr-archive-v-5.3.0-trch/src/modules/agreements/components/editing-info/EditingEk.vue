<template>
  <div class="editing-accordion">
    <div class="tree-accordion-wrapper" v-for="(agr, idx) in agreements" :key="idx">
      <div class="tree-accordion">
        <div class="tree-accordion__left">
          <p>Согласование {{ idx + 1 }}</p>
        </div>

        <div class="tree-accordion__right">
          <v-data-table
            hide-default-footer
            disable-sort
            no-data-text="Нет данных"
            group-by="Согласующие"
            item-key="id"
            class="mixin-table no-hover"
            :headers="headers"
            :items="getAgreementsList(agr.participants)"
          ><!-- eslint-disable-next-line -->
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Согласующие</div>
              </td>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.participant_fio="{ item }">
              <v-autocomplete
                v-if="checkEditability(agr, item)"
                v-model="item.participant_id"
                data-qa="choose-coordinator"
                class="rounded-lg"
                outlined
                item-text="participant_fio"
                item-value="participant_id"
                hide-details
                clearable
                placeholder="Выбрать"
                color="secondary"
                @change="checkSelectSigner($event, agr, item)"
                :items="agr.availableParticipants ?
                  agr.availableParticipants.filter(el => !el.select || el.participant_id === item.participant_id)
                  : coordinatorList.filter(el => !el.select
                    || el.participant_id === item.participant_id
                    )"
                :loading="loadingCoordinator"
                :no-data-text="'Нет результатов'"
              ></v-autocomplete>
              <span v-else>{{ item.participant_fio }}</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.actions="{ item }">
              <v-btn
                v-if="checkEditability(agr)"
                color="secondary"
                class="rounded-lg"
                icon
                @click="removeCoordinator(agr, item)"
              >
                <v-icon color="secondary">mdi-trash-can-outline</v-icon>
              </v-btn>
            </template>

            <template #footer>
              <div v-if="checkEditability(agr)" class="detail__buttons detail__buttons-border">
                <v-btn
                  color="secondary"
                  outlined
                  class="rounded-lg ml-4 mb-0"
                  @click="addParticipant(agr)"
                >
                  <v-icon class="mr-2">mdi-plus</v-icon>
                  Добавить согласующего
                </v-btn>
              </div>
            </template>
          </v-data-table>

          <v-data-table
            hide-default-footer
            disable-sort
            no-data-text="Нет данных"
            group-by="Утверждающий"
            class="mixin-table hide-header-table no-hover"
            item-key="id"
            :headers="headers"
            :items="getApprovingList(agr.participants)"
          ><!-- eslint-disable-next-line -->
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Председатель комиссии</div>
              </td>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.participant_fio="{ item }">
              <v-autocomplete
                v-if="checkEditability(agr, item)"
                v-model="item.participant_id"
                class="rounded-lg"
                data-qa="choose-approver"
                outlined
                item-text="participant_fio"
                item-value="participant_id"
                hide-details
                clearable
                placeholder="Выбрать"
                color="secondary"
                :items="approvingList"
                :loader-height="5"
                :loading="loadingApproving"
                :no-data-text="'Нет результатов'"
              ></v-autocomplete>
              <span v-else>{{ item.participant_fio }}</span>
            </template>
          </v-data-table>
        </div>
      </div>

      <div class="tree-accordion-date">
        <div v-if="checkEditability(agr)" style="width: 380px">
          <date-range-picker
            v-model="dateRangeMix.start"
            style="width: 100%"
            opens="right"
            show-dropdowns
            single-date-picker
            auto-apply
            :ranges="false"
            :locale-data="localeSettings"
            @toggle="$_setBeginDate($event, [agr.approval_period_till], 'start')"
            @update="agr.approval_period_till = $_setDate($event, 'date')"
          >
            <template #input>
              <v-text-field
                class="rounded-lg"
                readonly
                outlined
                hide-details
                append-icon="mdi-calendar-blank"
                clearable
                placeholder="Срок согласования до"
                :value="$_formatDate(agr.approval_period_till)">
              </v-text-field>
            </template>
          </date-range-picker>
        </div>

        <span
          v-else
          class="tree-accordion-date-text"
        >Срок согласования до: <b>{{ $_formatDate(agr.approval_period_till, 'time') }}</b>
        </span>
      </div>
    </div>

    <v-btn
      v-if="modeAgreements === 'create' && !existCreate"
      color="secondary"
      class="my-2 rounded-lg"
      outlined
      @click="addAgreement()"
    >
      <v-icon data-qa="new-agreement" class="mr-2">mdi-plus</v-icon>
      Новое согласование
    </v-btn>
  </div>
</template>

<script>

import { GET_SUMMARY_DETAIL } from '../../../registers/submodules/summary/services/api'
import * as agreements from '../../services/api'
import { format } from 'date-fns'
// import { required } from 'vuelidate/lib/validators'
import { mapGetters, mapState } from 'vuex'
import { GET_SIGNERS_LIST } from '@/services/app'
import store from '@/storages'

export default {
  name: 'EditingEk',

  props: {
    headers: {
      type: Array,
      required: true
    }
  },

  validations: {
    /* editingAgreement: {
      participantsRaw: {
        $each: {
          participant_id: { required }
        }
      },
      approval_period_till: { required }
    } */
  },

  data: () => ({
    pk: -1,
    format,
    loadingApproving: true,
    loadingCoordinator: true,
    approvingList: [],
    coordinatorList: [],
    url: 'project_register',
    agreements: []
  }),

  computed: {
    ...mapState({
      modeAgreements: state => state.agreements.modeAgreements
    }),

    ...mapGetters('registers/summary', ['GET_REGISTER_KEY']),
    ...mapGetters('agreements', ['GET_EK_LIST', 'GET_TRIGGER_VALUE']),

    id () {
      return this.GET_REGISTER_KEY('id')
    },

    existCreate () {
      const existAgreements = this.agreements.find(item => item.id < 0)
      return !!existAgreements
    },

    actualEk () {
      const ek = this.agreements.find(item => item.is_actual)
      if (ek) return ek
      // при создании вернет undefined если не нажали "Новое согласование"
      return this.agreements[0]
    },

    isInvalidAgreement () {
      return this.$v.$invalid
    }
  },

  watch: {
    GET_TRIGGER_VALUE () {
      this.submitHandler()
    },

    isInvalidAgreement: {
      handler (newV) {
        this.$emit('change-valid', newV)
      },
      immediate: true
    },

    'actualEk.participants': {
      handler () {
        if (!this.actualEk) return

        this.coordinatorList.forEach(item => {
          const selectCoordinator = this.getAgreementsList(this.actualEk.participants).find(i => item.participant_id === i.participant_id)
          item.select = selectCoordinator !== undefined
        })
      },

      deep: true
    }
  },

  async mounted () {
    this.prepareDataEditing()

    this.coordinatorList = await this.getFilterSigners('coordinator')
    this.loadingCoordinator = false
    this.approvingList = await this.getFilterSigners('approver')
    this.loadingApproving = false
  },

  methods: {
    isDisabledEdited (agreement, participant = {}) {
      // нельзя если: согласование актуальное или есть решение
      return agreement.is_actual || participant.decision
    },

    checkEditability (agreement, participant = {}) {
      // можно вносить изменения если: редактирование и нет дизейбла на него, либо создание и у подписанта отрицательный id (означает созданное с фронта)
      return (this.modeAgreements === 'edit' && agreement.order && this.isDisabledEdited(agreement, participant)) ||
        (this.modeAgreements === 'create' && agreement.id < 0)
    },

    prepareDataEditing () {
      this.agreements = [...this.GET_EK_LIST]
    },

    removeCoordinator (agreement, item) {
      if (agreement.participants.length <= 2) {
        const obj = {
          name: 'Обязательно наличие хотя бы 1 согласующего',
          show: true
        }
        store.dispatch('SET_VALUE', { key: 'errorList', value: [obj] }, { root: true })
        return
      }
      const removeItemIdx = agreement.participants.findIndex(participants => {
        if (this.modeAgreements === 'create') return participants.id === item.id
        return participants.participant_in_agreement_id === item.participant_in_agreement_id
      })
      this.$delete(agreement.participants, removeItemIdx)
    },

    async getFilterSigners (code) {
      const params = new URLSearchParams(`role_code=${code}`)
      const list = await GET_SIGNERS_LIST(params)
      return list.map(item => {
        return { participant_fio: item.fio, participant_id: item.id }
      })
    },

    addAgreement () {
      const participant = {
        id: this.pk,
        participant_id: null,
        decision: null,
        comment: null,
        files_comment: null,
        date: null,
        is_approving: true
      }

      const agreement = {
        id: this.pk,
        type_id: 1,
        approval_period_till: format(new Date(), 'yyyy-MM-dd'),
        register_id: null,
        participants: [],
        availableParticipants: this.coordinatorList.map(el => ({ ...el, select: false }))
      }

      agreement.participants.push({ ...participant })
      participant.id = --this.pk
      participant.is_approving = false
      agreement.participants.push({ ...participant })

      this.$set(this.agreements, this.agreements.length, agreement)
      this.pk--
    },

    fillDataCreate () {
      const createAgreement = this.agreements.find(item => item.id < 0)
      createAgreement.register_id = this.id
      createAgreement.participants = createAgreement.participants.map(item => item.participant_id)
      return createAgreement
    },

    fillDataEditing () {
      const editableAgreements = this.agreements.find(item => item.is_actual)
      return editableAgreements.participants.map(item => item.participant_id)
    },

    checkSelectSigner (evt, agr, item) {
      const selectIds = agr.participants.map(el => el.participant_id).filter(item => item !== null)
      if (!evt) {
        if (agr.availableParticipants) {
          agr.availableParticipants = agr.availableParticipants.map(el => ({ ...el, select: selectIds.includes(el.participant_id) }))
        } else {
          this.coordinatorList = this.coordinatorList.map(el => ({ ...el, select: selectIds.includes(el.participant_id) }))
        }
      }

      const selectCoordinator = agr.availableParticipants?.find(i => item.participant_id === i.participant_id)

      if (selectCoordinator) {
        // console.log('selectCoordinator ', selectCoordinator)
        this.$set(selectCoordinator, 'select', true)
      }
    },

    addParticipant (agreement) {
      this.$set(agreement.participants, agreement.participants.length, {
        id: this.pk,
        participant_id: null,
        decision: null,
        comment: null,
        files_comment: null,
        date: null,
        is_approving: false
      })
      this.pk--
    },

    async changeParticipants () {
      await agreements.EDITING_AGREEMENT(this.id, { ids: this.fillDataEditing() })
    },

    async createAgreement () {
      await agreements.CREATE_AGREEMENT(this.fillDataCreate())
    },

    async submitHandler () {
      this.loading = true
      const url = `${this.url}/${this.id}`
      try {
        if (this.modeAgreements === 'create') await this.createAgreement()
        if (this.modeAgreements === 'edit') await this.changeParticipants()

        await GET_SUMMARY_DETAIL(url)
        await agreements.GET_REGISTER_AGREEMENTS(this.$route.params.id)
      } catch (error) {
        console.log(error)
      } finally {
        this.loading = false
      }
    },

    getAgreementsList (participants) {
      return participants.filter(item => item.is_approving === false)

      // НЕ ПОНЯТНО ДЛЯ ЧЕГО ЭТОТ ФИЛЬТР БЫЛ (НУЖЕН В ТАКОМ СЛУЧАЕ MAP)
      // return participants.filter(item => {
      //   if (item.is_approving === false) {
      //     item.id = this.pk
      //     this.pk--
      //   }
      //   return item.is_approving === false
      // })
    },

    getApprovingList (participants) {
      return participants.filter(item => item.is_approving === true)
    }
  }
}
</script>

<style lang="scss">

$padding-header: 16px;
$margin-span-accordion: 10px;
$width-icon: 24px;
$margin-accordion: $width-icon + 3px;

.accordion {
  &__header {
    display: flex;
    align-items: center;
    margin-left: $margin-span-accordion;
    height: 100%;
    border-bottom: 1px solid #D9D9DE;
  }

  &__status.v-chip.v-size--default {
    margin-left: 12px;
    font-size: 12px;
    height: 24px;
    color: #fff;

    &:hover {
      &:before {
        opacity: 0 !important;
      }
    }
  }

  .v-expansion-panel {
    &-header {
      padding: 0;
      padding-left: $padding-header;
      height: 56px;

      &__icon {
        // position: relative;
        width: $width-icon;
        height: $width-icon;
        order: -1;

        i {
          position: relative;
          width: 100%;
          transition: none;

          &:before {
            position: absolute;
            content: "";
            width: 100%;
            height: 100%;
            background: #F0F5FD;
            border-radius: 4px;
          }

          &:after {
            position: absolute;
            content: "";
            opacity: 1;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 6px;
            height: 6px;
            border-radius: 100%;
            background: #9DBDED;
          }
        }

        &:before {
          position: absolute;
          content: "";
          width: 2px;
          height: calc(50% - 5px);
          background: #F0F5FD;
          top: 0;
          left: 27px;
          z-index: 1
        }

        &:after {
          position: absolute;
          content: "";
          width: 2px;
          height: calc(50% - 5px);
          background: #F0F5FD;
          bottom: 0;
          left: 27px;
          z-index: 1
        }
      }
    }

    &--active {
      & > .v-expansion-panel-header {
        min-height: 56px;
      }
    }

    &-content {
      position: relative;
      border-left: 2px solid #F0F5FD;
      margin-left: $margin-accordion;
      padding-left: $width-icon - 2px;

      &__wrap {
        border-bottom: 1px solid #D9D9DE;
      }
    }

    &:after {
      display: none;
    }

    &:first-child {
      .v-expansion-panel-header__icon {
        &:before {
          display: none
        }
      }
    }

    &:last-child {
      .v-expansion-panel-content {
        border-left: none;

        &__wrap {
          border-bottom: none;
        }
      }
    }

    &:last-child:not(.v-expansion-panel.v-expansion-panel--active) {
      .accordion__header {
        border: none
      }

      .v-expansion-panel-header__icon {
        &:after {
          display: none
        }
      }
    }

    &:before {
      box-shadow: none;
    }
  }

  .v-expansion-panel-content__wrap {
    padding: 0;
  }
}

.tree-accordion {
  display: flex;
  align-items: center;

  &-date {
    display: flex;
    justify-content: center;
    padding: 10px 0;
    border-top: 1px solid #D9D9DE;

    & > span {
      display: inline-block;
      padding: 12px 14px;
      font-size: 16px;
      background: #F0F5FD;
      border-radius: 8px;
      color: var(--v-secondary-base)
    }
  }

  &__left {
    flex: none;
    text-align: center;
    width: 185px;
    height: 100%;
    font-size: 16px;

    &-action {
      display: flex;
      align-items: center;
      margin-top: 10px;

      span {
        font-size: 14px;
      }
    }

    p {
      margin-bottom: 0;
    }
  }

  &__right {
    width: 100%;
    border-left: 1px solid #D9D9DE;
  }
}

.mixin-table {
  width: 100%;

  .group-title {
    display: flex;
    align-items: center;
    padding-left: 20px;
    height: 100%;
    background: #F0F5FD;
    font-weight: bold;
  }
}
</style>
