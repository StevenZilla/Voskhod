<template>
  <div class="tree-accordion-wrapper">
    <div v-for="(ekItem, index) in ek" :key="index" :class="{'panel-hide': isHideAgreement(ekItem)}">
      <div class="tree-accordion">
        <div class="tree-accordion__left">
          <p class="tree-accordion__title"
             @click="!ekItem.is_actual ? toggleItem(ekItem) : () => {}"
             :class="{'cursor-default': ekItem.is_actual}">
            <!-- Актульное согласование нельзя свернуть поэтому прячем иконки и убираем хэндлер -->
            <v-icon v-if="!ekItem.is_actual" color="secondary mr-2">mdi-menu-down</v-icon>
            Согласование {{ ekItem.order }}
          </p>
          <div class="tree-accordion__left-action" v-if="GET_ACTUAL_EK && GET_ACTUAL_EK.status.code === 'approved' && ekItem.path_xml_register">
            <v-btn
              color="secondary"
              class="mr-1 rounded-lg"
              icon
              :ripple="false"
              @click="downloadZip(approvingFiles)"
            ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
            </v-btn>
            <span class="secondary--text">Файлы утв.</span>
          </div>
        </div>

        <div class="tree-accordion__right">
          <v-data-table
            hide-default-footer
            disable-sort
            no-data-text="Нет данных"
            group-by="Согласующие"
            item-key="id"
            class="mixin-table no-hover row-default-cursor"
            :headers="headers"
            :items="getAgreementsList(ekItem.participants)"
          ><!-- eslint-disable-next-line -->
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Согласующие</div>
              </td>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.comment="{ item }">
              <div style="max-height: 150px; overflow-y: auto;">
                {{ item.comment }}
              </div>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.date="{ item }">
              <span v-if="item.date">{{ $_formatDate(item.date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.files_comment="{ item }">
              <v-btn
                v-if="item.files_comment"
                color="secondary"
                class="mr-1 rounded-lg"
                icon
                :ripple="false"
                @click="$_downloadFile(item.files_comment.uri)"
              ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
            </template>

          </v-data-table>

          <v-data-table
            hide-default-footer
            disable-sort
            no-data-text="Нет данных"
            group-by="Председатель комиссии"
            class="mixin-table hide-header-table no-hover row-default-cursor"
            item-key="id"
            :headers="headers"
            :items="getApprovingList(ekItem.participants)"
          ><!-- eslint-disable-next-line -->
            <template v-slot:group.header>
              <td class="px-0 py-0" :colspan="headers.length">
                <div class="group-title">Председатель комиссии</div>
              </td>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.comment="{ item }">
              <div style="max-height: 150px; overflow-y: auto;">
                {{ item.comment }}
              </div>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.date="{ item }">
              <span v-if="item.date">{{ $_formatDate(item.date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.files_comment="{ item }">
              <v-btn
                v-if="item.files_comment"
                color="secondary"
                class="rounded-lg"
                icon
                :ripple="false"
                @click="$_downloadFile(item.files_comment.uri)"
              ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </div>
      </div>

      <div class="tree-accordion-date" v-if="GET_ACTUAL_EK && GET_ACTUAL_EK.status.code === 'pending_approval'">
        <span class="tree-accordion-date-text">Срок согласования до: <b>{{ $_formatDate(ekItem.approval_period_till, 'date') }}</b></span>
      </div>
    </div>
  </div>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import mixin from '../../utils/mixins.js'

export default {
  mixins: [mixin],
  props: {
    headers: {
      type: Array,
      required: true
    }
  },

  computed: {
    ...mapState({
      detailAgreements: state => state.agreements.detailAgreements
    }),

    ...mapGetters('agreements', ['GET_ACTUAL_EK']),

    approvingFiles () {
      if (!this.GET_ACTUAL_EK) return []
      const files = []
      files.push(this.GET_ACTUAL_EK.path_xml_register)
      const approving = this.GET_ACTUAL_EK.participants.find(item => item.is_approving)
      if (!approving || !approving.path_ep) return []
      files.push(approving.path_ep)
      return files
    },

    ek () {
      const ek = this.detailAgreements.ek
      if (ek.length) ek[ek.length - 1].lastItem = true
      return ek
    }
  },

  methods: {
    downloadZip (files) {
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()
      let count = 0
      const errors = []

      files.forEach((item, index) => {
        console.log('item', item)
        JSZipUtils.getBinaryContent((`${this.$config.VUE_APP_HOST.replace('/api', '')}/${item.path}`), async (err, data) => {
          if (err) errors.push(err)
          zip.file(`file${index}`, data, { binary: true })
          count++
          if (count === files.length) { // если скачаны все файлы(или получили ошибку), то сохранить архив
            const content = await zip.generateAsync({ type: 'blob' })
            FileSaver.saveAs(content, 'epk_file_comment')
          }
        })
      })
      count = 0
    },

    toggleItem (item) {
      if (item.hide) this.$set(item, 'hide', false)
      else this.$set(item, 'hide', true)
    },

    getAgreementsList (participants) {
      return participants.filter(item => item.is_approving === false)
    },

    getApprovingList (participants) {
      return participants.filter(item => item.is_approving === true)
    },

    isHideAgreement (item) {
      const needHide = item.hide || (item.hide === undefined && !item.is_actual && !item.lastItem)
      if (needHide) this.$set(item, 'hide', true)
      else this.$set(item, 'hide', false)
      return needHide
    }
  }
}
</script>

<style lang="scss">

.panel-hide {
  .tree-accordion__title {
    .v-icon {
      transform: rotate(-90deg);
    }
  }
  .tree-accordion__right {
    max-height: 1px!important;
    opacity: 0;
    overflow: hidden;
  }
  .tree-accordion-date {
    padding: 0;
    max-height: 0;
    opacity: 0;
    overflow: hidden;
  }
}
</style>
