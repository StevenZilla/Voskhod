import * as permissions from '@/permissions'

export function checkAvailablePage (pathObj) {
  const _permissions = JSON.parse(localStorage.getItem('_list'))
  console.log('_permissions', _permissions)

  if (!_permissions) return '/login'
  if (pathObj?.code) {
    const historyAvailable = _permissions.find(per => pathObj.code === per.tech_name) // при обновлении страницы ищется
    if (historyAvailable) return pathObj.path
  }

  for (const key in permissions) {
    const _per = _permissions.find(per => permissions[key].code === per.tech_name)
    console.log('permissions[key].path', permissions[key].path)
    if (_per) return permissions[key].path
  }
}
