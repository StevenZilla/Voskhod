import api from '@/services/api'
import store from '@/storages'
import {
  CHECK_AUTH,
  GET_PERMISSIONS
} from '@/services/app'
// import router from '@/router'

export async function LOGIN (loginData) {
  console.log('loginData', loginData)
  try {
    const resp = await api.post('/login', {
      login: loginData.login,
      password: loginData.password
    }, {
      headers: {
        uid: loginData.uid
      }
    })
    localStorage.setItem('uid', loginData.uid)
    await store.dispatch('SET_VALUE', { key: 'isAuthorized', value: true })

    if (resp.data.is_change_password) await store.dispatch('login/SET_VALUE', { key: 'isChangePassword', value: true })
    if (resp.data.is_trust) {
      await store.dispatch('login/SET_VALUE', { key: 'isTrust', value: true })
      return
    }

    // await app.CHECK_AUTH()
    console.log(resp)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function LOGOUT () {
  try {
    const resp = await api.post('/logout')
    store.dispatch('SET_VALUE', { key: 'isAuthorized', value: false })
    await store.dispatch('SET_VALUE', { key: 'isAuthenticated', value: false })
    await store.dispatch('login/SET_VALUE', { key: 'isTrust', value: false })
    localStorage.removeItem('_list')
    console.log(resp)
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function GET_ESIA_LOGIN () {
  try {
    const resp = await api.get('/esia/login')
    return resp.data.url
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function GET_SUCCESS_ESIA_USER (code, state, uid) {
  try {
    const resp = await api.get(`/esia/login/auth?code=${code}&state=${state}`, {
      headers: {
        uid: uid
      }
    })
    localStorage.setItem('uid', uid)
    await CHECK_AUTH()
    await GET_PERMISSIONS()

    return resp.data
  } catch (error) {
    const resp = await api.get('/esia/logout')

    const esiaUrl = resp.data.url
    if (window.location.pathname !== esiaUrl) {
      // window.open(esiaUrl, '_blank')
      window.location.href = esiaUrl
    }
    console.log(error)
    throw error
  }
}

export async function ESIA_LOGOUT () {
  const resp = await api.post('/logout')
  console.log('esia-logout', resp)

  store.dispatch('SET_VALUE', { key: 'isAuthorized', value: false })
  await store.dispatch('SET_VALUE', { key: 'isEsiaisAuthorized', value: false })
  await store.dispatch('SET_VALUE', { key: 'isAuthenticated', value: false })
  await store.dispatch('login/SET_VALUE', { key: 'isTrust', value: false })
  localStorage.removeItem('_list')
  localStorage.removeItem('uid')

  const esiaResp = await api.get('/esia/logout')
  const esiaUrl = esiaResp.data.url

  if (esiaUrl) {
    if (window.location.pathname !== esiaUrl) {
      window.location.href = esiaUrl
    }
  }
  return esiaUrl
}

export async function CHECK_CODE (code) {
  try {
    const host = await api.get(`/check_code?code=${code}`)
    console.log('host  ', host)
    await CHECK_AUTH()
    store.dispatch('SET_VALUE', { key: 'isAuthorized', value: true })
  } catch (error) {
    console.log(error)
  }
}

export async function REPEAT_CODE () {
  try {
    const resp = await api.get('/2fa_code')
    console.log(resp)
  } catch (error) {
    console.log(error)
  }
}

export async function RECOVERY_PASSWORD (contact) {
  try {
    await api.put('/ead/users/password/restore', { contact })
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_PASSWORD (newPassword) {
  try {
    await api.put('/ead/users/reset_password', { new_password: newPassword })
    await store.dispatch('login/SET_VALUE', { key: 'isChangePassword', value: false })
  } catch (error) {
    console.log(error)
    throw (error)
  }
}
