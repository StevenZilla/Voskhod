// import EsiaCallback from '../router/EsiaCallback.vue'\
import { esia } from '@/permissions'

const EsiaCallback = () => import(/* webpackChunkName: 'eds-page' */ '../components/EsiaCallback.vue')

const loginRouter = [
  // {
  //   name: 'LoginPage',
  //   path: '/login',
  //   component: LoginPage
  // }
]

const EsiaCallbackRouter = [
  {
    name: 'EsiaCallback',
    path: esia.path,
    component: EsiaCallback,
    meta: {
      breadcrumb: [
        {
          text: 'Авторизация ЕСИА'
        }
      ]
      // tech_name: esia.code
    }
  }
]

export default router => {
  router.addRoutes(EsiaCallbackRouter, loginRouter)
}
