<template>
  <v-dialog
    v-model="isRecovery"
    content-class="dialog-auto-height"
    max-width="520px"
  >
    <template v-slot:activator="{ on, attrs }">
      <span
        v-bind="attrs"
        v-on="on"
        class="login__left-link"
      >Забыли пароль?
      </span>
    </template>

    <v-card>
      <v-toolbar
        dense
        flat
        class="popup-toolbar"
      >
        <v-toolbar-title>Восстановление пароля</v-toolbar-title>
        <v-btn dark icon @click="isRecovery = false">
          <v-icon color="element">mdi-close</v-icon>
        </v-btn>
      </v-toolbar>

      <!-- <v-alert
      dense
      class="ml-5 mr-5"
      icon="mdi-check"
      type="info"
      color="success"
      >Обновленные учетные данные были отправлены на вашу почту</v-alert> -->

      <v-card-text
        class="pb-0">
        <p>Заполните поле</p>
        <div class="form-group mb-3" :class="{ 'form-group-error': error }">
          <!-- <p class="form-group__title" :class="{ 'error--text': error }">Логин</p> -->
          <v-text-field
            v-model="contact"
            data-qa="contact"
            class="rounded-lg"
            hide-details
            outlined
            rounded
            required
            placeholder="Введите логин или e-mail">
            <template slot="append">
              <v-icon
                v-if="error"
                class="error--text"
                >
                mdi-alert-circle
              </v-icon>
            </template>
          </v-text-field>
        </div>
      </v-card-text>

      <v-card-actions class="justify-end">
        <v-btn
          class="rounded-lg"
          color="secondary"
          outlined
          @click="isRecovery = false"
        >
          Отменить
        </v-btn>
        <v-btn
          class="rounded-lg"
          color="secondary"
          :disabled="!contact"
          :loading="loading"
          @click="submitHandler()"
        >Далее</v-btn>
      </v-card-actions>

      <v-dialog
        v-model="isNotify"
        content-class="dialog-auto-height"
        max-width="615px">
        <AppNotify
          :title="'Восстановление пароля'"
          :text="error ? errorMsg : 'Обновленные учетные данные были отправлены на вашу почту'"
          :type="error ? 'error' : 'info'" :icon="error ? 'mdi-alert' : 'mdi-check'"
          @close-popup="isNotify = false, isRecovery = false"/>
      </v-dialog>
    </v-card>
  </v-dialog>
</template>

<script>

import { RECOVERY_PASSWORD } from '../services/api'

export default {
  data: () => ({
    isRecovery: false,
    isNotify: false,
    contact: null,
    error: false,
    errorMsg: '',
    loading: false
  }),

  methods: {
    async submitHandler () {
      this.loading = true
      this.error = false
      try {
        await RECOVERY_PASSWORD(this.contact)
      } catch (error) {
        this.error = true
        this.errorMsg = error.response.data.error
          ? error.response.data.error.contact
          : error.response.data.message
        // console.log(error)
        throw (error)
      } finally {
        this.isNotify = true
        this.loading = false
      }
    }
  }
}
</script>
