<template>
  <div class="login primary">
    <div class="login__left">
      <h1 class="login__left-title">АРХИВ</h1>

      <div class="login__form">
        <span class="login__form-title">Войти</span>
        <LoginForm v-if="!isTrust"/>
        <TwoFactor v-else/>
      </div>
      <div class="login__left-footer">
        <span class="mr-16">АРХИВ, {{ date }}</span>
        <a href="#">Соглашение об использовании</a>
      </div>
    </div>
    <div class="login__right">
<!--      <Snowf-->
<!--        v-if="isOurStand"-->
<!--        :amount="50"-->
<!--        :size="13"-->
<!--        :speed="1"-->
<!--        :wind="0"-->
<!--        :opacity="0.8"-->
<!--        :swing="1"-->
<!--        :image="showPath"-->
<!--        :zIndex="null"-->
<!--        :resize="true"-->
<!--        color="#fff"-->
<!--      />-->
      <div class="login__right-content">
        <div class="login__right-title mb-8">Государственный архив</div>
        <p>Подсистема "Архив" государственной информационной системы "Платформа "Центр хранения электронных документов" решает вопросы обеспечения сохранности электронных документов федеральных органов исполнительной власти (ФОИВ) и подведомственных им организаций на протяжении установленных сроков хранения.</p>

        <p>Обеспечивает юридическую значимость электронных документов на протяжении всего срока хранения, обеспечивает удаленный доступ к электронным архивным документам в любой точке мира и сокращает затраты на долгосрочное хранение документов.</p>
      </div>
      <div class="d-flex justify-space-between">
        <div>{{ support.email }}</div>
        <div>Версия системы: {{ version }}</div>
      </div>
    </div>
  </div>
</template>

<script>

import version from '../../../../VERSION.txt'
import { support } from '@/appVariables'
import { mapState } from 'vuex'
import LoginForm from '../components/LoginForm.vue'
import { format } from 'date-fns'
// import Snowf from 'vue-snowf'
const showPath = require('@/assets/icons/snow.svg')

const TwoFactor = () => import('../components/TwoFactor.vue')

export default {
  name: 'LoginPage',

  components: {
    // Snowf,
    LoginForm,
    TwoFactor
  },
  data: () => ({
    showPath,
    isResetPassword: false,
    version,
    support
  }),

  computed: {
    ...mapState({
      isTrust: state => state.login.isTrust
    }),

    date () {
      return format(new Date(), 'yyyy')
    },

    isOurStand () {
      const route = this.$config.VUE_APP_HOST.replace('/api', '')
      return route === 'https://dev.archive.eadsc.ru'
    }
  }
}
</script>

<style lang="scss">
.login {
  //height: 100vh;
  display: flex;
  position: absolute;
  height: 100%;
  width: 100%;
  &__form {
    width: 400px;
    margin: 0 auto;
    &-title {
      display: inline-block;
      font-size: 30px;
      margin-bottom: 35px;
    }
  }
  &__panel {
    display: flex;
    flex-direction: column;
    align-self: center;
    width: 100%;
    &-label {
      margin-bottom: 8px;
      font-weight: 300;
      font-size: 14px;
      line-height: 22px;
      color: #999999;
    }
    &-title {
      font-weight: 400;
      margin-bottom: 36px;
      font-size: 30px;
      line-height: 36px;
    }
  }
  &__left {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    width: 50%;
    padding: 60px;
    background: #f5f5f7;
    border-radius: 0 0 128px 0;
    .link-wrapper {
      display: flex;
      justify-content: center;
      padding-top: 36px;
    }
    &-link {
      line-height: 20px;
      text-decoration: underline;
      color: #0061d9 !important;
    }
    &-title {
      font-family: "Golos Text Medium";
      font-weight: 900;
      font-size: 70px;
    }
    &-footer {
      font-size: 18px;
      line-height: 22px;
    }
    .login-main {
      margin: auto;
    }
    .login-main_wrap {
      left: 14%;
      position: absolute;
      top: 32%;
    }
  }
  &__right {
    position: relative;
    color: #fff;
    height: 100%;
    width: 50%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 60px 120px;
    p {
      font-style: normal;
      font-weight: 400;
      font-size: 18px;
      line-height: 22px;
      font-feature-settings: "pnum" on, "lnum" on;
      color: #d9d9de;
    }
    &-content {
      margin: auto;
      padding-bottom: 75px;
    }
    &-title {
      font-weight: 700;
      font-size: 58px;
      line-height: 88px;
    }
    &-link {
      text-decoration: underline;
      color: #0061d9 !important;
      font-size: 18px;
      line-height: 22px;
    }
  }
  .v-text-field__details {
    padding-left: 0 !important;
    padding-top: 2px !important;
  }
}

</style>
