<template>
  <v-form class="login__panel">
    <div class="form-group mb-3" :class="{ 'form-group-error': errorAuth }">
      <p class="form-group__title" :class="{ 'error--text': errorAuth }">Код проверки</p>
      <v-text-field
        v-model="code"
        data-qa="code"
        class="rounded-lg"
        hide-details
        outlined
        rounded
        required
        :type="show ? 'text' : 'password'"
        @click:append="show = !show"
        :append-icon="show ? 'mdi-eye' : 'mdi-eye-off'"
        placeholder="Введите код"
      >
        <template slot="append">
          <v-icon class="error--text" v-if="errorAuth">mdi-alert-circle</v-icon>
        </template>
      </v-text-field>
    </div>
    <span v-if="errorAuth" class="error--text">{{ errorMsg }}</span>

    <v-btn
      class="rounded-lg mt-3"
      color="secondary"
      :disabled="!code"
      :loading="loginLoading"
      @click="submitHandler()"
    ><v-icon class="mr-2">mdi-login</v-icon>
      Войти
    </v-btn>

    <div class="login__left-link_wrap">
      <a href="#" class="login__left-link" @click="getRepeatCode()">Код не получен, отправить повторно.</a>
    </div>
  </v-form>
</template>

<script>
import {
  CHECK_AUTH,
  GET_PERMISSIONS
} from '@/services/app'

import {
  REPEAT_CODE,
  CHECK_CODE
} from '../services/api'

import { mapState } from 'vuex'
import { checkAvailablePage } from '@/modules/login/utils/helperLogin'

export default {
  data: () => ({
    code: null,
    errorAuth: false,
    errorMsg: '',
    show: false,
    loading: false
  }),

  computed: {
    ...mapState({
      loginLoading: state => state.login.loginLoading,
      isTrust: state => state.login.isTrust
      // permissions: state => state.appStore.permissions
    })
  },

  methods: {
    async submitHandler () {
      this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: false })
      this.errorAuth = false
      try {
        await CHECK_CODE(this.code)
        await CHECK_AUTH()
        await GET_PERMISSIONS()

        const availableUrl = checkAvailablePage()
        if (availableUrl && availableUrl !== this.$route.path) {
          this.$router.push(availableUrl)
        }
        // this.$router.push('/eds')
        // this.$router.push(this.checkAvailablePageMix(this.permissions))
      } catch (error) {
        console.log(error)
        this.errorAuth = true
        this.errorMsg = error.response.data.message
        throw (error)
      } finally {
        this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: false })
      }
    },
    async getRepeatCode () {
      await REPEAT_CODE()
    }
  }
}
</script>
