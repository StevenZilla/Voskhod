<template>
  <div class="info-page">
    <v-alert
      v-if="errorMsg"
      icon="mdi-alert"
      type="error"
    >{{ errorMsg }}</v-alert>

    <LoadingComponentVue v-if="loading"/>

    <div v-else class="info-page__block">
      <h2>Создание пароля</h2>
      <v-card>
        <v-card-text>
          <p class="info-page__block-title">Придумайте новый пароль</p>
          <div class="form-group mb-3" :class="{'error-field': isInvalidNew}">
            <p class="form-group__title">Новый пароль</p>
            <v-text-field
              class="rounded-lg"
              data-qa="new-password"
              rounded
              outlined
              v-model="new_password"
              placeholder="Введите новый пароль"
              hide-details
              clearable
              :type="typeField"
            >
              <!-- eslint-disable-next-line -->
              <template #append>
                <v-icon v-if="new_password" @click="switchTypeField" class="mr-2">mdi-eye-outline</v-icon>
                <v-icon v-if="isInvalidNew" color="error">mdi-alert-circle</v-icon>
              </template>
            </v-text-field>
          </div>
          <div class="form-group mb-3" :class="{'error-field': isInvalidRepeat}">
            <p class="form-group__title">Подтвердите новый пароль</p>
            <v-text-field
              class="rounded-lg"
              data-qa="repeat-password"
              rounded
              outlined
              v-model="repeat_password"
              placeholder="Новый пароль ещё раз"
              hide-details
              clearable
              :type="typeField"
            >
              <!-- eslint-disable-next-line -->
              <template #append>
                <v-icon v-if="repeat_password" @click="switchTypeField" class="mr-2">mdi-eye-outline</v-icon>
                <v-icon v-if="isInvalidRepeat" color="error">mdi-alert-circle</v-icon>
              </template>
            </v-text-field>
            <div class="v-messages error--text" v-if="isInvalidRepeat">Пароли в полях не совпадают!</div>
          </div>

          <div class="info-page__block-text">
            <p>Пароль должен содержать:</p>
            <ul>
              <li><v-icon color="success">mdi-{{ characterCount.value > new_password.length ? 'circle-small' : 'check' }}</v-icon> Минимальная длина пароля {{ +characterCount.value }} символов</li>
              <li v-if="lowerCase.value === 'Да'"><v-icon color="success">mdi-{{ !$v.new_password.haveLowerCase ? 'circle-small' : 'check' }}</v-icon> Как минимум одну маленькую букву (a-z)</li>
              <li v-if="upperCase.value === 'Да'"><v-icon color="success">mdi-{{ !$v.new_password.haveUpperCase ? 'circle-small' : 'check' }}</v-icon> Как минимум одну большую букву (A-Z)</li>
              <li v-if="numbers.value === 'Да'"><v-icon color="success">mdi-{{ !$v.new_password.haveNumber ? 'circle-small' : 'check' }}</v-icon> Как минимум одну цифру (0-9)</li>
              <li v-if="specialSymbols.value === 'Да'"><v-icon color="success">mdi-{{ !$v.new_password.haveSymbol ? 'circle-small' : 'check' }}</v-icon> Как минимум один специальный символ (!, $, %, &, ...)</li>
              <li><v-icon color="success">mdi-{{ !$v.new_password.haveCyr ? 'circle-small' : 'check' }}</v-icon> Пароль не должен содержать кириллицу</li>
            </ul>
          </div>
        </v-card-text>

        <v-card-actions class="justify-end">
          <v-btn
            class="rounded-lg"
            color="secondary"
            outlined
            @click="closePasswordPopup()"
          >Отменить</v-btn>
          <v-btn
            class="rounded-lg"
            color="secondary"
            :loading="loading"
            :disabled="isInvalidNew || isInvalidRepeat"
            @click="submitHandler()"
          >Далее</v-btn>
        </v-card-actions>
      </v-card>
    </div>
  </div>
</template>

<script>

// Wz6Lth
// testroman d9$Ia
// J$4qi testpassword
import { required, sameAs } from 'vuelidate/lib/validators'
import { CREATE_PASSWORD } from '../services/api'
import { GET_PASSWORD_REQUIREMENTS } from '@/services/app'

export default {
  validations: {
    new_password: {
      required,
      haveLowerCase (val) {
        if (this.lowerCase.value) {
          const regExp = /(?=.*[a-z])/g // проверка на маленькие буквы
          return regExp.test(val)
        }
        return true
      },
      haveUpperCase (val) {
        if (this.upperCase.value) {
          const regExp = /(?=.*[A-Z])/g // проверка на большие буквы
          return regExp.test(val)
        }
        return true
      },
      haveNumber (val) {
        if (this.numbers.value) {
          const regExp = /(?=.*[0-9])/g // проверка на цифры
          return regExp.test(val)
        }
        return true
      },
      haveSymbol (val) {
        if (this.specialSymbols.value === 'Да') {
          val = val.replace(/[A-Za-zА-Яа-я0-9]+/gm, '') // убрать все разрешенные символы (проверка на наличие спецсимвола)
          if (val.length === 0) return false // значит не имеет сиволов
          else return true
        } else return true
      },
      haveCyr (val) {
        const regExp = /(?=.*[А-Яа-я])/g // проверка на кириллицу (не должно быть)
        if (regExp.test(val)) return false
        else return true
      }
    },
    repeat_password: {
      sameAsPassword: sameAs('new_password')
    }
  },

  data: () => ({
    new_password: '',
    repeat_password: '',
    typeField: 'password',
    loading: false,
    errorMsg: null
  }),

  computed: {
    numbers () {
      return this.passwordRequirements.find(param => param.code === 'numbers')
    },

    lowerCase () {
      return this.passwordRequirements.find(param => param.code === 'lower_case')
    },

    upperCase () {
      return this.passwordRequirements.find(param => param.code === 'upper_case')
    },

    specialSymbols () {
      return this.passwordRequirements.find(param => param.code === 'special_symbols')
    },

    characterCount () {
      return this.passwordRequirements.find(param => param.code === 'character_count')
    },

    isInvalidNew () {
      return (this.$v.new_password.$invalid && this.new_password) || (!this.$v.new_password.$invalid && this.$v.repeat_password.$invalid)
    },

    isInvalidRepeat () {
      return this.$v.repeat_password.$invalid
    }
  },

  async created () {
    this.loading = true
    this.passwordRequirements = await GET_PASSWORD_REQUIREMENTS()
    this.loading = false
  },

  methods: {
    closePasswordPopup () {
      this.$store.dispatch('login/SET_VALUE', { key: 'isChangePassword', value: false })
    },

    async submitHandler () {
      this.loading = true
      try {
        await CREATE_PASSWORD(this.new_password)
        this.errorMsg = null
      } catch (error) {
        console.log(error)
        this.errorMsg = error.response.data.message
      } finally {
        this.loading = false
      }
    },

    switchTypeField () {
      if (this.typeField === 'text') {
        this.typeField = 'password'
      } else {
        this.typeField = 'text'
      }
    }
  }
}
</script>

<style lang="scss">

.info-page {
  background-color: #F5F5F5;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  &__block {
    width: 520px;
    &-title {
      color: var(--v-primary-base)
    }
    h2 {
      font-size: 44px;
      margin-bottom: 30px;
    }
    .v-card {
      color: #76767A;
      box-shadow: none!important;
      border-radius: 8px;
    }
    &-text {
      ul {
        padding-left: 0;
        list-style: none;
      }
      i:before {
        transition: .3s;
      }
    }
  }
}
</style>
