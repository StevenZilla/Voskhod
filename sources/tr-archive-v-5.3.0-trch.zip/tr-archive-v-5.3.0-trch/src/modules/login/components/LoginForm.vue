<template>
  <div class="login-wrapper">
    <v-form data-qa="form" class="login__panel">
      <div class="form-group mb-3" :class="{ 'form-group-error': errorAuth || oikError }">
        <p class="form-group__title">Организация</p>
        <v-autocomplete
          v-model="loginData.uid"
          data-qa="organization"
          class="rounded-lg"
          outlined
          item-text="name"
          item-value="uid"
          placeholder="Выберите организацию"
          hide-details
          color="secondary"
          :error="oikError"
          :items="oiksList"
          :loader-height="5"
          :filled="oiksLoading"
          :disabled="oiksLoading"
          :loading="oiksLoading"
          :no-data-text="'Нет результатов'"
        ></v-autocomplete>
        <span v-if="oikError" class="subtitle-2 error--text">Не удалось получить список организаций</span>
      </div>

      <div class="form-group mb-3" :class="{ 'form-group-error': errorAuth }">
        <p class="form-group__title">Логин</p>
        <v-text-field
          v-model="loginData.login"
          data-qa="login"
          class="rounded-lg"
          hide-details
          outlined
          required
          placeholder="Введите логин"
          :append-icon="errorAuth ? 'mdi-alert-circle' : ''"
        ></v-text-field>
      </div>

      <span v-if="errorAuth" class="error--text">{{ errorMsg.error && errorMsg.error.login ? errorMsg.error.login[0] : '' }}</span>

      <div class="form-group mb-3" :class="{ 'form-group-error': errorAuth }">
        <p class="form-group__title">Пароль</p>
        <v-text-field
          v-model="loginData.password"
          data-qa="password"
          class="rounded-lg"
          hide-details
          outlined
          required
          :type="show1 ? 'text' : 'password'"
          :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
          placeholder="Введите пароль"
          @click:append="show1 = !show1"
        >
<!--          <template slot="append">-->
<!--            <v-icon class="error&#45;&#45;text" v-if="errorAuth">mdi-alert-circle</v-icon>-->
<!--          </template>-->
        </v-text-field>
      </div>
      <!--      <span v-if="errorAuth" class="error&#45;&#45;text">{{ errorMsg }}</span>-->

      <v-alert
        v-if="errorPermissions"
        class="mt-3"
        dense
        type="error"
        icon="mdi-alert"
        color="error"
      >Не получилось запросить права пользователя.
      </v-alert>

      <span v-if="errorAuth" class="error--text">{{ errorMsg.message }}</span>

      <v-btn
        data-qa="submit"
        class="rounded-lg mt-3"
        color="secondary"
        :loading="loginLoading"
        :disabled="invalidData"
        @click="loginUser"
      >
        <v-icon class="mr-2">mdi-login</v-icon>
        Войти
      </v-btn>

      <EsiaCallback
        v-if="!isEsiaisAuthorized
          && !isEsiaAuthorization"
      />

      <v-btn
        data-qa="submit-esia"
        class="rounded-lg mt-3"
        color="secondary"
        outlined
        :loading="loginLoading"
        @click="loginEsia"
      >
        <v-icon class="mr-2">mdi-account-arrow-right</v-icon>
        Войти через Госуслуги (ЕСИА)
      </v-btn>
      <div class="link-wrapper">
        <RecoveryPasswordVue
        />
      </div>
    </v-form>
  </div>
</template>

<script>

import {
  LOGIN, GET_ESIA_LOGIN
  // ESIA_LOGOUT
} from '../services/api'
import {
  CHECK_AUTH, GET_PERMISSIONS, GET_OIKS_LIST
  //  LOGIN_AUTH_USER
} from '@/services/app'
import { mapState } from 'vuex'
// import store from '@/storages'

import { required } from 'vuelidate/lib/validators'
import { checkAvailablePage } from '../utils/helperLogin.js'
import EsiaCallback from '../components/EsiaCallback.vue'

const RecoveryPasswordVue = () => import('../Login/RecoveryPassword.vue')

export default {
  name: 'LoginForm',

  components: {
    EsiaCallback,
    RecoveryPasswordVue
  },

  validations: {
    loginData: {
      uid: { required },
      login: { required },
      password: { required }
    }
  },

  data () {
    return {
      oikError: false,
      oiksList: [],
      isNotify: false,
      loginData: {
        uid: null,
        login: null,
        password: null
      },
      isRecovery: false,
      errorAuth: false,
      errorMsg: '',
      oiksLoading: true,
      show1: false
    }
  },
  computed: {
    ...mapState({
      errorPermissions: state => state.errorPermissions,
      loginLoading: state => state.login.loginLoading,
      isAuthenticated: state => state.isAuthenticated,
      isAuthorized: state => state.isAuthorized,
      isEsiaAuthorization: state => state.isEsiaAuthorization,
      isEsiaisAuthorized: state => state.isEsiaisAuthorized
    }),

    invalidData () {
      return this.$v.$invalid
    }
  },

  beforeMount () {
    document.addEventListener('keydown', this.onKeyDown)
  },

  async mounted () {
    try {
      this.oiksList = await GET_OIKS_LIST()
      this.loginData.uid = localStorage.getItem('uid')
    } catch (error) {
      console.log(error)
      this.oikError = true
    } finally {
      this.oiksLoading = false
    }
  },

  beforeDestroy () {
    document.removeEventListener('keydown', this.onKeyDown)
  },

  methods: {
    async loginUser () {
      this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: true })

      this.errorAuth = false
      try {
        await LOGIN(this.loginData)
        await CHECK_AUTH()
        await GET_PERMISSIONS()

        const availableUrl = checkAvailablePage()
        if (availableUrl) {
          this.$router.push(availableUrl)
        }
      } catch (error) {
        this.errorAuth = true
        this.errorMsg = error.response?.data
        throw (error)
      } finally {
        this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: false })
      }
    },

    async loginEsia () {
      this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: true })
      localStorage.setItem('uid', this.loginData.uid)

      this.esiaUrl = await GET_ESIA_LOGIN()
      if (this.esiaUrl) {
        window.location.href = this.esiaUrl
        // window.open(this.esiaUrl, '_blank')
        this.$store.dispatch('login/SET_VALUE', { key: 'loginLoading', value: false })
      }
    },

    async onKeyDown (e) {
      if (e.code === 'Enter') {
        await this.loginUser()
      }
    }
  }
}
</script>

<style lang="scss">

</style>
