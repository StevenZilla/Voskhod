<template>
  <p v-if="loadingEsia" class="loader-container">
  <v-progress-circular
      indeterminate
      size="32"
      color="secondary"
      class="mr-3 ml-3 mt-3 mb-3"
  ></v-progress-circular>
      <!-- <span >
          <div><h4>Выполняется вход для пользователя:</h4></div>
          <div>{{ userInfo.fio }}</div>
      </span> -->
    <span >Идет авторизация через систему ЕСИА....</span>
  </p>
</template>

<script>
import { GET_SUCCESS_ESIA_USER } from '../services/api'
import { mapState } from 'vuex'
import store from '@/storages'

import { checkAvailablePage } from '../utils/helperLogin.js'

import {
// GET_OIKS_LIST
} from '@/services/app'

export default {
  name: 'EsiaCallback',
  props: {
  },
  components: {
  },

  data: () => ({
    loadingEsia: false
  }),
  computed: {
    ...mapState({
      userInfo: state => state.userInfo,
      isAuthenticated: state => state.isAuthenticated,
      isAuthorized: state => state.isAuthorized,
      isEsiaAuthorization: state => state.isEsiaAuthorization,
      isEsiaisAuthorized: state => state.isEsiaisAuthorized
    }),

    computedFio () {
      return this.userInfo.fio
    }
  },

  methods: {
    async prepareAuthLink () {
      let uid = ''
      uid = localStorage.getItem('uid')
      setTimeout(async () => {
        const query = new URLSearchParams(this.$route.query)
        const state = query.get('state')
        const code = query.get('code')

        // console.log('uid local', uid)
        // console.log('query', query)
        // console.log('state', state)
        // console.log('code', code)

        if (!this.isEsiaisAuthorized && state && code && uid) {
          this.loadingEsia = true
          try {
            const successUsers = await GET_SUCCESS_ESIA_USER(code, state, uid)
            // console.log('successUsers', successUsers)
            if (successUsers.code === 201) {
              console.log('Успешно запросили пользователя через ЕСИА')
              await store.dispatch('SET_VALUE', { key: 'isAuthorized', value: true })
              const availableUrl = checkAvailablePage()

              if (availableUrl) {
                console.log('availableUrl', availableUrl)

                if (availableUrl !== this.$route.path) {
                  console.log('this.$route.path', this.$route.path)

                  await store.dispatch('SET_VALUE', { key: 'isEsiaisAuthorized', value: true })
                  this.$router.push(availableUrl)
                }
              }
            }

            return successUsers
            // this.$router.push('/nomenclatures')
          } catch (error) {
            await store.dispatch('SET_VALUE', { key: 'isEsiaisAuthorized', value: false })
            this.$router.push('/login')
            console.error('Ошибка при обработке ответа от ЕСИА:', error)
          } finally {
            this.loadingEsia = false
          }
        } else {
          await store.dispatch('SET_VALUE', { key: 'isEsiaAuthorization', value: true })
          console.error('Отсутствуют требуемые параметры для обработки ответа от ЕСИА или уже авторизован')
        }
      }, 1500)
    }
  },

  async created () {
    this.prepareAuthLink()
  }
}
</script>

<style lang="scss">
.loader-container {
    display: flex;
    justify-content: flex-start;
    align-items: center;
}
</style>
