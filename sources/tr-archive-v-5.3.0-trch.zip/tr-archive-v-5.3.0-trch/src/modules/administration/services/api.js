import api from '@/services/api'
// import store from '@/storages'

export async function GET_SYSTEM_ROLE_LIST () {
  const resp = await api.get('/ead/system_roles')
  return resp.data.system_roles
}
