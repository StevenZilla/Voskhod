<template>
  <div class="form-group w-100">
    <p class="form-group__title">Окончание действия<span class="required-label">*</span></p>
    <date-range-picker
        v-model="dateRangeMix.end"
        opens="right"
        time-picker-seconds
        time-picker
        showDropdowns
        singleDatePicker
        :minDate="editingObj.start_date"
        :time-picker-increment="1"
        :locale-data="localeData"
        @toggle="$_setBeginDate($event, editingObj.end_date, 'end')"
        @update="value = $_setDate($event, 'time')"
    >
      <template #input>
        <v-text-field
            class="rounded-lg"
            readonly
            outlined
            hide-details
            placeholder="дд.мм.гггг чч:мм:сс"
            append-icon="mdi-calendar-blank"
            :value="editingObj.end_date"
        ></v-text-field>
      </template>

      <div slot="footer" slot-scope="data" class="slot">
        <v-btn
            color="secondary"
            class="rounded-lg mr-4"
            outlined
            @click="data.clickCancel"
        >Сбросить
        </v-btn>
        <v-btn
            color="secondary"
            class="rounded-lg"
            @click="data.clickApply"
        >Применить
        </v-btn>
      </div>
    </date-range-picker>
  </div>
</template>

<script>
export default {
  props: {
    localeData: {
      type: Object,
      required: true
    },
    editingInfo: {
      type: Object,
      required: true
    }
  },

  data: () => ({
    value: null,
    editingObj: null
  }),

  watch: {
    value: {
      handler: function (newVal) {
        if (newVal) this.$emit('set-property', newVal)
      },
      deep: true
    }
  },
  created () {
    this.value = this.editingInfo.end_date
    this.editingObj = this.editingInfo
  }
}
</script>

<style lang="scss">
</style>
