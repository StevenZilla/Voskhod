<template>
  <v-dialog
    v-model="isCreate"
    hide-overlay
    transition="scroll-y-transition"
    content-class="app-modal"
    :attach="true"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        class="justify-content-end rounded-lg mr-3"
        color="secondary"
        v-bind="attrs"
        v-on="on"
      >Добавить системную роль</v-btn>
    </template>

    <TemplateCreate
      :loading="loading"
      :disabled="invalidMainForm"
      @save="submitHandler()"
      @close="closeDialog()"
    >
      <template #content>
        <CreateMainInfo
          :trigger="trigger"
          :error-data="errorData"
          @change-valid="invalidMainForm = $event"
          @fill-data="fillData($event)"
        />
      </template>
    </TemplateCreate>
  </v-dialog>
</template>

<script>

import { CREATE_ROLE } from '../../services/api'

const CreateMainInfo = () => import('./CreateMainInfo.vue')

export default {
  components: {
    CreateMainInfo
  },

  data: () => ({
    clearComponentVar: 0,
    isCreate: false,
    invalidMainForm: true,
    loading: false,
    isSame: false,
    errorData: {},
    trigger: 0,
    createDetailInfo: {}
  }),

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.createDetailInfo, evt)
        resolve()
      })
    },

    async submitHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      try {
        const resp = await CREATE_ROLE(this.createDetailInfo)
        this.$emit('refresh-data', resp.data.message)
        this.$emit('clear')
      } catch (error) {
        if (error.response.data) {
          this.errorData = error.response.data
          this.isSame = true
        }
      } finally {
        this.loading = false
      }
    },

    closeDialog () {
      this.isCreate = false
      this.$emit('clear')
    }
  }
}
</script>

<style lang="scss">
</style>
