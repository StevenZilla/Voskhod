<template>
  <div class="form-group w-100">
    <p class="form-group__title">Начало действия<span class="required-label">*</span></p>
    <date-range-picker
        v-model="dateRangeMix.start"
        opens="right"
        time-picker-seconds
        time-picker
        showDropdowns
        singleDatePicker
        :minDate="todayMix"
        :maxDate="editingObj.end_date"
        :time-picker-increment="1"
        :locale-data="localeData"
        @toggle="$_setBeginDate($event, editingObj.start_date, 'start')"
        @update="value = $_setDate($event, 'time')"
    >
      <template #input>
        <v-text-field
            class="rounded-lg"
            readonly
            outlined
            hide-details
            placeholder="дд.мм.гггг чч:мм:сс"
            append-icon="mdi-calendar-blank"
            :value="editingObj.start_date"
        ></v-text-field>
      </template>

      <div slot="footer" slot-scope="data" class="slot">
        <DatePickerActions
            :disabled="!!data.in_selection"
            @cancel="data.clickCancel"
            @apply="data.clickApply"
        />
      </div>
    </date-range-picker>
  </div>
</template>

<script>
export default {
  props: {
    localeData: {
      type: Object,
      required: true
    },
    editingInfo: {
      type: Object,
      required: true
    }
  },

  data: () => ({
    value: null,
    editingObj: null
  }),

  watch: {
    value: {
      handler: function (newVal) {
        if (newVal) this.$emit('set-property', newVal)
      },
      deep: true
    }
  },
  created () {
    this.value = this.editingInfo.start_date
    this.editingObj = this.editingInfo
  }
}
</script>

<style lang="scss">
</style>
