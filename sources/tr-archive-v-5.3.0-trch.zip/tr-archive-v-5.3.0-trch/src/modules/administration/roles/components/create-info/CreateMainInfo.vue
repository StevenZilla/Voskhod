<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mb-5">Общая информация</h2>
    </v-card-title>
    <v-card-text class="pb-1">
      <v-row>

        <v-col cols="12">
          <NameRole @set-property="createMainInfo.name = $event"/>
        </v-col>

        <v-col cols="12" md="6">
          <PriorityRights @set-property="createMainInfo.priority = $event"/>
        </v-col>

        <v-col cols="12" md="6">
          <StartAction
              :editing-info="createMainInfo"
              :locale-data="localeSettings"
              @set-property="createMainInfo.start_date = $event"
          />
        </v-col>

        <v-col cols="12" md="6">
          <Description @set-property="createMainInfo.descr = $event"/>
        </v-col>

        <v-col cols="12" md="6">
            <EndAction
                :editing-info="createMainInfo"
                :locale-data="localeSettings"
                @set-property="createMainInfo.end_date = $event"
            />
        </v-col>
      </v-row>
      <p class="mt-3"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { required } from 'vuelidate/lib/validators'
import { format } from 'date-fns'
import NameRole from '../fields-main-info/NameRole.vue'
import PriorityRights from '@/modules/administration/roles/components/fields-main-info/PriorityRights.vue'
import StartAction from '@/modules/administration/roles/components/fields-main-info/StartAction.vue'
import EndAction from '@/modules/administration/roles/components/fields-main-info/EndAction.vue'
import Description from '@/modules/administration/roles/components/fields-main-info/Description.vue'

export default {
  components: {
    Description,
    StartAction,
    EndAction,
    PriorityRights,
    NameRole
  },
  name: 'CreateMainInfo',

  validations: {
    createMainInfo: {
      name: { required },
      priority: { required },
      descr: { required },
      start_date: { required },
      end_date: { required }
    }
  },

  props: {
    errorData: {
      type: Object,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    createMainInfo: {
      name: null,
      priority: null,
      descr: null,
      start_date: null,
      end_date: null
    },
    priorityList: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  }),

  computed: {
    invalidData () {
      return this.$v.$invalid
    }
  },

  watch: {
    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.$emit('fill-data', this.createMainInfo)
    }
  },

  async mounted () {
    this.getAutoDate()
  },

  methods: {
    getAutoDate () {
      this.createMainInfo.start_date = format(new Date(), 'yyyy-MM-dd HH:mm:ss')
      this.createMainInfo.end_date = format(new Date(2121, 0, 1, 0, 0, 0), 'yyyy-MM-dd HH:mm:ss')
    }
  }
}
</script>

<style>

</style>
