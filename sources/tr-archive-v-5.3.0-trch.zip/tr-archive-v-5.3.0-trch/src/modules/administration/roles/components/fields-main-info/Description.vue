<template>
  <div class="form-group w-100">
    <p class="form-group__title">Описание<span class="required-label">*</span></p>
    <v-text-field
        v-model="value"
        class="rounded-lg"
        outlined
        rounded
        clearable
        placeholder="Описание"
        hide-details
        required
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
