<template>
  <div class="card">
    <v-alert v-if="isSame" icon="mdi-alert" type="error">
      {{ errorData.message }}
    </v-alert>

    <EditingMainInfo
      :trigger="trigger"
      :error-data="errorData"
      @change-valid="invalidMainForm = $event"
      @fill-data="fillData($event)"
    />

    <TemplateButtons>
      <template #buttons-left>
        <BtnSaveSlot
          :loading="loading"
          :disabled="invalidEditingInfo"
          @save="updateHandler()"
        />
      </template>

      <template #buttons-right>
        <BtnCancelSlot
          :text="'Отменить'"
          @close="cancelEdit()"
        />
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { UPDATE_ROLE } from '../../services/api'
import { mapGetters } from 'vuex'

import EditingMainInfo from './EditingMainInfo.vue'

export default {
  name: 'EditingRole',
  components: {
    EditingMainInfo
  },

  data: () => ({
    loadingComponent: true,
    trigger: 0,
    invalidMainForm: false,
    invalidStructure: false,
    loading: false,
    errorData: {},
    isLoadStructure: true,
    isSame: false,
    editDetailRole: {}
  }),

  computed: {
    ...mapGetters('roles', ['GET_ROLE_ID']),

    invalidEditingInfo () {
      return this.invalidMainForm
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.editDetailRole, evt)
        resolve()
      })
    },

    cancelEdit () {
      this.$store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'view' })
    },

    async updateHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      try {
        await UPDATE_ROLE(this.GET_ROLE_ID, this.editDetailRole)
        this.$emit('refresh-data')
        this.$store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'view' })
      } catch (error) {
        if (error.response?.data) {
          this.errorData = error.response.data
          this.isSame = true
        }
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
