<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2>Общая информация</h2>
    </v-card-title>

    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="12">
          <div class="form-group">
            <p class="form-group__title">Наименование роли <span class="required-label">*</span></p>
            <v-text-field
              v-model="editMainInfo.name"
              class="rounded-lg"
              rounded
              outlined
              disabled
              filled
              placeholder="Наименование роли"
              hide-details
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3" md="3">
          <div class="form-group">
            <p class="form-group__title">Описание <span class="required-label">*</span></p>
            <v-text-field
              class="rounded-lg"
              rounded
              outlined
              clearable
              placeholder="Описание"
              hide-details
              v-model="editMainInfo.descr"
              required
            ></v-text-field>
          </div>
        </v-col>

<!--        <v-col cols="3" md="3">-->
<!--          <div class="form-group ml-10">-->
<!--            <p class="form-group__title">Приоритет прав доступа <span class="required-label">*</span></p>-->
<!--            <v-autocomplete-->
<!--              v-model="editMainInfo.priority"-->
<!--              class="rounded-lg"-->
<!--              rounded-->
<!--              outlined-->
<!--              return-object-->
<!--              hide-details-->
<!--              required-->
<!--              :no-data-text="'Нет результатов'"-->
<!--              :items="priorityList"-->
<!--            ></v-autocomplete>-->
<!--          </div>-->
<!--        </v-col>-->

        <v-col cols="3" md="3">
          <div class="form-group ml-10">
            <p class="form-group__title">Начало действия <span class="required-label">*</span></p>

            <date-range-picker
              v-model="dateRangeMix.start"
              opens="right"
              time-picker-seconds
              time-picker
              show-dropdowns
              single-date-picker
              :ranges="false"
              :min-date="todayMix"
              :max-date="editMainInfo.end_date"
              :time-picker-increment="1"
              :locale-data="localeSettings"
              @toggle="$_setBeginDate($event, [editMainInfo.start_date], 'start')"
              @update="editMainInfo.start_date = $_setDate($event, 'time')"
            >
              <template #input>
                <v-text-field
                  class="rounded-lg"
                  readonly
                  outlined
                  hide-details
                  placeholder="дд.мм.гггг чч:мм:сс"
                  append-icon="mdi-calendar-blank"
                  :value="$_formatDate(editMainInfo.start_date, 'time')"
                ></v-text-field>
              </template>

              <div slot="footer" slot-scope="data" class="slot">
                <v-btn
                  color="secondary"
                  class="rounded-lg mr-4"
                  outlined
                  @click="data.clickCancel()"
                >Сбросить
                </v-btn>
                <v-btn
                  color="secondary"
                  class="rounded-lg"
                  @click="data.clickApply"
                >Применить
                </v-btn>
              </div>
            </date-range-picker>
          </div>
        </v-col>

        <v-col cols="3" md="3">
          <div class="form-group ml-10">
            <p class="form-group__title">Окончание действия <span class="required-label">*</span></p>

            <date-range-picker
              v-model="dateRangeMix.end"
              opens="right"
              time-picker-seconds
              time-picker
              show-dropdowns
              single-date-picker
              :ranges="false"
              :min-date="editMainInfo.start_date"
              :time-picker-increment="1"
              :locale-data="localeSettings"
              @toggle="$_setBeginDate($event, [editMainInfo.end_date], 'end')"
              @update="editMainInfo.end_date = $_setDate($event, 'time')"
            >
              <template #input>
                <v-text-field
                  class="rounded-lg"
                  readonly
                  outlined
                  hide-details
                  placeholder="дд.мм.гггг чч:мм:сс"
                  append-icon="mdi-calendar-blank"
                  :value="$_formatDate(editMainInfo.end_date, 'time')"
                ></v-text-field>
              </template>

              <div slot="footer" slot-scope="data" class="slot">
                <v-btn
                  color="secondary"
                  class="rounded-lg mr-4"
                  outlined
                  @click="data.clickCancel()"
                >Сбросить
                </v-btn>
                <v-btn
                  color="secondary"
                  class="rounded-lg"
                  @click="data.clickApply"
                >Применить
                </v-btn>
              </div>
            </date-range-picker>
          </div>
        </v-col>
      </v-row>
      <p class="mt-3" style="font-size: 14px">
        <span class="required-label">*</span> Обязательные поля
      </p>
    </v-card-text>
  </v-card>
</template>

<script>

import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'

export default {
  name: 'EditingMainInfo',

  validations: {
    editMainInfo: {
      name: { required },
      priority: { required },
      descr: { required },
      start_date: { required },
      end_date: { required }
    }
  },

  props: {
    errorData: {
      type: Object,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    editMainInfo: {
      name: null,
      priority: null,
      descr: null,
      start_date: null,
      end_date: null
    },

    priorityList: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  }),

  computed: {
    ...mapState({
      detailRole: state => state.roles.detailRole
    }),

    invalidData () {
      return this.$v.$invalid
    }
  },

  watch: {
    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editMainInfo)
    }
  },

  mounted () {
    this.copyInfo()
  },

  methods: {
    copyInfo () {
      this.editMainInfo.name = this.detailRole.name
      this.editMainInfo.priority = this.detailRole.priority
      this.editMainInfo.descr = this.detailRole.descr
      this.editMainInfo.start_date = this.detailRole.start_date
      this.editMainInfo.end_date = this.detailRole.end_date
    }
  }
}
</script>

<style>

</style>
