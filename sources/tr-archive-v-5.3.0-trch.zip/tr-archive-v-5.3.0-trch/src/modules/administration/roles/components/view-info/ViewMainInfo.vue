<template>
  <v-card class="detail__main-info">
    <h2 class="detail__title">{{ detailRole.name }}</h2>

    <v-card-title>
      <h2>Общая информация</h2>
      <v-icon
        icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >mdi-chevron-down</v-icon>
    </v-card-title>
    <div class="main-info-block">
      <v-card-text
        class="detail__view-inner item-5"
        :class="{ open: isMainInfo }"
      >
        <div class="detail__item">
          <p class="detail__item-title">Описание</p>
          <span class="detail__value">{{ detailRole.descr }}</span>
        </div>
<!--        <div class="detail__item">-->
<!--          <p class="detail__item-title">Приоритет прав доступа</p>-->
<!--          <span class="detail__value">{{ detailRole.priority }}</span>-->
<!--        </div>-->
        <div class="detail__item">
          <p class="detail__item-title">Начало действия</p>
          <span class="detail__value">{{ $_formatDate(detailRole.start_date, 'time') }}</span>
        </div>
        <div class="detail__item">
          <p class="detail__item-title">Окончание действия</p>
          <span class="detail__value">{{ $_formatDate(detailRole.end_date, 'time') }}</span>
        </div>
      </v-card-text>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'ViewMainInfo',

  data: () => ({
    isMainInfo: true
  }),

  computed: {
    ...mapState({
      detailRole: state => state.roles.detailRole
    })
  },

  mounted () {
    // console.log(this.detailInfo)
  }
}
</script>

<style>

</style>
