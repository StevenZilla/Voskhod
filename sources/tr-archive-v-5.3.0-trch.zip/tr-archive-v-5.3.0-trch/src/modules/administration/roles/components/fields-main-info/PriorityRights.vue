<template>
  <div class="form-group">
    <p class="form-group__title">Приоритет прав доступа <span class="required-label">*</span></p>
    <v-autocomplete
        v-model="value"
        class="rounded-lg"
        outlined
        rounded
        clearable
        placeholder="Приоритет прав доступа"
        hide-details
        required
        :items="priorityList"
        :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    priorityList: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
