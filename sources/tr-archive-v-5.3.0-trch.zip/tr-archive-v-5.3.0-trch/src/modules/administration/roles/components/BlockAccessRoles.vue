<template>
  <v-card class="detail__additional-info mt-10">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Расширение прав доступа</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit"
          data-qa="access-edit-view"
          class="circle circle__btn circle--white"
          icon
          :disabled="loading"
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-else>
          <div class="d-flex">
            <v-btn
              data-qa="access-close-view"
              class="circle circle__btn circle--white"
              icon
              @click="isEdit = false"
            >
              <v-icon color="secondary">mdi-close</v-icon>
            </v-btn>
          </div>
        </template>
      </div>
    </v-card-title>

    <LoadingComponentVue class="mt-10" v-if="loading"/>

    <v-card-text v-else class="no-bg">
      <v-alert
        v-if="errorSetAccess"
        class="mt-2"
        icon="mdi-alert"
        type="error"
      >{{ errorSetAccess }}
      </v-alert>

      <div class="detail-wrapper">
        <v-data-table
          class="mixin-table no-hover row-default-cursor"
          item-key="tech_name"
          hide-default-footer
          disable-pagination
          height="500px"
          fixed-header
          group-by="group"
          no-results-text="Ничего не найдено"
          no-data-text="Нет данных"
          :loading="loadingChanges"
          :loader-height="5"
          :headers="headers"
          :items="accessList"
          :search="accessSearch"
        >
          <template #progress>
            <v-progress-linear
              indeterminate
              height="5"
              color="secondary"
            ></v-progress-linear>
          </template>

          <!-- eslint-disable-next-line -->
          <template #top>
            <div class="main-table__search">
              <v-text-field
                v-model="accessSearch"
                outlined
                clearable
                rounded
                required
                hide-details
                placeholder="Введите наименование"
                class="rounded-lg"
              ></v-text-field>
            </div>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:group.header="{ items }">
            <td class="px-0 py-0" :colspan="headers.length">
              <div class="group-title">{{ items[0].group }}</div>
            </td>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.id="{ index }">
            {{ index + 1 }}
          </template>
          <!-- eslint-disable-next-line -->
          <template v-slot:item.available="{ item }">
            <div class="d-flex justify-center">
              <v-simple-checkbox
                v-ripple
                color="secondary"
                :disabled="!isEdit || loadingChanges"
                :value="item.rule"
                @input="setAccess(item.tech_name, true)"
              ></v-simple-checkbox>
            </div>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.forbidden="{ item }">
            <div class="d-flex justify-center">
              <v-simple-checkbox
                v-ripple
                color="secondary"
                :disabled="!isEdit || loadingChanges"
                :value="!item.rule"
                @input="setAccess(item.tech_name, false)"
              ></v-simple-checkbox>
            </div>
          </template>
        </v-data-table>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { CHANGE_ROLE_ACCESS, GET_ROLE_ACCESS } from '../services/api'

export default {
  name: 'BlockAccessUser',

  data: () => ({
    accessList: [],
    isEdit: false,
    accessSearch: '',
    errorSetAccess: '',
    loading: true,
    loadingChanges: false,
    headers: [
      {
        text: '№',
        value: 'id',
        sortable: false,
        width: '64px'
      },
      {
        text: 'Наименование',
        value: 'name',
        sortable: false,
        width: '310px'
      },
      {
        text: 'Доступно',
        value: 'available',
        align: 'center',
        sortable: false,
        width: '200px'
      },
      {
        text: 'Запрещено',
        value: 'forbidden',
        align: 'center',
        sortable: false,
        width: '200px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['roles/GET_ROLE_ID']
    }
  },

  watch: {
    id: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    }
  },

  methods: {
    async getData () {
      this.loading = true
      this.accessList = await GET_ROLE_ACCESS(await this.id)
      this.convertPermissions()
      this.loading = false
    },

    convertPermissions () {
      const convertPermissions = []
      this.accessList.forEach(cat => {
        cat.permissions.forEach(per => {
          this.$set(per, 'group', cat.category)
          convertPermissions.push(per)
        })
      })

      this.accessList = [...convertPermissions]
    },

    async setAccess (techName, val) {
      this.loadingChanges = true
      const obj = {
        rule: val
      }
      try {
        await CHANGE_ROLE_ACCESS(this.id, techName, obj)
        const changedRuleIdx = this.accessList.findIndex(rule => rule.tech_name === techName)
        this.accessList[changedRuleIdx].rule = val
        // await this.getData()
      } catch (e) {
        this.errorSetAccess = e.response.data?.message
      } finally {
        this.loadingChanges = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
