<template>
  <div class="panel-search">
    <div class="d-flex justify-space-between align-center">
      <v-text-field
        v-model="filterObj.name"
        class="main-field"
        data-qa="main-field"
        placeholder="Введите наименование системной роли"
        solo
        outlined
        rounded
        clearable
        hide-details
        flat
        @click:clear="filterObj.name = null, acceptFilters()"
        @keyup.enter="trigger++"
      >
        <template v-slot:append-outer>
          <v-btn
            class="rounded-xl ml-8 bg-white"
            outlined
            icon
            data-qa="filter"
            color="secondary"
            @click="toggleFilter()"
          >
            <v-icon>
              mdi-tune-vertical-variant
            </v-icon>
          </v-btn>
        </template>
        <template v-slot:prepend-inner>
          <v-btn
            plain
            icon
            color="secondary"
            @click="acceptFilters()"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
            v-if="filterObj.name"
            class="find-link secondary--text"
            @click="acceptFilters()"
          >Найти
          </span>
        </template>
      </v-text-field>

      <CreateRole
        :key="clearComponent"
        @clear="clearComponent++"
        @refresh-data="$emit('refresh-data', $event)"
      />
    </div>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />
  </div>
</template>

<script>

import CreateRole from './create-info/CreateRole.vue'

const Filters = () => import(/* webpackChunkName: 'filters' */'./Filters.vue')

export default {
  name: 'SearchPanel',

  components: {
    CreateRole,
    Filters
  },

  data: () => ({
    trigger: 0,
    clearComponent: 0,
    fullFilter: false,
    chipsList: [],
    filterObj: {
      name: ''
    }
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.name) {
        paramsFilter.append('name', this.filterObj.name)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt ? evt.filter : undefined)
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    clearFilters () {
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
