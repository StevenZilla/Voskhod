import api from '@/services/api'
import store from '@/storages'
import mixin from '@/utils/mixins'

export async function GET_ROLES_INDEX (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('roles/SET_VALUE', { key: 'roleLoading', value: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/ead/system_roles', { params: searchParams })
    store.dispatch('roles/SET_VALUE', { key: 'roleList', value: resp.data })
  } catch (error) {
    store.dispatch('roles/SET_VALUE', { key: 'roleList', value: '' })
    throw (error)
  } finally {
    store.dispatch('roles/SET_VALUE', { key: 'roleLoading', value: false })
  }
}

export async function CREATE_ROLE (roleObject) {
  return await api.post('/ead/system_roles', roleObject)
}

export async function GET_DETAIL_ROLE (id) {
  try {
    const resp = await api.get(`/ead/system_roles/${id}`)
    store.dispatch('roles/SET_VALUE', { key: 'detailRole', value: resp.data })
  } catch (error) {
    console.log(error.response)
  }
}

export async function UPDATE_ROLE (id, systemRoleObject) {
  store.dispatch('roles/SET_VALUE', { key: 'roleLoading', value: true })
  try {
    await api.put(`/ead/system_roles/${id}`, systemRoleObject)
    // store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'view' })
  } catch (error) {
    console.log(error)
  } finally {
    store.dispatch('roles/SET_VALUE', { key: 'roleLoading', value: false })
  }
}

export async function CHANGE_ROLE_ACCESS (idRole, techName, rule) {
  const host = `/ead/roles/${idRole}/permissions/${techName}`
  await api.patch(host, rule)
}

export async function GET_ROLE_ACCESS (id) {
  const host = `/ead/roles/${id}/permissions`
  const res = await api.get(host)
  return res.data
}
