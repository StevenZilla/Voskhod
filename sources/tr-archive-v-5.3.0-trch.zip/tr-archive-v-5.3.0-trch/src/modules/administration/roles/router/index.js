import { roleEvent } from '@/event-code'
import { administration, systemRoles, systemRolesDetail } from '@/permissions'
const RolesPage = () => import(/* webpackChunkName: 'RolesPage' */ '../views/RolesPage.vue')
const DetailRole = () => import(/* webpackChunkName: 'DetailRole' */ '../views/DetailRole.vue')

const rolesRouter = [
  {
    name: 'RolesPage',
    path: systemRoles.path,
    component: RolesPage,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Системные роли'
        }
      ],
      tech_name: administration.code
    }
  },
  {
    name: 'detail-systemrole',
    path: `${systemRolesDetail.path}/:id`,
    component: DetailRole,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Системные роли',
          to: systemRoles.path,
          exact: true
        },
        {
          text: 'Просмотр системной роли'
        }
      ],
      parent: systemRoles.path,
      tech_name: administration.code,
      code: roleEvent.code
    }
  }
]

export default router => {
  router.addRoutes(rolesRouter)
}
