<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewMainInfo v-if="modeRole === 'view'"/>

      <EditingRole
        v-else
        :key="clearComponent"
        @refresh-data="refreshData"
      />

      <BlockAccessRoles v-if="modeRole === 'view'"/>

      <TemplateButtons v-if="modeRole === 'view'">
        <template #buttons-left>
          <v-btn
            color="secondary"
            class="mr-3 rounded-lg"
            outlined
            @click="switchMode()"
          ><v-icon class="mr-2">mdi-pencil-outline</v-icon>
            Редактировать
          </v-btn>
        </template>

        <template #buttons-right>
          <v-btn
            data-qa="close"
            color="secondary"
            class="rounded-lg"
            @click="$_closeDetail()"
          >Закрыть</v-btn>
        </template>
      </TemplateButtons>

      <v-dialog
        v-model="dialog"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
      >
        <ConfirmCancel
          @cancel="dialog = false"
          @confirm="confirmLeave"
        />
      </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DETAIL_ROLE } from '../services/api'
import ViewMainInfo from '../components/view-info/ViewMainInfo.vue'
import BlockAccessRoles from '../components/BlockAccessRoles.vue'
import { mapState } from 'vuex'
import ConfirmCancel from '@/components/ConfirmCancel.vue'

const EditingRole = () => import('../components/editing-info/EditingRole.vue')

export default {
  name: 'DetailRole',

  components: {
    BlockAccessRoles,
    ViewMainInfo,
    ConfirmCancel,
    EditingRole
  },

  data: () => ({
    confirmCallback: null,
    dialog: false,
    loading: true,
    clearComponent: 0
  }),

  computed: {
    ...mapState({
      modeRole: state => state.roles.modeRole,
      error: state => state.error
    })
  },

  async mounted () {
    await this.getData()
  },

  beforeRouteUpdate (to, from, next) {
    this.$store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'view' })
    this.getData()
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    switchMode () {
      this.$store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'edit' })
    },

    checkEditingMode (next) {
      if (this.modeRole === 'edit') {
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
      }
    },

    confirmLeave () {
      this.dialog = false
      this.$store.dispatch('roles/SET_VALUE', { key: 'modeRole', value: 'view' })
      this.confirmCallback()
    },

    async refreshData () {
      await this.getData()
      this.clearComponent++
    },

    async getData () {
      this.loading = true
      try {
        await GET_DETAIL_ROLE(this.$route.params.id)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style>
</style>
