<template>
  <TemplatePage>
    <template #title>Системные роли</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @refresh-data="refreshData"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
      </div>

      <v-progress-linear
        v-if="roleList === null"
        indeterminate
        height="7"
        color="secondary"
      ></v-progress-linear>

      <v-alert
        v-else-if="roleList === ''"
        icon="mdi-alert"
        type="error"
      >Произошла ошибка при получении данных</v-alert>

      <v-data-table
        v-else
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        item-key="id"
        class="main-table scroll-table sortable-table"
        hide-default-footer
        :loading="roleLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :server-items-length="roleList.count"
        :headers="headersSystemRole"
        :options.sync="options"
        :items="roleList.system_roles"
        :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
        @page-count="pageCount = $event"
        @click:row="showDetail"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.start_date="{item}">
          <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.end_date="{item}">
          <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template #footer="{ props }">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { mapState } from 'vuex'
import { GET_ROLES_INDEX } from '../services/api'
import SearchPanel from '../components/SearchPanel.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'RolesPage',

  components: {
    TemplatePage,
    SearchPanel
  },

  data: () => ({
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [],
    headersSystemRole: [
      {
        text: '№',
        sortable: false,
        value: 'id',
        width: '64px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '25%'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '25%'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '20%'
      }
    ]
  }),

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          this.GET_ROLES_INDEX(this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      roleList: state => state.roles.roleList,
      roleLoading: state => state.roles.roleLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.roleList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    GET_ROLES_INDEX()
  },

  methods: {
    refreshData (evt) {
      GET_ROLES_INDEX()
      this.showDetail(evt)
      this.clearForm++
    },

    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      await GET_ROLES_INDEX(this.filterParams, this.sortParams)
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-systemrole', params: { id: _id } })
    }
  }
}
</script>

<style>
</style>
