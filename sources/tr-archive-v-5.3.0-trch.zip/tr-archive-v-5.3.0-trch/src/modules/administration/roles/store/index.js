export default {
  namespaced: true,
  state: {
    modeRole: 'view',
    roleList: null,
    roleLoading: false,
    detailRole: {}
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },

  getters: {
    GET_ROLE_ID: state => {
      if (!state.detailRole.id) return
      return state.detailRole.id
    }
  }
}
