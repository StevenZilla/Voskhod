export default {
  namespaced: true,
  state: {
    loading: false,
    imageUrl: null,
    uid: 0,
    file: null
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },
    incrementUid (state) {
      state.uid++
    },
    changeFileName (state, payload) {
      let oldExt = state.file?.name.split('.') || []
      oldExt = oldExt.pop()
      if (!payload?.includes(oldExt)) {
        payload = payload + '.' + oldExt
      }
      const newFile = new File([state.file], payload)
      state.file = newFile
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  }
}
