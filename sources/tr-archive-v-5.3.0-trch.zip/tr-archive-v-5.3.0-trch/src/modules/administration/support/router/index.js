import { administration, supportMessage } from '@/permissions'
const SupportPage = () => import(/* webpackChunkName: 'events-page' */ '../views/SupportPage.vue')

const supportRouter = [
  {
    name: 'EventsPageVue',
    path: supportMessage.path,
    component: SupportPage,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Обращения в ТП'
        }
      ],
      tech_name: administration.code
    }
  }
]

export default router => {
  router.addRoutes(supportRouter)
}
