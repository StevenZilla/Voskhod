import api from '@/services/api'
import store from '@/storages'
import mixin from '@/utils/mixins'

export async function GET_SUPPORT_RESPONSE (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('support/SET_VALUE', { key: 'loading', value: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/v2/support_message', { params: searchParams })
    return resp.data
  } catch (e) {
    console.log(e)
    throw (e)
  } finally {
    store.dispatch('support/SET_VALUE', { key: 'loading', value: false })
  }
}

export async function CREATE_INCIDENT (formData) {
  store.dispatch('support/SET_VALUE', { key: 'loading', value: true })
  try {
    const res = await api.post('/v2/support', formData)
    return res.data
  } catch (e) {
    console.log(e)
    throw (e)
  } finally {
    store.dispatch('support/SET_VALUE', { key: 'loading', value: false })
  }
}
