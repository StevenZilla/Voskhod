<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <CreationDate
        class="w-20"
        ref="creationDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
      <User
        class="w-20"
        ref="user_id"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />
      <Email
        class="w-20"
        ref="email"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
      <SendDate
          class="w-20"
          ref="sendDate"
          :reset-filter="resetFilter"
          @set-filter="setFilter($event)"
      />
      <SentToTP
        class="w-20"
        ref="is_sent"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import CreationDate from '@/components/Filters/Fields/Support/CreationDate.vue'
import User from '@/components/Filters/Fields/Support/User.vue'
import Email from '@/components/Filters/Fields/Support/Email.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import SendDate from '@/components/Filters/Fields/Support/SendDate.vue'
import SentToTP from '@/components/Filters/Fields/Support/SentToTP.vue'

export default {
  name: 'Filters',
  components: {
    SentToTP,
    SendDate,
    ChipsFilters,
    CreationDate,
    User,
    Email,
    FilterFooter,
    FiltersTemplate
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.creationDate) {
        paramsFilter.append('start_create_date', this.filterObj.creationDate.query[0])
        paramsFilter.append('end_create_date', this.filterObj.creationDate.query[1])
        chips.push(this.filterObj.creationDate)
      }
      if (this.filterObj.sendDate) {
        paramsFilter.append('start_send_date', this.filterObj.sendDate.query[0])
        paramsFilter.append('end_send_date', this.filterObj.sendDate.query[1])
        chips.push(this.filterObj.sendDate)
      }
      if (this.filterObj.is_sent) {
        paramsFilter.append('is_sent', this.filterObj.is_sent.query.value)
        chips.push(this.filterObj.is_sent)
      }
      if (this.filterObj.user_id) {
        paramsFilter.append('user_id', this.filterObj.user_id.query.value)
        chips.push(this.filterObj.user_id)
      }
      if (this.filterObj.email) {
        paramsFilter.append('email', this.filterObj.email.query)
        chips.push(this.filterObj.email)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.searchTouch = false
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
