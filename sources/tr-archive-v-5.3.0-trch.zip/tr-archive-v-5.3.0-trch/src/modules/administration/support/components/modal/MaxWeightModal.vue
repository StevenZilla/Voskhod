<template>
  <v-dialog
    v-model="isVisible"
    persistent max-width="600"
    content-class="dialog-auto-height"
    @click:outside="$emit('close')"
  >
    <v-card>
      <v-card-title :style="{justifyContent: 'center'}">
        <h5 class="warn">Размер файла не должен превышать - 10 Мб</h5>
      </v-card-title>
      <v-card-actions class="justify-end">
        <v-btn
          class="default-btn"
          style="height: 35px !important; width: 110px" color="secondary"
          @click="$emit('close')">Закрыть</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
export default {
  name: 'MaxWeightModal',
  props: {
    isVisible: {
      type: Boolean,
      require: true,
      default: false
    }
  }
}
</script>

<style scoped>
.warn {
  color: #F44336;
  font-weight: bold;
}
.default-btn {
  height: 35px !important;
  width: 110px !important;
  border-radius: 5px;
  margin-bottom: 7px;
}
</style>
