<template>
  <v-dialog
    v-model="isVisible"
    persistent max-width="500"
    content-class="dialog-auto-height"
    @click:outside="$emit('close-popup')"
  >
    <v-card>
      <v-card-title :style="{justifyContent: 'center'}">
        <div class="d-flex justify-space-between align-center">
          <v-icon color="green" :style="{ 'margin-bottom': '-2px', 'margin-right': '6px'}">mdi-email-check</v-icon>
          <h4 class="success-support">Ваше обращение успешно отправлено.</h4>
        </div>
        <h5 class="">Ожидайте ответа на указанный email</h5>
      </v-card-title>
      <v-card-actions class="justify-end">
        <v-btn class="default-btn px-6" color="secondary" @click="$emit('confirm')">Закрыть</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
export default {
  name: 'SuccessRequestModal',
  props: {
    isVisible: {
      type: Boolean,
      require: true,
      default: false
    }
  }
}
</script>

<style scoped>
.success-support {
  color: #00a65a;
  font-weight: 600;
}
.default-btn {
  height: 35px !important;
  width: 110px !important;
  border-radius: 5px !important;
  margin-bottom: 7px;
}
.support-mail-icon {
  margin-bottom: 3px;
  margin-right: 6px;
}
</style>
