<template>
  <v-card class="support-card mt-2">
    <div class="create-support">
      <LoadingComponentVue v-if="loading"/>
    </div>
    <div class="d-flex align-center justify-space-between">
      <v-card-title class="support-title">
        <h5 class="m-1">Сообщение в техническую поддержку</h5>
      </v-card-title>
      <v-tooltip left>
        <template v-slot:activator="{ on }">
          <div class="" v-on="on">
            <v-btn icon dark @click="closeRequest">
              <v-icon color="element">mdi-close</v-icon>
            </v-btn>
          </div>
        </template>
        <span>Закрыть</span>
      </v-tooltip>
    </div>
    <v-card-text class="support-body">
      <v-row>
        <v-col cols="12" md="4" class="pr-0">
          <Email @set-property="$v.editingObj.email.$model = $event" :uid="uid"/>
        </v-col>
        <v-col cols="12" md="8" class="pl-1">
          <UploadScreen @set-property="editingObj.file = $event" @max-weight="$emit('max-weight')"/>
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="12" :md="imageUrl ? 4 : 12" :class="{ 'pr-0': imageUrl }">
          <Comment @set-property="$v.editingObj.comment.$model = $event"/>
        </v-col>
        <v-col v-if="imageUrl" cols="12" md="8" class="pl-1">
          <PreviewScreen :imageUrl="'https://dubna-uszn.ru/wp-content/uploads/2023/04/sa2.jpg'"/>
        </v-col>
      </v-row>
      <p class="my-0"><span class="required-label">*</span> Обязательные поля</p>
      <div class="d-flex justify-space-between align-center">
        <p class="mb-0 form-group__title" :style="{ 'white-space': 'normal !important' }">Ваше обращение будет отправлено в службу поддержки. Вся информация по вопросу будет отправлена на указанный Вами e-mail</p>
        <v-btn color="secondary default-btn" :disabled="invalidData" @click="submit">Отправить</v-btn>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { required, email } from 'vuelidate/lib/validators'
import Email from '../fields-main-info/Email.vue'
import Comment from '../fields-main-info/Comment.vue'
import UploadScreen from '../fields-main-info/UploadScreen.vue'
import PreviewScreen from '@/modules/administration/support/components/fields-main-info/PreviewScreen.vue'
import { CREATE_INCIDENT } from '@/modules/administration/support/services/api'
import { mapState } from 'vuex'

export default {
  components: {
    PreviewScreen,
    Email,
    Comment,
    UploadScreen
  },

  validations: {
    editingObj: {
      email: { required, email },
      comment: { required }
    }
  },
  data: () => ({
    isDirty: false,
    originalObj: {}, // чтобы потом сравнить с ним
    editingObj: {
      email: null,
      comment: null
    },
    uid: 0
  }),

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.fillData())
    }
  },

  computed: {
    invalidData () {
      return this.$v.$invalid
    },
    ...mapState({
      loading: state => state.support.loading,
      file: state => state.support.file,
      imageUrl: state => state.support.imageUrl
    })
  },

  mounted () {
    document.querySelector('.modal-content').parentElement.style.maxWidth = '70%'
    document.querySelector('.modal-content').parentElement.style.maxHeight = '100% !important'
  },

  methods: {
    async submit () {
      const formData = new FormData()
      formData.append('email', this.editingObj.email)
      formData.append('comment', this.editingObj.comment)
      if (this.file) formData.append('file', this.file)
      try {
        await CREATE_INCIDENT(formData)
        this.$emit('sent')
      } catch (err) {
        this.$emit('request-error', err.response.data.error)
      }
    },
    closeRequest () {
      this.$emit('close-request', this.editingObj)
    }
  }
}
</script>

<style lang="scss" scoped>
button {
  border-radius: 6px !important;
}
.create-support {
  position: absolute;
  top: 0;
  width: 100%;
}
.support-title {
  margin-bottom: 0;
  padding-top: 0;
  padding-bottom: 0;
}
.support-body {
  padding-top: 0;
}
.default-btn {
  height: 35px !important;
  width: 110px !important;
  margin-bottom: 7px;
}
</style>
