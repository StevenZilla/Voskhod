<template>
  <div class="form-group">
    <p class="form-group__title">Email<span class="required-label">*</span></p>
    <v-text-field
      v-model="value"
      class="rounded-lg"
      data-qa=""
      outlined
      clearable
      hide-details
      placeholder="Введите e-mail"
      counter="20"
      :maxlength="200"
    ></v-text-field>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),
  computed: {
    ...mapState({
      uid: state => state.support.uid,
      email: state => state.usersStore.userInfo?.email || ''
    })
  },
  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    },
    uid () {
      this.value = ''
      this.value = this.email
    }
  },
  mounted () {
    this.value = this.email
  }
}
</script>

<style lang="scss">

</style>
