<template>
  <div class="form-group" data-qa="support_tf">
    <input
      type="file"
      ref="uploadFile"
      style="display: none"
      accept=".png, .jpg, .jpeg"
      @change="uploadImage"
    />
    <div class="d-flex justify-space-between align-center">
      <p class="form-group__title">Скрин</p>
      <div :style="{ 'font-size': '0.7rem', 'font-weight': 800}">{{ weight }}/10мб</div>
    </div>
    <v-text-field
      v-model="value"
      data-qa="upload-screen"
      class="rounded-lg"
      outlined
      clearable
      hide-details
      placeholder="Выберите файл"
      @change="changeName"
      @click:clear="clearImage"
    >
      <template #append>
        <v-btn
            color="secondary"
            class="upload-support-btn"
            data-qa="support_screen"
            @click="selectImage"
        >Выберите файл...</v-btn>
      </template>
    </v-text-field>
  </div>
</template>

<script>

import { mapState } from 'vuex'

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null,
    imageUrl: null,
    weight: 0
  }),
  computed: { ...mapState({ uid: state => state.support.uid, file: state => state.support.file }) },
  watch: {
    param (newV) {
      if (newV) this.value = newV
      this.$emit('set-property', newV)
    },
    uid () {
      this.clearImage()
    }
  },
  methods: {
    selectImage () {
      this.$refs.uploadFile.click()
    },
    async uploadImage (e) {
      const fileSizeInMB = Math.round(e.target.files[0]?.size / (1024 * 1024) * 100) / 100
      if (fileSizeInMB > 10) {
        this.clearImage()
        this.$emit('max-weight')
        return
      }
      this.weight = fileSizeInMB
      if (e.target.files[0]) {
        this.value = e.target.files[0]?.name || ''
        this.imageUrl = URL.createObjectURL(e.target.files[0])
        this.$store.dispatch('support/SET_VALUE', { key: 'imageUrl', value: this.imageUrl })
        this.$store.dispatch('support/SET_VALUE', { key: 'file', value: e.target.files[0] })
      }
    },
    changeName () {
      this.$store.commit('support/changeFileName', this.value)
    },
    clearImage () {
      this.$refs.uploadFile.value = ''
      this.$store.dispatch('support/SET_VALUE', { key: 'imageUrl', value: '' })
      this.$store.dispatch('support/SET_VALUE', { key: 'file', value: null })
      this.value = null
      this.weight = 0
    }
  }
}
</script>

<style lang="scss" scoped>
.upload-support-btn {
  margin-right: -6px;
  margin-top: -5px !important;
  border-radius: 6px !important;
}
</style>
