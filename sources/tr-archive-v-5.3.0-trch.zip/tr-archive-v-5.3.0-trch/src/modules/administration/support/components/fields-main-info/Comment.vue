<template>
  <div class="form-group">
    <div class="d-flex justify-space-between align-center">
      <p class="form-group__title">Комментарий<span class="required-label">*</span></p>
      <p class="mb-2 comment-support-counter">{{ characterCount }}/1000</p>
    </div>
    <textarea
      placeholder="Комментарий"
      v-model="value"
      :style="{ height: imageUrl ? '':'200px !important'}"
    />
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),
  computed: {
    ...mapState({
      uid: state => state.support.uid,
      imageUrl: state => state.support.imageUrl
    }),
    characterCount () {
      return this.value?.length || 0
    }
  },
  watch: {
    param (newV) {
      if (newV) this.value = newV
    },
    value (newV, oldV) {
      if (newV.length > 1000) {
        this.value = this.value.substring(0, 1000)
      }
      this.$emit('set-property', newV)
    },
    uid () {
      this.value = ''
    }
  }
}
</script>

<style lang="scss" scoped>
textarea {
  border-radius: 5px;
  border: 1px solid #cbcbcd;
  width: 100%;
  outline-color: #cbcbcd;
  min-height: 200px;
  max-height: 600px;
  padding: 8px;
  resize: none;
  @media screen and (max-height: 1220px) {
    height: 500px !important;
  }
  @media screen and (min-height: 1221px) {
    height: 1000px !important;
  }
}
textarea:focus {
  border: 2px solid #cbcbcd;
}
textarea::placeholder {
  color: #cbcbcd;
}
.comment-support-counter {
  font-size: 0.7rem;
  font-weight: 800;
}
</style>
