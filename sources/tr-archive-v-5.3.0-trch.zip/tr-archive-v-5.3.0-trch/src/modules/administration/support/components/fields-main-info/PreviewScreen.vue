<template>
  <div class="preview-support">
    <div class="d-flex justify-space-between align-center">
      <p class="form-group__title">Предпросмотр</p>
      <div class="d-flex justify-space-between align-center">
        <v-icon @click="zoomIn">mdi-plus</v-icon>
        <v-icon @click="zoomOut">mdi-minus</v-icon>
      </div>
    </div>
    <div class="preview-support_screen image-container">
      <img ref="imageContainer"
           class="image-container_self"
           :src="imageSrc" :style="{ '--scale': scale, '--translateX': translateX + 'px', '--translateY': translateY + 'px' }">
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'

export default {
  name: 'PreviewScreen',
  data: () => ({
    scale: 1,
    isDragging: false,
    startX: 0,
    startY: 0,
    translateX: 0,
    translateY: 0,
    imageWidth: 0,
    imageHeight: 0
  }),
  computed: {
    imageSrc () {
      return this.imageUrl
    },
    ...mapState({
      imageUrl: state => state.support.imageUrl
    })
  },
  methods: {
    zoomIn () {
      this.scale += 0.1
      this.adjustImagePosition()
    },
    zoomOut () {
      if (this.scale > 0.2) {
        this.scale -= 0.1
        this.adjustImagePosition()
      }
    },
    adjustImagePosition () {
      const image = this.$refs.imageContainer
      const rect = image.getBoundingClientRect()

      this.translateX = this.translateX - ((rect.width * 0.1) / 2)
      this.translateY = this.translateY - ((rect.height * 0.1) / 2)
    },
    onMouseMove (event) {
      event.preventDefault()
      if (this.isDragging) {
        this.translateX = event.clientX - this.startX
        this.translateY = event.clientY - this.startY
      }
    },
    onMouseUp () {
      if (this.$refs.imageContainer) this.$refs.imageContainer.style.cursor = 'grab'
      this.isDragging = false
      document.removeEventListener('mousemove', this.onMouseMove)
    }
  },
  mounted () {
    this.$refs.imageContainer.addEventListener('mousedown', (event) => {
      event.preventDefault()
      if (this.$refs.imageContainer) this.$refs.imageContainer.style.cursor = 'grabbing'
      this.imageWidth = this.$refs.imageContainer.clientWidth
      this.imageHeight = this.$refs.imageContainer.clientHeight
      this.isDragging = true
      this.startX = event.clientX - this.translateX
      this.startY = event.clientY - this.translateY
      document.addEventListener('mousemove', this.onMouseMove)
      document.addEventListener('mouseup', this.onMouseUp)
    })
  }
}
</script>

<style scoped lang="scss">
  .preview-support {
    height: 100%;
    &_screen {
      border: 1px solid #cbcbcd !important;;
      border-radius: 5px;
      height: 100%;
      box-sizing: border-box;
      @media screen and (max-height: 1220px) {
        max-height: 500px !important;
      }
      @media screen and (min-height: 1221px) {
        height: 1000px !important;
      }
    }
  }
  .image-container {
    cursor: grab;
    overflow: scroll;
    border-right: 7px;
    height: 600px !important;
    margin-left: 1px;
    &_self {
      user-select: none;
      transform: scale(var(--scale)) translate(var(--translateX), var(--translateY));
      transition: transform 0.3s ease;
      --scale: 1;
      --translateX: 0px;
      --translateY: 0px;
    }
  }
</style>
