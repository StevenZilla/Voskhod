<template>
  <div class="create-support">
    <BtnCancelModal :isVisible="isCancelModal" @close="closePopup()" @cancel="isCancelModal=false"/>
    <SuccessRequestModal :isVisible="isSuccessModal" @confirm="closePopup()" @close-popup="closePopup"/>
    <ErrorRequestModal :isVisible="isErrorRequestModal" :errorData=errorData @close="isErrorRequestModal=false" />
    <MaxWeightModal :isVisible="isMaxWeightModal" @close="isMaxWeightModal=false"/>
    <v-dialog
        v-model="isCreate"
        persistent max-width="500"
        content-class="dialog-auto-height"
    >
      <template v-slot:activator="{ on: dialogOn, attrs: dialogAttrs }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on: tooltipOn, attrs: tooltipAttrs }">
            <div
                class="justify-content-end rounded-lg mr-1"
                v-bind="{ ...dialogAttrs, ...tooltipAttrs }"
                v-on="{ ...dialogOn, ...tooltipOn }"
            >
              <v-icon class="mr-1">mdi-headphones</v-icon>
            </div>
          </template>
          <span>Обратиться в поддержку</span>
        </v-tooltip>
      </template>

      <div class="modal-content">
        <CreateMainInfo
          @close-request="checkNotSaveChs"
          @sent="isSuccessModal=true"
          @request-error="isErrorReq($event)"
          @max-weight="isMaxWeightModal=true"
        />
      </div>
    </v-dialog>
  </div>
</template>

<script>

import { mapState } from 'vuex'
import CreateMainInfo from './CreateMainInfo.vue'
import BtnCancelModal from '@/modules/administration/support/components/modal/BtnCancelModal.vue'
import SuccessRequestModal from '@/modules/administration/support/components/modal/SuccessRequestModal.vue'
import ErrorRequestModal from '@/modules/administration/support/components/modal/ErrorRequestModal.vue'
import MaxWeightModal from '@/modules/administration/support/components/modal/MaxWeightModal.vue'
export default {
  name: 'CreateInc',
  components: { MaxWeightModal, ErrorRequestModal, SuccessRequestModal, BtnCancelModal, CreateMainInfo },
  data: () => ({
    trigger: 0,
    isCreate: false,
    invalidMainForm: true,
    loading: false,
    createDetailInfo: {},
    isCancelModal: false,
    isSuccessModal: false,
    isErrorRequestModal: false,
    isMaxWeightModal: false,
    errorData: {}
  }),

  computed: {
    ...mapState({
      imageUrl: state => state.support.imageUrl,
      defaultEmail: state => state.usersStore.userInfo.email
    })
  },
  methods: {
    checkNotSaveChs (editingObj) {
      if (editingObj.comment || (editingObj.email !== this.defaultEmail && editingObj.email) || !!this.imageUrl) {
        this.isCancelModal = true
      } else {
        this.closePopup()
      }
    },
    closePopup () {
      this.isCreate = false
      this.isCancelModal = false
      this.isSuccessModal = false
      this.$emit('clear')
      this.$store.commit('support/incrementUid')
    },
    isErrorReq (evt) {
      this.isErrorRequestModal = true
      this.errorData = evt
    }
  }
}
</script>

<style lang="scss" scoped>
.modal-content{
  background: #fff;
  border-radius: 8px;
  padding: 0;
  box-sizing: border-box;
  overflow: hidden;
}
</style>
