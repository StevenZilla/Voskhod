<template>
  <v-dialog
    v-model="isVisible"
    persistent max-width="500"
    content-class="dialog-auto-height"
    @click:outside="$emit('cancel')"
  >
    <v-card>
      <v-card-title>
        <h4 class="warn">Есть несохраненные данные</h4>
        <h5>Вы уверены, что хотите выйти?</h5>
      </v-card-title>
      <v-card-actions class="justify-end">
        <v-btn class="default-btn" color="secondary" outlined @click="$emit('cancel')">Нет</v-btn>
        <v-btn class="default-btn" color="secondary" @click="$emit('close')">Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
export default {
  name: 'BtnCancelModal',
  props: {
    isVisible: {
      type: Boolean,
      require: true,
      default: false
    }
  }
}
</script>

<style scoped>
.warn {
  color: #F44336;
  font-weight: bold;
  font-size: 1.2rem;
  text-align: center;
  flex-grow: 1;
}
.default-btn {
  height: 35px !important;
  width: 110px !important;
  border-radius: 5px;
  margin-bottom: 7px;
}
</style>
