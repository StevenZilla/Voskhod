<template>
  <TemplatePage>
    <template #title>Обращения в ТП</template>

    <template #content>
      <div class="d-flex justify-space-between align-center">
        <SearchPanel
          @set-filters="acceptFilters($event)"
          @refresh-data="refreshData"
        />
      </div>
      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
      </div>

      <v-data-table
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        item-key="id"
        class="main-table scroll-table sortable-table row-default-cursor"
        hide-default-footer
        :style="{cursor: 'default'}"
        :headers="headersList"
        :options.sync="options"
        :items="supportResponse.support_massage"
        :loading="loading"
        :items-per-page="itemsPerPage"
        :page.sync="page"
        :server-items-length="supportResponse.count"
        :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
        @page-count="pageCount = $event"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>
        <template v-slot:item.create_date="{item}">
          <span v-if="item.create_date">{{ $_formatDate(item.create_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>
        <template v-slot:item.comment="{item}">
          <div class="d-flex">
            <v-tooltip top>
              <template v-slot:activator="{ on }">
              <span class="" v-on="on">
               <v-icon class="mr-3" :color="item.is_sent ? 'success' : 'warning'">
                  mdi-{{ item.is_sent ? 'check-circle-outline' : 'backup-restore' }}
               </v-icon>
              </span>
              </template>
              <span>{{ item.is_sent ? 'Отправлено' : 'Ожидает отправки' }}</span>
            </v-tooltip>
            <v-card flat max-height="200px" max-width="550px" class="overflow-auto">
              <v-card-text style="word-wrap: break-word;" v-html="formatMultilineString(item.comment)"></v-card-text>
            </v-card>
          </div>
        </template>
        <template v-slot:item.user="{item}">
          <div>
            {{ item.user.fio }}
          </div>
        </template>
        <template v-slot:item.send_date="{item}">
          <span v-if="item.send_date">{{ $_formatDate(item.create_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>
        <template v-slot:item.url="{item}">
          <div v-if="item.url">
            <v-btn
                color="secondary"
                class="mr-1 rounded-lg"
                icon
                :ripple="false"
                @click="DOWNLOAD_SCREEN(item.url)"
            ><v-icon color="secondary">mdi-download-circle-outline</v-icon>
            </v-btn>
          </div>
        </template>

        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_SUPPORT_RESPONSE } from '../services/api'
import { mapState } from 'vuex'
import { format } from 'date-fns'

import SearchPanel from '../components/SearchPanel.vue'
import TemplatePage from '@/components/TemplatePage.vue'
import api from '@/services/api'

export default {
  name: 'EventsPage',
  components: {
    TemplatePage,
    SearchPanel
  },
  data: () => ({
    format,
    supportResponse: {},
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [],
    headersList: [
      {
        text: '№',
        value: 'id',
        width: '5%'
      },
      {
        text: 'Дата и время создания',
        value: 'create_date',
        width: '15%'
      },
      {
        text: 'Описание',
        value: 'comment',
        width: '50%'
      },
      {
        text: 'Дата и время отправки',
        value: 'send_date',
        width: '10%'
      },
      {
        text: 'Пользователь',
        value: 'user',
        width: '10%'
      },
      {
        text: 'Email',
        value: 'email',
        width: '10%'
      },
      {
        text: '',
        value: 'url',
        width: '10px',
        sortable: false
      }
    ]
  }),
  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          if (!newV.sortBy.length) newV.sortBy[0] = oldV.sortBy[0]
          GET_SUPPORT_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.supportResponse = resp })
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      loading: state => state.support.loading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.supportResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    refreshData (evt) {
      GET_SUPPORT_RESPONSE().then(resp => { this.supportResponse = resp })
      this.showDetail(evt)
      this.clearForm++
    },

    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      await GET_SUPPORT_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.supportResponse = resp })
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-event', params: { id: _id } })
    },

    formatMultilineString (str) {
      return str.replaceAll('\n', '<br>')
    },

    async DOWNLOAD_SCREEN (url) {
      try {
        const response = await api.get(url, { responseType: 'blob' })
        const blob = await response.data
        const downloadUrl = window.URL.createObjectURL(blob)
        const link = document.createElement('a')

        link.href = downloadUrl
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      } catch (err) {
        console.log(err)
      }
    }
  },

  mounted () {
    GET_SUPPORT_RESPONSE().then(resp => { this.supportResponse = resp })
  }
}
</script>

<style lang="scss">

</style>
