<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewEventsInfo/>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DETAIL_EVENT } from '../services/api'

import ViewEventsInfo from '../components/view-info/ViewEventsInfo.vue'

import { mapState } from 'vuex'

export default {
  name: 'DetailEvent',

  components: {
    ViewEventsInfo
  },

  beforeRouteUpdate (to, from, next) {
    this.getData()
    next()
  },

  data: () => ({
    loading: true
  }),

  computed: {
    ...mapState({
      error: state => state.error
    })
  },

  async mounted () {
    await this.getData()
  },

  methods: {
    async getData () {
      this.loading = true
      try {
        await GET_DETAIL_EVENT(this.$route.params.id)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
