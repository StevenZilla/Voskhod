<template>
  <TemplatePage>
    <template #title>Журнал событий</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @refresh-data="refreshData"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
      </div>

      <v-data-table
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        item-key="id"
        class="main-table scroll-table sortable-table"
        hide-default-footer
        :headers="headersList"
        :options.sync="options"
        :items="eventsResponse.audits"
        :loading="eventsLoading"
        :items-per-page="itemsPerPage"
        :page.sync="page"
        :server-items-length="eventsResponse.count"
        :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
        @page-count="pageCount = $event"
        @click:row="showDetail"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.descr="{ item }">
          <div v-if="item.is_success !== null">
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
              <span
                class="d-flex align-center"
                v-bind="attrs"
                v-on="on"
              >
                <v-icon class="mr-3" :color="item.is_success ? 'success' : 'error'">
                  mdi-{{ item.is_success ? 'check' : 'close' }}-circle-outline
                </v-icon>
                <span>{{ item.descr }}</span>
              </span>
              </template>
              <span>{{ item.is_success ? 'Успешно' : 'Не успешно' }}</span>
            </v-tooltip>
          </div>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.date="{item}">
          <span v-if="item.date">{{ $_formatDate(item.date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.subject_name="{ item }">
          <span v-if="item.resource_metadata.subject.subject_name">{{ item.resource_metadata.subject.subject_name }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.object_id="{ item }">
          <span v-if="item.resource_metadata.object[0].object_id">{{ item.resource_metadata.object[0].object_id }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.object_name="{ item }">
          <span v-if="item.resource_metadata.object[0].object_name">{{ item.resource_metadata.object[0].object_name }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.category="{ item }">
          <span v-if="item.category">{{ item.category.name }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_EVENTS_RESPONSE } from '../services/api'
import { mapState } from 'vuex'
import { format } from 'date-fns'

import SearchPanel from '../components/SearchPanel.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'EventsPage',
  components: {
    TemplatePage,
    SearchPanel
  },
  data: () => ({
    format,
    eventsResponse: {},
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [], // это нужно в дальнейшем вдруг настройка столбцов
    headersList: [
      {
        text: '№',
        sortable: false,
        value: 'id',
        width: '64px'
      },
      {
        text: 'ID объекта',
        value: 'object_id',
        width: '150px'
      },
      {
        text: 'Дата и время',
        value: 'date',
        width: '180px'
      },
      {
        text: 'Тип',
        value: 'type.name',
        width: '100px'
      },
      {
        text: 'Описание',
        value: 'descr',
        width: '550px'
      },
      {
        text: 'Пользователь',
        value: 'subject_name',
        width: '300px'
      },
      {
        text: 'Компонента',
        value: 'category',
        sortable: false,
        width: '200px'
      }
    ]
  }),
  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          GET_EVENTS_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.eventsResponse = resp })
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      eventsLoading: state => state.events.eventsLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.eventsResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('type.name') !== -1) {
            par += 'type_name'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    refreshData (evt) {
      GET_EVENTS_RESPONSE().then(resp => { this.eventsResponse = resp })
      this.showDetail(evt)
      this.clearForm++
    },

    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      await GET_EVENTS_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.eventsResponse = resp })
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-event', params: { id: _id } })
    }
  },

  mounted () {
    GET_EVENTS_RESPONSE().then(resp => { this.eventsResponse = resp })
  }
}
</script>

<style lang="scss">

</style>
