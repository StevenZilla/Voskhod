import api from '@/services/api'
import store from '@/storages'
import mixin from '@/utils/mixins'

export async function GET_EVENTS_RESPONSE (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('events/SET_VALUE', { key: 'eventsLoading', value: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/v2/ead/events', { params: searchParams })
    return resp.data
  } catch (e) {
    console.log(e)
    throw (e)
  } finally {
    store.dispatch('events/SET_VALUE', { key: 'eventsLoading', value: false })
  }
}

export async function GET_EVENTS_TYPES () {
  const res = await api.get('/v2/ead/event_types')
  return res.data.map(item => ({ text: item.name, value: item.id }))
}

export async function GET_DETAIL_EVENT (id) {
  try {
    const resp = await api.get(`v2/ead/events/${id}`)
    store.dispatch('events/SET_VALUE', { key: 'detailEvent', value: resp.data })
  } catch (error) {
    console.log(error.response)
    throw (error)
  }
}
