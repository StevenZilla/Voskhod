export default {
  namespaced: true,
  state: {
    eventsTypesList: [],
    eventsResponse: null,
    eventsLoading: true,
    eventsObject: null,
    detailEvent: {}
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  }
}
