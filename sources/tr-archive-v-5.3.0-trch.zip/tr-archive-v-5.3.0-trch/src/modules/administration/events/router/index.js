import { administration, eventDetail, events } from '@/permissions'
const EventsPage = () => import(/* webpackChunkName: 'events-page' */ '../views/EventsPage.vue')
const DetailEvent = () => import(/* webpackChunkName: 'detail-event' */ '../views/DetailEvent')

const eventsRouter = [
  {
    name: 'EventsPageVue',
    path: events.path,
    component: EventsPage,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Журнал событий'
        }
      ],
      tech_name: administration.code
    }
  },
  {
    name: 'detail-event',
    path: `${eventDetail.path}/:id`,
    component: DetailEvent,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Журнал событий',
          to: events.path,
          exact: true
        },
        {
          text: 'Просмотр события'
        }
      ],
      parent: events.path,
      tech_name: administration.code
    }
  }
]

export default router => {
  router.addRoutes(eventsRouter)
}
