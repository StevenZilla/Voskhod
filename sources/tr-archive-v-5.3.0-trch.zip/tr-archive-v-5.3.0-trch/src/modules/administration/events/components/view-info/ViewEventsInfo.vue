<template>
  <div class="card">
    <ViewMainInfo/>

    <TemplateButtons>
      <template #buttons-right>
        <v-btn
          data-qa="close"
          color="secondary"
          class="rounded-lg"
          @click="$_closeDetail()"
        >
          Закрыть
        </v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

const ViewMainInfo = () => import('./ViewMainInfo.vue')

export default {
  name: 'ViewEventsInfo',

  components: {
    ViewMainInfo
  }
}
</script>

<style>

</style>
