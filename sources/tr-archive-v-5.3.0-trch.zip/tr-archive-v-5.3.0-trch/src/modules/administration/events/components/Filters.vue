<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <EventDate
        class="w-20"
        ref="eventDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EventType
        class="w-20"
        ref="eventType"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <EventUser
        class="w-20"
        ref="eventUser"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <EventResult
        class="w-20"
        ref="isSuccess"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EventId
        class="w-20"
        ref="objectId"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EventNameSpace
        class="w-20"
        ref="namespaceCode"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import EventDate from '@/components/Filters/Fields/Event/EventDate.vue'
import EventType from '@/components/Filters/Fields/Event/EventType.vue'
import EventUser from '@/components/Filters/Fields/Event/EventUser.vue'
import EventResult from '@/components/Filters/Fields/Event/EventResult.vue'
import EventId from '@/components/Filters/Fields/Event/EventId.vue'
import EventNameSpace from '@/components/Filters/Fields/Event/EventNameSpace.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

export default {
  name: 'Filters',
  components: {
    ChipsFilters,
    EventDate,
    EventType,
    EventUser,
    EventResult,
    EventId,
    EventNameSpace,
    FilterFooter,
    FiltersTemplate
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.eventDate) {
        paramsFilter.append('start_date', this.filterObj.eventDate.query[0])
        paramsFilter.append('end_date', this.filterObj.eventDate.query[1])
        chips.push(this.filterObj.eventDate)
      }
      if (this.filterObj.eventType) {
        paramsFilter.append('type_id', this.filterObj.eventType.query.value)
        chips.push(this.filterObj.eventType)
      }
      if (this.filterObj.eventUser) {
        paramsFilter.append('user_id', this.filterObj.eventUser.query.value)
        chips.push(this.filterObj.eventUser)
      }

      if (this.filterObj.isSuccess) {
        paramsFilter.append('is_success', this.filterObj.isSuccess.query.value)
        chips.push(this.filterObj.isSuccess)
      }

      if (this.filterObj.objectId) {
        paramsFilter.append('object_id', this.filterObj.objectId.query)
        chips.push(this.filterObj.objectId)
      }

      if (this.filterObj.namespaceCode) {
        paramsFilter.append('namespace_code', this.filterObj.namespaceCode.query.value)
        chips.push(this.filterObj.namespaceCode)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.searchTouch = false
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
