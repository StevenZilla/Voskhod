<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2>Общая информация</h2>
      <v-icon
        icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >mdi-chevron-down
      </v-icon>
    </v-card-title>

    <v-card-text class="detail__view-inner item-3" :class="{open: isMainInfo}">
      <div class="detail__item">
        <p class="detail__item-title">Дата и время</p>
        <span class="detail__value">{{ $_formatDate(detailEvent.date, 'time') }}</span>
      </div>

      <div class="detail__item">
        <p class="detail__item-title">Тип</p>
        <span class="detail__value">{{ detailEvent.type.name }}</span>
      </div>

      <div class="detail__item">
        <p class="detail__item-title">Описание</p>
        <v-icon class="mr-1" :color="detailEvent.is_success ? 'success' : 'error'">
          mdi-{{ detailEvent.is_success ? 'check' : 'close' }}-circle-outline
        </v-icon>
        <span
          v-html="linkObject"
          class="detail__value"
          @click.capture="showDetail"
        ></span>
      </div>

      <div class="detail__item">
        <p class="detail__item-title">Пользователь</p>
        <span v-if="!detailEvent.resource_metadata.subject.subject_id" class="detail__value">{{ detailEvent.resource_metadata.subject.subject_name }}</span>
        <span
          v-else
          class="detail__value active-link"
          style="cursor: pointer"
          :data-link="createDataAttr(detailEvent.resource_metadata.subject.subject_code, detailEvent.resource_metadata.subject.subject_id)"
          @click="showDetail"
        >{{ detailEvent.resource_metadata.subject.subject_name }}</span>
      </div>

      <div class="detail__item">
        <p class="detail__item-title">Компонента</p>
        <span
          v-if="detailEvent.category"
          class="detail__value d-block mb-1"
        >{{ detailEvent.category.name }}</span>
<!--        active-link-->
<!--        style="cursor: pointer"-->
<!--        :data-link="createDataAttr(detailEvent.category.code, detailEvent.category.id)"-->
<!--        @click="showDetail"-->
        <span v-else>{{'Нет данных'}}</span>
      </div>
      <br>
    </v-card-text>
  </v-card>
</template>

<script>

import { format } from 'date-fns'
import { mapState } from 'vuex'

export default {
  name: 'ViewMainInfo',
  data: () => ({
    format,
    linkObject: '',
    isMainInfo: true
  }),

  computed: {
    ...mapState({
      detailEvent: state => state.events.detailEvent
    })
  },

  created () {
    this.convertTemplate()
  },

  methods: {
    showDetail (e) {
      const evt = e.target.dataset.link
      this.$router.push({ path: evt })
    },

    createDataAttr (code, id) {
      const _code = code.replace('obj:', '').replace('sub:', '')
      const itemRoute = this.$router.getRoutes().find(route => route.meta.code === _code)
      if (!itemRoute) return ''
      return id ? `${itemRoute.path.replace(':id', id)}` : itemRoute.meta.parent
    },

    getSpan (text, code, id) {
      return `<span
                class="active-link"
                style="cursor: pointer"
                data-link="${this.createDataAttr(code, id)}"
              >${text}</span>`
    },

    /* getRegex (code) {
      return new RegExp(`^(${code}:*)$`, 'g')
      return '/(' + code + ':\w+)/g'
    }, */

    convertTemplate () {
      const subject = this.detailEvent.resource_metadata.subject
      const subRegex = /(sub:\w+)/g
      const objRegex = /(obj:\w*)/g
      let count = 0
      this.linkObject = this.detailEvent.template.replace(subRegex, this.getSpan(subject.subject_name, subject.subject_code, subject.subject_id))
      this.linkObject = this.linkObject.replace(objRegex, (match) => {
        const object = this.detailEvent.resource_metadata.object[count]
        match = this.getSpan(object.object_name, object.object_code, object.object_id)
        count++
        return match
      })
    }
  }
}
</script>

<style>

</style>
