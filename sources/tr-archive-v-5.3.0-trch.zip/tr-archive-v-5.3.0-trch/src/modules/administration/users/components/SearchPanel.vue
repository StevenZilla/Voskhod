<template>
  <div class="panel-search">
    <div class="d-flex justify-space-between align-center">
      <v-text-field
        v-model="filterObj.fio"
        class="main-field"
        data-qa="main-field"
        placeholder="Введите ФИО пользователя"
        solo
        outlined
        rounded
        clearable
        hide-details
        flat
        @click:clear="filterObj.fio = null, acceptFilters()"
        @keyup.enter="trigger++"
      >
        <template v-slot:append-outer>
          <v-btn
          class="rounded-xl ml-8 bg-white"
            outlined
            icon
            color="secondary"
            data-qa="filter"
            @click="toggleFilter()"
          >
            <v-icon>mdi-tune-vertical-variant</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
            v-if="filterObj.fio"
            class="find-link secondary--text"
            @click="acceptFilters()"
            >Найти
          </span>
        </template>

        <template v-slot:prepend-inner>
          <v-btn
            plain
            icon
            @click="acceptFilters()"
            color="secondary"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>
      </v-text-field>

      <CreateUser
        @refresh-data="$emit('refresh-data', $event)"
      />
    </div>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      :is-load="isLoad"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />
  </div>
</template>

<script>

import CreateUser from './create-info/CreateUser.vue'

const Filters = () => import('./Filters.vue')

export default {
  name: 'SearchPanel',

  components: {
    CreateUser,
    Filters
  },

  data: () => ({
    trigger: 0,
    fullFilter: false,
    isLoad: false,
    chipsList: [],
    filterObj: {
      fio: ''
    }
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.fio) {
        paramsFilter.append('fio', this.filterObj.fio)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt ? evt.filter : undefined)
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    clearFilters () {
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
