<template>
  <v-card data-qa="block-subdivisions-user-view" class="detail__additional-info mt-10">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Подразделения</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit"
          data-qa="subdivisions-edit-view"
          class="circle circle__btn circle--white"
          icon
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-else>
          <div class="d-flex">
            <BtnIconSaveSlot
              :disabled="invalidData"
              :loading="loading"
              @save="updateHandler"
            />
            <div class="mr-3"></div>

            <BtnIconCancelSlot
              :loading="loading"
              @close="isEdit = false"
            />
          </div>
        </template>
      </div>
    </v-card-title>

    <v-card-text class="no-bg">
      <EditingSubdivisions
        v-if="isEdit"
        :headers="headers"
        :trigger="trigger"
        :select-elem="subdivisionsList.subdivisions"
        @change-valid="invalidData = $event"
        @fill-data="fillData($event)"
      />

      <div class="detail-wrapper" v-else>
        <v-data-table
          disable-sort
          item-key="id"
          no-data-text="Нет данных"
          class="main-table"
          hide-default-footer
          :headers="headers"
          :items="subdivisionsList?.subdivisions"
          @click:row="showDetail($event)"
        >
          <!-- eslint-disable-next-line -->
          <template v-slot:item.id="{index}">
            {{ index + 1 }}
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.start_date="{item}">
            <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
            <span v-else style="color:#CBCBCD">Нет данных</span>
          </template>

        <!-- eslint-disable-next-line -->
          <template v-slot:item.end_date="{item}">
            <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
            <span v-else style="color:#CBCBCD">Нет данных</span>
          </template>
        </v-data-table>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'
import { format } from 'date-fns'
// import { GET_SUBDIVISIONS_RESPONSE } from '../services/api'
import { GET_DETAIL_USER, GET_USER_SUBDIVISINS, CREATE_USER_SUBDIVISINS } from '@/modules/administration/users/services/api'

const EditingSubdivisions = () => import('../editing-info/EditingSubdivisions.vue')
const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'ViewSubdivisionsUser',

  components: {
    EditingSubdivisions,
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  data: () => ({
    format,
    trigger: 0,
    isEdit: false,
    loading: false,
    invalidData: false,
    subdivisionsList: null,
    newSubdivisions: null,
    headers: [
      {
        text: '№',
        align: 'start',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '765px'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '400px'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '400px'
      },
      {
        value: 'actions',
        width: '50px'
      }
    ]
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    id () {
      return this.GET_USER_KEY('id')
    }
  },

  watch: {
    async id (newV) {
      if (newV) {
        await this.getData()
      }
    }
  },

  methods: {
    async getData () {
      this.loading = true
      this.subdivisionsList = await GET_USER_SUBDIVISINS(this.id)
      this.loading = false
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        this.newSubdivisions = evt
        resolve()
      })
    },

    async updateHandler () {
      this.loading = true
      this.trigger++
      await this.fillData()
      try {
        await CREATE_USER_SUBDIVISINS(this.id, this.newSubdivisions)
        await GET_DETAIL_USER(this.id)
        await this.getData()
        this.isEdit = false
      } catch (error) {
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
