<template>
  <div>
    <v-card>
      <v-card-title>
        <h2>Общая информация</h2>
      </v-card-title>

      <v-card-text class="d-flex flex-wrap item-5">
        <slot name="fio"></slot>
        <slot name="login"></slot>
        <slot name="email"></slot>
        <slot name="update-date"></slot>
        <slot name="log-date"></slot>
        <slot name="2fa"></slot>
        <slot name="block"></slot>
        <slot name="oid_esia"></slot>
      </v-card-text>
    </v-card>

    <ResetPassword/>
  </div>
</template>

<script>

import ResetPassword from '../ResetPassword.vue'

export default {
  name: 'ViewMainInfo',
  components: { ResetPassword },

  data: () => ({
    isResetPassword: false
  })
}

</script>

<style></style>
