<template>
  <div class="form-group">
    <p class="form-group__title">Окончание действия</p>
    <date-range-picker
        v-model="dateRangeMix.end"
        opens="right"
        show-dropdowns
        single-date-picker
        auto-apply
        :ranges="false"
        :min-date="param"
        :locale-data="localeSettings"
        @toggle="$_setBeginDate($event, [value], 'end')"
        @update="setDate($event)"
    >
      <template #input>
        <v-text-field
            data-qa="end-date-user-create"
            class="rounded-lg"
            readonly
            outlined
            placeholder="дд.мм.гггг"
            append-icon="mdi-calendar-blank"
            :value="$_formatDate(value)"
        ></v-text-field>
      </template>
    </date-range-picker>
  </div>
</template>

<script>

import { format } from 'date-fns'

export default {
  props: {
    param: {
      type: String,
      required: false
    }
  },

  data: () => ({
    value: format(new Date(), 'yyyy-MM-dd')
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.$emit('set-property', this.value)
  },

  methods: {
    setDate (date) {
      this.value = this.$_setDate(date, 'date')
      this.$emit('set-property', this.value)
    }
  }
}
</script>

<style lang="scss">

</style>
