<template>
  <div class="detail-flex">
    <v-checkbox
      v-model="editObj.is_block"
      hide-details
      color="secondary"
      v-ripple
    ></v-checkbox>

    <EditingBtn
      :disabled="editObj.is_block === isBlock"
      :value="editObj"
      @change-mode="$emit('change-mode')"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  components: {
    EditingBtn
  },

  data: () => ({
    editObj: {
      is_block: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    isBlock () {
      return this.GET_USER_KEY('is_block')
    }
  },

  mounted () {
    this.editObj.is_block = this.isBlock
  }
}
</script>

<style>

</style>
