<template>
  <div class="detail__item">
    <p class="detail__item-title">ФИО пользователя</p>
    <EditingFio
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <span data-qa="fio-user-view" class="detail__value">{{ fio }}</span>
      <v-btn class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingFio = () => import('../editing-info/EditingFio.vue')
export default {
  components: {
    EditingFio
  },

  data: () => ({
    isEdit: false
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    fio () {
      return this.GET_USER_KEY('fio')
    }
  }
}
</script>

<style lang="scss">

</style>
