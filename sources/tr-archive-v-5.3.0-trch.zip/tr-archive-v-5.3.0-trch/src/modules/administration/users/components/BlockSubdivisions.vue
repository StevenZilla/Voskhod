<template>
  <v-card class="detail__additional-info mt-10">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Подразделения</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit"
          class="circle circle__btn circle--white"
          icon
          :disabled="loading"
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-else>
          <div class="d-flex">
            <v-btn
              data-qa="access-close-view"
              class="circle circle__btn circle--white"
              icon
              @click="isEdit = false"
            >
              <v-icon color="secondary">mdi-close</v-icon>
            </v-btn>
          </div>
        </template>
      </div>
    </v-card-title>

    <v-card-text class="no-bg">
      <div class="detail-wrapper">
        <v-data-table
          disable-sort
          item-key="id"
          no-data-text="Нет данных"
          loading-text="Загрузка"
          class="main-table"
          hide-default-footer
          :loading="loading"
          :headers="headers"
          :items="subdivisions"
        >
          <template #progress>
            <v-progress-linear
              indeterminate
              height="5"
              color="secondary"
            ></v-progress-linear>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.id="{index}">
            {{ index + 1 }}
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.name="{ item }">
            <v-select
              v-if="isEdit"
              v-model="item.currentSubdivision"
              data-qa="subdivision-list"
              return-object
              class="rounded-lg"
              outlined
              item-text="name"
              item-value="id"
              item-disabled="select"
              hide-details
              :disabled="!item.pk"
              :filled="!item.pk"
              :items="subdivisionsList"
            ></v-select>

            <span v-else>{{ item.name }}</span>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.start_date="{item}">
            <date-range-picker
              v-if="isEdit"
              v-model="dateRangeMix.start"
              style="width: 100%"
              opens="right"
              show-dropdowns
              time-picker-seconds
              time-picker
              single-date-picker
              :ranges="false"
              :min-date="todayMix"
              :max-date="item.end_date"
              :time-picker-increment="1"
              :locale-data="localeSettings"
              @toggle="$_setBeginDate($event, [item.start_date], 'start')"
              @update="item.start_date = $_setDate($event, 'time')"
            >
              <template #input>
                <v-text-field
                  class="rounded-lg"
                  readonly
                  outlined
                  hide-details
                  placeholder="дд.мм.гггг"
                  append-icon="mdi-calendar-blank"
                  :value="$_formatDate(item.start_date, 'time')"
                ></v-text-field>
              </template>

              <div slot="footer" slot-scope="data" class="slot">
                <DatePickerActions @cancel="data.clickCancel" @apply="data.clickApply"/>
              </div>
            </date-range-picker>

            <span v-else>{{ $_formatDate(item.start_date, 'time') }}</span>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.end_date="{item}">
            <date-range-picker
              v-if="isEdit"
              v-model="dateRangeMix.end"
              style="width: 100%"
              opens="right"
              show-dropdowns
              time-picker-seconds
              time-picker
              single-date-picker
              :ranges="false"
              :min-date="item.start_date"
              :time-picker-increment="1"
              :locale-data="localeSettings"
              @toggle="$_setBeginDate($event, [item.end_date], 'end')"
              @update="item.end_date = $_setDate($event, 'time')"
            >
              <template #input>
                <v-text-field
                  class="rounded-lg"
                  readonly
                  outlined
                  hide-details
                  placeholder="дд.мм.гггг"
                  append-icon="mdi-calendar-blank"
                  :value="$_formatDate(item.end_date, 'time')"
                ></v-text-field>
              </template>

              <div slot="footer" slot-scope="data" class="slot">
                <DatePickerActions @cancel="data.clickCancel" @apply="data.clickApply"/>
              </div>
            </date-range-picker>

            <span v-else>{{ $_formatDate(item.end_date, 'time') }}</span>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.actions="{ item }">
            <div v-if="isEdit" class="d-flex">
              <v-btn
                color="secondary"
                class="circle circle__btn circle--white"
                icon
                outlined
                :disabled="!item.currentSubdivision"
                @click="setDivision(item)"
              ><v-icon>mdi-check</v-icon>
              </v-btn>

              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                @click="deleteSubdivision(item)"
              ><v-icon>mdi-delete-outline</v-icon>
              </v-btn>
            </div>
          </template>

          <template #footer>
            <div v-if="isEdit" class="detail__buttons detail__buttons-border">
              <v-btn
                outlined
                color="secondary"
                class="ml-4 mb-0 rounded-lg"
                :disabled="disableAddSubdivision"
                @click="addSubdivision"
              >
                <v-icon class="mr-1">mdi-plus</v-icon>
                Добавить подразделение
              </v-btn>
            </div>
          </template>
        </v-data-table>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import {
  DELETE_DIVISION,
  DELETE_ORGANIZATION,
  GET_USER_SUBDIVISIONS, SET_ORGANIZATION, UPDATE_DIVISION
} from '@/modules/administration/users/services/api'
import { GET_SUBDIVISIONS_RESPONSE } from '@/modules/nsi/submodules/subdivisions/services/api'

export default {
  name: 'BlockSubdivisions',

  data: () => ({
    isEdit: false,
    loading: false,
    subdivisions: [],
    pk: -1,
    copyData: [],
    subdivisionsList: [],
    headers: [
      {
        text: '№',
        align: 'start',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '765px'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '400px'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '400px'
      },
      {
        value: 'actions',
        width: '50px'
      }
    ]
  }),

  computed: {
    ...mapState({
      subdivisionsResponse: (state) => state.nsi.subdivisions.subdivisionsResponse
    }),

    ...mapGetters('users', ['GET_USER_KEY']),

    id () {
      return this.GET_USER_KEY('id')
    },

    disableAddSubdivision () {
      return this.subdivisions.some(subdivision => subdivision.currentSubdivision?.name === 'Все подразделения')
    }
  },

  watch: {
    subdivisions: {
      handler () {
        if (!this.isEdit) return

        this.subdivisionsList.forEach(item => {
          const selectSubdivisions = this.subdivisions.find(i => item.id === i.currentSubdivision.id)
          item.select = selectSubdivisions !== undefined
        })
      },

      deep: true
    },

    async isEdit (newV) {
      if (newV) await this.prepareData()
      else {
        this.subdivisions = [...this.copyData]
      }
      this.$emit('update-editing', newV)
    },

    id: {
      handler (newV) {
        if (newV) this.getData()
      },
      immediate: true
    }
  },

  methods: {
    async prepareData () {
      this.loading = true
      await GET_SUBDIVISIONS_RESPONSE()
      this.subdivisionsList = this.subdivisionsResponse.subdivisions
      this.replaceName(this.subdivisionsList)
      this.copyData = [...this.subdivisions]
      this.subdivisions = this.subdivisions.map(item => {
        return {
          currentSubdivision: item,
          start_date: item.start_date,
          end_date: item.start_date
        }
      })
      this.loading = false
    },

    replaceName (list) {
      const org = list.find(item => item.is_org)
      if (org) org.name = 'Все подразделения'
    },

    addSubdivision () {
      this.$set(this.subdivisions, this.subdivisions.length, {
        currentSubdivision: {},
        pk: this.pk,
        start_date: new Date(),
        end_date: new Date(2999, 0, 1, 0, 0, 0)
      })
      this.pk--
    },

    getData () {
      this.loading = true
      GET_USER_SUBDIVISIONS(this.id).then(resp => {
        this.subdivisions = resp.subdivisions
        this.replaceName(this.subdivisions)
        this.loading = false
      })
    },

    removeEditSubdivision (division) {
      const idxSubdivision = this.subdivisions.findIndex(item => item.pk === division.pk)
      this.$delete(this.subdivisions, idxSubdivision)
    },

    async deleteSubdivision (division) {
      this.loading = true

      if (division.pk) this.removeEditSubdivision(division)

      const obj = {
        start_date: division.start_date,
        end_date: division.end_date
      }

      try {
        if (division.currentSubdivision.is_org && division.pk) {
          obj.subdivision_id = division.currentSubdivision.id
          await DELETE_ORGANIZATION(this.id, obj)
        } else {
          await DELETE_DIVISION(this.id, division.currentSubdivision.id, obj)
        }
        const idxDivision = this.copyData.findIndex(item => item.id === division.currentSubdivision.id)
        this.copyData.splice(idxDivision, 1)
        this.isEdit = false
      } catch (err) {
        console.log(err)
      } finally {
        this.loading = false
      }
    },

    async setDivision (division) {
      this.loading = true

      let obj = {
        start_date: division.start_date,
        end_date: division.end_date
      }

      try {
        if (division.pk) {
          obj.subdivision_id = division.currentSubdivision.id
          await SET_ORGANIZATION(this.id, obj)
          obj = Object.assign(division.currentSubdivision, obj)
          this.copyData.push(obj)
        } else {
          await UPDATE_DIVISION(this.id, division.currentSubdivision.id, obj)
          const idxDivision = this.copyData.findIndex(item => item.id === division.currentSubdivision.id)
          obj = Object.assign(division.currentSubdivision, obj)
          this.copyData[idxDivision] = obj
        }
        this.isEdit = false
      } catch (err) {
        console.log(err)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
