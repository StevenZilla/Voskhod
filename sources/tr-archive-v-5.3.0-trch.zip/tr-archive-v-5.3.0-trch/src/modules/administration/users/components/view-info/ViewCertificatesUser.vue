<template>
  <v-card data-qa="block-sert-user-view" class="detail__additional-info mt-10">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Сертификаты</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit"
          data-qa="sert-edit-view"
          class="circle circle__btn circle--white"
          icon
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-else>
          <div class="d-flex">
            <BtnIconSaveSlot
              :loading="loading"
              :disabled="checkSettings.is_required_mchd_sert_user_assign ? invalidData : false"
              @save="updateHandler"
            />
            <!-- Чтобы сделать отступ -->

            <div class="mr-3"></div>

            <BtnIconCancelSlot
              :loading="loading"
              @close="isEdit = false"
            />
          </div>
        </template>
      </div>
    </v-card-title>

    <v-card-text class="no-bg">
      <EditingCertificates
        v-if="isEdit"
        :headers="headers"
        :trigger="trigger"
        @change-valid="invalidData = $event"
        @fill-data="fillData($event)"
      />

      <div class="detail-wrapper" v-else>
          <v-data-table
            disable-sort
            item-key="id"
            no-data-text="Нет данных"
            class="main-table no-hover"
            hide-default-footer
            :headers="headers"
            :items="GET_USER_CERTIFICATES"
          >
            <template v-slot:item.id="{ index }">
              {{ index + 1 }}
            </template>

            <template v-slot:item.use="{ item }">
                    <span v-for="(use, idx) in item.use" :key="idx">{{
                        use.value
                      }}{{ item.use.length - 1 > idx ? ', ' : '' }}</span>
            </template>

            <template v-slot:item.start_date="{item}">
              <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <template v-slot:item.end_date="{item}">
              <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <template v-slot:item.mchd="{ item }">
              <div v-if="item.mchd" class="d-flex align-center">
                <v-btn
                  class="ml-3 rounded-lg"
                  color="secondary"
                  icon
                  title="Скачать файл"
                  @click.stop="$_downloadFile(item.mchd.url)"
                >
                  <v-icon
                    color="secondary">
                    mdi-download-circle-outline
                  </v-icon>
                </v-btn>
                <div>
                  <span class="subtext">
                    Срок действия:
                  </span>
                  <span class="subtext">
                    {{ $_formatDate(item.mchd.start_date) }}
                    <br>
                    -
                    {{ $_formatDate(item.mchd.end_date) }}
                  </span>
                </div>
              </div>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>
          </v-data-table>
        </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import { GET_DETAIL_USER, UPDATE_CERTIFICATE } from '@/modules/administration/users/services/api'

const EditingCertificates = () => import('../editing-info/EditingCertificates.vue')
const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'ViewCertificatesUser',

  components: {
    EditingCertificates,
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  data: () => ({
    trigger: 0,
    isEdit: false,
    loading: false,
    invalidData: false, // TODO добавить валидацию
    newCerts: {
      serts: []
    },
    headers: [
      {
        text: '№',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '370px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '310px'
      },
      {
        text: 'Назначение',
        value: 'use',
        width: '330px'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '300px'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '300px'
      },
      {
        text: 'МЧД',
        value: 'mchd',
        align: 'center',
        width: '200px'
      },
      {
        value: 'actions',
        width: '50px'
      }
    ]
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapState({
      checkSettings: state => state.checkSettings
    }),

    ...mapGetters('users', ['GET_USER_KEY', 'GET_USER_CERTIFICATES']),

    id () {
      return this.GET_USER_KEY('id')
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      const sertsObj = evt.serts.map(item => {
        return {
          id: item.id,
          mchd: item.mchd,
          use: item.use
        }
      })
      await this.newCerts.serts.push(...sertsObj)
    },

    async updateHandler () {
      this.loading = true
      this.trigger++
      await this.fillData()
      try {
        await UPDATE_CERTIFICATE(this.newCerts, this.id)
        await GET_DETAIL_USER(this.id)
        this.isEdit = false
      } catch (error) {
        console.log(error)
      } finally {
        this.loading = false
      }
    }

    // $_downloadFile (base64Data) {   // Функционал конвертации base64 в xml
    //   // console.log('base64Data', base64Data)
    //   const url = `data:application/xml;base64,${base64Data}`

    //   const link = document.createElement('a')
    //   link.href = url
    //   link.download = 'file.xml'
    //   link.click()
    //   link.remove()
    // },
  }
}
</script>

<style lang="scss">
</style>
