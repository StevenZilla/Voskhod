<template>
  <div class="editing-wrapper">
    <LoadingComponentVue class="mt-10" v-if="loading"/>

    <template v-else>
      <v-data-table
        item-key="id"
        disable-sort
        no-data-text="Нет данных"
        class="main-table no-hover no-overflow"
        hide-default-footer
        :headers="headers"
        :items="editObj.subdivisions"
      >

        <!-- eslint-disable-next-line -->
        <template v-slot:item.id="{ index }">
          {{ index + 1 }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.name="{ item }">
          <v-select
            data-qa="subdivision-list"
            class="rounded-lg"
            v-model="item.name"
            outlined
            item-text="name"
            item-value="id"
            item-disabled="select"
            hide-details
            :items="subdivisionsList"
            :filled="!!item.id"
            :disabled="!!item.id"
          ></v-select>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.start_date="{ item }">
          <date-range-picker
            v-model="dateRangeMix.start"
            style="width: 100%"
            opens="right"
            show-dropdowns
            time-picker-seconds
            time-picker
            single-date-picker
            :ranges="false"
            :max-date="item.end_date"
            :time-picker-increment="1"
            :locale-data="localeSettings"
            :filled="!!item.id"
            :disabled="!!item.id"
            @toggle="$_setBeginDate($event, [item.start_date], 'start')"
            @update="item.start_date = $_setDate($event, 'time')"
          >
            <template #input>
              <v-text-field
                class="rounded-lg"
                readonly
                outlined
                hide-details
                :filled="!!item.id"
                :disabled="!!item.id"
                placeholder="дд.мм.гггг"
                append-icon="mdi-calendar-blank"
                :value="$_formatDate(item.start_date, 'time')"
              ></v-text-field>
            </template>

            <div slot="footer" slot-scope="data" class="slot">
              <v-btn
                color="secondary"
                class="rounded-lg mr-4"
                outlined
                @click="data.clickCancel()"
              >Сбросить
              </v-btn>
              <v-btn
                color="secondary"
                class="rounded-lg"
                @click="data.clickApply"
              >Применить
              </v-btn>
            </div>
          </date-range-picker>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.end_date="{item}">
          <date-range-picker
            v-model="dateRangeMix.end"
            style="width: 100%"
            opens="right"
            show-dropdowns
            time-picker-seconds
            time-picker
            single-date-picker
            :ranges="false"
            :min-date="item.start_date"
            :time-picker-increment="1"
            :locale-data="localeSettings"
            :filled="!!item.id"
            :disabled="!!item.id"
            @toggle="$_setBeginDate($event, [item.end_date], 'end')"
            @update="item.end_date = $_setDate($event, 'time')"
          >
            <template #ranges>
              <div></div>
            </template>
            <template #input>
              <v-text-field
                class="rounded-lg"
                readonly
                outlined
                hide-details
                placeholder="дд.мм.гггг"
                append-icon="mdi-calendar-blank"
                :filled="!!item.id"
                :disabled="!!item.id"
                :value="$_formatDate(item.end_date, 'time')"
              ></v-text-field>
            </template>

            <div slot="footer" slot-scope="data" class="slot">
              <v-btn
                color="secondary"
                class="rounded-lg mr-4"
                outlined
                @click="data.clickCancel()"
              >Сбросить
              </v-btn>
              <v-btn
                color="secondary"
                class="rounded-lg"
                @click="data.clickApply"
              >Применить
              </v-btn>
            </div>
          </date-range-picker>
        </template>

        <!-- eslint-disable-next-line -->
        <!-- <template v-slot:item.actions="{item, index}">
          <v-btn
            v-if="item.pk"
            color="secondary"
            class="rounded-lg"
            icon
            @click="deleteSubdivisions(index)"
          >
            <v-icon>mdi-delete-outline</v-icon>
          </v-btn>
        </template> -->

        <template #footer>
          <div class="detail__buttons detail__buttons-border">
            <v-btn
              data-qa="add-subivision-user-edit"
              outlined
              color="secondary"
              class="ml-4 mb-0 rounded-lg"
              :disabled="editObj.subdivisions.length >= 1"
              @click="addSubdivision"
            >
              <v-icon class="mr-1">mdi-plus</v-icon>
              Добавить подразделение
            </v-btn>
          </div>
        </template>
      </v-data-table>
    </template>
  </div>
</template>

<script>

import { GET_SUBDIVISIONS_RESPONSE } from '../../../../nsi/submodules/subdivisions/services/api'
import { format } from 'date-fns'
import { mapState } from 'vuex'

import { required } from 'vuelidate/lib/validators'

export default {
  validations: {
    editObj: {
      subdivisions: {
        $each: {
          name: { required }
        }
      }
    }
  },

  props: {
    headers: {
      type: Array,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    },
    selectElem: {
      type: Array
    }
  },

  data: () => ({
    loading: true,
    // pk: 0,
    subdivisionsList: [],
    editObj: {
      subdivisions: []
    }
  }),

  watch: {
    trigger (newV) {
      if (newV) this.fillData()
    },

    'editObj.subdivisions': {
      handler () {
        this.subdivisionsList.forEach(item => {
          const selectSubdivisions = this.editObj.subdivisions.find(i => item.id === i.id)
          item.select = selectSubdivisions !== undefined
        })
      },

      deep: true
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  computed: {
    ...mapState({
      subdivisionsResponse: (state) =>
        state.nsi.subdivisions.subdivisionsResponse,
      organizationsResponse: (state) =>
        state.nsi.subdivisions.organizationsResponse,
      subdivisionsLoading: (state) =>
        state.nsi.subdivisions.subdivisionsLoading,
      error: (state) => state.error
    }),
    invalidData () {
      return this.$v.$invalid
    },

    subdivisions () {
      return this.$store.getters['users/GET_USER_SUBDIVISIONS']
    }
  },

  created () {
    this.loading = true
  },

  mounted () {
    this.prepareData()
  },

  methods: {
    async prepareData () {
      await GET_SUBDIVISIONS_RESPONSE()
      this.editObj.subdivisions = this.selectElem ? [...this.selectElem] : []
      this.subdivisionsList = await this.subdivisionsResponse.subdivisions || []
      this.subdivisionsList.forEach(el => {
        el.select = false
      })
      this.loading = false
    },

    fillData () {
      this.editObj.subdivisions.forEach(item => {
        item.subdivision_id = item.name
        item.start_date = format(new Date(item.start_date), 'yyyy-MM-dd HH:mm:ss')
        item.end_date = format(new Date(item.end_date), 'yyyy-MM-dd HH:mm:ss')
      })
      this.$emit('fill-data', this.editObj.subdivisions[0])
    },

    addSubdivision () {
      this.$set(this.editObj.subdivisions, this.editObj.subdivisions.length, {
        subdivision_id: null,
        start_date: format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        end_date: format(new Date(2999, 0, 1, 0, 0, 0), 'yyyy-MM-dd HH:mm:ss')
      })
    }

    // deleteSubdivision (index) {
    //   this.$delete(this.editObj.subdivisions, index)
    // }
  }

}
</script>

<style>
</style>
