<template>
  <div class="detail-flex">
    <date-range-picker
      v-model="dateRangeMix.end"
      opens="right"
      time-picker-seconds
      time-picker
      show-dropdowns
      single-date-picker
      :ranges="false"
      :min-date="isBefore(new Date(startDate), new Date(todayMix)) ? startDate : todayMix"
      :time-picker-increment="1"
      :locale-data="localeSettings"
      @toggle="$_setBeginDate($event, editObj.end_date, 'end')"
      @update="editObj.end_date = $_setDate($event, 'time')"
    >
      <template #input>
        <v-text-field
          class="rounded-lg"
          readonly
          outlined
          hide-details
          placeholder="дд.мм.гггг чч:мм:сс"
          append-icon="mdi-calendar-blank"
          :value="$_formatDate(editObj.end_date, 'time')"
        ></v-text-field>
      </template>

      <div slot="footer" slot-scope="data" class="slot">
        <DatePickerActions @cancel="data.clickCancel" @apply="data.clickApply"/>
      </div>
    </date-range-picker>

    <EditingBtn
      :disabled="editObj.end_date === endDate"
      :value="editObj"
      @change-mode="$emit('change-mode')"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { format } from 'date-fns'
import isBefore from 'date-fns/isBefore'
import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  name: 'EditingEndDate',
  methods: { isBefore },

  components: {
    EditingBtn
  },

  data: () => ({
    format,
    editObj: {
      end_date: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    startDate () {
      return this.GET_USER_KEY('start_date')
    },

    endDate () {
      return this.GET_USER_KEY('end_date')
    }
  },

  mounted () {
    this.editObj.end_date = this.endDate
  }
}
</script>

<style>

</style>
