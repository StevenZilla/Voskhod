<template>
  <div class="detail-flex">
    <v-text-field
      v-model="editObj.fio"
      class="rounded-lg"
      rounded
      hide-details
      outlined
      clearable
      :value="fio"
    ></v-text-field>

    <EditingBtn
      :disabled="editObj.fio === fio"
      :value="editObj"
      @change-mode="$emit('change-mode')"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  components: { EditingBtn },
  data: () => ({
    editObj: {
      fio: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    fio () {
      return this.GET_USER_KEY('fio')
    }
  },

  mounted () {
    this.editObj.fio = this.fio
  }
}
</script>

<style>

</style>
