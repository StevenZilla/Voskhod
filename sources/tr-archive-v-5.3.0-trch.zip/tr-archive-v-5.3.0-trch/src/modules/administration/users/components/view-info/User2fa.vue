<template>
  <div class="detail__item">
    <p class="detail__item-title">Двухфакторная аутентификация</p>

    <Editing2fa
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <v-checkbox
        data-qa="2fa-checkbox-view"
        v-model="is2fa"
        hide-details
        color="secondary"
        disabled
        filled
      ></v-checkbox>
      <v-btn data-qa="2fa-edit-view" class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const Editing2fa = () => import('../editing-info/Editing2fa.vue')
export default {
  components: {
    Editing2fa
  },

  data: () => ({
    isEdit: false
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    is2fa () {
      return this.GET_USER_KEY('is_2fa')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
