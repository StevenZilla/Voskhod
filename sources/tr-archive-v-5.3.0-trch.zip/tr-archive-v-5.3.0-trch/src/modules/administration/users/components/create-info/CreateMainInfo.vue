<template>
  <v-card class="detail__main-info">

    <h4 class="popup__content-title">Общая информация</h4>
    <FullName
        @set-property="$v.createMainInfo.fio.$model = $event"
    />
    <UserEmail
        :error-data="errorData"
        :validation="$v.createMainInfo.email.email"
        @set-property="$v.createMainInfo.email.$model = $event"
    />

    <h4 class="popup__content-title">Авторизация</h4>
    <UserLogin
        :error-data="errorData"
        :validation="$v.createMainInfo.login"
        @set-property="$v.createMainInfo.login.$model = $event"
    />

    <FieldPassword
      :error-data="errorData"
      @set-password="createMainInfo.password = $event"
      @change-valid-password="invalidPassword = $event"
    />

    <TwoFactorAuth
        @set-property="$v.createMainInfo.fio.$model = $event"
    />

    <h4 class="popup__content-title">Срок действия учетной записи пользователя</h4>
    <StartAction @set-property="createMainInfo.start_date = $event"/>

    <EndAction
        @set-property="createMainInfo.end_date = createEndDate($event)"
        :param="createMainInfo.end_date"
    />

  </v-card>
</template>

<script>

import { email, required } from 'vuelidate/lib/validators'
import FieldPassword from '@/components/FieldPassword.vue'
import FullName from '@/modules/administration/users/components/fields-main-info/FullName.vue'
import UserEmail from '@/modules/administration/users/components/fields-main-info/UserEmail.vue'
import UserLogin from '@/modules/administration/users/components/fields-main-info/UserLogin.vue'
import TwoFactorAuth from '@/modules/administration/users/components/fields-main-info/TwoFactorAuth.vue'
import StartAction from '@/modules/administration/users/components/fields-main-info/StartAction.vue'
import EndAction from '@/modules/administration/users/components/fields-main-info/EndAction.vue'

export default {
  name: 'CreateMainInfo',
  components: { EndAction, StartAction, TwoFactorAuth, UserLogin, UserEmail, FullName, FieldPassword },

  props: {
    trigger: {
      type: Number,
      required: true
    },

    errorData: {
      type: Object,
      required: true
    }
  },

  validations: {
    createMainInfo: {
      fio: { required },
      email: { required, email },
      login: {
        required,
        haveLetters (val) {
          const regExp = /(?=.*[0-9])/g // проверка на цифры (не должно быть)
          return !regExp.test(val)
        },
        haveCyr (val) {
          const regExp = /(?=.*[А-Яа-я])/g // проверка на кириллицу (не должно быть)
          return !regExp.test(val)
        },
        banSymbol (val) {
          const regExp = /(?=.*[^A-Za-z0-9А-Яа-я._])/g // проверка на символы (не должно быть) содержать символы, кроме "_" и "."
          return !regExp.test(val)
        }
      }
    }
  },

  data: () => ({
    invalidPassword: true,
    createMainInfo: {
      fio: '',
      email: '',
      login: '',
      password: '',
      start_date: '',
      end_date: ''
    }
  }),

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.createMainInfo)
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  computed: {
    invalidData () {
      return this.$v.$invalid || this.invalidPassword
    }
  },

  methods: {
    createEndDate (event) {
      if (!this.createMainInfo.end_date) {
        const [year, month, day] = this.createMainInfo.start_date.split('-')
        return String(Number(year) + 100) + '-' + month + '-' + day
      } return event
    }
  }
}
</script>

<style>

</style>
