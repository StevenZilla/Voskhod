<template>
  <div class="form-group">
    <p class="form-group__title">Логин <span class="required-label">*</span></p>
    <v-alert
        dense
        type="info"
        icon="mdi-alert-circle"
        color="#E52E2E"
        class="alert-notification"
        v-if="errorData.login"
    >
      {{ errorData.login[0] }}
    </v-alert>
    <v-text-field
        data-qa="login-user-create"
        v-model="value"
        outlined
        clearable
        hide-details
        rounded
        required
        placeholder="Введите логин пользователя для авторзации в системе"
        class="rounded-lg"
    ></v-text-field>
    <!-- нельзя вводить никакие знаки , кроме "_" и "."
    нельзя вводить цифры
    можно вводить только латиницу -->
    <div class="mb-2">
      <span
          v-if="!validation.haveCyr"
          class="v-messages error--text"
      >Логин не должен содержать кириллицу!</span>
      <span
          v-if="!validation.haveLetters"
          class="v-messages error--text"
      >Логин не должен содержать цифры!</span>
      <span
          v-if="!validation.banSymbol"
          class="v-messages error--text"
      >Логин не должен содержать символы, кроме "_" и "."</span>
    </div>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    },

    errorData: {
      type: Object,
      required: true
    },

    validation: {
      type: Object,
      required: true
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">
.mb-2{
  display: flex;
  flex-direction: column;
}
</style>
