<template>
  <div class="detail__item">
    <p class="detail__item-title">Идентификатор ЕСИА</p>
    <div class="detail-flex">
      <span data-qa="login-user-view" class="detail__value">{{ oidESIA ? oidESIA : 'Нет данных' }}</span>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    oidESIA () {
      return this.GET_USER_KEY('oid_esia')
    }
  }
}
</script>
