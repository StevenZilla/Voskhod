<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <Login
        class="w-20"
        ref="login"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Email
        class="w-20"
        ref="email"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <StartActionDate
        class="w-20"
        ref="startDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EndActionDate
        class="w-20"
        ref="endDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

// import { mapState } from 'vuex'
import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import Login from '@/components/Filters/Fields/User/Login.vue'
import Email from '@/components/Filters/Fields/User/Email.vue'
import StartActionDate from '@/components/Filters/Fields/StartActionDate.vue'
import EndActionDate from '@/components/Filters/Fields/EndActionDate.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

export default {
  name: 'Filters',
  components: {
    ChipsFilters,
    Login,
    Email,
    StartActionDate,
    EndActionDate,
    FilterFooter,
    FiltersTemplate
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.login) {
        paramsFilter.append('login', this.filterObj.login.query)
        chips.push(this.filterObj.login)
      }
      if (this.filterObj.email) {
        paramsFilter.append('email', this.filterObj.email.query)
        chips.push(this.filterObj.email)
      }
      if (this.filterObj.startDate) {
        paramsFilter.append('start_start_date', this.filterObj.startDate.query[0])
        paramsFilter.append('end_start_date', this.filterObj.startDate.query[1])
        chips.push(this.filterObj.startDate)
      }
      if (this.filterObj.endDate) {
        paramsFilter.append('start_end_date', this.filterObj.endDate.query[0])
        paramsFilter.append('end_end_date', this.filterObj.endDate.query[1])
        chips.push(this.filterObj.endDate)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.searchTouch = false
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
