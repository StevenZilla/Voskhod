<template>
  <v-card data-qa="block-system-roles-user-view" class="detail__additional-info mt-10">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Роли</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit"
          data-qa="role-edit-view"
          class="circle circle__btn circle--white"
          icon
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-else>
          <div class="d-flex">
            <BtnIconSaveSlot
              :disabled="invalidData"
              :loading="loading"
              @save="updateHandler"
            />
            <!-- Чтобы сделать отступ -->
            <div class="mr-3"></div>

            <BtnIconCancelSlot
              :loading="loading"
              @close="isEdit = false"
            />
          </div>
        </template>
      </div>
    </v-card-title>

    <v-card-text class="no-bg">
      <EditingRoles
        v-if="isEdit"
        :headers="headers"
        :trigger="trigger"
        @change-valid="invalidData = $event"
        @fill-data="fillData($event)"
      />

      <div class="detail-wrapper" v-else>
        <v-data-table
          disable-sort
          item-key="id"
          no-data-text="Нет данных"
          class="main-table"
          hide-default-footer
          :headers="headers"
          :items="GET_USER_ROLES"
          @click:row="showDetail($event)"
        >
          <template v-slot:item.id="{index}">
            {{ index + 1 }}
          </template>

          <template v-slot:item.start_date="{item}">
            <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
            <span v-else style="color:#CBCBCD">Нет данных</span>
          </template>

          <template v-slot:item.end_date="{item}">
            <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
            <span v-else style="color:#CBCBCD">Нет данных</span>
          </template>
        </v-data-table>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'
import { format } from 'date-fns'
import { GET_DETAIL_USER, UPDATE_USER } from '@/modules/administration/users/services/api'

const EditingRoles = () => import('../editing-info/EditingRoles.vue')
const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'ViewRolesUser',

  components: {
    EditingRoles,
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  data: () => ({
    format,
    trigger: 0,
    isEdit: false,
    loading: false,
    invalidData: false,
    newRoles: null,
    headers: [
      {
        text: '№',
        align: 'start',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Наименование',
        value: 'role.value',
        width: '765px'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '400px'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '400px'
      },
      {
        value: 'actions',
        width: '50px'
      }
    ]
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY', 'GET_USER_ROLES']),

    id () {
      return this.GET_USER_KEY('id')
    }
  },

  methods: {
    showDetail (e) {
      const path = `/system_roles/${e.role.id}`
      this.$router.push(path)
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        this.newRoles = evt
        resolve()
      })
    },

    async updateHandler () {
      this.loading = true
      this.trigger++
      await this.fillData()
      try {
        await UPDATE_USER(this.newRoles, this.id)
        await GET_DETAIL_USER(this.id)
        this.isEdit = false
      } catch (error) {
        console.log(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
