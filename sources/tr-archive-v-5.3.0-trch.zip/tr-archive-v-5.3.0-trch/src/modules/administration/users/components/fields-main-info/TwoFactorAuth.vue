<template>
  <div class="form-group d-flex">
    <p class="form-group__title">Двухфакторная аутентификация </p>
    <v-checkbox
        data-qa="2fa-checkbox"
        v-model="value"
        class="d-inline-block"
        color="secondary"
        v-ripple
    ></v-checkbox>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
