<template>
  <div class="detail-flex">
    <v-checkbox
      v-model="editObj.is_2fa"
      hide-details
      color="secondary"
      v-ripple
    ></v-checkbox>

    <EditingBtn
      :disabled="editObj.is_2fa === is2fa"
      :value="editObj"
      @change-mode="$emit('change-mode')"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  components: {
    EditingBtn
  },

  data: () => ({
    editObj: {
      is_2fa: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    is2fa () {
      return this.GET_USER_KEY('is_2fa')
    }
  },

  mounted () {
    this.editObj.is_2fa = this.is2fa
  }
}
</script>

<style>

</style>
