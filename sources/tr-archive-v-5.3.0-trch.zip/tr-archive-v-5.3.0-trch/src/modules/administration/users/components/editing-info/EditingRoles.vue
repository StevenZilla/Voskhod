<template>
  <div class="editing-wrapper">
    <LoadingComponentVue class="mt-10" v-if="loading"/>

    <template v-else>
      <v-data-table
        item-key="id"
        disable-sort
        no-data-text="Нет данных"
        class="main-table"
        hide-default-footer
        :headers="headers"
        :items="editObj.system_roles"
      >

        <!-- eslint-disable-next-line -->
        <template v-slot:item.id="{ index }">
          {{ index + 1 }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.role.value="{ item }">
          <v-select
            data-qa="system-role-list"
            class="rounded-lg"
            v-model="item.role"
            outlined
            item-text="name"
            item-value="id"
            item-disabled="select"
            hide-details
            return-object
            :items="rolesList"
            :filled="!!item.id"
            :disabled="!!item.id"
          ></v-select>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.start_date="{ item }">
          <date-range-picker
            v-model="dateRangeMix.start"
            style="width: 100%"
            opens="right"
            show-dropdowns
            time-picker-seconds
            time-picker
            single-date-picker
            :ranges="false"
            :max-date="item.end_date"
            :time-picker-increment="1"
            :locale-data="localeSettings"
            @toggle="$_setBeginDate($event, [item.start_date], 'start')"
            @update="item.start_date = $_setDate($event, 'time')"
          >
            <template #input>
              <v-text-field
                class="rounded-lg"
                readonly
                outlined
                hide-details
                placeholder="дд.мм.гггг чч:мм:сс"
                append-icon="mdi-calendar-blank"
                :value="$_formatDate(item.start_date, 'time')"
              ></v-text-field>
            </template>

            <div slot="footer" slot-scope="data" class="slot">
              <v-btn
                color="secondary"
                class="rounded-lg mr-4"
                outlined
                @click="data.clickCancel()"
              >Сбросить
              </v-btn>
              <v-btn
                color="secondary"
                class="rounded-lg"
                @click="data.clickApply"
              >Применить
              </v-btn>
            </div>
          </date-range-picker>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.end_date="{item}">
          <date-range-picker
            v-model="dateRangeMix.end"
            style="width: 100%"
            opens="right"
            show-dropdowns
            time-picker-seconds
            time-picker
            single-date-picker
            :ranges="false"
            :min-date="item.start_date"
            :time-picker-increment="1"
            :locale-data="localeSettings"
            @toggle="$_setBeginDate($event, [item.end_date], 'end')"
            @update="item.end_date = $_setDate($event, 'time')"
          >
            <template #ranges>
              <div></div>
            </template>
            <template #input>
              <v-text-field
                class="rounded-lg"
                readonly
                outlined
                hide-details
                placeholder="дд.мм.гггг чч:мм:сс"
                append-icon="mdi-calendar-blank"
                :value="$_formatDate(item.end_date, 'time')"
              ></v-text-field>
            </template>

            <div slot="footer" slot-scope="data" class="slot">
              <v-btn
                color="secondary"
                class="rounded-lg mr-4"
                outlined
                @click="data.clickCancel()"
              >Сбросить
              </v-btn>
              <v-btn
                color="secondary"
                class="rounded-lg"
                @click="data.clickApply"
              >Применить
              </v-btn>
            </div>
          </date-range-picker>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.actions="{item, index}">
          <v-btn
            v-if="item.pk"
            color="secondary"
            class="rounded-lg"
            icon
            @click="deleteRole(index)"
          >
            <v-icon>mdi-delete-outline</v-icon>
          </v-btn>
        </template>

        <template #footer>
          <div class="detail__buttons detail__buttons-border">
            <v-btn
              data-qa="add-system-role-user-edit"
              outlined
              color="secondary"
              class="ml-4 mb-0 rounded-lg"
              @click="addRole"
            >
              <v-icon class="mr-1">mdi-plus</v-icon>
              Добавить роль
            </v-btn>
          </div>
        </template>
      </v-data-table>
    </template>
  </div>
</template>

<script>

import { GET_SYSTEM_ROLE_LIST } from '../../../services/api'
import { format, isAfter } from 'date-fns'
import { required } from 'vuelidate/lib/validators'

export default {
  validations: {
    editObj: {
      system_roles: {
        $each: {
          role: {
            id: { required },
            start_date: { required },
            end_date: { required }
          }
        }
      }
    }
  },

  props: {
    headers: {
      type: Array,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    loading: true,
    isAfter,
    pk: 0,
    rolesList: [],
    editObj: {
      system_roles: []
    }
  }),

  watch: {
    trigger (newV) {
      if (newV) this.fillData()
    },

    'editObj.system_roles': {
      handler () {
        this.rolesList.forEach(item => {
          const selectRole = this.editObj.system_roles.find(i => item.id === i.role.id)
          item.select = selectRole !== undefined
        })
      },

      deep: true
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    }
  },

  computed: {
    invalidData () {
      return this.$v.$invalid
    },

    roles () {
      return this.$store.getters['users/GET_USER_ROLES']
    }
  },

  created () {
    this.loading = true
  },

  async mounted () {
    this.editObj.system_roles = [...this.roles]
    this.rolesList = await GET_SYSTEM_ROLE_LIST() || []
    this.rolesList.forEach(role => {
      role.select = false
    })
    this.loading = false
  },

  methods: {
    fillData () {
      this.editObj.system_roles.forEach(item => {
        item.role_id = item.role.id
        delete item.role
        item.start_date = format(new Date(item.start_date), 'yyyy-MM-dd HH:mm:ss')
        item.end_date = format(new Date(item.end_date), 'yyyy-MM-dd HH:mm:ss')
      })
      this.$emit('fill-data', this.editObj)
    },

    addRole () {
      this.pk--

      this.$set(this.editObj.system_roles, this.editObj.system_roles.length, {
        pk: this.pk,
        start_date: format(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        end_date: format(new Date(2999, 0, 1, 0, 0, 0), 'yyyy-MM-dd HH:mm:ss'),
        role: {
          id: null,
          value: null,
          start_date: '',
          end_date: ''
        }
      })
    },

    deleteRole (index) {
      this.$delete(this.editObj.system_roles, index)
    }
  }

}
</script>

<style>
</style>
