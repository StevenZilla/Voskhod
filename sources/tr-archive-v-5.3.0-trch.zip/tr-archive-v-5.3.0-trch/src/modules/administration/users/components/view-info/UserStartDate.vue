<template>
  <div class="detail__item">
    <p class="detail__item-title">Начало действия учетной записи</p>
    <EditingStartDate
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <span data-qa="start-date-user-view" class="detail__value">{{ $_formatDate(startDate, 'time') }}</span>
      <v-btn class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingStartDate = () => import('../editing-info/EditingStartDate.vue')

export default {
  name: 'UserStartDate',

  components: {
    EditingStartDate
  },

  data: () => ({
    isEdit: false
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    startDate () {
      return this.GET_USER_KEY('start_date')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
