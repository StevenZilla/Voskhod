<template>
  <div class="detail__item">
    <p class="detail__item-title">E-mail</p>

    <EditingEmail
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <span data-qa="email-user-view" class="detail__value">{{ email }}</span>
      <v-btn class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

const EditingEmail = () => import('../editing-info/EditingEmail.vue')

export default {
  name: 'UserEmail',

  components: {
    EditingEmail
  },

  data: () => ({
    isEdit: false
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    email () {
      return this.GET_USER_KEY('email')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
