<template>
  <div class="form-group">
    <p class="form-group__title">Email <span class="required-label">*</span></p>
    <v-alert
        dense
        type="info"
        icon="mdi-alert-circle"
        color="#E52E2E"
        class="alert-notification"
        v-if="errorData.email"
    >{{ errorData.email[0] }}
    </v-alert>
    <v-text-field
        data-qa="email-user-create"
        v-model="value"
        outlined
        clearable
        rounded
        required
        hide-details
        placeholder="Введите email"
        class="rounded-lg"
    ></v-text-field>
    <span class="v-messages error--text" v-if="!validation">E-mail должен быть в формате mail@mail.ru</span>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    },

    errorData: {
      type: Object,
      required: true
    },

    validation: {
      type: Boolean,
      required: true
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
