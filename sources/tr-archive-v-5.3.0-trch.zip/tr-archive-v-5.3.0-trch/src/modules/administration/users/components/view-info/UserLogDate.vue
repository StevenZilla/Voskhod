<template>
  <div class="detail__item">
    <p class="detail__item-title">Дата последнего входа в систему</p>
    <div class="detail-flex">
      <span class="detail__value">{{ $_formatDate(logDate, 'time') || 'Нет данных' }}</span>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    logDate () {
      return this.GET_USER_KEY('log_date')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
