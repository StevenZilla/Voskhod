<template>
  <div class="detail__item">
    <p class="detail__item-title">Логин пользователя</p>
    <div class="detail-flex">
      <span data-qa="login-user-view" class="detail__value">{{ login }}</span>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    login () {
      return this.GET_USER_KEY('login')
    }
  }
}
</script>

<style lang="scss">

</style>
