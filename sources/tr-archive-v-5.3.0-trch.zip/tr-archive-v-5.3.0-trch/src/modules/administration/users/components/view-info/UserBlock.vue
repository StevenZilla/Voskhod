<template>
  <div class="detail__item">
    <p class="detail__item-title">Заблокирован</p>

    <EditingBlock
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <v-checkbox
        v-model="isBlock"
        hide-details
        color="secondary"
        disabled
        filled
      ></v-checkbox>
      <v-btn class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

const EditingBlock = () => import('../editing-info/EditingBlock.vue')
export default {
  components: {
    EditingBlock
  },

  data: () => ({
    isEdit: false
  }),

  watch: {
    isEdit (newVal) {
      this.$emit('update-editing', newVal)
    }
  },

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    isBlock () {
      return this.GET_USER_KEY('is_block')
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
