<template>
  <div class="editing-wrapper">
    <LoadingComponentVue class="mt-10" v-if="loading"/>

    <template v-else>
      <v-data-table
        disable-sort
        item-key="id"
        no-data-text="Нет данных"
        class="main-table no-hover scroll-table"
        hide-default-footer
        :headers="headers"
        :items="editObj.serts"
      >
        <!-- eslint-disable-next-line -->
        <template v-slot:item.id="{ index }">
          {{ index + 1 }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.num="{item, index}">
          <span v-if="item.id">{{ item.num }}</span>

          <v-select
            data-qa="sert-list"
            v-else
            v-model="item.num"
            class="rounded-lg"
            outlined
            rounded
            hide-details
            color="secondary"
            item-text="name"
            item-value="num"
            item-disabled="select"
            :items="certificatesList"
            @input="changeSelectedCert($event, index)"
          ></v-select>
        </template>

        <template v-slot:item.use="{item}">
          <v-select
            data-qa="use-sert-list"
            v-model="item.use"
            class="rounded-lg"
            item-text="name"
            item-color="secondary"
            item-value="id"
            hide-details
            return-object
            outlined
            multiple
            :items="usesList"
          ></v-select>
        </template>

        <template v-slot:item.start_date="{item}">
          <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.end_date="{item}">
          <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.mchd="{item}">
          <label>
            <input type="file" hidden accept="*/*" @change="addXmlFile($event.target.files[0], item)" />
            <span style="cursor: pointer">
                <v-tooltip bottom
                  v-if="item.mchd">
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon
                        color="secondary"
                        v-bind="attrs"
                        v-on="on"
                      >
                        mdi-file-restore
                      </v-icon>
                    </template>
                    <span>Обновить файл МЧД</span>
                </v-tooltip>

                <v-tooltip bottom v-else>
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon
                        color="secondary"
                        v-bind="attrs"
                        v-on="on"
                      >
                        mdi-file-plus
                      </v-icon>
                    </template>
                    <span>Добавить файл МЧД</span>
                </v-tooltip>
            </span>
          </label>
        </template>

        <template v-slot:item.actions="{item, index}">
          <v-btn
            v-if="item.pk"
            color="secondary"
            class="rounded-lg"
            icon
            @click="deleteCert(index)"
          ><v-icon color="secondary">mdi-delete-outline</v-icon>
          </v-btn>
        </template>

        <template #footer>
          <div class="detail__buttons detail__buttons-border">
            <v-btn
              data-qa="add-sert-user-edit"
              outlined
              color="secondary"
              class="ml-4 mb-0 rounded-lg"
              :disabled="!certificatesList.length"
              @click="addCert"
            ><v-icon class="mr-1">mdi-plus</v-icon>
              Добавить сертификат
            </v-btn>
          </div>
        </template>
      </v-data-table>
    </template>
  </div>
</template>

<script>

import { GET_CERTIFICATES, GET_ALL_USE, GET_CHECK_SETTINGS } from '@/services/app'

// import { required } from 'vuelidate/lib/validators'

export default {
  props: {
    headers: {
      type: Array,
      required: true
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  // validations: {
  //   editObj: {
  //     serts: {
  //       $each: {
  //         mchd: { required }
  //       }
  //     }
  //   }
  // },

  validations: {
    editObj: {
      serts: {
        $each: {
          mchd: {
            custom: (value, obj) => {
              if (obj.pk) {
              // Проверяем значение mchd только если у объекта есть pk
                return value !== null && value !== undefined && value.length > 0
              }
              // Если у объекта нет pk, то сертификат уже был установлен ранее и его не проверяем
              return true
            }
          }
        }
      }
    }
  },

  data: () => ({
    base64Convert: '',
    sertSettingList: null,
    loading: true,
    pk: 0,
    certificatesList: [],
    usesList: [],
    editObj: {
      serts: []
    }
  }),

  watch: {
    invalidData (newVal) {
      console.log(newVal)
      console.log('watch this.editObj.serts', this.editObj.serts)
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.fillData()
    },

    'editObj.serts': {
      handler () {
        this.certificatesList.forEach(item => {
          const selectSert = this.editObj.serts.find(i => item.id === i.id)
          item.select = selectSert !== undefined
        })
      },

      deep: true
    }
  },

  computed: {
    certificates () {
      return this.$store.getters['users/GET_USER_CERTIFICATES']
    },

    invalidData () {
      return this.$v.$invalid
    }
  },

  created () {
    this.loading = true
  },

  async mounted () {
    this.editObj.serts = [...this.certificates]
    this.certificatesList = await GET_CERTIFICATES() || []
    this.usesList = await GET_ALL_USE()
    try {
      await GET_CHECK_SETTINGS()
    } catch (error) {
      if (error.response.data) {
        console.log(error.response.data)
      }
    }
    this.loading = false
  },

  methods: {
    changeSelectedCert (e, ind) {
      const selectCert = this.certificatesList.find(cert => e === cert.num)

      if (selectCert) {
        this.editObj.serts[ind].name = selectCert.name
        this.editObj.serts[ind].id = selectCert.id
        this.editObj.serts[ind].start_date = selectCert.start_date
        this.editObj.serts[ind].end_date = selectCert.end_date
      }
    },

    async readXmlFile (file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => {
          const base64FullPath = reader.result
          const base64 = base64FullPath.split(',')[1] // Убираем метаданные
          resolve(base64)
        }
        reader.onerror = reject
        reader.readAsDataURL(file)
      })
    },

    async addXmlFile (file, item) {
      this.base64Convert = await this.readXmlFile(file)
      this.editObj.serts.forEach(sert => {
        if (sert.id === item.id) {
          sert.mchd = this.base64Convert
        }
      })
    },

    fillData () {
      const copyObj = JSON.parse(JSON.stringify(this.editObj))
      copyObj.serts.forEach(item => {
        //  if (item.id < 0) delete item.id
        item.use = item.use.map(use => {
          return use.id
        })
      })
      copyObj.serts.forEach(item => {
        if (item?.mchd?.file_base64) {
          item.mchd = item.mchd.file_base64
        }
      })
      this.$emit('fill-data', copyObj)
    },

    deleteCert (index) {
      this.$delete(this.editObj.serts, index)
    },

    addCert () {
      this.pk--
      this.$set(this.editObj.serts, this.editObj.serts.length, {
        pk: this.pk,
        // end_date: null,
        // name: null,
        // num: null,
        // start_date: null,
        mchd: null,
        use: null
      })
    }
  }

}
</script>

<style>

</style>
