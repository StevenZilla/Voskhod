<template>
  <v-card class="mt-10">
    <v-card-title>
      <h2>Срок действия учётной записи пользователя</h2>
    </v-card-title>

    <v-card-text class="mt-8 d-flex justify-space-between item-2">
      <slot name="start-date"></slot>

      <slot name="end-date"></slot>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: 'ViewValidityUser'
}
</script>

<style lang="scss">

</style>
