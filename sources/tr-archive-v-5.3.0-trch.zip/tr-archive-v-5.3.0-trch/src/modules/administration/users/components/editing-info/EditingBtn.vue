<template>
  <div class="form-editing__controls d-flex mr-2">
    <BtnIconSaveSlot
      :disabled="disabled"
      :loading="loading"
      @save="updateHandler"
    />

    <BtnIconCancelSlot
      :loading="loading"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { UPDATE_USER, GET_DETAIL_USER } from '../../services/api'
import { mapGetters } from 'vuex'

const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'EditingBtn',

  components: {
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  props: {
    disabled: {
      type: Boolean,
      required: true
    },

    value: {
      type: Object,
      required: true
    }
  },

  data: () => ({
    loading: false
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    id () {
      return this.GET_USER_KEY('id')
    }
  },

  methods: {
    async updateHandler () {
      this.loading = true
      try {
        await UPDATE_USER(this.value, this.id)
        await GET_DETAIL_USER(this.id)
        this.$emit('change-mode')
      } catch (error) {
        console.log(error)
      } finally {
        this.loading = false
      }
    },

    cancelEdit () {

    }
  }
}
</script>

<style lang="scss">

</style>
