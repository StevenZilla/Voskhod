<template>
  <div class="detail-flex">
    <date-range-picker
      v-model="dateRangeMix.start"
      opens="right"
      time-picker-seconds
      time-picker
      show-dropdowns
      single-date-picker
      :ranges="false"
      :max-date="endDate"
      :time-picker-increment="1"
      :locale-data="localeSettings"
      @toggle="$_setBeginDate($event, editObj.start_date, 'start')"
      @update="editObj.start_date = $_setDate($event, 'time')"
    >
      <template #input>
        <v-text-field
          class="rounded-lg"
          readonly
          outlined
          hide-details
          placeholder="дд.мм.гггг чч:мм:сс"
          append-icon="mdi-calendar-blank"
          :value="$_formatDate(editObj.start_date, 'time')"
        ></v-text-field>
      </template>

      <div slot="footer" slot-scope="data" class="slot">
        <DatePickerActions @cancel="data.clickCancel" @apply="data.clickApply"/>
      </div>
    </date-range-picker>

    <EditingBtn
      :disabled="editObj.start_date === startDate"
      :value="editObj"
      @change-mode="$emit('change-mode')"
      @close="$emit('close')"
    />
  </div>
</template>

<script>

import { format } from 'date-fns'
import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  components: {
    EditingBtn
  },

  data: () => ({
    format,
    editObj: {
      start_date: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    startDate () {
      return this.GET_USER_KEY('start_date')
    },

    endDate () {
      return this.GET_USER_KEY('end_date')
    }
  },

  mounted () {
    this.editObj.start_date = this.startDate
  }
}
</script>

<style>

</style>
