<template>
  <div>
    <div class="detail-flex">
      <v-text-field
        v-model="editObj.email"
        class="rounded-lg"
        rounded
        hide-details
        outlined
        clearable
        :value="email"
      ></v-text-field>

      <EditingBtn
        :disabled="editObj.email === email || invalidMail"
        :value="editObj"
        @change-mode="$emit('change-mode')"
        @close="$emit('close')"
      />
    </div>
    <span class="v-messages error--text" v-if="invalidMail">E-mail должен быть в формате mail@mail.ru</span>
  </div>
</template>

<script>

import { email } from 'vuelidate/lib/validators'
import { mapGetters } from 'vuex'

const EditingBtn = () => import('./EditingBtn.vue')

export default {
  components: {
    EditingBtn
  },

  validations: {
    editObj: {
      email: { email }
    }
  },

  data: () => ({
    editObj: {
      email: null
    }
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    email () {
      return this.GET_USER_KEY('email')
    },

    invalidMail () {
      return this.$v.$invalid
    }
  },

  mounted () {
    this.editObj.email = this.email
  }
}
</script>

<style>

</style>
