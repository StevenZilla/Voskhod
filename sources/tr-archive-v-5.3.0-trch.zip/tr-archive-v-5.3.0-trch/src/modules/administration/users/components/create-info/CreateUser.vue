<template>
  <v-dialog
    v-model="isCreate"
    content-class="dialog-max-height"
    max-width="630px"
    :key="clearComponentVar"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        data-qa="add-user"
        class="justify-content-end rounded-lg"
        color="secondary"
        v-bind="attrs"
        v-on="on"
      >
        <v-icon class="mr-2">mdi-account-plus-outline</v-icon>
        Добавить пользователя
      </v-btn>
    </template>

    <v-card class="popup">
      <v-toolbar
        dense
        flat
        class="popup-toolbar"
      >
        <v-toolbar-title>
          Добавление пользователя
        </v-toolbar-title>
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <div class="popup__content">
        <CreateMainInfo
          :trigger="trigger"
          :error-data="errorData"
          @change-valid="invalidMainForm = $event"
          @fill-data="fillData($event)"
        />
      </div>

      <div class="popup__actions">
        <BtnSaveSlot
          :text="'Добавить'"
          :loading="loading"
          :disabled="invalidMainForm"
          @save="submitHandler"
        />

        <BtnCancelSlot
          @close="closeDialog()"
        />
      </div>
    </v-card>
  </v-dialog>
</template>

<script>

import { CREATE_USER } from '../../services/api'

const CreateMainInfo = () => import('./CreateMainInfo.vue')

export default {
  name: 'CreateUser',
  components: {
    CreateMainInfo
  },

  data: () => ({
    invalidMainForm: true,
    clearComponentVar: 0,
    isCreate: false,
    trigger: 0,
    createDetailInfo: {},
    errorData: {},
    loading: false
  }),

  methods: {
    closeDialog () {
      this.isCreate = false
      this.clearComponentVar++
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.createDetailInfo, evt)
        resolve()
      })
    },

    async submitHandler () {
      this.trigger++
      this.errorData = {}
      this.loading = true
      await this.fillData()
      try {
        const resp = await CREATE_USER(this.createDetailInfo)
        this.$emit('refresh-data', resp.data.message)
      } catch (error) {
        this.errorData = error.response.data.error
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">

.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
