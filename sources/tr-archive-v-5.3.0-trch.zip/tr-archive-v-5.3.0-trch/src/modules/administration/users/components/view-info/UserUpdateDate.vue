<template>
  <div class="detail__item">
    <p class="detail__item-title">Дата последнего обновления пароля</p>
    <div class="detail-flex">
      <span class="detail__value">{{ $_formatDate(updatePasswordDate, 'time') }}</span>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    updatePasswordDate () {
      return this.GET_USER_KEY('update_password_date')
    }
  }
}
</script>

<style lang="scss">
</style>
