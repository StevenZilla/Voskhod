<template>
  <v-dialog
    v-model="isReset"
    content-class="dialog-auto-height"
    max-width="630px"
    :key="clearComponentVar"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        class="mt-5 rounded-lg"
        color="secondary"
        outlined
        v-bind="attrs"
        v-on="on"
      ><v-icon data-qa="reset-password-user-view" class="mr-2">mdi-lock-reset</v-icon>
        Сбросить пароль
      </v-btn>
    </template>

    <v-card class="popup-form">
      <v-toolbar
        dense
        flat
      ><v-toolbar-title>Сброс пароля пользователя</v-toolbar-title>
        <BtnCancelSlot
          :icon="true"
          @close="closeDialog()"
        />
      </v-toolbar>

      <LoadingComponentVue v-if="loading"/>

      <div v-else class="popup-form__content">
        <div class="form-group mb-3" :class="{'error-field': isInvalidNew}">
          <p class="form-group__title">Новый пароль</p>
          <v-text-field
            v-model="new_password"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Введите новый пароль учётной записи пользователя"
            hide-details
            clearable
            :type="typeField"
          >
            <!-- eslint-disable-next-line -->
            <template #append>
              <v-icon v-if="new_password" @click="switchTypeField" class="mr-2">mdi-eye-outline</v-icon>
              <v-icon v-if="isInvalidNew" color="error">mdi-alert-circle</v-icon>
            </template>
          </v-text-field>
          <div class="v-messages error--text" v-if="specialSymbols.value === 'Да' && !$v.new_password.haveSymbol">Пароль должен содержать минимум один специальный символ (!, $, %, &, ...)!</div>
          <div class="v-messages error--text" v-if="lowerCase.value === 'Да' && !$v.new_password.haveLowerCase">Пароль должен содержать минимум одну маленькую букву (a-z)!</div>
          <div class="v-messages error--text" v-if="upperCase.value === 'Да' && !$v.new_password.haveUpperCase">Пароль должен содержать минимум одну большую букву (A-Z)!</div>
          <div class="v-messages error--text" v-if="!$v.new_password.haveCyr">Пароль не должен содержать кириллицу!</div>
          <div class="v-messages error--text" v-if="numbers.value === 'Да' && !$v.new_password.haveNumber">Пароль должен содержать минимум одну цифру (0-9)!</div>
          <div class="v-messages error--text" v-if="new_password.length < +characterCount.value">Минимальная длина пароля {{ characterCount.value }} символов!</div>
          <div class="v-messages error--text" v-if="$v.repeat_password.$invalid">Пароли в полях не совпадают!</div>
        </div>

        <v-btn
          class="mb-3 rounded-lg"
          outlined
          color="secondary"
          :loading="loadingPassword"
          @click="getTempPassword()"
        >Сгенерировать пароль</v-btn>

        <div class="form-group mb-3" :class="{'error-field': $v.repeat_password.$invalid}">
          <p class="form-group__title">Подтверждение пароля</p>
          <v-text-field
            v-model="repeat_password"
            class="rounded-lg"
            rounded
            outlined
            placeholder="Повторно введите новый пароль учётной записи пользователя"
            hide-details
            clearable
            :type="typeField"
          >
            <!-- eslint-disable-next-line -->
            <template #append>
              <v-icon v-if="repeat_password" @click="switchTypeField" class="mr-2">mdi-eye-outline</v-icon>
              <v-icon v-if="$v.repeat_password.$invalid" color="error">mdi-alert-circle</v-icon>
            </template>
          </v-text-field>
          <div class="v-messages error--text" v-if="$v.repeat_password.$invalid">Пароли в полях не совпадают!</div>
        </div>
      </div>

      <div class="popup-form__actions">
        <BtnSaveSlot
          :loading="loadingSubmit"
          :disabled="isInvalidNew"
          @save="submitHandler"
        />
        <BtnCancelSlot @close="closeDialog()"/>
      </div>
    </v-card>
  </v-dialog>
</template>

<script>

import { RESET_PASSWORD, GET_TEMP_PASSWORD } from '../services/api'
import { required, sameAs } from 'vuelidate/lib/validators'
import { mapGetters } from 'vuex'
import { GET_PASSWORD_REQUIREMENTS } from '@/services/app'

export default {
  validations: {
    new_password: {
      required,
      haveLowerCase (val) {
        if (this.lowerCase.value) {
          const regExp = /(?=.*[a-z])/g // проверка на маленькие буквы
          return regExp.test(val)
        }
        return true
      },
      haveUpperCase (val) {
        if (this.upperCase.value) {
          const regExp = /(?=.*[A-Z])/g // проверка на большие буквы
          return regExp.test(val)
        }
        return true
      },
      haveNumber (val) {
        if (this.numbers.value) {
          const regExp = /(?=.*[0-9])/g // проверка на цифры
          return regExp.test(val)
        }
        return true
      },
      haveSymbol (val) {
        if (this.specialSymbols.value === 'Да') {
          val = val.replace(/[A-Za-zА-Яа-я0-9]+/gm, '') // убрать все разрешенные символы (проверка на наличие спецсимвола)
          if (val.length === 0) return false // значит не имеет сиволов
          else return true
        } else return true
      },
      haveCyr (val) {
        const regExp = /(?=.*[А-Яа-я])/g // проверка на кириллицу (не должно быть)
        return !regExp.test(val)
      }
    },
    repeat_password: {
      sameAsPassword: sameAs('new_password')
    }
  },
  data: () => ({
    passwordRequirements: [],
    clearComponentVar: 0,
    isReset: false,
    loading: true,
    loadingPassword: true,
    loadingSubmit: false,
    new_password: '',
    repeat_password: '',
    typeField: 'password'
  }),

  computed: {
    ...mapGetters('users', ['GET_USER_KEY']),

    id () {
      return this.GET_USER_KEY('id')
    },

    numbers () {
      return this.passwordRequirements.find(param => param.code === 'numbers')
    },

    lowerCase () {
      return this.passwordRequirements.find(param => param.code === 'lower_case')
    },

    upperCase () {
      return this.passwordRequirements.find(param => param.code === 'upper_case')
    },

    specialSymbols () {
      return this.passwordRequirements.find(param => param.code === 'special_symbols')
    },

    characterCount () {
      return this.passwordRequirements.find(param => param.code === 'character_count')
    },

    isInvalidNew () {
      return (this.$v.new_password.$invalid && this.new_password) || (!this.$v.new_password.$invalid && this.$v.repeat_password.$invalid)
    }
  },

  async mounted () {
    this.loading = true
    this.passwordRequirements = await GET_PASSWORD_REQUIREMENTS()
    this.loading = false
    await this.getTempPassword()
  },

  methods: {
    async getTempPassword () {
      this.loadingPassword = true
      try {
        this.new_password = await GET_TEMP_PASSWORD()
      } catch (error) {
        console.log(error)
      } finally {
        this.loadingPassword = false
      }
    },

    closeDialog () {
      this.isReset = false
      this.clearComponentVar++
    },

    async submitHandler () {
      this.loadingSubmit = true
      try {
        await RESET_PASSWORD(this.id, { new_password: this.new_password })
      } catch (e) {
        console.log(e)
      } finally {
        this.loadingSubmit = false
        this.closeDialog()
      }
    },

    switchTypeField () {
      if (this.typeField === 'text') this.typeField = 'password'
      else this.typeField = 'text'
    }
  }
}
</script>

<style lang="scss">
</style>
