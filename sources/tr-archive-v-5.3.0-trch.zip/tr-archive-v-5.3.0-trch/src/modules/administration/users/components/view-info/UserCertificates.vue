<template>
  <div class="detail__item">
    <p class="detail__item-title">Начало действия учетной записи</p>
    <EditingStartDate
      v-if="isEdit"
      @change-mode="isEdit = false"
      @close="isEdit = false"
    />

    <div v-else class="detail-flex">
      <span class="detail__value">{{ startDate }}</span>
      <v-btn class="circle circle__btn circle--white" icon @click="isEdit = true">
        <v-icon color="secondary">mdi-pencil-outline</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script>

const EditingStartDate = () => import('../editing-info/EditingStartDate.vue')

export default {
  name: 'UserStartDate',

  components: {
    EditingStartDate
  },

  data: () => ({
    isEdit: false
  }),

  computed: {
    startDate () {
      return this.$store.getters['users/GET_USER_START']
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
