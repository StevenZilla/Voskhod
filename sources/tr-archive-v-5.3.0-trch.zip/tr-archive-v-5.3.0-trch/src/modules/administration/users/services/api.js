import api from '@/services/api'
import notify from '@/services/notify'
import store from '@/storages'
import mixin from '@/utils/mixins'
import { NativeEventSource, EventSourcePolyfill } from '@/plugins/EventSourcePolyfill'
const EventSource = NativeEventSource || EventSourcePolyfill

export async function GET_USERS_INDEX (params1, params2) {
  const searchParams = mixin.methods.combineSearchParamsMix(params1, params2)
  store.dispatch('users/SET_VALUE', { key: 'userLoading', value: true })
  try {
    !searchParams ? new URLSearchParams() : searchParams.toString()
    const resp = await api.get('/ead/users', { params: searchParams })
    store.dispatch('users/SET_VALUE', { key: 'userList', value: resp.data })
  } catch (error) {
    store.dispatch('SET_VALUE', { key: 'error', value: true })
    throw (error)
  } finally {
    store.dispatch('users/SET_VALUE', { key: 'userLoading', value: false })
  }
}

export async function GET_DETAIL_USER (id) {
  try {
    const resp = await api.get(`/ead/users/${id}`)
    store.dispatch('users/SET_VALUE', { key: 'detailUser', value: resp.data })
  } catch (error) {
    console.log(error.response)
  }
}

export async function RESET_PASSWORD (id, data) {
  try {
    const resp = await api.put(`/ead/users/${id}/reset_password`, data)
    return resp.data.password
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function GET_USER_ACCESS (id) {
  const host = `/ead/users/${id}/permissions`
  const res = await api.get(host)
  return res.data
}

export async function CHANGE_USER_ACCESS (idUser, techName, rule) {
  const host = `/ead/users/${idUser}/permissions/${techName}`
  await api.patch(host, rule)
}

export async function UPDATE_USER (userData, id) {
  try {
    await api.patch(`/ead/users/${id}`, userData)
  } catch (error) {
    console.log(error)
  }
}

export async function UPDATE_CERTIFICATE (sertData, id) {
  return await api.put(`/ead/users/${id}/serts`, sertData)
}

export async function GET_USER_SUBDIVISIONS (id) {
  const host = `/v2/admin/users/${id}/subdivisions?is_include_end_date_over=false`
  const res = await api.get(host)
  return res.data
}

export async function SET_ORGANIZATION (id, subdivisionObj) {
  return await api.post(`/v2/admin/users/${id}/subdivisions`, subdivisionObj)
}

export async function UPDATE_DIVISION (idUser, idDivision, subdivisionObj) {
  return await api.put(`/v2/admin/users/${idUser}/subdivisions/${idDivision}`, subdivisionObj)
}

export async function DELETE_ORGANIZATION (id, subdivisionObj) {
  return await api.delete(`/v2/admin/users/${id}/subdivisions`, subdivisionObj)
}

export async function DELETE_DIVISION (idUser, idDivision, subdivisionObj) {
  return await api.delete(`/v2/admin/users/${idUser}/subdivisions/${idDivision}`, subdivisionObj)
}

export async function GET_TEMP_PASSWORD () {
  try {
    const resp = await api.get('/ead/users/time_password')
    return resp.data.password
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function CREATE_USER (createObj) {
  return await api.post('/ead/users', createObj)
}

export async function GET_USER_NOTIFICATION_COOKIE () {
  return await api.get('v2/ead/users/notification_cookie')
}

export async function SETUP_STREAM () {
  const uid = localStorage.getItem('uid')
  const es = new EventSourcePolyfill(`${notify.defaults.baseURL}/notification/stream`, {
    withCredentials: true,
    headers: { uid }
  })

  es.addEventListener('message', async event => {
    console.log('event.parsed', event.parsed)
    // count = event.parsed.total
    store.dispatch('users/SET_VALUE', { key: 'userNotifications', value: event.parsed.unread_count })
  })

  es.addEventListener('error', event => {
    console.log('Event was closed')
    if (event.readyState === EventSource.CLOSED) {
      console.log(EventSource)
    }
  })
}

export async function GET_USER_NOTIFICATION (query) {
  const res = await notify.get('notification', { params: query })
  return res.data
}

export async function READ_NOTIFICATION (id) {
  let host = 'notification/read'
  if (id) host += `/${id}`
  return await notify.get(host)
}
