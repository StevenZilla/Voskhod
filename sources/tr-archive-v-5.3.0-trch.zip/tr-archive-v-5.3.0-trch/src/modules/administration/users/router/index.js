import { userEvent } from '@/event-code'
import { administration, usersDetail, users } from '@/permissions'
const UsersPage = () => import(/* webpackChunkName: 'users-page' */ '../views/UsersPage.vue')
const DetailUser = () => import(/* webpackChunkName: 'detail-user' */ '../views/DetailUser.vue')

const usersRouter = [
  {
    name: 'UsersPage',
    path: users.path,
    component: UsersPage,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Пользователи'
        }
      ],
      tech_name: administration.code
    }
  },
  {
    name: 'detail-user',
    path: `${usersDetail.path}/:id`,
    component: DetailUser,
    meta: {
      breadcrumb: [
        {
          text: 'Администрирование'
        },
        {
          text: 'Пользователи',
          to: users.path,
          exact: true
        },
        {
          text: 'Просмотр пользователя'
        }
      ],
      parent: users.path,
      tech_name: administration.code,
      code: userEvent.code
    }
  }
]

export default router => {
  router.addRoutes(usersRouter)
}
