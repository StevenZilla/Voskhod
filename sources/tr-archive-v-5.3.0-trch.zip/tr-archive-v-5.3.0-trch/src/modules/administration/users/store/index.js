export default {
  namespaced: true,
  state: {
    modeUser: 'view',
    userNotifications: 0,
    userList: {},
    userLoading: false,
    detailUser: {}
  },

  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },

  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },

  getters: {
    GET_USER_KEY: state => code => {
      if (!state.detailUser) return {}
      return state.detailUser[code]
    },

    GET_USER_CERTIFICATES: state => {
      if (!state.detailUser.serts) return []
      return state.detailUser.serts
    },

    GET_USER_ROLES: state => {
      if (!state.detailUser.system_roles) return []
      return state.detailUser.system_roles
    }
  }
}
