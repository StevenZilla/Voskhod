<template>
  <TemplatePage>
    <template #title>Пользователи</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @refresh-data="refreshData"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
      </div>

      <v-data-table
        class="main-table scroll-table sortable-table"
        no-data-text="Нет данных"
        item-key="id"
        loading-text="Загрузка данных"
        hide-default-footer
        :loading="userLoading"
        :headers="headersUsers"
        :options.sync="options"
        :items="userList.users"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :server-items-length="userList.count"
        :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
        @page-count="pageCount = $event"
        @click:row="showDetail"
      >
        <!-- eslint-disable-next-line -->
        <template v-slot:item.is_block="{ isSelected, select, item }">
          <div class="d-flex justify-center checkbox-color">
            <v-simple-checkbox
              v-if="item.is_block === true"
              v-ripple
              :value="item.is_block === true"
              disabled
            ></v-simple-checkbox>
            <v-simple-checkbox v-ripple disabled v-else></v-simple-checkbox>
          </div>
        </template>

        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.start_date="{item}">
          <span v-if="item.start_date">{{ $_formatDate(item.start_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.end_date="{item}">
          <span v-if="item.end_date">{{ $_formatDate(item.end_date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_USERS_INDEX } from '../services/api'
import { mapState } from 'vuex'

import SearchPanel from '../components/SearchPanel.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'UsersPage',
  components: {
    TemplatePage,
    SearchPanel
  },
  data: () => ({
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [],
    headersUsers: [
      {
        text: '№',
        align: 'start',
        sortable: false,
        value: 'id',
        width: '4%'
      },
      {
        text: 'ФИО',
        value: 'fio',
        width: '25%'
      },
      {
        text: 'Логин',
        value: 'login',
        width: '12%'
      },
      {
        text: 'Email',
        value: 'email',
        width: '15%'
      },
      {
        text: 'Начало действия',
        value: 'start_date',
        width: '15%'
      },
      {
        text: 'Окончание действия',
        value: 'end_date',
        width: '15%'
      },
      {
        text: 'Заблокирован',
        align: 'center',
        sortable: true,
        value: 'is_block',
        width: '20%'
      }
    ]
  }),
  watch: {
    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          await GET_USERS_INDEX(this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      userList: state => state.users.userList,
      userLoading: state => state.users.userLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.userList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },
  methods: {
    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      await GET_USERS_INDEX(this.filterParams, this.sortParams)
    },

    refreshData (evt) {
      GET_USERS_INDEX()
      this.showDetail(evt)
      this.clearForm++
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-user', params: { id: _id } })
    }
  },

  mounted () {
    GET_USERS_INDEX()

    if (this.$route.params.id) {
      this.showDetail(Number(this.$route.params.id))
    }
  }
}
</script>

<style>

</style>
