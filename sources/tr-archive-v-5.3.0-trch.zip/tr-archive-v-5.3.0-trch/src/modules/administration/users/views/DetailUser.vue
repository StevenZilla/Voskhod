<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <div class="detail__main-info">
        <h2 class="detail__title">Профиль пользователя</h2>

        <ViewMainInfo>
          <template #fio>
            <UserFio
                @update-editing="updateEditing('UserFio', $event)"
            />
          </template>

          <template #login>
            <UserLogin/>
          </template>

          <template #email>
            <UserEmail
                @update-editing="updateEditing('UserEmail', $event)"
            />
          </template>

          <template #update-date>
            <UserUpdateDate/>
          </template>

          <template #log-date>
            <UserLogDate/>
          </template>

          <template #2fa>
            <User2fa
                @update-editing="updateEditing('User2fa', $event)"
            />
          </template>

          <template #block>
            <UserBlock
                @update-editing="updateEditing('UserBlock', $event)"
            />
          </template>

          <template #oid_esia>
            <OidEsia/>
          </template>
        </ViewMainInfo>
      </div>

      <!-- НАЧАЛО И ОКОНЧАНИЕ ДЕЙСТВИЯ УЧЕТНОЙ ЗАПИСИ -->
      <ViewValidityUser>
        <template #start-date>
          <UserStartDate
              @update-editing="updateEditing('UserStartDate', $event)"
          />
        </template>

        <template #end-date>
          <UserEndDate
              @update-editing="updateEditing('UserEndDate', $event)"
          />
        </template>
      </ViewValidityUser>

      <!-- ПОДРАЗДЕЛЕНИЯ -->
      <BlockSubdivisions
          @update-editing="updateEditing('BlockSubdivisions', $event)"
      />

      <!-- СЕРТИФИКАТЫ -->
      <ViewCertificatesUser
          @update-editing="updateEditing('ViewCertificatesUser', $event)"
      />

      <!-- РОЛИ ПОЛЬЗОВАТЕЛЯ -->
      <ViewRolesUser
          @update-editing="updateEditing('ViewRolesUser', $event)"
      />

      <!-- ДОСТУП К КОМПОНЕНТАМ СИСТЕМЫ -->
      <BlockAccessUser
          @update-editing="updateEditing('BlockAccessUser', $event)"
      />

      <TemplateButtons>
        <template #buttons-right>
          <v-btn
            data-qa="close"
            class="rounded-lg"
            color="secondary"
            @click="$_closeDetail()"
          >Закрыть
          </v-btn>
        </template>
      </TemplateButtons>

        <v-dialog
            v-model="dialog"
            persistent
            max-width="500"
            content-class="dialog-auto-height"
        >
            <ConfirmCancel @cancel="dialog = false" @confirm="confirmLeave"/>
        </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DETAIL_USER } from '../services/api'
import { mapState } from 'vuex'

import ViewMainInfo from '../components/view-info/ViewMainInfo.vue'
import ViewValidityUser from '../components/view-info/ViewValidityUser.vue'
import BlockSubdivisions from '../components/BlockSubdivisions.vue'
import ViewCertificatesUser from '../components/view-info/ViewCertificatesUser.vue'
import ViewRolesUser from '../components/view-info/ViewRolesUser.vue'
import BlockAccessUser from '../components/BlockAccessUser.vue'
import UserFio from '../components/view-info/UserFio.vue'
import OidEsia from '../components/view-info/OidEsia.vue'
import UserLogin from '../components/view-info/UserLogin.vue'
import UserEmail from '../components/view-info/UserEmail.vue'
import UserUpdateDate from '../components/view-info/UserUpdateDate.vue'
import UserLogDate from '../components/view-info/UserLogDate.vue'
import User2fa from '../components/view-info/User2fa.vue'
import UserBlock from '../components/view-info/UserBlock.vue'
import UserStartDate from '../components/view-info/UserStartDate.vue'
import UserEndDate from '../components/view-info/UserEndDate.vue'

import ConfirmCancel from '@/components/ConfirmCancel.vue'

export default {
  name: 'DetailUser',
  components: {
    BlockSubdivisions,
    ViewCertificatesUser,
    ViewRolesUser,
    ViewValidityUser,
    ViewMainInfo,
    BlockAccessUser,
    UserFio,
    UserLogin,
    UserEmail,
    UserUpdateDate,
    UserLogDate,
    User2fa,
    UserBlock,
    UserStartDate,
    UserEndDate,
    OidEsia,
    ConfirmCancel
  },

  data: () => ({
    loading: false,
    dialog: false,
    confirmCallback: null,
    editingStates: {}
  }),

  watch: {
    $route: {
      async handler (newV, oldV) {
        if (!oldV || newV.name === oldV.name) await this.getData()
      },
      immediate: true
    }
  },

  computed: {
    ...mapState({
      detailUser: state => state.usersStore.detailUser,
      error: state => state.error
    })
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    async getData () {
      this.loading = true
      try {
        await GET_DETAIL_USER(this.$route.params.id)
      } catch (error) {
        this.setErrorMix(error.response?.data)
      } finally {
        this.loading = false
      }
    },

    checkEditingMode (next) {
      const isAnyEditing = Object.values(this.editingStates).some(state => state)
      if (isAnyEditing) {
        this.dialog = true
        this.confirmCallback = next
      } else {
        next()
      }
    },

    confirmLeave () {
      this.dialog = false
      this.confirmCallback()
    },

    updateEditing (componentName, isEditing) {
      this.$set(this.editingStates, componentName, isEditing)
    }
  }
}
</script>

<style lang="scss">

</style>
