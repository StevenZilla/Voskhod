import api from '@/services/api'
import store from '@/storages'

export async function GET_DETAIL_ED (id) {
  const resp = await api.get(`/v2/ead/eds/${id}`)
  store.dispatch('eds/SET_VALUE', { key: 'detailEd', value: resp.data })
}

export async function DELETE_ED (id) {
  return await api.delete(`/v2/ead/eds/${id}`)
}

export async function GET_SUBDIVISION_HISTORY (id) {
  try {
    const resp = await api.get(`v2/admin/nsi/subdivisions/liquidate?ed_id=${id}`)
    store.dispatch('eds/SET_VALUE', { key: 'transitInfo', value: resp.data })
  } catch (error) {
    console.log(error)
    // throw (error)
  }
}

export async function GET_SUGGEST_QUERY (q) {
  const resp = await api.get(`/opensearch/eds/userquery?q=${q}`)
  return resp.data
}

export async function GET_OPENSEARCH_EDS (config) {
  const resp = await api.post('/opensearch/proxy/_search', config)
  // console.log('resp', resp.data)
  return resp.data
}

export async function GET_OPENSEARCH_TRANSFORM (query) {
  const resp = await api.get(`/opensearch/proxy/_msearch?q=${query}`)
  // console.log('resp', resp.data)
  return resp.data
}

export async function GET_ED_FILES (id) {
  const res = await api.get(`/v2/ead/eds/${id}/files`)
  await store.dispatch('eds/SET_VALUE', { key: 'edFiles', value: res.data.files })
  // return res.data.files
}

export async function UPDATE_ED (id, edObject) {
  await api.put(`v2/ead/eds/${id}`, edObject)
  store.dispatch('eds/CLEAR_DIRTY')
  // await GET_DETAIL_ED(id)
}

export async function UPDATE_FILE_ED (id, formData) {
  await api.post(`v2/ead/eds/${id}/files`, formData)
  // store.dispatch('eds/PUSH_ARRAY', null)
}

export async function CHECK_FILES_ED (formData) {
  const res = await api.post('/v2/ead/eds/verify', formData)
  // store.dispatch('eds/SET_VALUE', { key: 'errorFiles', value: res.data })
  return res.data
}

export async function CHECK_ANTIVIRUS (formData) {
  const res = await api.post('/antivirus/check', formData)
  return res.data
}

export async function GET_ED_STATUSES_LIST () {
  const res = await api.get('/ead/nsi/ed_statuses')
  return res.data.ed_statuses.map(item => ({ text: item.value, value: item.id }))
}

export async function GET_ED_MEDIA_LIST () {
  const res = await api.get('/ead/nsi/ed/media_types')
  // .map(item => ({ text: item.value, value: item.id }))
  return res.data
}

export async function GET_SOURCES_LIST (query) {
  const res = await api.get('/v2/nsi/sources', { params: query })
  // .map(item => ({ text: item.value, value: item.id }))
  return res.data.sources
}

export async function GET_ROLES_LIST () {
  const res = await api.get('/ead/nsi/file_roles')
  return res.data.file_roles
}

export async function CREATE_ED (edObject) {
  const resp = await api.post('v2/ead/eds', edObject)
  store.dispatch('eds/CLEAR_DIRTY')
  return resp
}

export async function UPLOAD_ED (formData) {
  const response = await api.post('/v2/ead/eds/upload', formData)
  return response
}
