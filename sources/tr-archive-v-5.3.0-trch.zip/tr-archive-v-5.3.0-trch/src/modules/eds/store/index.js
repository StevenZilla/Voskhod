export default {
  namespaced: true,
  state: {
    dirtyBlocks: [],
    edFiles: [],
    edsList: {},
    edLoading: false,
    edStatusesList: [],
    detailEd: {},
    errorFiles: {}
  },

  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    },

    setDirty (state, object) {
      if (!object) {
        state.dirtyBlocks = []
        return
      }
      state.dirtyBlocks.push(object)
    },

    clearDirty (state, code) {
      if (!code) {
        state.dirtyBlocks = []
        return
      }
      const indexDirtyBlock = state.dirtyBlocks.findIndex(block => block.code === code)
      if (indexDirtyBlock !== -1) state.dirtyBlocks.splice(indexDirtyBlock, 1)
    }
  },

  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    },

    SET_DIRTY ({ commit }, object) {
      commit('setDirty', object)
    },

    CLEAR_DIRTY ({ commit }, code) {
      commit('clearDirty', code)
    }
  },

  getters: {
    GET_ED_KEY: state => code => {
      if (!state.detailEd) return {}
      return state.detailEd[code]
    },

    GET_FILE_TYPE_DOCUMENT: state => {
      if (!state.edFiles.length) return
      const document = state.edFiles.find(item => item.file_role.code === 'document')
      console.log('document', document)
      return document
    },

    GET_DOSSIER_ID: state => {
      if (!state.detailEd.dossier) return

      return state.detailEd.dossier.id
    },

    GET_ED_DSP: state => {
      if (state.detailEd.is_dsp === undefined) return

      return state.detailEd.is_dsp
    },

    GET_VIEW_BUTTONS: state => {
      if (!state.detailEd.view_buttons) return

      return state.detailEd.view_buttons
    }
  }
}
