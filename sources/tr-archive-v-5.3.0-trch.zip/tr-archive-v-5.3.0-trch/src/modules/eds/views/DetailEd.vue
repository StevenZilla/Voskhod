<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewEdInfo @refresh="refreshData()"/>

      <v-dialog
        v-model="dialog"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
      >
        <ConfirmCancel
          :blocks="blocks"
          @cancel="dialog = false"
          @confirm="confirmLeave"
        />
      </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { GET_DETAIL_ED, GET_SUBDIVISION_HISTORY } from '../services/api'
import { mapState } from 'vuex'
import ConfirmCancel from '@/components/ConfirmCancel.vue'

const ViewEdInfo = () => import(/* webpackChunkName: 'main-info-ed' */ '../components/view-info/ViewEdInfo.vue')

export default {
  name: 'detail-ed',

  components: {
    ConfirmCancel,
    ViewEdInfo
  },

  data: () => ({
    confirmCallback: null,
    blocks: [],
    dialog: false,
    loading: true
  }),

  computed: {
    ...mapState({
      dirtyBlocks: state => state.eds.dirtyBlocks,
      error: state => state.error
    })
  },

  async mounted () {
    await this.getData()
  },

  async beforeRouteUpdate (to, from, next) {
    this.$store.dispatch('eds/CLEAR_DIRTY')
    await this.getData(to.params.id)
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    checkEditingMode (next) {
      if (this.dirtyBlocks.length) {
        this.blocks = this.dirtyBlocks.map(item => item.name)
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
      }
    },

    confirmLeave () {
      this.dialog = false
      this.$store.dispatch('eds/CLEAR_DIRTY')
      this.confirmCallback()
    },

    refreshData () {
      this.getData()
    },

    async getData (id) {
      const _id = id || this.$route.params.id
      this.loading = true
      try {
        await GET_DETAIL_ED(_id)
        await GET_SUBDIVISION_HISTORY(_id)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
