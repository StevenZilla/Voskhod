<template>
  <TemplatePage>
    <template #title>
      Электронные документы
    </template>

    <template #title-additional>
      <v-tabs class="page-pills" v-model="typeSearch">
        <v-tab :ripple="false">Обычный поиск</v-tab>
        <v-tab :ripple="false">Расширенный поиск</v-tab>
      </v-tabs>
    </template>

    <template #content>
      <v-tabs-items
        v-model="typeSearch"
        class="page-tabs"
      >
        <v-tab-item>
          <v-snackbar
            color="success"
            v-model='showSnackbar'
            :top="true"
            variant="outlined"
          >
            <span>ЭД с делами успешно загружены</span>
            <template v-slot:action>
              <v-icon
                color="white"
                @click="showSnackbar = false"
              >mdi-close
              </v-icon>
            </template>
          </v-snackbar>

          <SearchPanel
            @success-loadEd="showSnackbar = true"
            @set-filters="acceptFilters($event)"
            @clear-filters="refreshData()"
            @refresh-data="refreshData($event)"
          />

          <!-- ФУНКЦИОНАЛ СКРЫТИЯ КОЛОНОК -->
          <div class="mb-5 d-flex justify-space-between align-center">
            <h2 class="results-title">Результаты поиска</h2>
            <SettingsTableVue
              :code="'edPage'"
              :headers="headers"
              :headersSettingsOutside="headersSettingsOutside"
              :headersList="headersList"
              @updateHeaders="headers = [...$event]"
            />
          </div>

          <v-data-table
            item-key="id"
            class="main-table scroll-table sortable-table"
            hide-default-footer
            no-data-text="Нет данных"
            loading-text="Загрузка данных"
            :headers="headers"
            :items="edsResponse.eds"
            :server-items-length="edsResponse.count"
            :loading="edLoading"
            :item-class="checkMessageError"
            :options.sync="options"
            :page.sync="page"
            :items-per-page="itemsPerPage"
            :header-props="{
              'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
            }"
            @click:row="showDetail"
            @page-count="pageCount = $event"
          >
            <template #progress>
              <v-progress-linear
                indeterminate
                height="5"
                color="secondary"
              ></v-progress-linear>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.ed_cipher="{item}">
              <div>
                <v-icon v-if="item.is_deleted" class="mr-2" color="black">mdi-delete</v-icon>
                <span v-if="item.ed_cipher">
                  <v-chip
                    class="ma-2 info-badge"
                    color="#00A65A"
                    text-color="white"
                  ><span style="font-size: 16px"
                  >{{ item.ed_cipher }}</span>
                  </v-chip>
                </span>
                <span v-else style="color:#CBCBCD">Нет данных</span>
              </div>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.reg_date="{item}">
              <span v-if="item.reg_date">{{ $_formatDate(item.reg_date) }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.create_date="{item}">
              <span v-if="item.create_date">{{ $_formatDate(item.create_date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.update_date="{item}">
              <span v-if="item.update_date">{{ $_formatDate(item.update_date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.is_trans_temp="{item}">
              <span>{{ item.ak ? 'Да' : 'Нет' }}</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.tk.status.value="{item}">
              <span v-if="!item.tk" style="color:#CBCBCD">Нет данных</span>
              <span v-else>{{ item.tk.status.value }}</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.tk.form_date="{item}">
              <span v-if="item.tk">{{ $_formatDate(item.tk.form_date, 'time') }}</span>
              <span v-else style="color:#CBCBCD">Нет данных</span>
            </template>

            <!-- eslint-disable-next-line -->
            <template v-slot:item.is_dsp="{item}">
              <div v-if="item.is_dsp">
                <v-chip
                  class="info-badge"
                  color="warning"
                  text-color="white"
                >ДСП
                </v-chip>
              </div>
              <span v-else>Нет</span>
            </template>
            <!-- eslint-disable-next-line -->
            <template v-slot:item.files="{item}">
              <v-btn
                color="secondary"
                class="rounded-lg"
                icon
                @click.stop="downloadZip(item)"
              >
                <v-icon color="secondary">mdi-download-circle-outline</v-icon>
              </v-btn>
<!--                <div class="block-error">{{ checkMessageError(item, 'message').message_error }}</div>-->

              <!--          <v-btn-->
              <!--            color="secondary"-->
              <!--            class="rounded-lg"-->
              <!--            icon-->
              <!--            @click.stop="downloadZip(item)"-->
              <!--          ><v-progress-circular-->
              <!--            v-if="item.isDownload !== undefined && item.isDownload === true"-->
              <!--            color="primary"-->
              <!--            indeterminate-->
              <!--            :width="3"-->
              <!--          ></v-progress-circular>-->
              <!--            <v-icon color="secondary" v-else>mdi-download-circle-outline</v-icon>-->
              <!--          </v-btn>-->
            </template>

            <template #footer="{props}">
              <PaginationTable
                :page.sync="page"
                :pagination="props.pagination"
              />
            </template>
          </v-data-table>
        </v-tab-item>

        <v-tab-item>
          <SearchComponent/>
        </v-tab-item>
      </v-tabs-items>
    </template>
  </TemplatePage>
</template>

<script>

import { GET_EDS_RESPONSE } from '@/services/app'
import { mapState } from 'vuex'
import SearchPanel from '../components/SearchPanel.vue'
import SearchComponent from '../components/semantic-search/SearchComponent.vue'
import SettingsTableVue from '@/components/SettingsTableVue.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'EdsPage',

  components: {
    TemplatePage,
    SearchComponent,
    SearchPanel,
    SettingsTableVue
  },

  data: () => ({
    typeSearch: null,
    edsResponse: {},
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [],
    headersSettingsOutside: ['num', 'name', 'files'],
    showSnackbar: false,
    headersList: [
      {
        text: 'Архивный шифр',
        value: 'ed_cipher',
        width: '250px'
      },
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '250px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '530px'
      },
      {
        text: 'Дата регистрации',
        value: 'reg_date',
        width: '180px'
      },
      {
        text: 'Дата и время создания в системе',
        value: 'create_date',
        width: '235px'
      },
      {
        text: 'Дата последнего обновления',
        value: 'update_date',
        width: '235px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type.value',
        width: '235px'
      },
      {
        text: 'Статус обработки',
        value: 'ed_status.value',
        width: '175px'
      },
      {
        text: 'Статус отправки в ЦХЭД',
        value: 'tk.status.value',
        width: '215px '
      },
      {
        text: 'Дата и время отправки в ЦХЭД',
        value: 'tk.form_date',
        width: '215px'
      },
      {
        text: 'Во временном хранилище',
        value: 'is_trans_temp',
        width: '215px '
      },
      {
        text: 'Источник',
        value: 'source.value',
        width: '430px'
      },
      {
        text: 'Отметка',
        value: 'is_dsp',
        width: '190px',
        align: 'center'
      },
      {
        text: 'Скачать все',
        sortable: false,
        value: 'files',
        align: 'center',
        width: '80px',
        cellClass: 'not-hover'
      }
    ]
  }),

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          GET_EDS_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.edsResponse = resp })
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      edLoading: state => state.eds.edLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.edsResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source'
          } else if (sortBy[0].indexOf('media_type.value') !== -1) {
            par += 'media_type_value'
          } else if (sortBy[0].indexOf('tk') !== -1) {
            par += 'tk_status_value'
          } else if (sortBy[0].indexOf('ed_status') !== -1) {
            par += 'ed_status_name'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    GET_EDS_RESPONSE().then(resp => { this.edsResponse = resp })
  },

  methods: {
    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      this.edsResponse = await GET_EDS_RESPONSE(this.filterParams, this.sortParams)
    },

    refreshData (evt) {
      GET_EDS_RESPONSE().then(resp => { this.edsResponse = resp })
      // если передали айдишник то перейти в карточку
      if (evt) this.showDetail(evt)
    },

    closeSettings () {
      this.isShowSettingsTable = false
    },

    checkMessageError (e, msg) {
      const errorFile = e.files.find(file => {
        return (file.file_role.id === 5 || file.file_role.value === 'Подпись') && (file.message_error !== null && file.message_error !== '')
      })
      if (msg) {
        return errorFile
      } else {
        return errorFile ? 'error-file' : ''
      }
    },

    downloadZip (doc) {
      const JSZip = require('jszip')
      const JSZipUtils = require('jszip-utils')
      const FileSaver = require('file-saver')
      const zip = new JSZip()
      this.$set(doc, 'isDownload', true)
      let count = 0
      const errors = []

      doc.files.forEach(item => {
        JSZipUtils.getBinaryContent((this.$config.VUE_APP_HOST.replace('/api', '') + '/' + item.uri), async (err, data) => {
          if (err) {
            errors.push(err)
          }
          zip.file(item.name, data, { binary: true })
          count++
          if (count === doc.files.length) { // если скачаны все файлы(или получили ошибку), то сохранить архив
            const content = await zip.generateAsync({ type: 'blob' })
            let nameDoc = doc.name.replaceAll('.', '_').substring(0, 90)
            nameDoc += ' ' + doc.num.substring(0, 90)
            // const nameDoc = doc.name.replaceAll('.', '_') + ' ' + doc.num
            FileSaver.saveAs(content, nameDoc)
            this.$set(doc, 'isDownload', false)
          }
        })
      })
      count = 0
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-ed', params: { id: _id } })
    }
  }
}
</script>

<style lang="scss">
.filter-field {
  width: 60%;

  .v-input__slot {
    border: 1px solid #A7A8AB;
  }
}
</style>
