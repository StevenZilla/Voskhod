import { eadEvent } from '@/event-code'
import { ed, edDetail } from '@/permissions'
const EdsPage = () => import(/* webpackChunkName: 'eds-page' */ '../views/EdsPage')
const DetailEd = () => import(/* webpackChunkName: 'detail-ed' */ '../views/DetailEd')

const edsRouter = [
  {
    name: 'EdsPage',
    path: ed.path,
    component: EdsPage,
    meta: {
      breadcrumb: [
        {
          text: 'Электронные документы',
          exact: true
        }
      ],
      tech_name: ed.code
    }
  },
  {
    name: 'detail-ed',
    path: `${edDetail.path}/:id`,
    component: DetailEd,
    meta: {
      breadcrumb: [
        {
          text: 'Электронные документы',
          exact: true,
          to: ed.path
        },
        {
          text: 'Просмотр электронного документа'
        }
      ],
      parent: ed.path,
      tech_name: edDetail.code,
      code: eadEvent.code
    }
  }
]

export default router => {
  router.addRoutes(edsRouter)
}
