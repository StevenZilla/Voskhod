<template>
  <v-card class="detail__additional-info">
    <v-card-text class="no-bg">
      <v-data-table
        item-key="id"
        class="main-table no-hover scroll-table"
        no-data-text="Нет файлов"
        disable-sort
        disable-pagination
        hide-default-footer
        :loading-text="'Загрузка файлов'"
        :item-class="setErrorClass"
        :headers="headers"
        :items="editingFilesList"
      >
        <!-- eslint-disable-next-line -->
        <template v-slot:item.file_role="{ item, index }">
          <FileRole
            :key="index"
            :param="item.file_role"
            @set-property="setFileRole(item, $event)"
          />
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.parent_id="{ item, index }">
          <ParentFile
            :key="index"
            :file="item"
            :items="getRefFiles(item)"
            @set-property="item.parent_id = $event"
          />
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.size="{item}">
          {{ item.size.toFixed(2) }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.changed="{ item, index }">
          <ChangeFile
            :file="item"
            @change-file="changeFile($event, item, index)"
          />
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.is_original="{ item, index }">
          <div class="form-group">
            <v-radio-group
              v-model="item.is_original"
              hide-details
              class="d-flex"
              row
              :disabled="invalidMediaType && (item.file_role && item.file_role.code === 'document')"
            >
              <v-radio
                v-for="(option, index) in copyOptions"
                color="secondary"
                :key="index"
                :label="option.label"
                :value="option.value"
              ></v-radio>
            </v-radio-group>
          </div>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.delete="{item, index}">
          <v-btn
            color="secondary"
            class="rounded-lg"
            icon
            @click="deleteFile(index, item)"
          >
            <v-icon>mdi-delete-outline</v-icon>
          </v-btn>
        </template>

        <template #footer>
          <div class="table-footer">
            <div class="table-footer__left">
              <div class="table-footer__files">
                <BtnUpload
                  @add-files="addFiles($event)"
                  :form-data-files="formDataFiles"
                ></BtnUpload>

                <!--  если параметр false, значит запрещен прием невалидной подписи и ОБЯЗАТЕЛЬНО проверка  -->
<!--                <v-btn-->
<!--                  v-if="!checkSettings.is_reception_not_sign"-->
<!--                  outlined-->
<!--                  color="secondary"-->
<!--                  class="rounded-lg"-->
<!--                  :loading="loadingCheck"-->
<!--                  :disabled="$v.$invalid || !editingFilesList.length"-->
<!--                  @click="checkValidFiles"-->
<!--                >Проверить приложенные файлы-->
<!--                </v-btn>-->

                <p class="ml-3 mb-0">
                  <span class="required-label">*</span> Обязательные поля
                </p>

                <h4 v-if="hasInvalidSign.length" class="flex-100 error--text mb-1">Прием файлов с невалидной подписью запрещен!</h4>

                <div class="flex-100" v-if="hasInvalidSign">
                  <p v-for="(file, ind) in hasInvalidSign" :key="ind" class="error--text mb-1">
                    {{ file.name }} - {{ file.message_error }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapGetters, mapState } from 'vuex'

import _ from 'lodash'
import { CHECK_FILES_ED } from '../../services/api'
import { required } from 'vuelidate/lib/validators'
import FileRole from '../fields-files/FileRole.vue'
import ParentFile from '@/modules/eds/components/fields-files/ParentFile.vue'
import ChangeFile from '@/modules/eds/components/fields-files/ChangeFile.vue'

const BtnUpload = () => import('../fields-files/BtnUpload.vue')

export default {
  components: {
    ChangeFile,
    ParentFile,
    FileRole,
    BtnUpload
  },

  props: {
    trigger: {
      type: Number,
      required: true
    },

    triggerCheckFiles: {
      type: Number,
      required: true
    }
  },

  validations: {
    editingFilesList: {
      $each: {
        file_role: { required }
      },

      isUnique (val) {
        // проверка на наличие ТОЛЬКО 1 файла с типом ДОКУМЕНТ
        const documentArray = val.filter(item => item.file_role.code === 'document')
        return documentArray.length === 1
      },

      isNotDocument (val) {
        // проверка на заполненность данных у файлов с типом !== ДОКУМЕНТ
        const arrFileNotDoc = val.filter(item => item.file_role?.code !== 'document')
        const emptyRole = arrFileNotDoc.find(item => !item.file_role?.id || !item.parent_id)
        return emptyRole === undefined
      }
    }
  },
  data: () => ({
    isDirty: false,
    pk: -1,
    filesIsChecked: true,
    loadingCheck: false,
    loadingFiles: true,
    clickedValidFiles: false,
    originalObj: {}, // чтобы потом сравнить с ним
    editingFilesList: [],
    formDataFiles: [],
    copyOptions: [
      { label: 'Копия', value: false },
      { label: 'Подлинник', value: true }
    ],
    headers: [
      {
        text: 'Наименование',
        value: 'name',
        width: '200px'
      },
      {
        text: 'Роль файла',
        value: 'file_role',
        width: '200px'
      },
      {
        text: 'Относится к файлу',
        value: 'parent_id',
        width: '200px'
      },
      {
        text: 'Обьем, Мб',
        align: 'center',
        value: 'size',
        width: '150px'
      },
      {
        text: 'Заменить файл',
        align: 'center',
        value: 'changed',
        width: '160px'
      },
      {
        text: 'Подлинность',
        align: 'center',
        value: 'is_original',
        width: '100px'
      },
      {
        text: '',
        value: 'delete',
        width: '64px'
      }
    ]
  }),

  watch: {
    trigger (newV) {
      if (newV) {
        this.$emit('fill-data', this.fillData('submit'))
      }
    },

    triggerCheckFiles (newV) {
      if (newV) this.checkValidFiles()
    },

    editingFilesList: {
      handler () {
        if (!_.isEqual(this.originalObj, this.editingFilesList)) this.isDirty = true
        else this.isDirty = false
      },
      deep: true
    },

    isDirty (newV) {
      if (newV) this.setDirty()
      else this.clearDirty()
    },

    invalidData: {
      handler (newVal) {
        this.$emit('change-valid', newVal)
      },
      immediate: true
    },

    isRequiredCheck (newV) {
      this.$emit('need-check', newV)
    }
  },

  computed: {
    ...mapState({
      edFiles: state => state.eds.edFiles,
      checkSettings: state => state.checkSettings
    }),

    ...mapGetters('eds', ['GET_ED_KEY']),

    mediaTypeEd () {
      return this.GET_ED_KEY('media_type')
    },

    hasInvalidSign () {
      return this.editingFilesList.filter(file => file.message_error)
    },

    // ЕСЛИ прием файлов запрещен И файлы не проверены И файлы не инвалидные И они существуют
    isRequiredCheck () {
      return !this.checkSettings.is_reception_not_sign && !this.filesIsChecked &&
        !this.$v.$invalid && this.editingFilesList.length
    },

    invalidData () {
      return this.$v.$invalid || !!this.hasInvalidSign.length
    },

    invalidMediaType () {
      return this.mediaTypeEd.value === 'Бумага' || this.mediaTypeEd.value === 'Электронный вид'
    }
  },

  async mounted () {
    this.prepareData()
  },

  methods: {
    setFileRole (file, role) {
      file.file_role = role
      if (file.file_role?.code === 'document') {
        file.parent_id = null
        file.parent_name = null
        file.is_original = this.mediaTypeEd.code === 'elec_view'
      }
    },

    changeFile (newFile, oldFile, index) {
      this.$set(this.editingFilesList, index, {
        id: this.pk,
        name: newFile.target.files[0].name,
        file_role: oldFile.file_role,
        parent_name: oldFile.parent_name,
        parent_id: oldFile.parent_id,
        size: (newFile.target.files[0].size / 1024) / 1024
      })
      this.$set(this.formDataFiles, index, newFile.target.files[0])
      this.pk--

      // проверка на наличие привязки в других файлах
      this.editingFilesList.forEach(item => {
        if (item.parent_id === oldFile.id) {
          item.parent_id = this.editingFilesList[index].id
          item.parent_name = this.editingFilesList[index].name
        }
      })
    },

    setDirty () {
      const obj = {
        name: 'Файлы',
        code: 'files'
      }
      this.$store.dispatch('eds/SET_DIRTY', obj)
    },

    clearDirty () {
      this.$store.dispatch('eds/CLEAR_DIRTY', 'files')
    },

    addFiles (objectFiles) {
      console.log('objectFiles', objectFiles)
      this.editingFilesList = [...this.editingFilesList, ...objectFiles.fileList]
      this.formDataFiles = [...this.formDataFiles, ...objectFiles.metaFileList]
      this.filesIsChecked = false
      // this.clickedValidFiles = false
      // files.forEach(file => {
      //   this.$set(this.editingFilesList, this.editingFilesList.length, {
      //     id: this.pk,
      //     name: file.name,
      //     is_original: this.mediaTypeEd.code === 'elec_view',
      //     file_role: {},
      //     parent_name: null,
      //     parent_id: null,
      //     size: (file.size / 1024) / 1024
      //   })
      //   this.$set(this.formDataFiles, this.formDataFiles.length, file.file)
      //   this.pk--
      // })
    },

    removeKeys (filesArray) {
      filesArray.forEach(item => {
        if (item.id < 0) delete item.id
        item.fr_id = item.file_role.id
        delete item.file_role
        delete item.parent_id
        delete item.parent_name
        delete item.size
        delete item.message_error
        if (item.children.length) this.removeKeys(item.children)
      })
    },

    fillData (type) {
      const formData = new FormData()
      const copyFiles = {
        files: JSON.parse(JSON.stringify(this.editingFilesList))
      }
      copyFiles.files = this.$_changeTreeV2(copyFiles.files)
      this.removeKeys(copyFiles.files)
      this.formDataFiles.forEach(file => {
        formData.append('files[]', file)
      })
      console.log('copyFiles', copyFiles)
      formData.append('data', JSON.stringify(copyFiles))
      if (type === 'submit') formData.append('_method', 'put')
      return formData
    },

    checkMessageError (e) {
      if (e.file_role.code === 'signature') {
        if (e.message_error !== null && e.message_error !== '') {
          return 'error-file'
        } else return ''
      } else return ''
    },

    prepareData () {
      this.loadingFiles = true
      this.originalObj = JSON.parse(JSON.stringify(this.edFiles))
      this.editingFilesList = JSON.parse(JSON.stringify(this.originalObj))
      this.loadingFiles = false
    },

    setErrorClass (e) {
      if (e.message_error) return 'error-file'
    },

    async checkValidFiles () {
      this.loadingCheck = true
      // this.clickedValidFiles = true
      const formData = await this.fillData()
      this.$emit('updateHandler')
      CHECK_FILES_ED(formData).then(resp => {
        if (resp) {
          for (const prop in resp.error) {
            const invalidFile = this.editingFilesList.find(file => file.name === prop)
            if (invalidFile) invalidFile.message_error = resp.error[prop].message
          }
        }
      }).finally(() => {
        this.filesIsChecked = true
        this.loadingCheck = false
      })
    },

    deleteFile (ind, item) {
      // this.clickedValidFiles = false
      // ищем файл, кто являлся родителем удаляемого
      const same = this.editingFilesList.find(item => item.parent_id === this.editingFilesList[ind].id)
      // если нашли, то удаляем все данные о родителе
      if (same !== undefined) {
        same.parent_id = null
        same.parent_name = null
      }
      this.$delete(this.editingFilesList, ind)

      // ищем удаляемый файл в метаинфе файлов
      const indexFormData = this.formDataFiles.findIndex(dataFile => dataFile.name === item.name)
      // если нашли, то удаляем данные о файле
      if (indexFormData !== -1) this.$delete(this.formDataFiles, indexFormData)
    },

    getRefFiles (file) {
      const arrRefFiles = this.editingFilesList.filter(item => file.id !== item.id)
      return arrRefFiles.map(item => {
        return {
          text: item.name,
          value: item.id
        }
      })
    }
  }
}
</script>

<style lang="scss">

.error-text {
  td:first-child {
    color: var(--v-error-base)
  }
}

.required-label-files {
  color: #C81919;
  position: absolute;
  top: -5px;
  right: -10px;
}

.table-footer__files {
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  .flex-100 {
    margin-top: 10px;
    flex-basis: 100%;
  }
}

.file-btn {
  color: var(--v-secondary-base) !important;
  caret-color: var(--v-secondary-base) !important;
  cursor: pointer;
}
</style>
