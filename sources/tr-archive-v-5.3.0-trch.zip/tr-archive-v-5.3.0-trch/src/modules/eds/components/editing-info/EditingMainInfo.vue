<template>
  <v-card class="create__main-info">
    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12" md="12">
          <div class="d-flex align-end">
            <NameEd :param="originalObj.name" @set-property="$v.editingObj.name.$model = $event"/>
            <Dsp :param="originalObj.is_dsp" @set-property="editingObj.is_dsp = $event"/>
          </div>
        </v-col>

        <v-col cols="12" md="2">
          <NumberEd :param="originalObj.num" @set-property="$v.editingObj.num.$model = $event"/>
        </v-col>

        <v-col cols="12" md="2">
          <RegDate :param="originalObj.reg_date" @set-property="$v.editingObj.reg_date.$model = $event"/>
        </v-col>

        <v-col cols="12" md="3">
          <Subdivision
            :param="originalObj.subdivision"
            :dossier="originalObj.dossier"
            @set-property="editingObj.subdivision = $event, editingObj.dossier = null"
          />
        </v-col>

        <v-col cols="12" md="3">
          <Dossier
            :param="originalObj.dossier"
            :subdivision="editingObj.subdivision"
            @set-property="editingObj.dossier = $event"
          />
        </v-col>

        <v-col cols="12" md="2">
          <EdStatus :param="detailEd.ed_status"/>
        </v-col>

        <v-col cols="12" md="2">
          <ArchiveCipher :param="detailEd.ed_cipher"/>
        </v-col>

        <v-col cols="12" md="2">
          <MediaType :param="originalObj.media_type" @set-property="editingObj.media_type = $event"/>
        </v-col>

        <v-col cols="12" md="2">
          <SaveType :param="detailEd.save_type"/>
        </v-col>

        <v-col cols="12" md="2">
          <SavePeriod :param="detailEd.temp_save_period"/>
        </v-col>

        <v-col cols="12" md="2">
          <Source :param="originalObj.source" @set-property="$v.editingObj.source.$model = $event"/>
        </v-col>

        <v-col cols="12" md="2">
          <SourceEdId :param="originalObj.source_ed_id" @set-property="editingObj.source_ed_id = $event"/>
        </v-col>

        <v-col cols="12" md="2">
          <CreateDate :param="detailEd.create_date"/>
        </v-col>

        <v-col cols="12" md="2">
          <UpdateDate :param="detailEd.update_date"/>
        </v-col>
      </v-row>
      <p class="mt-3"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { required } from 'vuelidate/lib/validators'
import { mapState } from 'vuex'
import NameEd from '../fields-main-info/NameEd.vue'
import Dsp from '../fields-main-info/Dsp.vue'
import NumberEd from '../fields-main-info/NumberEd.vue'
import RegDate from '../fields-main-info/RegDate.vue'
import Subdivision from '../fields-main-info/Subdivision.vue'
import Dossier from '../fields-main-info/Dossier.vue'
import EdStatus from '../fields-main-info/EdStatus.vue'
import ArchiveCipher from '../fields-main-info/ArchiveCipher.vue'
import MediaType from '../fields-main-info/MediaType.vue'
import SaveType from '../fields-main-info/SaveType.vue'
import SavePeriod from '../fields-main-info/SavePeriod.vue'
import Source from '../fields-main-info/Source.vue'
import SourceEdId from '../fields-main-info/SourceEdId.vue'
import CreateDate from '../fields-main-info/CreateDate.vue'
import UpdateDate from '../fields-main-info/UpdateDate.vue'

const _ = require('lodash')

export default {
  components: {
    NameEd,
    Dsp,
    NumberEd,
    RegDate,
    Subdivision,
    Dossier,
    EdStatus,
    ArchiveCipher,
    MediaType,
    SaveType,
    SavePeriod,
    Source,
    SourceEdId,
    CreateDate,
    UpdateDate
  },

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  validations: {
    editingObj: {
      name: { required },
      num: { required },
      reg_date: { required },
      source: { required }
    }
  },

  data: () => ({
    isDirty: false,
    originalObj: {}, // чтобы потом сравнить с ним
    editingObj: {
      name: null,
      is_dsp: false,
      num: null,
      reg_date: null,
      source: null,
      media_type: null,
      dossier: null,
      subdivision: null,
      source_ed_id: null
    }
  }),

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', this.fillData())
    },

    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    editingObj: {
      handler () {
        if (!_.isEqual(this.originalObj, this.editingObj)) this.isDirty = true
        else this.isDirty = false
      },
      deep: true
    },

    isDirty (newV) {
      if (newV) this.setDirty()
      else this.clearDirty()
    }
  },

  computed: {
    ...mapState({
      detailEd: state => state.eds.detailEd
    }),

    invalidData () {
      return this.$v.$invalid
    }
  },

  mounted () {
    this.copyInfo()
  },

  methods: {
    setDirty () {
      const obj = {
        name: 'Общая информация',
        code: 'main'
      }
      this.$store.dispatch('eds/SET_DIRTY', obj)
    },

    clearDirty () {
      this.$store.dispatch('eds/CLEAR_DIRTY', 'main')
    },

    copyInfo () {
      this.originalObj = _.pick(this.detailEd, [
        'name',
        'is_dsp',
        'num',
        'reg_date',
        'source',
        'media_type',
        'dossier',
        'source_ed_id',
        'subdivision'
      ])
    },

    fillData () {
      const copyObj = JSON.parse(JSON.stringify(this.editingObj))
      if (copyObj.dossier) copyObj.dossier_id = copyObj.dossier.id
      else copyObj.dossier_id = null
      if (copyObj.subdivision) copyObj.subdivision_id = copyObj.subdivision.id
      else copyObj.subdivision_id = null
      copyObj.source_id = copyObj.source.id
      copyObj.media_type_id = copyObj.media_type.id
      delete copyObj.dossier
      delete copyObj.source
      delete copyObj.media_type
      delete copyObj.subdivision
      return copyObj
    }
  }
}
</script>

<style lang="scss">

</style>
