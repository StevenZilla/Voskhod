<template>
  <div class="detail__main-info">
    <v-card>
      <!-- <LoadingComponentVue v-if="loading && !error"/> -->
      <v-card-title>
        <h2>История действий</h2>
      </v-card-title>

      <v-data-table
        item-key="id"
        class="main-table sortable-table row-default-cursor"
        hide-default-footer
        :loading="eventsLoading"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        :headers="headers"
        :items="eventsResponse.audits"
        :server-items-length="eventsResponse.count"
        :options.sync="options"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :header-props="{
            'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
          }"
        @page-count="pageCount = $event"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.date="{ item }">
          <span v-if="item.date">{{ $_formatDate(item.date, 'time') }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.subject_name="{ item }">
          <span v-if="item.resource_metadata">{{ item.resource_metadata.subject.subject_name }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </v-card>
  </div>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import { format } from 'date-fns'
import { GET_EVENTS_RESPONSE } from '@/modules/administration/events/services/api'

export default {
  data: () => ({
    format,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    eventsResponse: {},
    headers: [
      {
        text: 'Дата и время',
        value: 'date',
        width: '20%'
      },
      {
        text: 'Тип',
        value: 'type.name',
        width: '20%'
      },
      {
        text: 'Описание',
        value: 'descr',
        width: '40%'
      },
      {
        text: 'Пользователь',
        value: 'subject_name',
        width: '20%'
      }
    ]
  }),

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          this.getData()
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      eventsLoading: state => state.events.eventsLoading
    }),

    ...mapGetters('eds', ['GET_ED_KEY']),

    id () {
      return this.GET_ED_KEY('id')
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      paramsFilter.append('namespace_code', 'ead')
      paramsFilter.append('object_id', this.id)
      return paramsFilter
    },

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.eventsResponse.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('type.name') !== -1) {
            par += 'type_name'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    getData () {
      GET_EVENTS_RESPONSE(this.filterParams, this.sortParams).then(resp => { this.eventsResponse = resp })
    }
  }
}
</script>

<style>
</style>
