<template>
  <v-dialog
    v-model="isCreate"
    hide-overlay
    transition="scroll-y-transition"
    content-class="app-modal"
    attach=".content"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        data-qa="create-ed"
        class="justify-content-end rounded-lg"
        color="secondary"
        v-bind="attrs"
        v-on="on"
      >
        <v-icon class="mr-1">mdi-note-plus-outline</v-icon>
        Добавить документ
      </v-btn>
    </template>

    <TemplateCreate
      :loading="loading"
      :disabled="invalidCreateInfo"
      @save="submitHandler()"
      @close="closeDialog()"
    >
      <template #content>
        <CreateMainInfo
          :trigger="trigger"
          @fill-data="fillData($event)"
          @change-valid="invalidMainForm = $event"
        />
      </template>
    </TemplateCreate>
  </v-dialog>
</template>

<script>

import { CREATE_ED } from '../../services/api'
import { mapState } from 'vuex'

import CreateMainInfo from './CreateMainInfo.vue'

export default {
  name: 'CreateEd',

  components: {
    CreateMainInfo
  },

  data: () => ({
    trigger: 0,
    isCreate: false,
    invalidMainForm: true,
    loading: false,
    createDetailInfo: {}
  }),

  computed: {
    ...mapState({
      errorFiles: state => state.eds.errorFiles
    }),

    invalidCreateInfo () {
      return this.invalidMainForm
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.createDetailInfo, evt)
        resolve()
      })
    },

    async submitHandler () {
      this.loading = true
      this.createDetailInfo = {}
      this.trigger++
      await this.fillData()

      try {
        const resp = await CREATE_ED(this.createDetailInfo)
        this.$emit('refresh-data', resp.data.message)
        this.$emit('clear')
      } finally {
        this.loading = false
      }
    },

    closeDialog () {
      this.isCreate = false
      this.$emit('clear')
    }
  }
}
</script>

<style lang="scss">
</style>
