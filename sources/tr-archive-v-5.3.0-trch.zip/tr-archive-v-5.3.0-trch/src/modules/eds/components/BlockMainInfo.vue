<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2 class="mr-3">Общая информация</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit && viewButtons.is_edit_ed"
          class="circle circle__btn circle--white"
          icon
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-if="isEdit">
          <div class="d-flex">
            <BtnIconSaveSlot
              :disabled="invalidData"
              :loading="loading"
              @save="updateHandler"
            />
            <!-- Чтобы сделать отступ -->
            <div class="mr-3"></div>

            <BtnIconCancelSlot
              :loading="loading"
              @close="cancelEdit()"
            />
          </div>
        </template>
      </div>
    </v-card-title>

    <ViewMainInfo v-if="!isEdit"/>

    <EditingMainInfo
      v-else
      :trigger="trigger"
      @fill-data="fillData($event)"
      @change-valid="invalidData = $event"
    />
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'
import { dossierDetail } from '@/permissions'
import { UPDATE_ED, GET_DETAIL_ED } from '../services/api'
import ViewMainInfo from './view-info/ViewMainInfo.vue'
import EditingMainInfo from './editing-info/EditingMainInfo.vue'

const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  name: 'BlockMainInfo',
  components: {
    ViewMainInfo,
    EditingMainInfo,
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  data: () => ({
    loading: false,
    isEdit: false,
    trigger: 0,
    invalidData: false,
    mainInfoObj: {}
  }),

  computed: {
    ...mapGetters('eds', ['GET_ED_KEY']),

    edId () {
      return this.GET_ED_KEY('id')
    },

    viewButtons () {
      return this.GET_ED_KEY('view_buttons')
    }
  },

  methods: {
    cancelEdit () {
      this.isEdit = false
      this.$store.dispatch('eds/CLEAR_DIRTY')
    },

    showDetail (e) {
      const path = `${dossierDetail.path}/${e.id}`
      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.mainInfoObj, evt)
        console.log('evt', evt)
        resolve()
      })
    },

    async updateHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      try {
        await UPDATE_ED(this.edId, this.mainInfoObj)
        await GET_DETAIL_ED(this.edId)
        this.isEdit = false
        // this.$emit('refresh')
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style>
</style>
