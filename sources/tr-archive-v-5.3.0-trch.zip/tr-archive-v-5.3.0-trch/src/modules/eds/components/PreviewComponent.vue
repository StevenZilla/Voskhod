<template>
  <v-card class="detail__main-info">
    <div class="preview-wrapper">
      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title" v-if="isTitle">Предпросмотр документа</h2>
        <div v-else class="mb-12"></div>
      </div>

      <v-card-text>
        <div v-if="isValidExt && fileUrl" class="webviewer">
          <object v-if="fileTypeDocument.viewer_path" type="type/html" width="100%" height="700px">
            <!-- <iframe :src="fileUrl" type="application/pdf" frameborder="0" width="100%" height="700px"></iframe> -->
            <!-- <iframe v-if="this.initialDoc.viewer_path !== null" :src="fileUrl" type="application/pdf" width="100%" height="1100px"></iframe> -->
            <embed
              type="application/pdf"
              width="100%"
              height="1100px"
              :src="fileUrl"
            />
          </object>
          <p v-else style="color:#CBCBCD">Подготовка документа к просмотру, обновите страницу</p>
        </div>
        <p v-else>Предпросмотр невозможен</p>
      </v-card-text>
    </div>

    <div ref="previewButton" class="preview-button" :class="{'preview-button-none': !isValidExt}"></div>
  </v-card>
</template>

<script>

export default {
  name: 'PreviewComponent',

  data: () => ({
    isTitle: true,
    fileUrl: null,
    renderPreview: 1,
    isValidExt: false
  }),

  computed: {
    fileTypeDocument () {
      return this.$store.getters['eds/GET_FILE_TYPE_DOCUMENT']
    }
  },

  watch: {
    fileTypeDocument (newV) {
      if (newV) {
        this.createPreview()
        const elem = document.querySelector('.detail__row-info')
        const widthContainer = document.querySelector('.detail__row').offsetWidth
        if (localStorage.getItem('preview') === null) {
          localStorage.setItem('preview', '980')
          elem.style.width = (widthContainer - 35) - 980 + 'px'
        } else {
          if (localStorage.getItem('preview') <= 380) {
            this.isTitle = false
          } else {
            this.isTitle = true
          }
          elem.style.width = (widthContainer - 35) - localStorage.getItem('preview') + 'px'
        }
        this.resizePreview()
      }
    }
  },

  methods: {
    createPreview () {
      console.log('this.fileTypeDocument', this.fileTypeDocument)
      if (!this.fileTypeDocument) {
        this.isValidExt = false
        return
      }
      const fileExt = this.fileTypeDocument.file_ext.value
      if (fileExt === 'pdf' || fileExt === 'doc' || fileExt === 'docx' || fileExt === 'rtf') {
        const fileUrl = this.$config.VUE_APP_HOST.replace('/api', '') + '/' + this.fileTypeDocument.viewer_path
        this.$axios.get(fileUrl, { responseType: 'blob', headers: { uid: localStorage.getItem('uid') } })
          .then(res => { this.fileUrl = URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' })) })
          .catch(() => { this.fileUrl = null })
        this.isValidExt = true
      } else {
        this.isValidExt = false
      }
    },

    resizePreview () {
      let myoffset
      const elem = this.$parent.$el.querySelector('#detailBlock')
      const preview = this.$parent.$el.querySelector('#detailPreview')

      const mouseMove = (e) => {
        preview.classList.add('draggable')
        this.isTitle = preview.offsetWidth > 390
        elem.style.width = `${e.clientX - myoffset - elem.offsetLeft}px`
      }

      const myresize = function myrsize (e) {
        myoffset = e.clientX - (elem.offsetLeft + parseInt(window.getComputedStyle(elem).getPropertyValue('width')))
        window.addEventListener('mouseup', mouseUp)
        document.addEventListener('mousemove', mouseMove)
      }

      const _resizeE = () => {
        const borderDiv = this.$refs.previewButton
        if (borderDiv) {
          borderDiv.addEventListener('mousedown', myresize)
        }
      }

      function mouseUp () {
        document.removeEventListener('mousemove', mouseMove)
        window.removeEventListener('mouseup', mouseUp)
        localStorage.setItem('preview', (preview.offsetWidth))
        preview.classList.remove('draggable')
      }

      _resizeE()
    }
  }
}
</script>

<style lang="scss">
.webviewer {
  width: 100%;
}
</style>
