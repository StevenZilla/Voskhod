<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <ArchiveCipher
        class="w-20"
        ref="cipher"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdNumber
        class="w-20"
        ref="edNumber"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <RegisterDate
        class="w-20"
        ref="regDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <CreateDate
        class="w-20"
        ref="createDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <UpdateDate
        class="w-20"
        ref="updateDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdStatus
        class="w-20"
        ref="edStatus"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <EdMediaType
        class="w-20"
        ref="mediaType"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <Classifier
        class="w-20"
        ref="classifier"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <ClassifierKinds
        class="w-40"
        ref="diKinds"
        :reset-filter="resetFilter"
        :selected-classifier="filterObj.classifier"
        :disabled="!filterObj.classifier"
        @set-filter="setFilter($event)"
      />

      <Dsp
        class="w-20"
        ref="isDsp"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <StorageExpirationYear
        class="w-20"
        ref="expirationYear"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <OriginalityFiles
        class="w-20"
        ref="isDocOriginal"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Subdivision
        class="w-20"
        ref="subdivision"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <Source
        class="w-20"
        ref="source"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <TkStatus
        class="w-20"
        ref="tkStatus"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <TkSendDate
        class="w-20"
        ref="sendDate"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <SendAk
        class="w-20"
        ref="sendAk"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <ResendAk
        class="w-20"
        ref="resendAk"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <ShowDeletedEd
        class="w-20"
        ref="isDeletedEd"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import ArchiveCipher from '@/components/Filters/Fields/ArchiveCipher.vue'
import EdNumber from '@/components/Filters/Fields/Ed/EdNumber.vue'
import RegisterDate from '@/components/Filters/Fields/RegisterDate.vue'
import CreateDate from '@/components/Filters/Fields/CreateDate.vue'
import TkSendDate from '@/components/Filters/Fields/TkSendDate.vue'
import UpdateDate from '@/components/Filters/Fields/UpdateDate.vue'
import EdMediaType from '@/components/Filters/Fields/Ed/EdMediaType.vue'
import EdStatus from '@/components/Filters/Fields/Ed/EdStatus.vue'
import Classifier from '@/components/Filters/Fields/Classifier.vue'
import Subdivision from '@/components/Filters/Fields/Subdivision.vue'
import ClassifierKinds from '@/components/Filters/Fields/ClassifierKinds.vue'
import TkStatus from '@/components/Filters/Fields/TkStatus.vue'
import SendAk from '@/components/Filters/Fields/SendAk.vue'
import ResendAk from '@/components/Filters/Fields/ResendAk.vue'
import Source from '@/components/Filters/Fields/Source.vue'
import Dsp from '@/components/Filters/Fields/Ed/Dsp.vue'
import OriginalityFiles from '@/components/Filters/Fields/Ed/OriginalityFiles.vue'
import StorageExpirationYear from '@/components/Filters/Fields/StorageExpirationYear.vue'
import ShowDeletedEd from '@/components/Filters/Fields/Ed/ShowDeletedEd.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'

export default {
  name: 'Filters',
  components: {
    ShowDeletedEd,
    StorageExpirationYear,
    FiltersTemplate,
    ChipsFilters,
    ArchiveCipher,
    EdNumber,
    RegisterDate,
    CreateDate,
    TkSendDate,
    UpdateDate,
    EdMediaType,
    EdStatus,
    Classifier,
    Subdivision,
    ClassifierKinds,
    TkStatus,
    SendAk,
    ResendAk,
    Source,
    Dsp,
    OriginalityFiles,
    FilterFooter
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []

      if (this.filterObj.cipher) {
        paramsFilter.append('ed_cipher', this.filterObj.cipher.query)
        chips.push(this.filterObj.cipher)
      }
      if (this.filterObj.edNumber) {
        paramsFilter.append('num', this.filterObj.edNumber.query)
        chips.push(this.filterObj.edNumber)
      }
      if (this.filterObj.regDate) {
        paramsFilter.append('start_reg_date', this.filterObj.regDate.query[0])
        paramsFilter.append('end_reg_date', this.filterObj.regDate.query[1])
        chips.push(this.filterObj.regDate)
      }
      if (this.filterObj.createDate) {
        paramsFilter.append('start_create_date', this.filterObj.createDate.query[0])
        paramsFilter.append('end_create_date', this.filterObj.createDate.query[1])
        chips.push(this.filterObj.createDate)
      }
      if (this.filterObj.sendDate) {
        paramsFilter.append('tk_start_form_date', this.filterObj.sendDate.query[0])
        paramsFilter.append('tk_end_form_date', this.filterObj.sendDate.query[1])
        chips.push(this.filterObj.sendDate)
      }
      if (this.filterObj.updateDate) {
        paramsFilter.append('start_update_date', this.filterObj.updateDate.query[0])
        paramsFilter.append('end_update_date', this.filterObj.updateDate.query[1])
        chips.push(this.filterObj.updateDate)
      }
      if (this.filterObj.mediaType) {
        paramsFilter.append('media_type_id', this.filterObj.mediaType.query.value)
        chips.push(this.filterObj.mediaType)
      }
      if (this.filterObj.edStatus) {
        paramsFilter.append('ed_status_id', this.filterObj.edStatus.query.value)
        chips.push(this.filterObj.edStatus)
      }
      if (this.filterObj.classifier) {
        paramsFilter.append('di_classifier_id', this.filterObj.classifier.query.value)
        chips.push(this.filterObj.classifier)
      }
      if (this.filterObj.subdivision) {
        paramsFilter.append('ed_subdivision', this.filterObj.subdivision.query.value)
        chips.push(this.filterObj.subdivision)
      }
      if (this.filterObj.diKinds) {
        const groups = this.filterObj.diKinds.query.filter(item => item.type === 'group').map(group => group.pk)
        const kinds = this.filterObj.diKinds.query.filter(item => item.type === 'kind').map(kind => kind.pk)
        if (groups.length) paramsFilter.append('di_group_id', JSON.stringify(groups))
        if (kinds.length) paramsFilter.append('di_kind_id', JSON.stringify(kinds))
        // chips.push(this.filterObj.classifier)
      }
      if (this.filterObj.tkStatus) {
        paramsFilter.append('tk_status', this.filterObj.tkStatus.query.value)
        chips.push(this.filterObj.tkStatus)
      }
      if (this.filterObj.sendAk) {
        paramsFilter.append('is_trans_temp', this.filterObj.sendAk.query.value)
        chips.push(this.filterObj.sendAk)
      }
      if (this.filterObj.resendAk) {
        paramsFilter.append('resend_ak', this.filterObj.resendAk.query.value)
        chips.push(this.filterObj.resendAk)
      }
      if (this.filterObj.source) {
        paramsFilter.append('source_id', this.filterObj.source.query.value)
        chips.push(this.filterObj.source)
      }
      if (this.filterObj.isDsp) {
        paramsFilter.append('is_dsp', this.filterObj.isDsp.query.value)
        chips.push(this.filterObj.isDsp)
      }
      if (this.filterObj.expirationYear) {
        paramsFilter.append('storage_expiration_year', this.filterObj.expirationYear.query)
        chips.push(this.filterObj.expirationYear)
      }
      if (this.filterObj.isDocOriginal) {
        paramsFilter.append('is_doc_original', this.filterObj.isDocOriginal.query.value)
        chips.push(this.filterObj.isDocOriginal)
      }
      if (this.filterObj.isDeletedEd) {
        paramsFilter.append('is_only_deleted', this.filterObj.isDeletedEd.query.value)
        chips.push(this.filterObj.isDeletedEd)
      }
      return { filter: paramsFilter, chips }
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.resetFilter = false
        this.searchTouch = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
