<template>
  <v-card class="detail__additional-info">
    <v-card-title class="d-flex justify-space-between align-center">
      <h2>Файлы</h2>

      <div class="control-buttons">
        <v-btn
          v-if="!isEdit && viewButtons.is_edit_ed"
          class="circle circle__btn circle--white"
          icon
          @click="isEdit = true"
        >
          <v-icon color="secondary">mdi-pencil-outline</v-icon>
        </v-btn>

        <template v-if="isEdit">
          <div class="d-flex">
            <v-btn
              v-if="needCheckFiles"
              icon
              class="circle circle__btn circle--white"
              @click="triggerCheckFiles++"
            ><v-icon color="secondary">mdi-check</v-icon>
            </v-btn>

            <BtnIconSaveSlot
              v-else
              :disabled="invalidData"
              :loading="loading"
              @save="updateHandler"
            />
            <!-- Чтобы сделать отступ -->
            <div class="mr-3"></div>

            <BtnIconCancelSlot
              :loading="loading"
              @close="cancelEdit()"
            />
          </div>
        </template>
      </div>
    </v-card-title>

    <ViewFiles
      v-if="!isEdit"
      :loading="loading"
    />

    <EditingFiles
      v-else
      :trigger="trigger"
      :triggerCheckFiles="triggerCheckFiles"
      @change-valid="invalidData = $event"
      @fill-data="fillData($event)"
      @updateHandler="updateHandler"
      @need-check="needCheckFiles = $event"
    />
  </v-card>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import { GET_ED_FILES, UPDATE_FILE_ED } from '../services/api'
import EditingFiles from '@/modules/eds/components/editing-info/EditingFiles.vue'
import ViewFiles from '@/modules/eds/components/view-info/ViewFiles.vue'

const BtnIconSaveSlot = () => import('@/components/BtnIconSaveSlot.vue')
const BtnIconCancelSlot = () => import('@/components/BtnIconCancelSlot.vue')

export default {
  components: {
    ViewFiles,
    EditingFiles,
    BtnIconSaveSlot,
    BtnIconCancelSlot
  },

  data: () => ({
    loading: false,
    trigger: 0,
    triggerCheckFiles: 0,
    formData: {},
    invalidData: false,
    needCheckFiles: false,
    isEdit: false
  }),

  computed: {
    ...mapState({
      errorFiles: state => state.eds.errorFiles
    }),

    ...mapGetters('eds', ['GET_ED_KEY']),

    edId () {
      return this.GET_ED_KEY('id')
    },

    viewButtons () {
      return this.GET_ED_KEY('view_buttons')
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    cancelEdit () {
      this.isEdit = false
      this.$store.dispatch('eds/CLEAR_DIRTY')
    },

    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        // Object.assign(this.formData, evt)
        this.formData = evt
        console.log('evt', evt)
        console.log('this.formData', this.formData)
        resolve()
      })
    },

    async updateHandler () {
      this.loading = true
      this.trigger++
      await this.fillData()
      try {
        await UPDATE_FILE_ED(this.edId, this.formData)
        this.isEdit = false
        this.getData()
        this.$store.dispatch('eds/CLEAR_DIRTY')
      } finally {
        this.loading = false
      }
    },

    checkMessageError (e) {
      if (e.file_role.code === 'signature') {
        if (e.message_error !== null && e.message_error !== '') {
          return 'error-file'
        } else return ''
      } else return ''
    },

    getData () {
      this.loading = true
      GET_ED_FILES(this.edId).then(() => {
        this.loading = false
      })
    }
  }
}
</script>

<style lang="scss">

.error-text {
  td:first-child {
    color: var(--v-error-base)
  }
}

.required-label-files {
  color: #C81919;
  position: absolute;
  top: -5px;
  right: -10px;
}

.table-footer__files {
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  .flex-100 {
    margin-top: 10px;
    flex-basis: 100%;
  }
}

.file-btn {
  color: var(--v-secondary-base) !important;
  caret-color: var(--v-secondary-base) !important;
  cursor: pointer;
}
</style>
