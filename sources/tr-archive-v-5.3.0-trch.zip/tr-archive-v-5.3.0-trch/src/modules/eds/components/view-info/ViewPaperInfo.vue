<template>
  <v-card class="detail__main-info mt-5">
    <v-card-title>
      <h2>Информация о бумажном носителе</h2>
      <v-icon
          icon
          class="ml-2"
          color="secondary"
          @click="isMainInfo = !isMainInfo"
        >{{ chevron }}
        </v-icon>
    </v-card-title>

    <transition name="fade" mode="out-in">
      <v-card-text v-if="isMainInfo" class="detail__view-inner">
        <div class="detail__item">
          <p class="detail__item-title">Место размещения</p>
          <span class="detail__value">{{ paperInfo }}</span>
        </div>
      </v-card-text>
    </transition>
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'

export default {
  name: 'ViewPaperInfo',

  data: () => ({
    isMainInfo: false
  }),

  computed: {
    ...mapGetters('eds', ['GET_ED_KEY']),

    paperInfo () {
      return this.GET_ED_KEY('dossier')?.paper_info?.location || 'Нет данных'
    },

    chevron () {
      return this.isMainInfo ? 'mdi-chevron-up' : 'mdi-chevron-down'
    }
  },
  mounted () {
    if (this.GET_ED_KEY('media_type').code !== 'elec_view') this.isMainInfo = true
  }
}
</script>
