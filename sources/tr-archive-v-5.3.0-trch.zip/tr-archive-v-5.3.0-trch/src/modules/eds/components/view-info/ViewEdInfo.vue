<template>
  <div class="card">
    <template>
      <v-alert
        v-if="resendAk"
        icon="mdi-alert"
        class="warning-alert mb-3 border-bottom rounded"
      ><span>Необходимо переотправить во временное хранилище</span>
    </v-alert>
    </template>
    <v-badge
      v-if="edIsDeleted"
      class="big-badge"
      color="black"
      content="УДАЛЕН"
    ></v-badge>

    <h2
      data-qa="ed-name-card"
      class="detail__title"
      style="cursor:pointer"
      @click="showFullName"
    >
      <span v-if="edName.length > 200 && !fullName">{{ shortName }}...</span>
      <span v-if="fullName || edName.length < 200">{{ edName }}</span>
      <v-chip
        v-if="GET_ED_DSP"
        class="ma-2 info-badge"
        color="warning"
        text-color="white"
      >ДСП
      </v-chip>
    </h2>

    <v-tabs class="tabs-pills detail__tabs detail__tabs--absolute" right v-model="tabItem">
      <v-tab :ripple="false">Электронный документ</v-tab>
      <v-tab :ripple="false">История действий</v-tab>

      <v-tab-item>
        <BlockMainInfo @refresh="$emit('refresh')"/>

        <ViewPaperInfo/>

        <div class="detail__row">
          <div id="detailBlock" class="detail__row-info" :class="{full: isPreview}">
            <!-- ФАЙЛЫ -->
            <BlockFiles/>

            <!-- НОМЕНКЛАТУРА ДЕЛА -->
            <ViewNomenclatures/>

            <!-- ОПИСИ -->
            <ViewRegisters/>

            <ViewAcceptRegisters/>

            <!-- ТК -->
            <ViewTk/>
          </div>
          <div id="detailPreview" class="detail__preview-document" :class="{'hide': isPreview}">
            <PreviewComponent ref="previewComponent"/>
          </div>
        </div>
      </v-tab-item>

      <v-tab-item>
        <HistoryActions/>
      </v-tab-item>
    </v-tabs>

    <TemplateButtons>
      <template #buttons-left>
        <template v-if="tabItem === 0">
          <BtnSend
            v-if="GET_VIEW_BUTTONS.is_send_ed_tk"
            :type-item="'ed'"
            :type-send="'tk'"
            :item-id-send="edId"
            @refresh-data="$emit('refresh')"
          />
          <BtnSend
            v-if="GET_VIEW_BUTTONS.is_send_ed_ak"
            :type-item="'ed'"
            :type-send="'ak'"
            :item-id-send="edId"
            @refresh-data="$emit('refresh')"
          />
          <BtnDelete
              v-if="GET_VIEW_BUTTONS.can_delete_ed"
          />
        </template>
      </template>

      <template #buttons-right>
        <v-btn
          color="secondary"
          class="rounded-lg"
          @click="$_closeDetail()"
        >Закрыть</v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

import BtnSend from '@/components/Containers/BtnSend.vue'
import BtnDelete from '../fields-files/BtnDelete.vue'
import BlockMainInfo from '../BlockMainInfo.vue'
import ViewPaperInfo from './ViewPaperInfo.vue'
import BlockFiles from '../BlockFiles.vue'
import ViewNomenclatures from './ViewNomenclatures'
import ViewRegisters from './ViewRegisters'
import ViewAcceptRegisters from './ViewAcceptRegisters.vue'
import ViewTk from './ViewTk.vue'
import PreviewComponent from '../PreviewComponent.vue'

import Velocity from 'velocity-animate'

const HistoryActions = () => import(/* webpackChunkName: 'history-actions' */ '../HistoryActions.vue')

export default {
  name: 'ViewEdInfo',

  components: {
    BlockMainInfo,
    ViewPaperInfo,
    BlockFiles,
    ViewNomenclatures,
    ViewRegisters,
    ViewAcceptRegisters,
    ViewTk,
    BtnSend,
    PreviewComponent,
    HistoryActions,
    BtnDelete
  },

  data: () => ({
    tabItem: 0,
    fullName: false,
    isPreview: false
  }),

  computed: {
    ...mapGetters('eds', ['GET_ED_KEY', 'GET_ED_DSP', 'GET_VIEW_BUTTONS']),

    edId () {
      return this.GET_ED_KEY('id')
    },

    edName () {
      return this.GET_ED_KEY('name')
    },

    edIsDeleted () {
      return this.GET_ED_KEY('is_deleted')
    },

    shortName () {
      return this.edName.substring(0, 200)
    },

    resendAk () {
      return this.GET_ED_KEY('resend_ak')
    }
  },

  methods: {
    showFullName (el) {
      this.fullName = !this.fullName
      if (this.fullName) {
        Velocity(el, { translateX: '0%', opacity: 1 }, { duration: 1000 })
      }
    },

    close () {
      this.$emit('refresh-data')
    }
  }
}
</script>

<style lang="scss">

</style>
