<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Транспортные контейнеры</h2>
    </v-card-title>
    <v-card-text>
      <v-data-table
        item-key="id"
        disable-sort
        hide-default-footer
        class="main-table mt-4"
        :no-data-text="'Нет данных'"
        :headers="headers"
        :items="tksList.tks"
        @click:row="showDetail($event)"
      >
        <!-- eslint-disable-next-line -->
        <template v-slot:item.form_date="{item}">
          {{ item.form_date ? $_formatDate(item.form_date, 'time') : 'Нет данных' }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.archive="{ item }">
          <v-tooltip v-if="item.archive" bottom>
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on">{{
                  item.archive.short_name
                }}</span>
            </template>
            <span>{{item.archive.value }}</span>
          </v-tooltip>

          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.message_guid="{item}">
          {{ item.message_guid ? item.message_guid : 'Нет данных' }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.sign_end_date="{item}">
          {{ item.sign_end_date ? `${$_formatDate(item.sign_end_date, 'date')}` : 'Нет данных' }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.in_out="{item}">
          {{ item.in_out ? 'Входящий' : 'Исходящий' }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.uri="{ item }">
          <v-btn
            color="secondary"
            class="rounded-lg"
            icon
            title="Скачать файл"
            @click.stop="$_downloadFile(item.uri)"
          >
            <v-progress-circular
              v-if="item.isDownload !== undefined && item.isDownload === true"
              color="primary"
              indeterminate
              :width="3"
            ></v-progress-circular>
            <v-icon color="secondary" v-else>mdi-download-circle-outline</v-icon>
          </v-btn>
        </template>

<!--        <template #footer="{props}">-->
<!--          <PaginationTable-->
<!--            :page.sync="page"-->
<!--            :pagination="props.pagination"-->
<!--            :hide-page="true"-->
<!--          />-->
<!--        </template>-->
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_TK_LIST } from '@/services/app'
import { mapGetters } from 'vuex'

export default {
  data: () => ({
    tksList: {},
    headers: [
      {
        text: 'Вид ТК',
        value: 'in_out',
        width: '10%'
      },
      {
        text: 'Дата и время формирования',
        value: 'form_date',
        width: '10%'
      },
      {
        text: 'Статус',
        value: 'status.value'
      },
      {
        text: 'Архив',
        value: 'archive.value'
      },
      {
        text: 'Фонд',
        value: 'fund.value'
      },
      {
        text: 'Дата и время отправки в ЦХЭД',
        value: 'send_date',
        width: '10%'
      },
      {
        text: 'GUID сообщения МЭДО',
        value: 'message_guid'
      },
      {
        text: 'Окончание действия сертификата подписи',
        value: 'sign_end_date',
        width: '10%'
      },
      {
        value: 'uri',
        align: 'center',
        width: '100px'
      }
    ]
  }),

  computed: {
    ...mapGetters('eds', ['GET_ED_KEY']),

    id () {
      return this.GET_ED_KEY('id')
    }
  },

  async created () {
    this.tksList = await GET_TK_LIST(new URLSearchParams(`ed_id=${this.id}`))
  },

  methods: {
    showDetail (e) {
      const path = `/tks/${e.id}`

      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    }
  }
}
</script>

<style>

</style>
