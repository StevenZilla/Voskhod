<template>
  <v-card-text class="no-bg">
    <v-data-table
      item-key="id"
      class="main-table no-hover scroll-table row-default-cursor"
      no-data-text="Нет файлов"
      disable-sort
      disable-pagination
      hide-default-footer
      :loading-text="'Загрузка файлов'"
      :loading="loading"
      :item-class="setErrorClass"
      :headers="headers"
      :items="edFiles"
    >
      <template #progress>
        <v-progress-linear
          indeterminate
          height="5"
          color="secondary"
        ></v-progress-linear>
      </template>
      <!-- eslint-disable-next-line -->
      <template v-slot:item.file_role="{ item, index }">
        <span>{{ item.file_role.value }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.parent_id="{item}">
        <span>{{ item.parent_name ? item.parent_name : 'Нет связанных файлов' }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.size="{item}">
        {{ item.size.toFixed(2) }}
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.is_original="{ item }">
        <span>{{ item.is_original ? 'Подлинник' : 'Копия' }}</span>
      </template>

      <!-- eslint-disable-next-line -->
      <template v-slot:item.uri="{item}">
        <v-btn
          :color="setErrorClass(item) === 'error-file' ? 'white' : 'secondary'"
          class="rounded-lg"
          icon
          @click.stop="$_downloadFile(item.uri)"
        >
          <v-progress-circular
            v-if="item.isDownload !== undefined && item.isDownload === true"
            color="primary"
            indeterminate
            :width="3"
          ></v-progress-circular>
          <v-icon
            v-else
            :color="setErrorClass(item) === 'error-file' ? 'white' : 'secondary'"
          >mdi-download-circle-outline</v-icon>
        </v-btn>
      </template>
    </v-data-table>
    <h4 v-if="invalidSign" class="flex-100 error--text mt-3">Прием файлов с невалидной подписью запрещен!</h4>
  </v-card-text>
</template>

<script>

import { mapState } from 'vuex'

export default {
  props: {
    loading: {
      type: Boolean
    }
  },

  data: () => ({
    invalidSign: false,
    headers: [
      {
        text: 'Наименование',
        value: 'name',
        width: '200px'
      },
      {
        text: 'Роль файла',
        value: 'file_role',
        width: '200px'
      },
      {
        text: 'Относится к файлу',
        value: 'parent_id',
        width: '200px'
      },
      {
        text: 'Обьем, Мб',
        align: 'center',
        value: 'size',
        width: '150px'
      },
      {
        text: 'Подлинность',
        align: 'center',
        value: 'is_original',
        width: '100px'
      },
      {
        text: 'Скачать файл',
        cellClass: 'not-hover',
        align: 'center',
        value: 'uri',
        width: '150px'
      }
    ]
  }),

  computed: {
    ...mapState({
      edFiles: state => state.eds.edFiles
    })
  },

  methods: {
    setErrorClass (e) {
      if (e.message_error !== '') {
        this.invalidSign = true
        return 'error-file'
      } else this.invalidSign = false
    }
  }
}
</script>

<style lang="scss">

.error-text {
  td:first-child {
    color: var(--v-error-base)
  }
}

.required-label-files {
  color: #C81919;
  position: absolute;
  top: -5px;
  right: -10px;
}

.table-footer__files {
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  .flex-100 {
    margin-top: 10px;
    flex-basis: 100%;
  }
}

.file-btn {
  color: var(--v-secondary-base) !important;
  caret-color: var(--v-secondary-base) !important;
  cursor: pointer;
}
</style>
