<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Сводные описи</h2>
    </v-card-title>
    <v-card-text>
      <v-data-table
        item-key="id"
        hide-default-footer
        disable-pagination
        disable-sort
        class="main-table scroll-table"
        no-data-text="Нет данных"
        :loading-text="'Загрузка данных'"
        :loading="loading"
        :headers="headers"
        :items="registersList.registers"
        @click:row="showDetail($event)"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.register_part="{item}">
          <span v-if="item.register_part.id" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.register_part.name }}</span>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_REGISTERS_LIST } from '@/services/app'
import { registerDetail, projectDetail } from '@/permissions'

export default {
  data: () => ({
    registersList: [],
    loading: false,
    headers: [
      {
        text: 'Заголовок',
        value: 'name',
        width: '250px'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '230px'
      },
      {
        text: 'Раздел / подраздел',
        value: 'register_part.name',
        width: '250px'
      },
      {
        text: 'Год',
        value: 'year',
        width: '80px'
      },
      {
        text: 'Вид',
        value: 'register_type.value',
        width: '290px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['eds/GET_DOSSIER_ID']
    },

    registerStatus () {
      return this.$store.getters['registers/summary/GET_REGISTER_STATUS']
    }
  },

  async created () {
    if (this.id) this.registersList = await GET_REGISTERS_LIST(new URLSearchParams(`dossier_id=${this.id}`))
  },

  methods: {
    showDetail (e) {
      let path = ''
      if (e.register_status.code === 'approved') path = `${registerDetail.path}/${e.id}`
      else path = `${projectDetail.path}/${e.id}`
      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    }
  }
}
</script>

<style>

</style>
