<template>
  <v-card-text class="detail__view-inner item-6">
    <div class="detail__item">
      <p class="detail__item-title">Регистрационный номер</p>
      <span data-qa="ed-num-card" class="detail__value">{{ getValue(detailEd.num) }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Дата регистрации</p>
      <span data-qa="ed-reg-date-card" class="detail__value">{{ $_formatDate(getValue(detailEd.reg_date), 'date') }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Подразделение</p>
      <span v-if="detailEd.subdivision" data-qa="ed-reg-date-card" class="detail__value">
        {{ detailEd.subdivision.code }} {{ detailEd.subdivision.name }}
        <TransitSubdivisionIcon :transitInfo="transitInfo" v-if="transitInfo.count"/>
      </span>
      <span v-else class="detail__value">Нет данных</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Индекс и заголовок дела</p>
      <span v-if="!detailEd.dossier" class="detail__value">Нет данных</span>
      <span
        v-else
        data-qa="ed-dossier-card"
        class="detail__value"
        style="cursor: pointer"
        :class="{'active-link': $can('read', 'dossier')}"
        @click="$can('read', 'dossier') ? showDetail(detailEd.dossier) : () => {}"
      >{{ `${detailEd.dossier.index} - ${detailEd.dossier.name}` }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Вид носителя</p>
      <span data-qa="ed-media-type-card" class="detail__value">{{ getValue(detailEd.media_type) }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Вид хранения</p>
      <span data-qa="ed-save-type-card" class="detail__value">{{ getValue(detailEd.save_type) }}</span>
      <br>
      <span v-if="detailEd.temp_save_type_id"
            style="color:#76767A"
            class="detail__value">
        {{ getValue(detailEd.temp_save_type_id.value) }}
      </span>
    </div>
    <div v-if="detailEd.save_type && detailEd.save_type.code === 'temporarily'" class="detail__item">
      <p class="detail__item-title">Срок хранения во временном хранилище, год (лет)</p>
      <span class="detail__value">{{ `${detailEd.temp_save_period}` }} </span>
      <span style="color:#76767A" class="detail__value">{{ `(${calculateEndTimeTemp})` }} </span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Источник</p>
      <span data-qa="ed-source-card" class="detail__value">{{ getValue(detailEd.source) }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Идентификатор ЭД в источнике</p>
      <span data-qa="ed-source-id-card" class="detail__value">{{ getValue(detailEd.source_ed_id) }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Статус обработки</p>
      <span data-qa="ed-status-card" class="detail__value">{{ getValue(detailEd.ed_status) }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Дата и время создания в системе</p>
      <span data-qa="ed-date-system-card" class="detail__value">{{
          $_formatDate(getValue(detailEd.create_date), 'time')
        }}</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Дата последнего обновления</p>
      <span data-qa="ed-date-change-card" class="detail__value"
            v-if="detailEd.update_date">{{ $_formatDate(detailEd.update_date, 'time') }}</span>
      <span data-qa="ed-date-change-card" class="detail__value" v-else>Нет данных</span>
    </div>
    <div class="detail__item">
      <p class="detail__item-title">Архивный шифр</p>
      <v-chip
        v-if="detailEd.ed_cipher"
        data-qa="ed-cipher-card"
        class="info-badge"
        color="#00A65A"
      ><span class="detail__item-title white--text">{{ getValue(detailEd.ed_cipher) }}</span></v-chip>
      <span v-else class="detail__value">Нет данных</span>
    </div>
  </v-card-text>
</template>

<script>

import { mapState } from 'vuex'
import { dossierDetail } from '@/permissions'
import { add, format } from 'date-fns'
import TransitSubdivisionIcon from '@/components/TransitSubdivisionIcon.vue'

export default {
  name: 'ViewMainInfo',
  components: { TransitSubdivisionIcon },

  computed: {
    ...mapState({
      detailEd: state => state.eds.detailEd,
      transitInfo: state => state.eds.transitInfo
    }),

    calculateEndTimeTemp () {
      if (!this.detailEd.temp_save_period) return null
      return format(add(new Date(this.detailEd.reg_date), { years: (this.detailEd.temp_save_period + 1) }), 'dd.MM.yyyy')
    }
  },

  methods: {
    getValue (val) {
      if (!val) return 'Нет данных'
      if (val.value) return val.value
      else return val
    },

    showDetail (e) {
      const path = `${dossierDetail.path}/${e.id}`
      if (this.$route.path !== path) {
        this.$router.push(path)
      }
    }
  }
}
</script>

<style>
</style>
