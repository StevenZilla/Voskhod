<template>
  <v-card>
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    >
    <v-toolbar-title>Прием ЭД с невалидной ЭП - Разрешен</v-toolbar-title>
    </v-toolbar>
    <div class="popup-form">
      <v-alert
        icon="mdi-alert"
        class="warning-alert mb-0"
      >
        Вы уверены, что хотите загрузить ЭД с невалидной ЭП?
      </v-alert>
      <div>
        <div class="error-item" v-for="(file, ind) in errorFiles.error" :key="ind">
          <span>{{ file.file_name }}</span>
          <span class="error--text">Подпись не верна</span>
        </div>
      </div>
      <div class="d-flex justify-end">
        <v-btn
          class="mr-2 rounded-lg"
          color="secondary"
          outlined
          @click="$emit('cancel')"
        >Нет</v-btn>
        <v-btn
          class="rounded-lg"
          color="secondary"
          @click="$emit('approve')"
        >Да</v-btn>
      </div>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'DialogValidSignVue',

  computed: {
    ...mapState({
      errorFiles: state => state.eds.errorFiles
    })
  }
}
</script>

<style lang="scss">

.error-item {
  display: flex;
  justify-content: space-between;
  padding: 20px;
  border-bottom: 1px solid #D9D9DE;
  span:first-child {
    max-width: 60%;
  }
  &:last-child {
    border: none;
  }
}
</style>
