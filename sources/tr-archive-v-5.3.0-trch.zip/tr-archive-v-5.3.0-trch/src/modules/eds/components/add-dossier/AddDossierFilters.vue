<template>
  <FiltersTemplate
    class="filter--dialog"
    :full-filter="true"
  >
    <template #filter-fields>
      <!--      поиск по коду фильтра в filterObj-->
      <DossierName
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierIndex
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <NomenclatureYear
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <NomenclatureNumber
        class="w-49"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import DossierIndex from '@/components/Filters/Fields/Dossier/DossierIndex.vue'
import DossierName from '@/components/Filters/Fields/Dossier/DossierName.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import NomenclatureNumber from '@/components/Filters/Fields/Nomenclature/NomenclatureNumber.vue'
import NomenclatureYear from '@/components/Filters/Fields/Nomenclature/NomenclatureYear.vue'

export default {
  name: 'AddDossierFilters',
  components: {
    FiltersTemplate,
    DossierName,
    DossierIndex,
    NomenclatureNumber,
    NomenclatureYear,
    FilterFooter
  },

  data: () => ({
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      // paramsFilter.append('status_code', 'actively')

      if (this.filterObj.dossierName) {
        paramsFilter.append('name', this.filterObj.dossierName.query)
      }
      if (this.filterObj.index) {
        paramsFilter.append('index', this.filterObj.index.query)
      }
      if (this.filterObj.nomYear) {
        paramsFilter.append('nomenclature_years', this.filterObj.nomYear.query)
      }
      if (this.filterObj.nomNumber) {
        paramsFilter.append('nomenclature_num', this.filterObj.nomNumber.query)
      }
      return paramsFilter
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    acceptFilters () {
      this.searchTouch = true
      this.$emit('set-filters', this.filterParams)
      this.clear = true
    },

    clearFilters () {
      this.resetFilter = true
      this.$nextTick(() => {
        this.resetFilter = false
        this.$emit('clear-filters')
        this.searchTouch = false
      })
    }
  }
}
</script>

<style>
</style>
