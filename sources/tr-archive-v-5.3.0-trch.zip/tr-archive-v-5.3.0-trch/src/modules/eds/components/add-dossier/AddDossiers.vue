<template>
  <v-dialog
    v-model="isSelect"
    transition="scroll-y-transition"
    max-width="910px"
    style="z-index: 99999 !important;"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
        class="rounded-lg ml-3"
        color="secondary"
        outlined
        v-bind="attrs"
        v-on="on"
        :disabled="disabled"
      >Выбрать
      </v-btn>
    </template>

    <v-card class="create__main-info select-popup">
      <v-toolbar
        dense
        flat
        class="popup-toolbar"
      >
        <v-toolbar-title>Дела</v-toolbar-title>
        <v-btn icon dark @click="isSelect = false">
          <v-icon color="element">mdi-close</v-icon>
        </v-btn>
      </v-toolbar>

      <AddDossierFilters
        @set-filters="acceptFilters($event)"
        @clear-filters="getData()"
      />

      <div class="main-table-inner">
        <v-data-table
          class="scroll-popup-table sortable-table no-hover"
          hide-default-footer
          :no-data-text="'Нет данных'"
          loading-text="Загрузка данных"
          :headers="headers"
          :items="dossiersList.dossiers"
          :server-items-length="dossiersList.count"
          :loading="dossierLoading"
          :options.sync="options"
          :page.sync="page"
          :fixed-header="true"
          :items-per-page="itemsPerPage"
          :header-props="{
            'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
          }"
          @page-count="pageCount = $event"
        >
          <template #progress>
            <v-progress-linear
              indeterminate
              height="5"
              color="secondary"
            ></v-progress-linear>
          </template>

          <!-- eslint-disable-next-line -->
          <template v-slot:item.action="{item}">
            <v-radio-group hide-details v-model="selectedDossier">
              <v-radio
                class="doss-radio"
                data-qa="select-dossier"
                color="secondary"
                :disabled="dossierLoading"
                :value="item"
              />
            </v-radio-group>
          </template>

          <!-- eslint-disable-next-line -->
          <template #footer="{ props }">
            <PaginationTable
              :page.sync="page"
              :pagination="props.pagination"
            />

            <div class="main-table-inner__buttons">
              <v-btn
                color="secondary"
                class="mr-3 rounded-lg px-6 py-6"
                :disabled="!selectedDossier"
                @click="setDossier()"
              >Выбрать
              </v-btn>
              <v-btn
                outlined
                color="secondary"
                class="rounded-lg px-6 py-6"
                @click="isSelect = false"
              >Отменить
              </v-btn>
            </div>
          </template>
        </v-data-table>
      </div>
    </v-card>
  </v-dialog>
</template>

<script>

import { mapState } from 'vuex'
import AddDossierFilters from './AddDossierFilters.vue'
import { GET_DOSSIERS_LIST } from '@/services/app'

export default {
  name: 'AddDossiers',

  props: {
    dossier: {
      type: Object,
      default: () => {
        return {}
      }
    },

    excludeDossier: {
      type: Object,
      default: () => {
        return {}
      }
    },

    subdivision: {
      type: Object,
      required: false,
      default: null
    },

    disabled: {
      type: Boolean,
      default: false
    }
  },

  components: {
    AddDossierFilters
  },

  data: () => ({
    selectedDossier: null,
    isSelect: false,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    dossiersList: {},
    headers: [
      {
        value: 'action',
        sortable: false,
        width: '64px'
      },
      {
        text: 'Индекс дела',
        width: '25%',
        value: 'index'
      },
      {
        text: 'Заголовок дела',
        width: '70%',
        value: 'name'
      }
    ]
  }),

  watch: {
    trigger (newV) {
      if (newV) this.$emit('fill-data', { dossier_id: this.selectedDossier.id })
    },

    dossier: {
      handler (newV) {
        if (newV) this.selectedDossier = this.dossier
      },
      deep: true
    },

    isSelect (newV) {
      if (newV) this.getData()
    },

    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.dossiersList = await GET_DOSSIERS_LIST(this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      dossierLoading: state => state.dossiers.dossierLoading
    }),

    filterParams () {
      const paramsFilter = new URLSearchParams()
      paramsFilter.append('status_code', 'actively')
      // если нет подразделения, передавать null
      paramsFilter.append('dossier_subdivision', `${this.subdivision?.id || null}`)
      if (this.excludeDossier?.id) paramsFilter.append('exclude_ids', `[${this.excludeDossier.id}]`)
      return paramsFilter
    },

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.dossiersList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          par += sortBy
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  async mounted () {
    if (this.dossier) this.selectedDossier = this.dossier
  },

  methods: {
    getData () {
      GET_DOSSIERS_LIST(this.filterParams).then(resp => { this.dossiersList = resp })
    },

    async acceptFilters (evt) {
      const filterParams = this.combineSearchParamsMix(this.filterParams, evt)
      this.dossiersList = await GET_DOSSIERS_LIST(filterParams, this.sortParams)
    },

    setDossier () {
      this.$emit('set-dossier', this.selectedDossier)
      this.isSelect = false
    }
  }
}
</script>

<style lang="scss">
</style>
