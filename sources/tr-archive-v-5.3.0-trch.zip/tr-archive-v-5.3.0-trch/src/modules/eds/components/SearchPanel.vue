<template>
  <div class="panel-search">
    <div class="d-flex justify-space-between align-center">
      <v-text-field
        v-model="filterObj.nameDoc"
        class="main-field"
        data-qa="main-field"
        placeholder="Введите заголовок или регистрационный номер документа"
        solo
        outlined
        rounded
        clearable
        hide-details
        flat
        @click:clear="filterObj.nameDoc = null, acceptFilters()"
        @keyup.enter="trigger++"
      >
        <template v-slot:append-outer>
          <v-btn
            class="rounded-xl ml-8 bg-white"
            outlined
            icon
            data-qa="filter"
            color="secondary"
            @click="toggleFilter()"
          >
            <v-icon>mdi-tune-vertical-variant</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
            v-if="filterObj.nameDoc"
            class="find-link secondary--text"
            @click="acceptFilters()"
            >Найти
          </span>
        </template>
        <template v-slot:prepend-inner>
          <v-btn
            plain
            icon
            color="secondary"
            @click="acceptFilters()"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </template>
      </v-text-field>

      <CreateEd
        :key="reset"
        @refresh-data="$emit('refresh-data', $event)"
        @clear="reset++"
      />

      <label>
        <input
          type="file"
          hidden
          accept="text/csv"
          @change="submit($event.target.files[0])"
        />
        <v-btn
          tag="span"
          style="cursor: pointer"
          color="secondary"
          class="justify-content-end rounded-lg ml-3"
        >Загрузка из CSV
        </v-btn>
      </label>
    </div>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      :is-load="isLoad"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />
  </div>
</template>

<script>

import CreateEd from './create-info/CreateEd.vue'
import { UPLOAD_ED } from '../services/api'
import store from '@/storages'

const Filters = () => import('./Filters.vue')

export default {
  name: 'SearchPanel',

  components: {
    CreateEd,
    Filters
  },

  data: () => ({
    trigger: 0,
    reset: 0,
    fullFilter: false,
    isLoad: false,
    filterObj: {
      nameDoc: null
    }
  }),
  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.nameDoc) {
        paramsFilter.append('q', this.filterObj.nameDoc)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt ? evt.filter : undefined)
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    clearFilters () {
      this.$emit('clear-filters')
    },

    async submit (file) {
      this.loading = true
      try {
        const formData = new FormData()
        formData.append('files[]', file)
        const response = await UPLOAD_ED(formData)
        if (response.status === 204) {
          this.$emit('success-loadEd')
        }
      } catch (error) {
        await store.dispatch('SET_VALUE',
          { key: 'errorList', value: [{ name: error.response.data.message, show: true }] },
          { root: true })
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style>
</style>
