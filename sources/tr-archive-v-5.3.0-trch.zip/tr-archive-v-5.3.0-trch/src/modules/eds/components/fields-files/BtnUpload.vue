<template>
  <div class="table-footer__files">
    <label v-if="reloadFiles">
      <input
        type="file"
        hidden
        accept="*/*"
        multiple
        @change="selectFiles($event)"
      />
      <v-btn
        data-qa="add-file"
        style="cursor:pointer"
        tag="span"
        color="secondary"
        class="rounded-lg mr-3"
        outlined
      ><v-icon class="mr-1">mdi-note-plus-outline</v-icon>
        Добавить файлы
      </v-btn>
    </label>

    <v-dialog
      v-model="isCheckAntivirus"
      transition="scroll-y-transition"
      max-width="730px"
      content-class="dialog-auto-height"
      @click:outside="isCheckAntivirus = false"
    >
      <AntivirusDialog
        :files-to-check="uncheckingFiles"
        :meta-files-to-check="metaFilesToCheck"
        @add-files="addFiles($event)"
        @close="isCheckAntivirus = false"
      />
    </v-dialog>
  </div>
</template>

<script>

import { mapGetters, mapState } from 'vuex'
import AntivirusDialog from '../AntivirusDialog.vue'
import { GET_CHECK_SETTINGS } from '@/services/app'

export default {
  components: { AntivirusDialog },

  props: {
    formDataFiles: {
      type: Array
    },
    antivirusEnabled: {
      type: Boolean
    }
  },

  data: () => ({
    uncheckingFiles: [],
    metaFilesToCheck: [],
    isCheckAntivirus: false,
    reloadFiles: true,
    pk: -1
  }),

  computed: {
    ...mapState({
      checkSettings: state => state.checkSettings
    }),

    ...mapGetters('eds', ['GET_ED_KEY']),

    mediaTypeEd () {
      return this.GET_ED_KEY('media_type')
    }
  },

  async mounted () {
    await GET_CHECK_SETTINGS()
  //   в AntivirusDialog не делаем запрос, так как он будет следующий открытым компонентом и данные уже новые
  },

  methods: {
    addFiles (checkingFiles) {
      const metaFilesArray = Array.from(this.metaFilesToCheck)
      const validMetaFiles = metaFilesArray.filter(meta =>
        checkingFiles.some(file => file.name === meta.name)
      )

      console.log('checkingFiles', checkingFiles)
      console.log('validMetaFiles', validMetaFiles)
      this.$emit('add-files', {
        fileList: checkingFiles,
        metaFileList: validMetaFiles
      })
      this.isCheckAntivirus = false
    },

    selectFiles (e) {
      this.uncheckingFiles = []
      this.metaFilesToCheck = []
      const metaFilesArray = Array.from(this.formDataFiles)
      e.target.files.forEach(file => {
        // проверка на уже существующий файл
        const checkFormDataFiles = metaFilesArray.find(item => file.name === item.name && file.size === item.size)
        // если есть, то не загружать файл
        if (checkFormDataFiles) {
          const obj = {
            name: `Файл ${file.name} уже добавлен в этот документ!`,
            show: true
          }
          this.$store.commit('setError', obj)
        } else { // иначе добавить файл для проверки
          const objFile = {
            id: this.pk,
            name: file.name,
            file_role: null,
            size: file.size / 1024 / 1024,
            is_original: this.mediaTypeEd.code === 'elec_view',
            parent_id: null,
            message_error: null
          }
          this.uncheckingFiles.push(objFile)
          this.metaFilesToCheck.push(file)
          this.pk--
        }
      })

      // если включен антивирус и есть файлы для проверки антивирусом, то показать окно
      if (this.checkSettings.is_check_antivirus && this.uncheckingFiles.length) {
        this.isCheckAntivirus = true
        return
      }
      // если другие условия не выполнились, просто добавить файлы
      this.addFiles(this.uncheckingFiles)

      // // нужно чтобы загрузить один и тот же файл удалив его в Хроме
      // this.reloadFiles = false
      // this.$nextTick(() => {
      //   this.reloadFiles = true
      // })
    }
  }
}
</script>

<style lang="scss">
</style>
