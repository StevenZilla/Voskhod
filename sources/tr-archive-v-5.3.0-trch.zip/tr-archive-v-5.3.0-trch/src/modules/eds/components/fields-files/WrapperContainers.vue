<template>
  <div class="wrapper-containers">
    <v-card v-if="!isError && !isSuccess">
      <h3 style="padding: 10px; text-align: center;">
        <p class="mb-0">Регистрационный номер:</p>
        <p class="mb-0">{{ edNum }}</p>
        <hr />
        <v-icon color="red" size="50">mdi-alert-box</v-icon>
        <hr />
        Вы уверены, что хотите безвозвратно удалить документ?
      </h3>
      <div style="min-height: 50px"></div>

      <div class="wrapper-containers__actions">
        <v-btn
          class="mr-3 rounded-lg"
          color="secondary"
          outlined
          :style="'min-width: 130px; height: 35px !important'"
          @click="$emit('close-popup')"
        >Отменить
        </v-btn>
        <v-btn
          data-qa="send"
          class="rounded-lg"
          color="secondary"
          :loading="loading"
          :style="'min-width: 140px; height: 35px !important'"
          @click="submitHandler()"
        >Да
        </v-btn>
      </div>
    </v-card>
    <v-card v-if="isError">
      <h3 style="padding: 10px; text-align: center;">
        <p class="mb-0" style="font-size: 14px;">Произошла ошибка при удалении документа</p>
        <hr />
        <v-icon color="red" size="50">mdi-alert-box</v-icon>
        <hr />
        <p style="font-size: 17px;">{{ errorData }}</p>
<!--        <p style="font-size: 17px;">Ошибка. ЭАД с идентификатором 10000 не существует в системе.</p>-->
      </h3>
    </v-card>
    <v-card v-if="isSuccess">
      <h3 style="padding: 10px; text-align: center;">
        <hr />
        <v-icon color="green" size="50">mdi-alert-box</v-icon>
        <p style="font-size: 17px;">Документ успешно удален из системы</p>
        <hr />
      </h3>
    </v-card>
  </div>
</template>

<script>

import { DELETE_ED } from '@/modules/eds/services/api'
import { mapState } from 'vuex'

export default {
  name: 'WrapperContainers',

  data: () => ({
    loading: false,
    isError: false,
    isSuccess: false,
    errorData: ''
  }),
  computed: {
    ...mapState({
      edNum: state => state.eds.detailEd.num
    })
  },
  methods: {
    submitHandler () {
      this.loading = true
      this.errorSend = false
      const id = this.$route.params.id
      DELETE_ED(id).then(res => {
        this.isSuccess = true
        setTimeout(() => {
          this.$router.push('/eds')
        }, 2000)
      }).catch(e => {
        this.loading = false
        this.isError = true
        this.errorData = e.response.data.message || ''
        setTimeout(() => {
          this.$emit('close-popup')
        }, 3000)
        setTimeout(() => {
          this.isError = false
        }, 3500)
      })
    }
  }
}
</script>
