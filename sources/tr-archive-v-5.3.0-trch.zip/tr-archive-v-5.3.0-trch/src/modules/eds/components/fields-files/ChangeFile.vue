<template>
  <label class="file-btn rounded-lg">
    <v-btn
      tag="div"
      color="secondary"
      class="rounded-lg"
      icon
    ><v-icon>mdi-download-circle-outline</v-icon>
    </v-btn>
    <input
      type="file"
      hidden
      accept="*/*"
      @change.stop="changeFile($event)"
    />
    <!--          <v-icon color="secondary">mdi-download-circle-outline</v-icon>-->
  </label>
</template>

<script>
export default {
  methods: {
    changeFile (newFile) {
      this.$emit('change-file', newFile)
    }
  }
}
</script>

<style lang="scss">

</style>
