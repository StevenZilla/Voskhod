<template>
  <v-dialog
      v-model="isOpen"
      max-width="425px"
      transition="scroll-y-transition"
      content-class="dialog-auto-height"
      @click:outside="isOpen = false"
  >
    <template v-slot:activator="{ on, attrs }">
      <v-btn
          color="secondary"
          class="mr-3 rounded-lg"
          outlined
          :loading="loading"
          v-bind="attrs"
          v-on="on"
      ><v-icon class="mr-2">mdi-delete</v-icon>
        Удалить ЭД</v-btn>
    </template>

    <WrapperContainers
        @close-popup="isOpen = false"
    />
  </v-dialog>
</template>

<script>

import WrapperContainers from '../fields-files/WrapperContainers.vue'

export default {
  components: {
    WrapperContainers
  },

  data: () => ({
    loading: false,
    isOpen: false
  }),

  methods: { }
}
</script>
