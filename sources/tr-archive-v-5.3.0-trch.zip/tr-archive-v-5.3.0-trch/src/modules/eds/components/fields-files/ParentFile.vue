<template>
  <div class="form-group">
    <v-select
      v-model="value"
      class="rounded-lg"
      data-qa="file-parent"
      outlined
      clearable
      hide-details
      :placeholder="fileTypeDocument ? 'Невозможно выбрать' : 'Выберите файл'"
      no-data-text="Невозможно выбрать"
      :disabled="fileTypeDocument"
      :filled="fileTypeDocument"
      :items="items"
    ></v-select>
  </div>
</template>

<script>

export default {
  props: {
    items: {
      type: Array,
      required: false
    },

    file: {
      type: Object,
      required: false,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    file: {
      handler (newV) {
        if (newV.file_role?.code === 'document') this.value = null
        else this.value = this.file.parent_id
      },
      deep: true
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  computed: {
    fileTypeDocument () {
      return this.file.file_role?.code === 'document'
    }
  },

  mounted () {
    this.value = this.file.parent_id
  }
}
</script>

<style lang="scss">

</style>
