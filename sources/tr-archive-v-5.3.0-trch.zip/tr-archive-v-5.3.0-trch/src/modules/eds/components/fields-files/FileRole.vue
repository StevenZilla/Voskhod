<template>
<!--  :class="{'error-field': !item.file_role }"-->
  <div class="form-group">
    <v-select
      v-model="value"
      class="rounded-lg"
      data-qa="file-role"
      return-object
      outlined
      clearable
      hide-details
      item-text="value"
      item-value="id"
      placeholder="Выберите роль"
      :items="rolesList"
    ></v-select>
  </div>
</template>

<script>

import { GET_ROLES_LIST } from '@/modules/eds/services/api'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    rolesList: [],
    value: null
  }),

  watch: {
    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.getData()
    this.value = { ...this.param }
  },

  methods: {
    getData () {
      GET_ROLES_LIST().then(resp => { this.rolesList = resp })
    }
  }
}
</script>

<style lang="scss">

</style>
