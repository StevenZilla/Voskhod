<template>
  <div class="main-card">
    <div class="main-card__title">
      <h2 class="active-link crop-text" @click="showDetailEd(+item._id)">
        <span
          v-if="item.highlight && item.highlight.name"
          v-html="item.highlight.name[0]"
          class="highlight-tag"
        ></span>
        <span v-else>{{ item._source.name }}</span>
      </h2>

      <h3>ЭАД:
        <span
          v-if="item.highlight && item.highlight.num"
          v-html="item.highlight.num[0]"
          class="highlight-tag"
        />
        <span v-else>{{ item._source.num }}</span>
      </h3>
    </div>

    <div class="main-card__info">
<!--      <pre>{{item}}</pre>-->
      <div v-if="hasHighlightFileContent(item)">
        <v-expansion-panels class="card-content" accordion>
          <v-expansion-panel
            v-for="(file, index) in item.inner_hits.file.hits.hits"
            :key="index"
          >
            <v-expansion-panel-header>
              <span>
                <font class="d-block"><b>Файл:</b> {{ item._source.file[index].name }}</font>
                <font class="d-block mt-2"><b>Количество вхождений (частота слов):</b> {{ file.highlight['file.file_content.content'].length }}</font>
              </span>
            </v-expansion-panel-header>
            <v-expansion-panel-content>
              <b>Содержимое файла:</b>
              <span
                v-for="(content, index) in file.highlight['file.file_content.content']"
                v-html="'...' + content + '...'"
                class="highlight-tag"
                :key="index"
              ></span>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
<!--        <div-->
<!--          v-for="(file, index) in item.inner_hits.file.hits.hits"-->
<!--          class="mb-4"-->
<!--          :key="index"-->
<!--        >-->
<!--          <span><b>Файл:</b> {{ file._source.name }}</span>-->
<!--          <br/>-->
<!--          <b>Содержимое файла:</b>-->
<!--          <span-->
<!--            v-for="(content, index) in file.highlight['file.file_content.content']"-->
<!--            v-html="'...' + content + '...'"-->
<!--            class="highlight-tag"-->
<!--            :key="index"-->
<!--          ></span>-->

<!--          <span>Количество вхождений (фрагментов): {{ file.highlight['file.file_content.content'].length }}<br></span>-->
<!--        </div>-->
      </div>
      <span class="main-card__hit">
        <b>Архивный шифр:</b> {{ item._source.ed_cipher ? item._source.ed_cipher.value : 'Нет данных' }}
      </span>
      <span class="main-card__hit">
        <b>Статус обработки:</b> {{ item._source.ed_status ? item._source.ed_status.name : 'Нет данных' }}
      </span>
      <span class="main-card__hit"><b>Дата регистрации:</b> {{ item._source.reg_date ? item._source.reg_date : 'Нет данных' }}</span>
      <span class="main-card__hit"><b>ДСП:</b> {{ item._source.is_dsp ? 'Да' : 'Нет' }}</span>
      <span class="main-card__hit"><b>Индекс и заголовок дела:</b>
        {{ item._source.dossier ? `${item._source.dossier.index} - ${item._source.dossier.name}` : 'Нет данных' }}
      </span>

      <span class="main-card__hit">
        <b>Вид документа:</b>
        {{ item._source.dossier && item._source.dossier.di_kind && item._source.dossier.di_kind[0] ? item._source.dossier.di_kind[0].num_show : 'Нет данных' }}
      </span>

      <span class="main-card__hit">
        <b>Срок хранения:</b>
        {{ item._source.dossier && item._source.dossier.di_kind && item._source.dossier.di_kind[0] ? item._source.dossier.di_kind[0].di_save_period.save_info : 'Нет данных' }}
      </span>

      <span class="main-card__hit">
        <b>Вид носителя:</b>
        {{ item._source.media_type_ed ? item._source.media_type_ed.name : 'Нет данных' }}
      </span>

      <span
        class="main-card__hit"
        :style="{
          cursor: hasRegister(item._source.dossier) ? 'pointer' : 'text'
        }"
        @click="hasRegister(item._source.dossier) ? showDetailRegister(item._source.dossier.register[0]) : () => {}"
      >
        <b>Заголовок сводной описи:</b>
        {{ hasRegister(item._source.dossier) && item._source.dossier.register[0] ? item._source.dossier.register[0].name : 'Нет данных' }}
      </span>

      <span class="main-card__hit">
        <b>Архив:</b>
        {{ hasRegister(item._source.dossier) && item._source.dossier.register[0] ? item._source.dossier.register[0].archive.name : 'Нет данных' }}
      </span>

      <span class="main-card__hit">
        <b>Фонд:</b>
        {{ hasRegister(item._source.dossier) && item._source.dossier.register[0] ? item._source.dossier.register[0].fund.name : 'Нет данных' }}
      </span>
    </div>
  </div>
</template>

<script>

export default {
  props: {
    item: {
      type: Object,
      required: true
    }
  },

  methods: {
    hasHighlightFileContent (item) {
      return item.inner_hits?.file
    },

    hasRegister (dossier) {
      if (!dossier) return false
      return dossier.register || dossier.register
    },

    showDetailEd (id) {
      this.$router.push({ name: 'detail-ed', params: { id: id } })
    },

    showDetailRegister (register) {
      if (register.register_status.code === 'approved') {
        this.$router.push({ name: 'detail-approved-register', params: { id: register.id } })
      } else this.$router.push({ name: 'detail-project-register', params: { id: register.id } })
    }
  }
}
</script>

<style lang="scss">

.main-card {
  padding: 15px;
  background-color: #fff;
  margin-bottom: 30px;

  .card-content {
    .v-expansion-panel {
      .v-expansion-panel-header, .v-expansion-panel-content__wrap {
        padding: 0;
      }
      &:before {
        box-shadow: none;
      }
    }
  }

  .highlight-tag {
    display: inline-block;
    margin-bottom: 15px;
    em {
      font-style: normal;
      font-weight: bold;
      background-color: rgba(0, 97, 217, .22);
      color: var(--v-secondary-base);
    }
  }

  &__hit {
    display: inline-block;
    margin-right: 30px;
    color: #76767A;

    b {
      color: var(--v-primary-base);
    }
  }

  &__title {
    margin-bottom: 20px;
  }

  .crop-text {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}
</style>
