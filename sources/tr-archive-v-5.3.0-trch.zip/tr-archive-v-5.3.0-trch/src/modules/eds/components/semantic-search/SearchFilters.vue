<template>
  <div class="search-filters">
    <div class="search-filters__title">
      <h2 class="mb-3">Фильтры</h2>
      <!--      <span @click="clearFilters">Сбросить все</span>-->
    </div>
    <div class="search-filters__blocks">
      <ArchiveCipher
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdStatus
        class="mb-3"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <EdName
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdNumber
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <RegisterDate
        class="mb-3"
        :position="'left'"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Dsp
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <EdMediaType
        class="mb-3"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <DossierIndex
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierName
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Archive
        class="mb-3"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <Fund
        class="mb-3"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <RegisterNumber
        class="mb-3"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Classifier
        class="mb-3"
        ref="classifier"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <ClassifierKinds
        class="mb-3"
        ref="diKinds"
        :reset-filter="resetFilter"
        :selected-classifier="filterObj.classifier"
        :disabled="!filterObj.classifier"
        @set-filter="setFilter($event)"
      />

      <SaveTypeList
        class="mb-3"
        ref="saveType"
        :reset-filter="resetFilter"
        :is-load="true"
        @set-filter="setFilter($event)"
      />

      <SavePeriod
        class="mb-6"
        ref="savePeriod"
        :disabled="!isTemp"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <v-btn
        class="w-100 rounded-lg"
        color="secondary"
        @click="apply"
      >Применить
      </v-btn>
    </div>
  </div>
</template>

<script>

import ArchiveCipher from '@/components/Filters/Fields/ArchiveCipher.vue'
import EdStatus from '@/components/Filters/Fields/Ed/EdStatus.vue'
import EdMediaType from '@/components/Filters/Fields/Ed/EdMediaType.vue'
import EdName from '@/components/Filters/Fields/Ed/EdName.vue'
import EdNumber from '@/components/Filters/Fields/Ed/EdNumber.vue'
import RegisterDate from '@/components/Filters/Fields/RegisterDate.vue'
import Dsp from '@/components/Filters/Fields/Ed/Dsp.vue'
import DossierIndex from '@/components/Filters/Fields/Dossier/DossierIndex.vue'
import DossierName from '@/components/Filters/Fields/Dossier/DossierName.vue'
import Archive from '@/components/Filters/Fields/Archive.vue'
import Fund from '@/components/Filters/Fields/Fund.vue'
import SaveTypeList from '@/components/Filters/Fields/SaveType.vue'
import SavePeriod from '@/components/Filters/Fields/SavePeriod.vue'
import RegisterNumber from '@/components/Filters/Fields/Register/RegisterNumber.vue'
import ClassifierKinds from '@/components/Filters/Fields/ClassifierKinds.vue'
import Classifier from '@/components/Filters/Fields/Classifier.vue'

export default {
  name: 'SearchFilters',
  components: {
    Classifier,
    ClassifierKinds,
    RegisterNumber,
    SavePeriod,
    Fund,
    Archive,
    ArchiveCipher,
    RegisterDate,
    EdStatus,
    EdMediaType,
    EdName,
    EdNumber,
    Dsp,
    DossierIndex,
    SaveTypeList,
    DossierName
  },

  data: () => ({
    resetFilter: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const filters = []
      if (this.filterObj.cipher) {
        filters.push({ fields: 'text', key: 'ed_cipher.value.keyword', value: this.filterObj.cipher.query })
      }
      if (this.filterObj.edStatus) {
        filters.push({ fields: 'text', key: 'ed_status.id', value: this.filterObj.edStatus.query.value })
      }
      if (this.filterObj.edName) {
        filters.push({ fields: 'text', key: 'name.keyword', value: this.filterObj.edName.query })
      }
      if (this.filterObj.edNumber) {
        filters.push({ fields: 'text', key: 'num.keyword', value: this.filterObj.edNumber.query })
      }
      if (this.filterObj.regDate) {
        filters.push({
          fields: 'date_range',
          key: 'reg_date',
          range: {
            from: this.filterObj.regDate.query[0],
            to: this.filterObj.regDate.query[1]
          }
        })
      }
      if (this.filterObj.isDsp) {
        filters.push({ fields: 'boolean', key: 'is_dsp', value: this.filterObj.isDsp.query.value })
      }
      if (this.filterObj.mediaType) {
        filters.push({ fields: 'text', key: 'media_type_ed.id', value: this.filterObj.mediaType.query.value })
      }
      if (this.filterObj.index) {
        filters.push({ fields: 'text', key: 'dossier.index.keyword', value: this.filterObj.index.query })
      }
      if (this.filterObj.dossierName) {
        filters.push({ fields: 'text', key: 'dossier.name.keyword', value: this.filterObj.dossierName.query })
      }
      if (this.filterObj.archive) {
        filters.push({ fields: 'text', key: 'dossier.register.archive.id', value: this.filterObj.archive.query.value })
      }
      if (this.filterObj.fund) {
        filters.push({ fields: 'text', key: 'dossier.register.fund.id', value: this.filterObj.fund.query.value })
      }
      if (this.filterObj.registerName) {
        filters.push({ fields: 'text', key: 'dossier.register.name.keyword', value: this.filterObj.registerName.query })
      }
      if (this.filterObj.registerNumber) {
        filters.push({ fields: 'text', key: 'dossier.register.num.keyword', value: this.filterObj.registerNumber.query })
      }
      if (this.filterObj.classifier) {
        filters.push({ fields: 'text', key: 'dossier.di_kind.di_kind_group.di_classifier.id', value: this.filterObj.classifier.query.value })
      }
      if (this.filterObj.diKinds) {
        const groups = this.filterObj.diKinds.query.filter(item => item.type === 'group').map(group => group.pk)
        const kinds = this.filterObj.diKinds.query.filter(item => item.type === 'kind').map(kind => kind.pk)
        if (groups.length) filters.push({ fields: 'text_array', key: 'dossier.di_kind.di_kind_group.id', value: groups })
        if (kinds.length) filters.push({ fields: 'text_array', key: 'dossier.di_kind.di_kind.id', value: kinds })
      }
      if (this.filterObj.saveType) {
        filters.push({ fields: 'text', key: 'save_type.id', value: this.filterObj.saveType.query.value })
      }
      if (this.filterObj.savePeriod) {
        filters.push({ fields: 'text', key: 'temp_save_period', value: this.filterObj.savePeriod.query })
      }
      return filters
    },

    isTemp () {
      return this.filterObj?.saveType?.query.code === 'temporarily'
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    apply () {
      this.$emit('set-filters', this.filterParams)
      // const filters = []
      //
      // if (this.selectedOption1) {
      //   filters.push(`media_type_ed:${this.selectedOption1}`)
      // }
      // const combinedFilters = filters.join(' AND ')
      // cb({...sp, this.filterParams})
    },

    clearFilters () {
      this.resetFilter = true
      this.$nextTick(() => {
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }
}
</script>

<style lang="scss">

.search-filters {
  flex: none;
  padding: 10px 15px 15px 15px;
  background-color: #fff;
  max-width: 350px;
  width: 350px;
}
</style>
