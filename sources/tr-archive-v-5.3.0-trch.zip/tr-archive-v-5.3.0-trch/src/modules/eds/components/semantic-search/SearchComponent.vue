<template>
  <div class="semantic">
<!--    <pre>{{responseEds}}</pre>-->
    <div class="semantic__main-search" v-click-outside="onClickOutside">
      <v-text-field
        v-model="config.search"
        class="search-field"
        data-qa="main-field"
        placeholder="Введите любой запрос"
        solo
        outlined
        rounded
        hide-details
        flat
        @focus="openSuggest = true, suggestInput()"
        @input="suggestInput"
        @keyup.enter="getResponse()"
      >
        <template v-slot:append-outer>
          <div v-if="openSuggest" class="search-field__suggest">
            <p
              class="suggest-options"
              v-for="(suggest, index) in suggestItems"
              :key="index"
              v-html="substringSuggest(suggest)"
              @click.stop="selectSuggest(suggest)"
            ></p>
          </div>
        </template>
      </v-text-field>
      <v-btn
        class="rounded-lg ml-3"
        color="secondary"
        @click="getResponse()"
      >Найти
      </v-btn>
    </div>

    <div class="semantic__results">
      <div v-if="loading" class="results-loader">
        <LoadingComponentVue/>
      </div>
      <div v-else class="results-list">
        <p>Общее количество ЭАД: {{ responseEds.hits.total.value }}</p>
        <p>Общее количество вхождений (частота слов) по запросу: {{ getCountHighlightFile(responseEds.hits.hits) }}</p>
        <CardEd
          v-for="(ed, index) in responseEds.hits.hits"
          :key="index"
          :item="ed"
        />

        <div class="pagination">
          <v-btn
            class="pagination__btn"
            color="secondary"
            outlined
            :disabled="page === 1"
            @click="page = 1"
          >
            <v-icon class="rounded-lg" color="secondary">
              mdi-chevron-double-left
            </v-icon>
          </v-btn>

          <v-pagination
            v-model="page"
            color="secondary"
            total-visible="7"
            :length="countPage"
          ></v-pagination>

          <v-btn
            class="pagination__btn"
            color="secondary"
            outlined
            :disabled="page === countPage"
            @click="page = countPage"
          >
            <v-icon class="rounded-lg" color="secondary">
              mdi-chevron-double-right
            </v-icon>
          </v-btn>
        </div>
      </div>

      <SearchFilters
        @set-filters="setFilters($event)"
      />
    </div>
  </div>
</template>

<script>

import CardEd from '@/modules/eds/components/semantic-search/Card.vue'
import SearchFilters from '@/modules/eds/components/semantic-search/SearchFilters.vue'
import {
  GET_OPENSEARCH_EDS,
  GET_SUGGEST_QUERY
} from '@/modules/eds/services/api'

export default {
  components: {
    SearchFilters,
    CardEd
  },

  data: () => ({
    suggestItems: [],
    page: 1,
    loading: true,
    openSuggest: false,
    responseEds: {},
    debounceTimer: 0,
    config: {
      search: '',
      filters: [],
      size: 15,
      from: 0
    }
  }),

  computed: {
    countPage () {
      return Math.ceil(this.responseEds.hits.total.value / this.config.size)
    }
  },

  watch: {
    page (newV) {
      console.log('page')
      this.config.from = (newV * this.config.size) - this.config.size
      this.getResponse()
    }
  },

  async mounted () {
    console.log('mounted')
    this.getResponse()
  },

  methods: {
    getCountHighlightFile (hits) {
      let count = 0
      hits.forEach(item => {
        console.log('item', item)
        if (item.inner_hits?.file) {
          item.inner_hits.file.hits.hits.forEach(highlightItem => {
            if (highlightItem.highlight) count = count + highlightItem.highlight['file.file_content.content'].length
          })
        }
      })
      return count || '-'
    },

    onClickOutside () {
      this.openSuggest = false
    },

    substringSuggest (item) {
      // Реализация фильтрации для выделения совпадающего текста
      const normalizedQuery = this.config.search.toLowerCase()
      const normalizedItem = item.toLowerCase()

      if (normalizedItem.includes(normalizedQuery)) {
        const startIndex = normalizedItem.indexOf(normalizedQuery)
        const endIndex = startIndex + normalizedQuery.length

        return [
          item.substring(0, startIndex),
          `<em>${item.substring(startIndex, endIndex)}</em>`,
          item.substring(endIndex)
        ].join('')
      } else {
        return item
      }
    },

    selectSuggest (e) {
      this.config.search = e
      this.openSuggest = false
      this.getResponse()
    },

    setFilters (filters) {
      console.log('filters')
      this.config.filters = [...filters]
      this.getResponse()
    },

    suggestInput (e) {
      // Отменяем предыдущий таймер, если он был
      if (this.debounceTimer) {
        clearTimeout(this.debounceTimer)
      }

      // Устанавливаем новый таймер для задержки отправки запроса
      this.debounceTimer = setTimeout(() => {
        this.getSuggest(e)
      }, 300)
    },

    getResponse () {
      this.loading = true
      this.openSuggest = false
      GET_OPENSEARCH_EDS(this.config).then(resp => {
        console.log('resp', resp)
        this.responseEds = resp
        this.loading = false
      })
    },

    getSuggest () {
      if (!this.config.search) return
      GET_SUGGEST_QUERY(this.config.search).then(resp => {
        this.suggestItems = resp.hits.hits.map(item => item._source.query)
        this.openSuggest = true
      })
    }
  }
}
</script>

<style lang="scss">

.semantic {
  .search-field {
    &__suggest {
      position: absolute;
      background: #fff;
      width: 100%;
      max-height: 400px;
      left: 0;
      border-bottom-left-radius: 8px;
      border-bottom-right-radius: 8px;
      top: 100%;
      box-shadow: 0 0 4px rgba(0, 0, 0, 0.25);
      z-index: 2;
      em {
        font-style: normal;
        font-weight: bold;
        background-color: rgba(0, 97, 217, .22);
        color: var(--v-secondary-base);
      }
    }
    .suggest-options {
      padding: 12px 16px;
      margin: 0;
      cursor: pointer;
      transition: .3s;
      &:hover {
        background: rgba(0, 0, 0, 0.03);
      }
    }
  }

  &__main-search {
    display: flex;
    align-items: center;
    margin: 30px 0;
  }

  &__results {
    display: flex;
    //flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;

    .results-loader {
      display: flex;
      justify-content: center;
      width: 100%;
    }

    .results-list {
      flex-basis: calc(100% - 380px);
      max-width: calc(100% - 380px);
    }

    .pagination {
      flex-basis: 100%;
    }
  }

  //.pagination {
  //  .ais-Pagination {
  //    &-list {
  //      display: flex;
  //      list-style: none;
  //      padding-left: 0;
  //    }
  //
  //    &-item {
  //      height: 44px;
  //      width: 44px;
  //      border: 1px solid #B5C9E5;
  //      background-color: #fff;
  //      transition: .3s;
  //
  //      &--selected {
  //        background-color: var(--v-secondary-base);
  //        border-color: var(--v-secondary-base);
  //
  //        a {
  //          color: #fff;
  //        }
  //      }
  //    }
  //
  //    &-link {
  //      display: flex;
  //      transition: .3s;
  //      height: 100%;
  //      text-decoration: none;
  //      align-items: center;
  //      justify-content: center;
  //    }
  //  }
  //}
}
</style>
