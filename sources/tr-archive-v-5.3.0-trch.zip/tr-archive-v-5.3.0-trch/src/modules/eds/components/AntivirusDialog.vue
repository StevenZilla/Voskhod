<template>
  <v-card class="detail__main-info popup">
    <v-toolbar
      flat
      dense
      class="popup-toolbar"
    >
      <v-toolbar-title>Проверка файлов</v-toolbar-title>
<!--      <BtnCancelSlot :icon="true" @close="$emit('close')"/>-->
      <v-btn icon dark @click="$emit('close')">
        <v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>

    <div class="main-table-inner">
      <v-data-table
        item-key="id"
        no-data-text="Нет данных"
        loading-text="Загрузка данных"
        class="scroll-popup-table sortable-table no-hover"
        hide-default-footer
        disable-sort
        :headers="headers"
        :items="checkingLocalFiles"
        :loading="loadingCheck"
        :fixed-header="true"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.short_name="{ item }">
          <span
            :class="{
              'success--text': item.status.code === 'ok',
              'error--text': item.status.code === 'infection' || item.status.code === 'error',
              'warning--text': !item.status.code
            }"
          >{{ item.status.short_name }}</span>
        </template>

        <template v-slot:item.delete="{ index }">
          <v-btn
            color="secondary"
            class="rounded-lg"
            icon
            @click="deleteFile(index)"
          >
            <v-icon>mdi-delete-outline</v-icon>
          </v-btn>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer>
          <div class="popup__actions">
            <v-alert
              v-if="invalidFiles && checkingLocalFiles.length"
              icon="mdi-alert"
              type="error"
            >Файлы, не прошедшие проверку, не будут прикреплены в карточку ЭАД!
            </v-alert>
          </div>
        </template>
      </v-data-table>
    </div>

    <div class="main-table-inner__buttons popup__actions d-flex justify-end">
      <v-btn
        color="secondary"
        class="rounded-lg mr-3"
        outlined
        :disabled="loadingCheck || !checkingLocalFiles.length"
        @click="uploadFiles"
      ><v-icon class="mr-1">mdi-note-plus-outline</v-icon>
        Загрузить
      </v-btn>

<!--      <BtnCancelSlot-->
<!--        :text="'Отменить'"-->
<!--        @close="$emit('close')"-->
<!--      />-->
      <v-btn
        outlined
        color="secondary"
        class="rounded-lg"
        @click="$emit('close')"
      >Отменить
      </v-btn>
    </div>

    <v-dialog
      v-model="isNotify"
      content-class="dialog-auto-height"
      max-width="615px"
    >
      <AppNotify
        :title="'Редактирование'"
        :text="error"
        :type="'error'"
        :icon="'mdi-alert'"
        @close-popup="isNotify = false"
      />
    </v-dialog>
  </v-card>
</template>

<script>

import { CHECK_ANTIVIRUS } from '@/modules/eds/services/api'
import { mapState } from 'vuex'

export default {
  props: {
    filesToCheck: {
      type: Array
    },

    metaFilesToCheck: {
      type: Array
    }
  },

  data: () => ({
    checkingLocalFiles: [],
    invalidFiles: false,
    loadingCheck: false,
    isNotify: false,
    loading: true,
    error: [],
    headers: [
      {
        text: 'Файл',
        width: '150px',
        value: 'name'
      },
      {
        text: 'Статус проверки',
        width: '200px',
        value: 'short_name'
      },
      {
        text: 'Сообщение проверки',
        width: '70%',
        value: 'status.name'
      },
      {
        text: '',
        value: 'delete',
        width: '64px'
      }
    ]
  }),

  watch: {
    filesToCheck: {
      handler () {
        this.prepareData()
        this.checkAntivirus()
      },
      immediate: true
    }
  },

  computed: {
    ...mapState({
      checkSettings: state => state.checkSettings
    })
  },

  methods: {
    deleteFile (index) {
      this.$delete(this.checkingLocalFiles, index)
    },

    prepareData () {
      this.checkingLocalFiles = this.filesToCheck.map(file => {
        return {
          ...file,
          status: {
            short_name: 'Ожидание',
            name: null
          }
        }
      })
    },

    uploadFiles () {
      let filterArray = []
      filterArray = this.checkingLocalFiles.filter(item => item.status.code === 'ok')
      this.$emit('add-files', filterArray)
    },

    async checkAntivirus () {
      this.loadingCheck = true
      const formData = new FormData()
      this.metaFilesToCheck.forEach(file => {
        formData.append('files[]', file)
      })
      CHECK_ANTIVIRUS(formData).then(resp => {
        // индекс нужен чтобы поменялся статус
        resp.files.forEach((file, index) => {
          if (file.status.code === 'infection' || file.status.code === 'error') {
            this.invalidFiles = true
            // const index = this.checkingLocalFiles.findIndex(localFile => localFile.name === file.originalName)
            // либо при н
            // if (index !== -1) this.checkingLocalFiles.splice(index, 1)
          }
          this.checkingLocalFiles[index].status = file.status
          // this.$set(this.checkingLocalFiles, index, file)
        })
      }).finally(() => {
        this.loadingCheck = false
      })
    }
  }
}
</script>

<style lang="scss">

.popup {
  &-toolbar {
    padding: 0 15px;
  }

  &__content {
    position: relative;
    overflow: auto;
    height: calc(100% - 128px);
    scrollbar-width: thin;
    padding: 0 15px 15px 15px;

    &-title {
      color: #000026;
      font-size: 16px;
      font-family: "Golos Text Medium";
      font-weight: 500;
      margin-top: 15px;
      margin-bottom: 15px;
    }
  }

  &__actions {
    padding: 15px;
  }
}
</style>
