<template>
  <div class="form-group">
    <p class="form-group__title">Дата регистрации <span class="required-label">*</span></p>
    <date-range-picker
      v-model="dateRangeMix.start"
      opens="right"
      show-dropdowns
      single-date-picker
      auto-apply
      :max-date="todayMix"
      :ranges="false"
      :locale-data="localeSettings"
      @toggle="$_setBeginDate($event, [value], 'start')"
      @update="setDate($event)"
    >
      <template #input>
        <v-text-field
          data-qa="ed-reg-date"
          class="rounded-lg"
          readonly
          outlined
          hide-details
          placeholder="Дата регистрации"
          append-icon="mdi-calendar-blank"
          :value="$_formatDate(value)"
        ></v-text-field>
      </template>
    </date-range-picker>
  </div>
</template>

<script>

import { format } from 'date-fns'

export default {
  props: {
    param: {
      type: String,
      required: false
    }
  },

  data: () => ({
    value: format(new Date(), 'yyyy-MM-dd')
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.$emit('set-property', this.value)
  },

  methods: {
    setDate (date) {
      this.value = this.$_setDate(date, 'date')
      this.$emit('set-property', this.value)
    }
  }
}
</script>

<style lang="scss">

</style>
