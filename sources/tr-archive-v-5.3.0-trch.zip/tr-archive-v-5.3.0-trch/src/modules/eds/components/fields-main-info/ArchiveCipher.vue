<template>
  <div class="form-group">
    <p class="form-group__title">Архивный шифр</p>
    <v-text-field
      class="rounded-lg"
      outlined
      clearable
      disabled
      filled
      hide-details
      :value="getValue(param)"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  methods: {
    getValue (val) {
      if (!val) return 'Нет данных'
      return val
    }
  }
}
</script>

<style lang="scss">

</style>
