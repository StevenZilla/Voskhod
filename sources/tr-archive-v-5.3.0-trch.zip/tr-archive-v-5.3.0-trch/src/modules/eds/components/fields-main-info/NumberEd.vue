<template>
  <div class="form-group">
    <p class="form-group__title">Регистрационный номер <span class="required-label">*</span></p>
    <v-text-field
      v-model="value"
      class="rounded-lg"
      data-qa="ed-num"
      outlined
      clearable
      hide-details
      placeholder="Регистрационный номер"
      counter="20"
      :maxlength="20"
    ></v-text-field>
  </div>
</template>

<script>
export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
