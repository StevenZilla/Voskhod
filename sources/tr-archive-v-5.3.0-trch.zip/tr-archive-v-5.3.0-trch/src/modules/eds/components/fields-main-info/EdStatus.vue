<template>
  <div class="form-group">
    <p class="form-group__title">Статус обработки</p>
    <v-text-field
      class="rounded-lg"
      outlined
      clearable
      disabled
      filled
      hide-details
      :value="value"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: Object,
      required: false
    }
  },

  data: () => ({
    value: 'Черновик'
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV.value
    }
  }
}
</script>

<style lang="scss">

</style>
