<template>
  <div class="form-group">
    <p class="form-group__title">Вид носителя</p>
    <v-autocomplete
      v-model="value"
      class="rounded-lg eds-media-type"
      return-object
      data-qa="ed-media-type"
      hide-details
      outlined
      item-text="value"
      item-value="id"
      placeholder="Выберите вид носителя"
      :items="edMediaList"
      :attach="'.eds-media-type'"
      :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_ED_MEDIA_LIST } from '../../services/api'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    edMediaList: [],
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    getData () {
      GET_ED_MEDIA_LIST().then(resp => { this.edMediaList = resp })
    }
  }
}
</script>

<style lang="scss">

</style>
