<template>
  <div class="form-group">
    <p class="form-group__title">Подразделение</p>
    <v-autocomplete
      v-model="value"
      class="rounded-lg eds-subdivisions"
      hide-details
      return-object
      outlined
      clearable
      placeholder="Выберите подразделение"
      item-text="name"
      item-value="id"
      :items="subdivisionList"
      :attach="'.eds-subdivisions'"
      :no-data-text="'Нет результатов'"
      :disabled="dossierStatusClose"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_SUBDIVISIONS_LIST } from '@/services/app'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    },

    dossier: {
      type: Object,
      required: false,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    subdivisionList: [],
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  computed: {
    dossierStatusClose () {
      return this.dossier?.status.code === 'closed'
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    getData () {
      if (this.dossierStatusClose) return

      GET_SUBDIVISIONS_LIST().then(resp => {
        this.subdivisionList = resp.map(item => {
          return {
            name: `${item.code} ${item.name}`,
            id: item.id
          }
        })
      })
    }
  }
}
</script>

<style lang="scss">

</style>
