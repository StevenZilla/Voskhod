<template>
  <div class="form-group">
    <p class="form-group__title">Срок хранения во вр. хранилище (лет)</p>
    <v-text-field
      class="rounded-lg"
      outlined
      clearable
      disabled
      filled
      hide-details
      :value="getValue(param)"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: Number,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'number'
      }
    }
  },

  methods: {
    getValue (val) {
      if (!val) return 'Нет данных'
      return val
    }
  }
}
</script>

<style lang="scss">

</style>
