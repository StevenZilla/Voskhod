<template>
  <div class="form-group">
    <p class="form-group__title">Вид хранения</p>
    <v-text-field
      class="rounded-lg"
      outlined
      clearable
      disabled
      filled
      hide-details
      :value="getValue(param)"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  methods: {
    getValue (val) {
      if (!val) return 'Нет данных'
      return val.value
    }
  }
}
</script>

<style lang="scss">

</style>
