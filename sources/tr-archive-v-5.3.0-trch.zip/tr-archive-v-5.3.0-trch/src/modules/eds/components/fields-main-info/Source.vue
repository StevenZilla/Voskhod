<template>
  <div class="form-group">
    <p class="form-group__title">Источник <span class="required-label">*</span></p>
    <v-autocomplete
      v-model="value"
      class="rounded-lg"
      data-qa="ed-source"
      outlined
      clearable
      return-object
      hide-details
      item-text="value"
      item-value="id"
      placeholder="Выберите источник"
      color="secondary"
      :attach="true"
      :loader-height="5"
      :items="sourceList"
      :no-data-text="'Нет результатов'"
    ></v-autocomplete>
  </div>
</template>

<script>

import { GET_SOURCES_LIST } from '../../services/api'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  data: () => ({
    sourceList: [],
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = { ...newV }
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  mounted () {
    this.getData()
  },

  methods: {
    getData () {
      GET_SOURCES_LIST().then(resp => { this.sourceList = resp })
    }
  }
}
</script>

<style lang="scss">

</style>
