<template>
  <div class="form-group">
    <p class="form-group__title">Дата и время создания в системе</p>
    <v-text-field
      class="rounded-lg"
      outlined
      clearable
      disabled
      filled
      hide-details
      :value="$_formatDate(value, 'time')"
    ></v-text-field>
  </div>
</template>

<script>

export default {
  props: {
    param: {
      type: String,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'string'
      }
    }
  },

  data: () => ({
    value: null
  }),

  mounted () {
    this.value = this.param
  }
}
</script>

<style lang="scss">

</style>
