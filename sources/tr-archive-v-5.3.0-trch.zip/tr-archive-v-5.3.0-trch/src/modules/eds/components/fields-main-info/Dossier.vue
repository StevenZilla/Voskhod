<template>
  <div class="form-group w-100">
    <p class="form-group__title">Индекс и заголовок дела</p>
    <div class="d-flex">
      <v-text-field
        class="rounded-lg"
        outlined
        hide-details
        readonly
        :append-icon="value ? 'mdi-close' : ''"
        :value="getDossierValue(value)"
        :disabled="dossierStatusClose"
        @click:append="value = null"
      ></v-text-field>

      <AddDossiers
        :dossier="value"
        :exclude-dossier="param"
        :subdivision="subdivision"
        :disabled="dossierStatusClose"
        @set-dossier="value = $event"
      />
    </div>
  </div>
</template>

<script>

import AddDossiers from '../add-dossier/AddDossiers.vue'

export default {
  props: {
    param: {
      type: Object,
      required: false,
      default: null,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    },

    subdivision: {
      type: Object,
      required: false,
      validator: function (value) {
        return value === null || typeof value === 'object'
      }
    }
  },

  components: {
    AddDossiers
  },

  data: () => ({
    value: null
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  },

  computed: {
    dossierStatusClose () {
      return this.param?.status.code === 'closed'
    }
  },

  methods: {
    getDossierValue (dossier) {
      if (!dossier) return 'Нет данных'
      return `${dossier.index} - ${dossier.name}`
    }
  }
}
</script>

<style lang="scss">

</style>
