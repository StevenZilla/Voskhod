<template>
  <div class="form-group d-flex align-center mb-2">
    <v-chip
      class="ma-2 info-badge"
      color="warning"
      text-color="white"
    >ДСП
    </v-chip>
    <v-simple-checkbox
      v-model="value"
      color="secondary"
      v-ripple
    ></v-simple-checkbox>
  </div>
</template>

<script>
export default {
  props: {
    param: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data: () => ({
    value: false
  }),

  watch: {
    param (newV) {
      if (newV) this.value = newV
    },

    value (newV) {
      this.$emit('set-property', newV)
    }
  }
}
</script>

<style lang="scss">

</style>
