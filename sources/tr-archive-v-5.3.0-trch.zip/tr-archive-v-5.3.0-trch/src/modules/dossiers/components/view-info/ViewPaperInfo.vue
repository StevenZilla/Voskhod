<template>
  <v-card class="detail__main-info mt-5">
    <v-card-title>
      <h2>Информация о бумажном носителе</h2>
      <v-icon
        icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >{{ chevron }}
      </v-icon>
    </v-card-title>

    <transition name="fade" mode="out-in">
      <v-card-text v-if="isMainInfo" class="detail__view-inner item-5">
        <div class="detail__item">
          <p class="detail__item-title">Место размещения</p>
          <span class="detail__value">{{ paperInfo ? paperInfo.location : 'Нет данных' }}</span>
        </div>
      </v-card-text>
    </transition>
  </v-card>
</template>

<script>

import { mapGetters } from 'vuex'

export default {
  name: 'ViewPaperInfo',

  data: () => ({
    isMainInfo: false
  }),

  computed: {
    ...mapGetters('dossiers', ['GET_DOSSIER_KEY']),

    paperInfo () {
      return this.GET_DOSSIER_KEY('paper_info')
    },

    mediaType () {
      return this.GET_DOSSIER_KEY('media_type')
    },

    chevron () {
      return this.isMainInfo ? 'mdi-chevron-up' : 'mdi-chevron-down'
    }
  },

  watch: {
    mediaType (newV) {
      if (newV.code !== 'electronic') this.isMainInfo = true
    }
  }
}
</script>
<style>
.fade-enter-active,
.fade-leave-active {
  transition: all .5s;
}

.fade-enter,
.fade-leave-to {
  transform: translateY(-50px);
  opacity: 0;
}
</style>
