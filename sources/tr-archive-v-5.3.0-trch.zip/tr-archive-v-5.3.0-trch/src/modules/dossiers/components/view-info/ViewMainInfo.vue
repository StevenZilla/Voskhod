<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2>Общая информация</h2>
      <v-icon
        class="ml-2"
        color="secondary"
        @click="isMainInfo = !isMainInfo"
      >mdi-chevron-down</v-icon>
    </v-card-title>

    <v-card-text class="detail__view-inner item-5" :class="{'detail__view-inner--collapse': !isMainInfo}">
      <div class="detail__item">
        <p class="detail__item-title">Индекс дела</p>
        <span class="detail__value">{{ getValue(detailDossier.index) }}</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Подразделение</p>
        <span v-if="detailDossier.subdivision" class="detail__value">
          {{ detailDossier.subdivision.code }} {{ detailDossier.subdivision.name }}
          <TransitSubdivisionIcon :transitInfo="transitInfo" v-if="transitInfo.count"/>
        </span>
        <span v-else class="detail__value">Нет данных</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Вид хранения</p>
        <span class="detail__value">{{ getValue(detailDossier.save_type) }}</span>
      </div>
      <div v-if="detailDossier.save_type && detailDossier.save_type.code === 'temporarily'" class="detail__item">
        <p class="detail__item-title">Срок хранения во временном хранилище, год (лет)</p>
        <span class="detail__value">{{ getValue(detailDossier.temp_save_period) }}</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Архивный шифр</p>
        <v-chip
          v-if="detailDossier.dossier_cipher"
          class="info-badge"
          color="#00A65A"
        ><span class="detail__value white--text">{{ detailDossier.dossier_cipher }}</span></v-chip>
        <span v-else class="detail__value">Нет данных</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Вид носителя</p>
        <span class="detail__value">{{ getValue(detailDossier.media_type) }}</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Объем, Мб</p>
        <span class="detail__value">{{ getValue(detailDossier.size) }}</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Крайние даты</p>
        <span class="detail__value" v-if="detailDossier.start_date && detailDossier.end_date">{{ `${$_formatDate(detailDossier.start_date,'date')}&mdash;${$_formatDate(detailDossier.end_date,'date')}` }}</span>
        <span class="detail__value" v-else>Нет данных</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Статус дела</p>
        <span class="detail__value">{{ getValue(detailDossier.status) }}</span>
      </div>
      <div class="detail__item">
        <p class="detail__item-title">Переходящее</p>
        <v-simple-checkbox
          color="secondary"
          disabled
          filled
          v-ripple
          v-model="detailDossier.is_transit"
        ></v-simple-checkbox>
      </div>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import TransitSubdivisionIcon from '@/components/TransitSubdivisionIcon.vue'

export default {
  name: 'ViewMainInfo',
  components: { TransitSubdivisionIcon },

  data: () => ({
    isMainInfo: true
  }),

  computed: {
    ...mapState({
      detailDossier: state => state.dossiers.detailDossier,
      transitInfo: state => state.dossiers.transitInfo
    })
  },

  methods: {
    getValue (val) {
      if (!val) return 'Нет данных'
      if (val.value) return val.value
      else return val
    }
  }
}
</script>

<style>
</style>
