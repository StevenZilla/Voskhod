<template>
  <div class="card">
    <v-badge
      v-if="dossierIsDeleted"
      class="big-badge"
      color="black"
      content="УДАЛЕН"
    ></v-badge>
    <h2 class="detail__title">
      {{ GET_DOSSIER_NAME }}
      <v-chip
        v-if="GET_DOSSIER_CIPHER"
        class="ma-2 info-badge"
        color="#00A65A"
        text-color="white"
      >{{ GET_DOSSIER_CIPHER }}
      </v-chip>
    </h2>

    <ViewMainInfo/>
    <ViewPaperInfo/>
    <ViewNomenclatures/>
    <ViewAcceptRegisters/>
    <ViewRegisters/>
    <ViewDeletedActs/>
    <ViewEds/>

    <TemplateButtons>
      <template #buttons-left>
        <v-btn
          v-if="GET_VIEW_BUTTONS.is_edit"
          class="rounded-lg mr-3"
          color="secondary"
          outlined
          @click="switchMode()"
        >
          <v-icon class="mr-2">mdi-pencil-outline</v-icon>
          Редактировать
        </v-btn>
        <v-btn
          v-if="GET_VIEW_BUTTONS.is_rollback"
          class="rounded-lg mr-3"
          color="secondary"
          outlined
          @click="changeStatus('actively')"
        >
          <v-icon class="mr-2">mdi-pencil-outline</v-icon>
          Вернуть дело
        </v-btn>
        <v-btn
          v-if="GET_VIEW_BUTTONS.is_closed"
          class="rounded-lg"
          color="secondary"
          outlined
          @click="changeStatus('close')"
        >
          <v-icon class="mr-2">mdi-block-helper</v-icon>
          Закрыть дело
        </v-btn>
      </template>

      <template #buttons-right>
        <v-btn
          data-qa="close"
          class="rounded-lg"
          color="secondary"
          @click="$_closeDetail()"
        >
          Закрыть
        </v-btn>
      </template>
    </TemplateButtons>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import { UPDATE_DOSSIER_STATUS } from '../../services/api'
import ViewMainInfo from './ViewMainInfo.vue'
import ViewPaperInfo from './ViewPaperInfo.vue'
import ViewNomenclatures from './ViewNomenclatures'
import ViewRegisters from './ViewRegisters'
import ViewAcceptRegisters from './ViewAcceptRegisters'
import ViewEds from './ViewEds'
import ViewDeletedActs from './ViewDeletedActs.vue'

export default {
  name: 'ViewDossierInfo',

  components: {
    ViewMainInfo,
    ViewNomenclatures,
    ViewRegisters,
    ViewAcceptRegisters,
    ViewEds,
    ViewPaperInfo,
    ViewDeletedActs
  },

  computed: {
    ...mapGetters('dossiers', ['GET_DOSSIER_KEY', 'GET_DOSSIER_NAME', 'GET_DOSSIER_CIPHER', 'GET_VIEW_BUTTONS']),

    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    },

    dossierIsDeleted () {
      return this.GET_DOSSIER_KEY('is_deleted')
    }
  },

  methods: {
    switchMode () {
      this.$store.dispatch('dossiers/SET_VALUE', { key: 'modeDossier', value: 'edit' })
    },

    async changeStatus (code) {
      await UPDATE_DOSSIER_STATUS(this.id, code)
      this.$emit('refresh-data')
    }
  }
}
</script>

<style>

</style>
