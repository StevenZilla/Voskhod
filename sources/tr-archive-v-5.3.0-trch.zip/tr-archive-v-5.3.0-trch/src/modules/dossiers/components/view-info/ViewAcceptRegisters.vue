<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Сдаточные описи</h2>
    </v-card-title>

    <v-card-text>
      <v-data-table
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        item-key="id"
        class="main-table"
        :loading="loading"
        :loading-text="'Загрузка данных'"
        :headers="headers"
        :items="acceptRegistersList"
        @click:row="showDetail($event)"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.part="{ item }">
          <span v-if="!item.part.name" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.part.name }}</span>
        </template>

        <template v-slot:item.register_type>
          —
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_ACCEPT_DOSSIER } from '@/services/app'

export default {
  data: () => ({
    acceptRegistersList: [],
    loading: true,
    headers: [
      {
        text: 'Заголовок',
        value: 'name',
        width: '250px'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '230px'
      },
      {
        text: 'Раздел / подраздел',
        value: 'part',
        width: '250px'
      },
      {
        text: 'Год',
        value: 'year',
        width: '80px'
      },
      {
        text: 'Вид',
        value: 'register_type',
        width: '290px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  created () {
    if (this.id) {
      GET_ACCEPT_DOSSIER(this.id).then(resp => {
        this.$set(this.acceptRegistersList, 0, resp.accept_register)
        // this.acceptRegistersList = resp.accept_register
      }).finally(() => {
        this.loading = false
      })
    }
  },

  methods: {
    showDetail (e) {
      if (e.accept_register_status?.code === 'approved') this.$router.push({ name: 'detail-approved-accepted', params: { id: e.id } })
      else this.$router.push({ name: 'detail-project-accepted', params: { id: e.id } })
    }
  }
}
</script>

<style>

</style>
