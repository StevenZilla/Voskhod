<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Сводные описи</h2>
    </v-card-title>

    <v-card-text>
      <v-data-table
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        item-key="id"
        class="main-table"
        :loading="loading"
        :loading-text="'Загрузка данных'"
        :headers="headers"
        :items="registersList.registers"
        @click:row="showDetail($event)"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.register_part="{ item }">
          <span v-if="!item.register_part.name" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.register_part.name }}</span>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_REGISTERS_LIST } from '@/services/app'

export default {
  data: () => ({
    registersList: [],
    loading: true,
    headers: [
      {
        text: 'Заголовок',
        value: 'name',
        width: '250px'
      },
      {
        text: 'Номер',
        value: 'num',
        width: '230px'
      },
      {
        text: 'Раздел / подраздел',
        value: 'register_part',
        width: '250px'
      },
      {
        text: 'Год',
        value: 'year',
        width: '80px'
      },
      {
        text: 'Вид',
        value: 'register_type.value',
        width: '290px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  created () {
    if (this.id) {
      GET_REGISTERS_LIST(new URLSearchParams(`dossier_id=${this.id}`)).then(resp => {
        this.registersList = resp
        this.loading = false
      })
    }
  },

  methods: {
    showDetail (e) {
      if (e.register_status.code === 'approved') this.$router.push({ name: 'detail-approved-register', params: { id: e.id } })
      else this.$router.push({ name: 'detail-project-register', params: { id: e.id } })
    }
  }
}
</script>

<style>

</style>
