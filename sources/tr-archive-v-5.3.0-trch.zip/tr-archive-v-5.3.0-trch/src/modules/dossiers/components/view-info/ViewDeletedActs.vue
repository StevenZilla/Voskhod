<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Акты об уничтожении</h2>
    </v-card-title>

    <v-card-text>
      <v-data-table
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        item-key="id"
        class="main-table"
        :loading="loading"
        :loading-text="'Загрузка данных'"
        :headers="headers"
        :items="deletedActsList"
        @click:row="showDetail($event)"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.status="{ item }">
          <span v-if="!item.status.value" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.status.value }}</span>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_DELETED_ACTS_DOSSIER } from '@/modules/dossiers/services/api'

export default {
  data: () => ({
    deletedActsList: [],
    loading: true,
    headers: [
      {
        text: 'Номер акта',
        value: 'num',
        width: '250px'
      },
      {
        text: 'Год акта',
        value: 'year',
        width: '230px'
      },
      {
        text: 'Дата формирования акта',
        value: 'create_date',
        width: '250px'
      },
      {
        text: 'Статус акта',
        value: 'status',
        width: '80px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  created () {
    if (this.id) {
      GET_DELETED_ACTS_DOSSIER(this.id).then(resp => {
        this.deletedActsList = resp.delete_acts
      }).finally(() => {
        this.loading = false
      })
    }
  },

  methods: {
    showDetail (e) {
      if (e.status?.code === 'project') this.$router.push({ name: 'detail-project-delete-act', params: { id: e.id } })
      else this.$router.push({ name: 'detail-approved-delete-act', params: { id: e.id } })
    }
  }
}
</script>

<style>

</style>
