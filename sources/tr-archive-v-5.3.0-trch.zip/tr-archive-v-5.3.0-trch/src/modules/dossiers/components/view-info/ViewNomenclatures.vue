<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Номенклатуры дел</h2>
    </v-card-title>

    <v-card-text>
      <v-data-table
        no-data-text="Нет данных"
        item-key="id"
        class="main-table"
        hide-default-footer
        disable-pagination
        disable-sort
        :loading-text="'Загрузка данных'"
        :loading="loading"
        :headers="headers"
        :items="nomenclaturesResponse.nomenclatures"
        :item-class="getNodeClass"
        @click:row="showDetail($event)"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <template v-slot:item.tk.status.value="{item}">
          <span v-if="item.tk === null" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.tk !== null ? item.tk.status.value : '' }}</span>
        </template>

        <template v-slot:item.nom_parts_by_dossier="{item}">
          <span v-if="item.nom_parts_by_dossier">{{ item.nom_parts_by_dossier }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.save_info>
          <div v-if="typeKind">
            <p class="accent-item">{{ typeKind.save_info }}</p>
          </div>

          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <template v-slot:item.di_kinds>
          <ViewTreeKinds :items="diKinds"></ViewTreeKinds>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_NOMENCLATURES_RESPONSE, GET_KIND_AGGREGATE } from '@/services/app'
import { mapState } from 'vuex'
import ViewTreeKinds from '@/components/ViewTreeKinds.vue'

export default {
  components: { ViewTreeKinds },
  data: () => ({
    loading: false,
    nomenclaturesResponse: {},
    diKinds: [],
    typeKind: null,
    headers: [
      {
        text: 'Номер',
        value: 'num',
        width: '10%'
      },
      {
        text: 'Год',
        value: 'year',
        width: '10%'
      },
      {
        text: 'Раздел',
        value: 'nom_parts_by_dossier',
        width: '10%'
      },
      {
        text: 'Срок хранения',
        value: 'save_info',
        width: '20%'
      },
      {
        text: 'Статья',
        value: 'di_kinds',
        width: '50%'
      }
    ]
  }),

  computed: {
    ...mapState({
      detailDossier: state => state.dossiers.detailDossier
    }),

    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  async mounted () {
    if (this.id) {
      this.loading = true
      this.diKinds = await GET_KIND_AGGREGATE(this.id)
      GET_NOMENCLATURES_RESPONSE(new URLSearchParams(`dossier_id=${this.id}`)).then(resp => {
        this.nomenclaturesResponse = resp
        this.loading = false
      })
      this.diKinds.forEach(kind => {
        this.getTypeKind(kind)
      })
    }
  },

  methods: {
    getTypeKind (kind) {
      console.log('kind', kind)
      if (kind.type === 'kind') {
        this.typeKind = kind
        return
      }
      if (kind.children) {
        kind.children.forEach(child => {
          this.getTypeKind(child)
        })
      }
    },

    showDetail (e) {
      this.$router.push({ name: 'detail-nomenclature', params: { id: e.id } })
    },

    getNodeClass (item) {
      if (item.status && item.status.code === 'closed') {
        return 'grey grey-text'
      }
    }
  }
}
</script>

<style>
</style>
