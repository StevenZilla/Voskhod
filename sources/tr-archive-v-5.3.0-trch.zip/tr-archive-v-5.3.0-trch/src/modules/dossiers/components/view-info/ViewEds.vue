<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Электронные документы</h2>
    </v-card-title>
    <v-card-text>
      <v-data-table
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        item-key="id"
        class="main-table"
        :items="edsList.eds"
        :headers="headers"
        @click:row="showDetail($event)"
      >
        <template v-slot:item.num="{ item }">
          <span>
            <v-icon v-if="item.is_deleted" class="mr-2" color="black">mdi-delete</v-icon>
            {{ item.num }}
          </span>
        </template>

        <template v-slot:item.reg_date="{ item }">
          {{ $_formatDate(item.reg_date, 'date') }}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.ed_status="{item}">
          <span v-if="!item.ed_status" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.ed_status ? item.ed_status.value : '' }} </span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.tk.status.value="{item}">
          <span v-if="!item.tk" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.tk ? item.tk.status.value : '' }} </span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.ak="{item}">
          <span v-if="item.ak !== null"> Да</span>
          <span v-else> Нет </span>
        </template>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>

import { GET_EDS_RESPONSE } from '@/services/app'

export default {
  name: 'ViewEds',

  data: () => ({
    edsList: {},
    headers: [
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '255px'
      },
      {
        text: 'Заголовок',
        value: 'name',
        width: '465px'
      },
      {
        text: 'Дата регистрации',
        value: 'reg_date',
        width: '300px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type.value',
        width: '300px'
      },
      {
        text: 'Статус обработки',
        value: 'ed_status',
        width: '300px'
      },
      {
        text: 'Статус отправки в ЦХЭД',
        value: 'tk.status.value',
        width: '300px'
      },
      {
        text: 'Во временном хранилище',
        value: 'ak',
        width: '300px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  async created () {
    if (this.id) {
      const paramsObj = { dossier_id: this.id, sort: 'order_in_dossier', paginate: false }
      this.edsList = await GET_EDS_RESPONSE(new URLSearchParams(paramsObj))
    }
  },

  methods: {
    showDetail (e) {
      this.$router.push({ name: 'detail-ed', params: { id: e.id } })
    }
  }
}
</script>

<style>

</style>
