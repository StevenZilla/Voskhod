<template>
  <v-card class="detail__additional-info mt-5">
    <v-card-title>
      <h2>Электронные документы</h2>
    </v-card-title>
    <v-card-text>
      <v-data-table
        hide-default-footer
        disable-pagination
        disable-sort
        no-data-text="Нет данных"
        item-key="id"
        class="main-table no-hover"
        :headers="headers"
        :items="edsList.eds"
      >
        <template #body="props">
          <tbody v-if="!props.items.length">
            <tr class="v-data-table__empty-wrapper">
              <td :colspan="headers.length">Нет данных</td>
            </tr>
          </tbody>

          <draggable
            v-else
            tag="tbody"
            :list="edsList.eds"
            :move="onMoveCallback"
            :clone="onCloneCallback"
          >
            <!-- <transition-group name="flip-list"> -->
            <data-table-row-handler
              v-for="(item, index) in props.items"
              :key="index"
              :item="item"
              :headers="headers"
            >
              <template v-slot:item.id>
                {{ index + 1 }}
              </template>

              <template v-slot:item.ed_status="{item}">
                <span v-if="!item.ed_status" style="color:#CBCBCD">Нет данных</span>
                <span v-else>{{ item.ed_status ? item.ed_status.value : '' }} </span>
              </template>

              <template v-slot:item.media_type.value="{item}">
                <span>{{ item.media_type.value }}</span>
              </template>

              <template v-slot:item.tk.status.value="{item}">
                <span v-if="!item.tk" style="color:#CBCBCD">Нет данных</span>
                <span v-else>{{ item.tk ? item.tk.status.value : '' }} </span>
              </template>

              <template v-slot:item.ak="{item}">
                <span>{{ item.ak ? 'Да' : 'Нет' }}</span>
              </template>

              <template #item.reg_date="{ item }">
                {{`${$_formatDate(item.reg_date, 'time') ||''}`}}
              </template>

              <!-- Данная проверка не нужна, возможность редактирования проверяется на уровень выше !this.checkStatusDeleteMix(item) -->
              <template v-slot:item.actions="{}">
                <v-btn
                  v-if="true"
                  color="secondary"
                  class="rounded-lg"
                  icon
                  @click="deleteItem(index)"
                >
                  <v-icon color="secondary">mdi-delete-outline</v-icon>
                </v-btn>
              </template>
            </data-table-row-handler>
            <!-- </transition-group> -->
          </draggable>
        </template>

        <template #footer>
          <div class="detail__buttons detail__buttons-border">
            <v-btn
              color="secondary"
              outlined
              class="rounded-lg ml-4 mb-0"
              @click="isDialog = true"
            >
              <v-icon class="mr-2">mdi-note-plus-outline</v-icon>
              Добавить документ
            </v-btn>
          </div>
        </template>
      </v-data-table>
    </v-card-text>

    <v-dialog
      v-model="isDialog"
      @click:outside="isDialog = false"
      max-width="1100px"
      style="z-index: 99999 !important;"
    >
      <AddEd
        :key="clearComponent"
        :current-eds-list-dossier="edsList"
        @accept-ed="concatEds($event)"
        @close-popup="isDialog = false"
        v-if="isDialog"
      />
    </v-dialog>
  </v-card>
</template>

<script>

import draggable from 'vuedraggable'
import DataTableRowHandler from '@/components/DataTableRowHandler.vue'
import AddEd from '../add-ed/AddEd'
import { GET_EDS_RESPONSE } from '@/services/app'

export default {
  name: 'EditingEds',

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  components: {
    AddEd,
    draggable,
    DataTableRowHandler
  },

  data: () => ({
    isDialog: false,
    clearComponent: 0,
    edsList: {},
    headers: [
      {
        text: '№',
        value: 'id',
        width: '64px'
      },
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '255px'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '465px'
      },
      {
        text: 'Дата регистрации',
        value: 'reg_date',
        width: '300px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type.value',
        width: '300px'
      },
      {
        text: 'Статус обработки',
        value: 'ed_status',
        width: '300px'
      },
      {
        text: 'Статус отправки в ЦХЭД',
        value: 'tk.status.value',
        width: '300px'
      },
      {
        text: 'Во временном хранилище',
        value: 'ak',
        width: '300px'
      },
      {
        value: 'actions',
        width: '50px'
      }
    ]
  }),

  computed: {
    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.fillData()
    }
  },

  async created () {
    this.edsList = await GET_EDS_RESPONSE(new URLSearchParams(`dossier_id=${this.id}&sort=order_in_dossier&paginate=false`))
  },

  methods: {
    fillData () {
      const obj = {
        id_eds: []
      }
      obj.id_eds = this.edsList.eds.map(item => item.id)
      this.$emit('fill-data', obj)
    },

    concatEds (evt) {
      evt.forEach(item => {
        this.$set(this.edsList.eds, this.edsList.eds.length, item)
      })
    },

    deleteItem (index) {
      this.$delete(this.edsList.eds, index)
    },

    onCloneCallback (item) {
      return JSON.parse(JSON.stringify(item))
    },

    onMoveCallback (evt) {
      const item = evt.draggedContext.element

      return !item.locked
    }
  }
}
</script>

<style>

</style>
