<template>
  <v-card class="detail__main-info">
    <v-card-title>
      <h2>Общая информация</h2>
    </v-card-title>

    <v-card-text class="pb-1">
      <v-row>
        <v-col cols="12">
          <div class="form-group">
            <p class="form-group__title">Заголовок <span class="required-label">*</span></p>
            <v-text-field
              v-model="editMainInfo.name"
              class="rounded-lg"
              outlined
              clearable
              placeholder="Заголовок"
              hide-details
              required
              @change="filterInputMix(editMainInfo, 'name')"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Индекс <span class="required-label">*</span></p>
            <v-text-field
              v-model="editMainInfo.index"
              class="rounded-lg"
              outlined
              clearable
              placeholder="Индекс"
              hide-details
              required
              @change="filterInputMix(editMainInfo, 'index')"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Вид хранения <span class="required-label">*</span></p>
            <v-text-field
              class="rounded-lg"
              disabled
              outlined
              filled
              clearable
              hide-details
              :value="detailDossier.save_type ? detailDossier.save_type.value : 'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Статус дела</p>
            <v-text-field
              class="rounded-lg"
              outlined
              filled
              disabled
              hide-details
              :value="detailDossier.status ? detailDossier.status.value : 'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
            <div class="form-group">
              <p class="form-group__title">Подразделение</p>
              <v-text-field
                class="rounded-lg"
                rounded
                outlined
                filled
                disabled
                hide-details
                :value="subdivision"
              ></v-text-field>
            </div>
          </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Вид носителя</p>
            <v-text-field
              class="rounded-lg"
              outlined
              filled
              disabled
              hide-details
              :value="detailDossier.media_type ? detailDossier.media_type.value : 'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Объем, Мб</p>
            <v-text-field
              class="rounded-lg"
              outlined
              hide-details
              filled
              disabled
              :value="editMainInfo.size ? editMainInfo.size : 'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Срок хранения во временном хранилище, год (лет)</p>
            <v-text-field
              class="rounded-lg"
              outlined
              disabled
              filled
              hide-details
              :value="detailDossier.temp_save_period"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Крайние даты</p>
            <v-text-field
              class="rounded-lg"
              outlined
              hide-details
              filled
              disabled
              required
              :value="detailDossier.start_date && detailDossier.end_date ? `${detailDossier.start_date} — ${detailDossier.end_date}` : 'Нет данных'"
            ></v-text-field>
          </div>
        </v-col>

        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Переходящее</p>
            <v-simple-checkbox
              v-model="editMainInfo.is_transit"
              color="secondary"
              v-ripple
            ></v-simple-checkbox>
          </div>
        </v-col>
      </v-row>
      <p class="mt-3" style="font-size:14px"><span class="required-label">*</span> Обязательные поля</p>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import { required } from 'vuelidate/lib/validators'
import { GET_SAVE_TYPE_LIST } from '@/services/app'
// import { add, format } from 'date-fns'

export default {
  name: 'EditingMainInfo',

  validations: {
    editMainInfo: {
      name: { required },
      index: { required }
    }
  },

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    loadingSaveTypes: false,
    editMainInfo: {
      index: null,
      name: null,
      save_type_id: null,
      temp_save_period: null,
      size: null,
      media_type_id: null,
      is_transit: false
    },
    saveTypeList: []
  }),

  computed: {
    ...mapState({
      detailDossier: state => state.dossiers.detailDossier
    }),

    invalidData () {
      return this.$v.$invalid
    },

    subdivision () {
      if (!this.detailDossier.subdivision) return 'нет информации'
      return this.detailDossier.subdivision.code + ' ' + this.detailDossier.subdivision.name
    }
  },

  watch: {
    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editMainInfo)
    }
  },

  async created () {
    this.copyInfo()
    this.loadingSaveTypes = true
    this.saveTypeList = await GET_SAVE_TYPE_LIST()
    this.loadingSaveTypes = false
  },

  methods: {
    copyInfo () {
      this.editMainInfo.index = this.detailDossier.index
      this.editMainInfo.name = this.detailDossier.name
      this.editMainInfo.size = this.detailDossier.size
      this.editMainInfo.save_type_id = this.detailDossier.save_type?.id
      this.editMainInfo.media_type_id = this.detailDossier.media_type?.id
      this.editMainInfo.temp_save_period = this.detailDossier.temp_save_period
    }
  }
}
</script>

<style>

</style>
