<template>
  <v-card class="detail__main-info mt-5">
    <v-card-title>
      <h2>Информация о бумажном носителе</h2>
    </v-card-title>

    <v-card-text>
      <v-row>
        <v-col cols="3">
          <div class="form-group">
            <p class="form-group__title">Место размещения</p>
            <v-text-field
              v-model="editMainInfo.paper_info.location"
              class="rounded-lg"
              outlined
              clearable
              placeholder="Место размещения"
              hide-details
              @change="filterInputMix(editMainInfo.paper_info, 'location')"
            ></v-text-field>
          </div>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'

export default {
  name: 'EditingPaperInfo',

  props: {
    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    editMainInfo: {
      paper_info: {
        location: null
      }
    }
  }),

  computed: {
    ...mapState({
      detailDossier: state => state.dossiers.detailDossier
    })
  },

  watch: {
    invalidData (newVal) {
      this.$emit('change-valid', newVal)
    },

    trigger (newV) {
      if (newV) this.$emit('fill-data', this.editMainInfo)
    }
  },

  async created () {
    this.copyInfo()
  },

  methods: {
    copyInfo () {
      if (this.detailDossier.paper_info) {
        this.editMainInfo.paper_info.location = this.detailDossier.paper_info.location
      }
    }
  }
}
</script>

<style>

</style>
