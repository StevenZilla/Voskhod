<template>
  <div class="card">
    <v-alert
      v-if="isSame"
      icon="mdi-alert"
      type="error"
      class="mb-3 border-bottom rounded"
    >
      {{ errorData.message }}
    </v-alert>

    <EditingMainInfo
      :trigger="trigger"
      @change-valid="invalidMainForm = $event"
      @fill-data="fillData($event)"
    />

    <EditingPaperInfo
      :trigger="trigger"
      @change-valid="invalidPaperForm = $event"
      @fill-data="fillData($event)"
    />

    <EditingEds
      :trigger="trigger"
      @fill-data="fillData($event)"
    />

    <TemplateButtons>
      <template #buttons-left>
        <BtnSaveSlot
          :loading="loading"
          :disabled="invalidEditingInfo"
          @save="updateHandler()"
        />
      </template>

      <template #buttons-right>
        <BtnCancelSlot
          :text="'Отменить'"
          @close="cancelEdit()"
        />
      </template>
    </TemplateButtons>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { UPDATE_DOSSIER } from '../../services/api'
import EditingMainInfo from './EditingMainInfo.vue'
import EditingPaperInfo from './EditingPaperInfo.vue'
import EditingEds from './EditingEds'

export default {
  name: 'EditingDossier',
  components: {
    EditingEds,
    EditingMainInfo,
    EditingPaperInfo
  },

  data: () => ({
    loadingComponent: true,
    trigger: 0,
    invalidMainForm: false,
    invalidPaperForm: false,
    loading: false,
    errorData: {},
    isSame: false,
    editDetailDossier: {}
  }),

  computed: {
    ...mapState({
      detailDossier: state => state.dossiers.detailDossier
    }),

    id () {
      return this.$store.getters['dossiers/GET_DOSSIER_ID']
    },

    invalidEditingInfo () {
      return this.invalidMainForm || this.invalidPaperForm
    }
  },

  methods: {
    async fillData (evt) {
      if (!evt) return
      return new Promise(resolve => {
        Object.assign(this.editDetailDossier, evt)
        resolve()
      })
    },

    cancelEdit () {
      this.$store.dispatch('dossiers/SET_VALUE', { key: 'modeDossier', value: 'view' })
    },

    async updateHandler () {
      this.trigger++
      this.loading = true
      await this.fillData()
      try {
        console.log(this.editDetailDossier)
        await UPDATE_DOSSIER(this.id, this.editDetailDossier)
        this.$emit('refresh-data')
        this.$store.dispatch('dossiers/SET_VALUE', { key: 'modeDossier', value: 'view' })
      } catch (error) {
        if (error.response?.data) {
          this.errorData = error.response.data
          this.isSame = true
        }
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style lang="scss">
</style>
