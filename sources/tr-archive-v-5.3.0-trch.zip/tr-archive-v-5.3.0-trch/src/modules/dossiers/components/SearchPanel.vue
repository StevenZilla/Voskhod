<template>
  <div class="panel-search">
    <div class="d-flex justify-space-between align-center">
      <v-text-field
        v-model="filterObj.title"
        class="main-field"
        data-qa="main-field"
        placeholder="Введите заголовок или индекс дела"
        solo
        outlined
        rounded
        clearable
        hide-details
        flat
        @click:clear="filterObj.title = null, acceptFilters()"
        @keyup.enter="trigger++"
      >
        <template v-slot:append-outer>
          <v-btn
            class="rounded-xl ml-8 bg-white"
            outlined
            icon
            data-qa="filter"
            color="secondary"
            @click="toggleFilter()"
          >
            <v-icon>mdi-tune-vertical-variant</v-icon>
          </v-btn>
        </template>

        <template v-slot:append>
          <span
            v-if="filterObj.title"
            class="find-link secondary--text"
            @click="acceptFilters()"
          >Найти
          </span>
        </template>
        <template v-slot:prepend-inner>
          <v-btn
            plain
            icon
            color="secondary"
            @click="acceptFilters()"
          >
            <v-icon>
              mdi-magnify
            </v-icon>
          </v-btn>
        </template>
      </v-text-field>
    </div>

    <Filters
      :full-filter="fullFilter"
      :trigger="trigger"
      :is-load="isLoad"
      @accept-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />
  </div>
</template>

<script>

const Filters = () => import('./Filters.vue')

export default {
  name: 'SearchPanel',

  components: { Filters },

  data: () => ({
    trigger: 0,
    fullFilter: false,
    isLoad: false,
    filterObj: {
      title: null
    }
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.title) {
        paramsFilter.append('q', this.filterObj.title)
      }
      return paramsFilter
    }
  },

  methods: {
    toggleFilter () {
      this.fullFilter = !this.fullFilter
      if (this.isLoad) return
      this.isLoad = true
    },

    acceptFilters (evt) {
      const params = this.combineSearchParamsMix(this.filterParams, evt ? evt.filter : undefined)
      this.$emit('set-filters', params)
      this.fullFilter = false
    },

    clearFilters () {
      this.$emit('clear-filters')
    }
  }
}
</script>

<style>
</style>
