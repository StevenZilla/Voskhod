<template>
  <FiltersTemplate
    :full-filter="fullFilter"
    :chips-length="chipsList.length"
  >
    <template #chips>
      <ChipsFilters
        :chips-list="chipsList"
        @remove-filter="removeFilter"
      />
    </template>

    <template #filter-fields>
      <!--  ref обозначать по коду фильтра  -->
      <ArchiveCipher
        class="w-20"
        ref="cipher"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierIndex
        class="w-20"
        ref="index"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <DossierMediaType
        class="w-20"
        ref="mediaType"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <SaveType
        class="w-20"
        ref="saveType"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <SavePeriod
        class="w-20"
        ref="savePeriod"
        :disabled="!isTemp"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <AcceptRegisterNumber
        class="w-20"
        ref="acceptRegisterNumber"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <RegisterNumber
        class="w-20"
        ref="registerNumber"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <NomenclatureNumber
        class="w-20"
        ref="nomNumber"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <NomenclatureYear
        class="w-20"
        ref="nomYear"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />

      <Classifier
        class="w-20"
        ref="classifier"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <ClassifierKinds
        class="w-40"
        ref="diKinds"
        :reset-filter="resetFilter"
        :selected-classifier="filterObj.classifier"
        :disabled="!filterObj.classifier"
        @set-filter="setFilter($event)"
      />

      <DossierStatus
        class="w-20"
        ref="status"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <Subdivision
        class="w-20"
        ref="subdivision"
        :reset-filter="resetFilter"
        :is-load="isLoad"
        @set-filter="setFilter($event)"
      />

      <DeletedDossiers
        class="w-20"
        :reset-filter="resetFilter"
        ref="deletedDossiers"
        @set-filter="setFilter($event)"
      />

    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>

import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import ChipsFilters from '@/components/Filters/ChipsFilters.vue'
import ArchiveCipher from '@/components/Filters/Fields/ArchiveCipher.vue'
import DossierIndex from '@/components/Filters/Fields/Dossier/DossierIndex.vue'
import SavePeriod from '@/components/Filters/Fields/SavePeriod.vue'
import DossierMediaType from '@/components/Filters/Fields/Dossier/DossierMediaType.vue'
import SaveType from '@/components/Filters/Fields/SaveType.vue'
import RegisterNumber from '@/components/Filters/Fields/Register/RegisterNumber.vue'
import NomenclatureNumber from '@/components/Filters/Fields/Nomenclature/NomenclatureNumber.vue'
import NomenclatureYear from '@/components/Filters/Fields/Nomenclature/NomenclatureYear.vue'
import ClassifierKinds from '@/components/Filters/Fields/ClassifierKinds.vue'
import Classifier from '@/components/Filters/Fields/Classifier.vue'
import Subdivision from '@/components/Filters/Fields/Subdivision.vue'
import DeletedDossiers from '@/components/Filters/Fields/DeletedDossiers.vue'
import DossierStatus from '@/components/Filters/Fields/Dossier/DossierStatus.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import AcceptRegisterNumber from '../../../components/Filters/Fields/Register/AcceptRegisterNumber.vue'

export default {
  name: 'Filters',

  components: {
    FiltersTemplate,
    ChipsFilters,
    ArchiveCipher,
    DossierIndex,
    SavePeriod,
    DossierMediaType,
    SaveType,
    RegisterNumber,
    NomenclatureNumber,
    NomenclatureYear,
    Classifier,
    ClassifierKinds,
    Subdivision,
    DossierStatus,
    FilterFooter,
    AcceptRegisterNumber,
    DeletedDossiers
  },

  props: {
    fullFilter: {
      type: Boolean,
      required: true
    },

    isLoad: {
      type: Boolean,
      required: false,
      default: false
    },

    trigger: {
      type: Number,
      required: true
    }
  },

  data: () => ({
    chipsList: [],
    resetFilter: false,
    searchTouch: false,
    filterObj: {}
  }),

  computed: {
    filterParams () {
      const paramsFilter = new URLSearchParams()
      const chips = []
      if (this.filterObj.deletedDossiers) {
        !!this.filterObj.deletedDossiers?.query.value && paramsFilter.append('is_only_deleted', true)
        chips.push(this.filterObj.deletedDossiers)
      }
      if (this.filterObj.cipher) {
        paramsFilter.append('dossier_cipher', this.filterObj.cipher.query)
        chips.push(this.filterObj.cipher)
      }
      if (this.filterObj.index) {
        paramsFilter.append('index', this.filterObj.index.query)
        chips.push(this.filterObj.index)
      }
      if (this.filterObj.savePeriod) {
        paramsFilter.append('temp_save_period', this.filterObj.savePeriod.query)
        chips.push(this.filterObj.savePeriod)
      }
      if (this.filterObj.mediaType) {
        paramsFilter.append('media_type_id', this.filterObj.mediaType.query.value)
        chips.push(this.filterObj.mediaType)
      }
      if (this.filterObj.saveType) {
        paramsFilter.append('save_type_id', this.filterObj.saveType.query.value)
        chips.push(this.filterObj.saveType)
      }
      if (this.filterObj.registerNumber) {
        paramsFilter.append('first_register_number', this.filterObj.registerNumber.query)
        chips.push(this.filterObj.registerNumber)
      }
      if (this.filterObj.acceptRegisterNumber) {
        paramsFilter.append('accept_register_num', this.filterObj.acceptRegisterNumber.query)
        chips.push(this.filterObj.acceptRegisterNumber)
      }
      if (this.filterObj.nomNumber) {
        paramsFilter.append('nomenclature_num', this.filterObj.nomNumber.query)
        chips.push(this.filterObj.nomNumber)
      }
      if (this.filterObj.nomYear) {
        paramsFilter.append('nomenclature_years', this.filterObj.nomYear.query)
        chips.push(this.filterObj.nomYear)
      }
      if (this.filterObj.classifier) {
        paramsFilter.append('di_classifier_id', this.filterObj.classifier.query.value)
        chips.push(this.filterObj.classifier)
      }
      if (this.filterObj.diKinds) {
        const groups = this.filterObj.diKinds.query.filter(item => item.type === 'group').map(group => group.pk)
        const kinds = this.filterObj.diKinds.query.filter(item => item.type === 'kind').map(kind => kind.pk)
        if (groups.length) paramsFilter.append('di_group_id', JSON.stringify(groups))
        if (kinds.length) paramsFilter.append('di_kind_id', JSON.stringify(kinds))
        // chips.push(this.filterObj.classifier)
      }
      if (this.filterObj.subdivision) {
        paramsFilter.append('dossier_subdivision', this.filterObj.subdivision.query.value)
        chips.push(this.filterObj.subdivision)
      }
      if (this.filterObj.status) {
        paramsFilter.append('status_id', this.filterObj.status.query.value)
        chips.push(this.filterObj.status)
      }
      return { filter: paramsFilter, chips }
    },

    isTemp () {
      return this.filterObj?.saveType?.query.code === 'temporarily'
    },

    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    }
  },

  watch: {
    trigger (newV) {
      if (newV) this.acceptFilters()
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    removeFilter (filterCode) {
      this.$refs[filterCode].removeFilter()
      this.acceptFilters()
    },

    acceptFilters () {
      this.searchTouch = true
      this.chipsList = this.filterParams.chips.map(chip => {
        return {
          title: chip.title,
          value: chip.query.text ? chip.query.text : chip.query,
          code: chip.code
        }
      })
      this.$emit('accept-filters', this.filterParams)
    },

    clearFilters () {
      this.resetFilter = true
      this.chipsList = []
      this.$nextTick(() => {
        this.searchTouch = false
        this.resetFilter = false
      })
      this.$emit('clear-filters')
    }
  }

}
</script>

<style>
</style>
