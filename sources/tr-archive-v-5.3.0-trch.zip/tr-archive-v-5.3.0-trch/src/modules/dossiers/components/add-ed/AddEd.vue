<template>
  <v-card class="select-popup">
    <v-toolbar
      dense
      flat
      class="popup-toolbar"
    >
      <v-toolbar-title>Выбор электронного документа</v-toolbar-title>
      <v-btn icon class="rounded-lg" @click="$emit('close-popup')">
        <v-icon color="element">mdi-close</v-icon>
      </v-btn>
    </v-toolbar>

    <AddEdFilters
      @set-filters="acceptFilters($event)"
      @clear-filters="clearFilters()"
    />

    <div class="main-table-inner">
      <v-data-table
        v-model="selectedEds"
        show-select
        no-data-text="Нет данных"
        item-key="id"
        class="scroll-popup-table sortable-table no-hover"
        hide-default-footer
        :headers="headers"
        :items="edsList.eds"
        :options.sync="options"
        :server-items-length="edsList.count"
        :loading-text="'Загрузка данных'"
        :loading="edLoading"
        :fixed-header="true"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :header-props="{
          'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
        }"
        @page-count="pageCount = $event"
      >
        <template #item.media_type_value="{ item }">
          {{ item.media_type.value }}
        </template>
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>
        <template #item.reg_date="{ item }">
          {{`${$_formatDate(item.reg_date, 'time') ||''}`}}
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.data-table-select="{ isSelected, select, item}">
          <v-simple-checkbox
            color="secondary"
            v-ripple
            :value="isSelected"
            @input="select($event)"
          ></v-simple-checkbox>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />

          <div class="main-table-inner__buttons">
            <v-btn
              class="mr-3 rounded-lg"
              color="secondary"
              :disabled="selectedEds.length === 0"
              @click="acceptEd()"
            >Выбрать
            </v-btn>
            <v-btn
              outlined
              class="rounded-lg"
              color="secondary"
              @click="$emit('close-popup')"
            >Отменить
            </v-btn>
          </div>
        </template>
      </v-data-table>
    </div>
  </v-card>
</template>

<script>

import { mapState } from 'vuex'
import { GET_EDS_RESPONSE } from '@/services/app'
import AddEdFilters from './AddEdFilters.vue'

export default {
  name: 'AddEd',
  props: {
    currentEdsListDossier: Object
  },
  components: {
    AddEdFilters
  },

  data: () => ({
    edsList: {},
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    selectedEds: [],
    headers: [
      {
        text: 'Регистрационный номер',
        value: 'num',
        width: '26%'
      },
      {
        text: 'Наименование',
        value: 'name',
        width: '23%'
      },
      {
        text: 'Дата регистрации',
        value: 'reg_date',
        width: '23%'
      },
      {
        text: 'Вид носителя',
        value: 'media_type_value',
        width: '23%'
      }
    ]
  }),
  watch: {
    options: {
      async handler (newV, oldV) {
        if (oldV !== null) {
          this.edsList = await GET_EDS_RESPONSE(this.filterParams, this.sortParams)
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapState({
      edLoading: state => state.eds.edLoading,
      subDivision: state => state.dossiers.detailDossier.subdivision
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      // paramsSort.append('status_id', 'actively')
      if (this.subDivision) paramsSort.append('ed_subdivision', this.subDivision.id)
      paramsSort.append('has_close_dossier', 'false')
      paramsSort.append('with_empty_subdivision', true)
      const excludeIds = this.currentEdsListDossier.eds.map(el => el.id)
      if (excludeIds.length) {
        paramsSort.append('exclude_ids', excludeIds)
      }
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.edsList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          par += sortBy
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  methods: {
    async acceptFilters (evt) {
      this.filterParams = evt
      this.edsList = await GET_EDS_RESPONSE(this.filterParams, this.sortParams)
    },

    acceptEd () {
      this.$emit('accept-ed', this.selectedEds)
      this.$emit('close-popup')
    },

    clearFilters () {
      GET_EDS_RESPONSE(this.sortParams).then(resp => { this.edsList = resp })
    }
  },

  async mounted () {
    this.edsList = await GET_EDS_RESPONSE(this.sortParams)
  }
}
</script>

<style lang="scss">
</style>
