<template>
  <FiltersTemplate
    class="filter--dialog"
    :full-filter="true"
  >
    <template #filter-fields>
<!--      поиск по коду фильтра в filterObj-->
      <EdName
        class="w-100"
        :reset-filter="resetFilter"
        @set-filter="setFilter($event)"
      />
      <div class="d-flex">
        <EdNumber
          class="w-49 pr-3"
          :reset-filter="resetFilter"
          @set-filter="setFilter($event)"
        />

        <RegisterDate
          class="w-49 pr-3"
          :reset-filter="resetFilter"
          @set-filter="setFilter($event)"
        />

        <EdMediaType
          class="w-49"
          :reset-filter="resetFilter"
          :is-load="isLoad = true"
          @set-filter="setFilter($event)"
        />
      </div>
    </template>

    <template #filter-footer>
      <FilterFooter
        :disabled="!filterValid"
        :search-touch="searchTouch"
        @accept-filters="acceptFilters()"
        @clear-filters="clearFilters()"
      />
    </template>
  </FiltersTemplate>
</template>

<script>
import FiltersTemplate from '@/components/Filters/FiltersTemplate.vue'
import FilterFooter from '@/components/Filters/FilterFooter.vue'
import EdName from '@/components/Filters/Fields/Ed/EdName.vue'
import EdNumber from '@/components/Filters/Fields/Ed/EdNumber.vue'
import RegisterDate from '@/components/Filters/Fields/RegisterDate.vue'
import EdMediaType from '@/components/Filters/Fields/Ed/EdMediaType.vue'

// import { GET_ED_MEDIA_LIST } from '@/modules/eds/services/api'

export default {
  components: {
    FiltersTemplate,
    FilterFooter,
    EdName,
    EdNumber,
    RegisterDate,
    EdMediaType
  },

  name: 'AddEdFilters',
  data: () => ({
    resetFilter: false,
    searchTouch: false,
    isLoad: false,
    filterObj: {}
  }),

  computed: {
    filterValid () {
      const keys = Object.keys(this.filterObj)
      return keys.length
    },

    filterParams () {
      const paramsFilter = new URLSearchParams()
      if (this.filterObj.edName) paramsFilter.append('name', this.filterObj.edName.query)
      if (this.filterObj.edNumber) paramsFilter.append('num', this.filterObj.edNumber.query)
      if (this.filterObj.regDate) {
        paramsFilter.append('start_reg_date', this.filterObj.regDate.query[0])
        paramsFilter.append('end_reg_date', this.filterObj.regDate.query[1])
      }
      if (this.filterObj.mediaType) {
        paramsFilter.append('media_type_value', this.filterObj.mediaType.query.value)
      }
      return paramsFilter
    }
  },

  methods: {
    setFilter (filter) {
      if (!filter.code) this.$delete(this.filterObj, filter)
      else this.$set(this.filterObj, filter.code, filter)
    },

    acceptFilters () {
      this.searchTouch = true
      this.$emit('set-filters', this.filterParams)
      this.clear = true
    },

    clearFilters () {
      this.resetFilter = true
      this.$nextTick(() => {
        this.resetFilter = false
        this.$emit('clear-filters')
        this.searchTouch = false
      })
    }
  }
}
</script>

<style>
</style>
