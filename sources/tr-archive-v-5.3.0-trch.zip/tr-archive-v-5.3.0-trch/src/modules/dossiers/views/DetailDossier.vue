<template>
  <TemplateDetail :loading="loading" :error="error">
    <template #content>
      <ViewDossierInfo
        v-if="modeDossier === 'view'"
        @refresh-data="refreshData"
      />

      <EditingDossier
        v-else
        :key="clearComponent"
        @refresh-data="refreshData"
      />

      <v-dialog
        v-model="dialog"
        persistent
        max-width="500"
        content-class="dialog-auto-height"
      >
        <ConfirmCancel
          @cancel="dialog = false"
          @confirm="confirmLeave"
        />
      </v-dialog>
    </template>
  </TemplateDetail>
</template>

<script>

import { mapState } from 'vuex'
import ViewDossierInfo from '../components/view-info/ViewDossierInfo.vue'
import { GET_DETAIL_DOSSIER, GET_SUBDIVISION_HISTORY } from '../services/api'
import ConfirmCancel from '@/components/ConfirmCancel.vue'

const EditingDossier = () => import('../components/editing-info/EditingDossier.vue')

export default {
  name: 'DetailDossier',
  components: {
    ConfirmCancel,
    ViewDossierInfo,
    EditingDossier
  },

  data: () => ({
    confirmCallback: null,
    dialog: false,
    loading: false,
    clearComponent: 0
  }),

  computed: {
    ...mapState({
      modeDossier: state => state.dossiers.modeDossier,
      error: state => state.error
    })
  },

  async mounted () {
    await this.getData()
  },

  async beforeRouteUpdate (to, from, next) {
    this.$store.dispatch('dossiers/SET_VALUE', { key: 'modeDossier', value: 'view' })
    await this.getData(to.params.id)
    next()
  },

  beforeRouteLeave (to, from, next) {
    this.checkEditingMode(next)
  },

  methods: {
    checkEditingMode (next) {
      if (this.modeDossier === 'edit') {
        this.confirmCallback = next
        this.dialog = true
      } else {
        next()
      }
    },

    confirmLeave () {
      this.dialog = false
      this.$store.dispatch('dossiers/SET_VALUE', { key: 'modeDossier', value: 'view' })
      this.confirmCallback()
    },

    async getData (id) {
      const _id = id || this.$route.params.id
      this.loading = true
      try {
        await GET_DETAIL_DOSSIER(_id)
        await GET_SUBDIVISION_HISTORY(_id)
      } catch (error) {
        this.setErrorMix(error)
      } finally {
        this.loading = false
      }
    },

    async refreshData () {
      await this.getData()
      this.clearComponent++
    }
  }
}
</script>

<style lang="scss">
</style>
