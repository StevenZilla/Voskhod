<template>
  <TemplatePage>
    <template #title>Дела</template>

    <template #content>
      <SearchPanel
        @set-filters="acceptFilters($event)"
        @clear-filters="refreshData()"
        @refresh-data="refreshData"
      />

      <div class="mb-5 d-flex justify-space-between align-center">
        <h2 class="results-title">Результаты поиска</h2>
        <SettingsTableVue
          :code="'dossiersPage'"
          :headers="headers"
          :headersSettingsOutside="headersSettingsOutside"
          :headersList="headersList"
          @updateHeaders="headers = [...$event]"
        />
      </div>

      <v-data-table
        no-data-text="Нет данных"
        item-key="id"
        class="main-table scroll-table sortable-table"
        hide-default-footer
        :loading-text="'Загрузка данных'"
        :headers="headers"
        :options.sync="options"
        :server-items-length="dossiersList.count"
        :items="dossiersList.dossiers"
        :loading="dossierLoading"
        :page.sync="page"
        :items-per-page="itemsPerPage"
        :header-props="{
        'sort-icon': options && options.sortDesc[0] ? 'mdi-sort-ascending' : 'mdi-sort-descending'
      }"
        @click:row="showDetail"
        @page-count="pageCount = $event"
      >
        <template #progress>
          <v-progress-linear
            indeterminate
            height="5"
            color="secondary"
          ></v-progress-linear>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.dossier_cipher="{item}">
          <div>
            <v-icon v-if="item.is_deleted" class="mr-2" color="black">mdi-delete</v-icon>
            <span v-if="item.dossier_cipher">
            <v-chip
              class="ma-2 info-badge"
              color="#00A65A"
              text-color="white"
            ><span style="font-size: 16px">
              {{ item.dossier_cipher }}
            </span></v-chip>
          </span>
            <span v-else style="color:#CBCBCD">Нет данных</span>
          </div>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.nomenclature_year="{item}">
          <span v-if="item.nomenclatures">{{ item.nomenclatures.year }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.first_register_number="{item}">
          <span v-if="item.first_register_number">{{ item.first_register_number }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.media_type_value="{item}">
          <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
            <span v-bind="attrs" v-on="on">
              <v-icon v-if="item.media_type.code === 'electronic'" color="secondary">$vuetify.icons.electronic</v-icon>
              <v-icon v-else color="secondary" icon="$paper">$vuetify.icons.hybrid</v-icon>
            </span>
            </template>
            <span>{{ item.media_type.value }}</span>
          </v-tooltip>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.save_type_value="{item}">
          <span v-if="!item.save_type" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.save_type.value }}</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.accept_register_number="{ item }">
          <span v-if="!item.accept_registers" style="color:#CBCBCD">Нет данных</span>
          <span v-else>{{ item.accept_registers.num }}</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.temp_save_period="{item}">
          <span v-if="item.save_type && item.save_type.code === 'temporarily'">{{ item.temp_save_period }}</span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template v-slot:item.date="{item}">
        <span v-if="item.start_date && item.end_date">
          {{`${$_formatDate(item.start_date, 'date') ||''} - ${$_formatDate(item.end_date, 'date') ||''}`}}
        </span>
          <span v-else style="color:#CBCBCD">Нет данных</span>
        </template>

        <!-- eslint-disable-next-line -->
        <template #footer="{props}">
          <PaginationTable
            :page.sync="page"
            :pagination="props.pagination"
          />
        </template>
      </v-data-table>
    </template>
  </TemplatePage>
</template>

<script>

import { mapState } from 'vuex'
import { format } from 'date-fns'
import { GET_DOSSIERS_LIST } from '@/services/app'
import SearchPanel from '../components/SearchPanel.vue'
import SettingsTableVue from '@/components/SettingsTableVue.vue'
import TemplatePage from '@/components/TemplatePage.vue'

export default {
  name: 'DossiersPage',
  components: {
    TemplatePage,
    SearchPanel,
    SettingsTableVue
  },

  data: () => ({
    dossiersList: {},
    format,
    filterParams: null,
    page: 1,
    pageCount: 0,
    itemsPerPage: 15,
    options: null,
    headers: [],
    headersSettingsOutside: ['id', 'index', 'name'],
    headersList: [
      {
        text: 'Архивный шифр',
        value: 'dossier_cipher',
        width: '180px'
      },
      {
        text: 'Индекс дела',
        value: 'index',
        width: '200px'
      },
      {
        text: 'Заголовок дела',
        value: 'name',
        width: '500px'
      },
      {
        text: 'Год номенклатуры',
        value: 'nomenclature_year',
        width: '280px'
      },
      {
        text: 'Вид хранения',
        value: 'save_type_value',
        width: '340px'
      },
      {
        text: 'Срок хранения во временном хранилище, год (лет)',
        value: 'temp_save_period',
        width: '340px'
      },
      {
        text: 'Крайние даты',
        value: 'date',
        width: '270px'
      },
      {
        text: 'Номер сдаточной описи',
        value: 'accept_register_number',
        width: '280px'
      },
      {
        text: 'Номер сводной описи',
        value: 'first_register_number',
        width: '280px'
      },
      {
        text: 'Вид носителя',
        value: 'media_type_value',
        align: 'center',
        width: '200px'
      },
      {
        text: 'Статус',
        value: 'status.value',
        width: '280px'
      }
    ]
  }),

  watch: {
    options: {
      handler (newV, oldV) {
        if (oldV !== null) {
          GET_DOSSIERS_LIST(this.filterParams, this.sortParams).then(resp => { this.dossiersList = resp })
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapState({
      dossierLoading: state => state.dossiers.dossierLoading
    }),

    sortParams () {
      const paramsSort = new URLSearchParams()
      if (this.options !== null) {
        const { sortBy, sortDesc, page, itemsPerPage } = this.options
        if (itemsPerPage !== null && itemsPerPage !== -1) {
          paramsSort.append('page[size]', itemsPerPage)
        } else if (itemsPerPage === -1) {
          paramsSort.append('page[size]', this.dossiersList.count)
        }
        if (page !== null) {
          paramsSort.append('page[number]', page)
        }
        if (sortBy.length > 0) {
          let par = ''
          if (sortDesc[0] === true) {
            par = '-'
          }
          if (sortBy[0].indexOf('source.value') !== -1) {
            par += 'source_name'
          } else if (sortBy[0].indexOf('status.value') !== -1) {
            par += 'status_value'
          } else if (sortBy[0].indexOf('date') !== -1) {
            par += 'start_end_date'
          } else {
            par += sortBy
          }
          paramsSort.append('sort', par)
        }
      }
      return paramsSort
    }
  },

  mounted () {
    GET_DOSSIERS_LIST().then(resp => { this.dossiersList = resp })
  },

  methods: {
    async acceptFilters (evt) {
      this.page = 1
      this.filterParams = evt
      this.dossiersList = await GET_DOSSIERS_LIST(this.filterParams, this.sortParams)
    },

    async refreshData (evt) {
      GET_DOSSIERS_LIST().then(resp => { this.dossiersList = resp })
      // если передали айдишник то перейти в карточку
      if (evt) this.showDetail(evt)
    },

    closeSettings () {
      this.isShowSettingsTable = false
    },

    showDetail (e) {
      const _id = typeof e === 'number' ? e : e.id
      this.$router.push({ name: 'detail-dossier', params: { id: _id } })
    }
  }
}
</script>

<style>

</style>
