import api from '@/services/api'
import store from '@/storages'

export async function UPDATE_DOSSIER_STATUS (id, code) {
  store.dispatch('dossiers/SET_VALUE', { key: 'dossierLoading', value: true })
  try {
    await api.patch(`/ead/dossiers/${id}/${code}`)
  } catch (err) {
    console.log(err)
  } finally {
    store.dispatch('dossiers/SET_VALUE', {
      key: 'dossierLoading',
      value: false
    })
  }
}

export async function UPDATE_DOSSIER (id, dossierObject) {
  // commit('setValue', { key: 'dossiersLoading', value: true })
  try {
    await api.put(`/ead/dossiers/${id}`, dossierObject)
    store.dispatch('dossiers/SET_VALUE', { key: 'modeDos', value: 'view' })
  } catch (error) {
    console.log(error)
  } finally {
    // commit('setValue', { key: 'dossiersLoading', value: false })
  }
}

export async function GET_DOSSIERS_STATUS () {
  const resp = await api.get('/ead/nsi/dossier_statuses')
  return resp.data.dossier_statuses.map(item => ({ text: item.value, value: item.id }))
}

export async function GET_DETAIL_DOSSIER (id) {
  try {
    const resp = await api.get(`/ead/dossiers/${id}`)
    store.dispatch('dossiers/SET_VALUE', { key: 'detailDossier', value: resp.data })
  } catch (error) {
    console.log(error)
    throw (error)
  }
}

export async function GET_SUBDIVISION_HISTORY (id) {
  try {
    const resp = await api.get(`v2/admin/nsi/subdivisions/liquidate?dossier_id=${id}`)
    store.dispatch('dossiers/SET_VALUE', { key: 'transitInfo', value: resp.data })
  } catch (error) {
    console.log(error)
    // throw (error)
  }
}

export async function GET_DOSSIER_MEDIA_LIST () {
  const res = await api.get('/ead/nsi/dossier/media_types')
  return res.data.map(item => ({ text: item.value, value: item.id }))
}

export async function GET_DELETED_ACTS_DOSSIER (id) {
  const res = await api.get(`/delete_act/?dossier_id=${id}`)
  return res.data
}
