import { dossierEvent } from '@/event-code'
import { dossier, dossierDetail } from '@/permissions'
const DossiersPage = () => import('../views/DossiersPage.vue')
const DetailDossier = () => import('../views/DetailDossier.vue')

const dossierRouter = [
  {
    name: 'DossiersPage',
    path: dossier.path,
    component: DossiersPage,
    meta: {
      breadcrumb: [
        {
          text: 'Дела'
        }
      ],
      tech_name: dossier.code
    }
  },
  {
    name: 'detail-dossier',
    path: `${dossierDetail.path}/:id`,
    component: DetailDossier,
    meta: {
      breadcrumb: [
        {
          text: 'Дела',
          to: dossier.path
        },
        {
          text: 'Просмотр дела'
        }
      ],
      parent: dossier.path,
      tech_name: dossierDetail.code,
      code: dossierEvent.code
    }
  }
]

export default router => {
  router.addRoutes(dossierRouter)
}
