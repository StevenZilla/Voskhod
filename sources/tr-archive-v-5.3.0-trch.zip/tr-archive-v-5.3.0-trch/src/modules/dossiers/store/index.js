export default {
  namespaced: true,
  state: {
    modeDossier: 'view',
    dossiersList: {},
    dossierLoading: false,
    detailDossier: {}
  },
  mutations: {
    setValue (state, keyValue) {
      state[keyValue.key] = keyValue.value
    }
  },
  actions: {
    async SET_VALUE ({ commit }, keyValue) {
      commit('setValue', keyValue)
    }
  },

  getters: {
    GET_DOSSIER_KEY: state => code => {
      if (!state.detailDossier) return {}
      return state.detailDossier[code]
    },

    GET_DOSSIER_ID: state => {
      if (!state.detailDossier.id) return

      return state.detailDossier.id
    },

    GET_DOSSIER_NAME: state => {
      if (!state.detailDossier.name) return

      return state.detailDossier.name
    },

    GET_DOSSIER_CIPHER: state => {
      if (!state.detailDossier.cipher) return

      return state.detailDossier.cipher
    },

    GET_VIEW_BUTTONS: state => {
      if (!state.detailDossier.view_buttons) return {}

      return state.detailDossier.view_buttons
    }
  }
}
