#!/bin/bash

TIME="10"
URL="https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage"
TEXT="$2"

curl -s --max-time $TIME -d "chat_id=$1&disable_web_page_preview=1&text=$TEXT" $URL > /dev/null
