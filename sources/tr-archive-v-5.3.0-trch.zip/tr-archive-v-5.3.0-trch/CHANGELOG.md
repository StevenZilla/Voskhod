# Changelog

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.7.0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/compare/v2.6.0...v2.7.0) (2022-10-13)


### Features

* **1784/trch:** реализовали вывод результата на страницах Журнал событий и фильтрацию по результату ([0398351](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/0398351702f1efeba8c05b0dfc87d5a0690f2168))
* **1795-arch:** добавили блокировку пользователя ([8a7a884](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/8a7a88432a23adf0cfc1adea822f3f3575985b05))
* **trch-1774:** добавлена страница смены пароля ([f3c4a4c](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/f3c4a4c2bdd1e2812187b99088dcfd42f482ed3b))
* **trch-1791:** добавили в справочники нси раздел скомпрометированных паролей ([0b326e2](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/0b326e2e92996725711bfc85b130e424f9e66769))
* **trch-1804:** сделана двухфакторная авторизация и форма забыли пароль ([206140a](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/206140a6b380d319c1c74912cc07dba57bf34c02))


### Bug Fixes

* **1691/trch:** настроили корректное поведение чекбокса атрибута Переходящее в карточке дела и номенклатуры ([aa6e673](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/aa6e67387c1d5212f8325e61d5541e48b80d7366))
* **1787-trch:** добавили кнопку генерации пароля на страницах добавления пользователя и сброса пароля ([20e7aa6](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/20e7aa6cc157b66fa0c69d7a44a6ae03fc23f6d7))
* **179/trch:** установили ограничение для начала действия учетной записи при создании пользователя ([cd2b0bf](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/cd2b0bf9446b3ada1c78ae97b257bf41abe7f516))
* **1791-arch:** Изменил адрес создания пользователя ([dd7b409](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/dd7b409b198a862afbb31b5f8e683432700207d3))
* **1791-trch:** добавили валидацию, косметические правки ([f62e814](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/f62e814f14286bd3a17cefca18e5da4cab7b109a))
* **1791-trch:** добавили прелоадер при загрузке данных, настроили permission ([7502ba0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/7502ba02be2c37de70678a5695b5f8bf73138027))
* **1791/trch:** Добавили верстку страниц и некоторую логику ([c253bb3](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/c253bb380796be743f5f8282bade7052f801c53e))
* **1795-arch:** исправили поведение чекбокса при блокировке пользователя ([2c8ff49](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/2c8ff49d20aea442206bea76cc5582c66cda7e04))
* **1803/trch:** Сделали корректное отображение таблицы, при добавлении новых строк в редактировании НСИ ([59795ff](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/59795ffeeb22a3054dcfbd676e25676c5ef4620d))
* добавлена валидация для пароля и поправлен фильтр событий по дате ([78ccef5](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/78ccef53b8034c848a7214df66970e03809387d7))
* добавлена валидация на сброс пароля ([7011f54](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/7011f54ddbea43649b67d96cbdbf2feace424b5e))
* добавлена фильтрация по времени в событиях ([daba443](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/daba443894f775b4bab35dd194c659cfca0c57e3))
* исправлена авторизация облачного архива ([83c1af0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/83c1af0d1cce73aab96c6685958852caacb4266c))
* исправлена валидация при создании пользователя ([78a4dee](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/78a4dee10b7affd1c183f6630057d4d211f5e492))
* исправлено закрытие окна при отправке вк ([3b86913](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/3b869130eae9ae7bfbd7595266c3e9ab249a65aa))
* убрана валидация при создании пеользователя ([5c06f5b](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/5c06f5bf47cc0d9d1459eb892315922af255faa2))
* merge conflicts ([0eefffc](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/0eefffc749aa052f7eae8c06febd66c7cd7d905c))
* **trch-1626:** исправили вертску в описях ([ba26cc3](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/ba26cc3e928a0e2a60c011d89f63ef1eaafc7f59))
* **trch-1705:** переделан вид фильтра по дате ([b18f252](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/b18f252031dd24cc7b2ddfe1f08f88a1882cad94))
* **trch-1723:** исправлена фильтрация по пользователю ([9319cd5](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/9319cd5f4588ca31ea41ae877e7cc7dcb554b58a))
* **trch-1724:** исправлена сортировка на странице Журнал событий ([8dff45d](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/8dff45ddfe6ad5823bb15d0f4e029ceb826a7409))
* **trch-1759:** исправлена загрузка ЭД с невалидной подписью ([5045813](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/5045813b1416f02a97d7a0b152f609a52cccb374))
* **trch-1777:** исправлена добавление одного и того же файла ([2851bc8](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/2851bc8e100f3dadcff89dbad1d1439666199c3c))
* **trch-1790:** убрали кнопку обработано ([f0342ea](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/f0342eacc4cd7abbc5cdf8dd0ea0531da041c85f))
* **trch-1792:** доработано прочитывание уведомлений ([02aa843](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/02aa8430485db03dbc04d86c9cc4c98942d6c023))
* **trch-1801:** исправили выбор фонда при редактировании описи ([49bf1f4](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/49bf1f41a9e4dd4e64f6d604c2ffa6cd13cfb350))
* **trch-1802:** исправили закрытие режима редактирпования в описях ([d8f6038](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/d8f6038f7cb5232b42eb0a6049e77eaac2d3f0a5))
* **trch-1802:** исправлено закрытие описи ([df5928d](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/df5928d9f335fb86fe8d622630fc784c717af7be))
* **trch-1806:** исправили отображение иконки удаления подписанта в описи в режиме редактирования ([fedfe89](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/fedfe8954f2582fcd5badf51bd337337a2121815))
* **trch:** исправили некорректно названные переменные в объекте на создание пользователя ([33701db](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/33701db8c08fd8509cae06fe0a88e8572f5de3f3))
* **trch:** исправили поля  Срок действия учетной записи пользователя согласно требованию ([683f997](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/683f997e3d52a80893f19dcc9c10df34ae07de01))
* **trch:** исправлено появление ВО поджтверждения ([ddbed8b](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/ddbed8b7bfe361080c5f73a8b3ff8ec213ded3b1))
* **trch:** поправленыы задачи 1762 1758 1730 ([28dfb2d](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-v/commit/28dfb2d923a6e5f8f46b7448ecfce78533212412))

