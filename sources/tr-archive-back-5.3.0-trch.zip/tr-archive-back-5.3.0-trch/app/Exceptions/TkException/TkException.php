<?php

namespace App\Exceptions\TkException;

use App\Exceptions\CustomException;

class TkException extends CustomException
{
	//
}
