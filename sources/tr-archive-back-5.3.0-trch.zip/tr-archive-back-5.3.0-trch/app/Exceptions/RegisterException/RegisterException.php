<?php

namespace App\Exceptions\RegisterException;

use App\Exceptions\CustomException;

class RegisterException extends CustomException
{
    //
}
