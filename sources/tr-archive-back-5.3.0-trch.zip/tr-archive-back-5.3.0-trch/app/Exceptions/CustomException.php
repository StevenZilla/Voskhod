<?php

namespace App\Exceptions;

use Exception;
use Throwable;

class CustomException extends Exception
{
    public $error = '';
    public $target = '';

    public function __construct($message = '', $error = '', $target = '', $code = 0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);

        $this->error = $error;
        $this->target = $target;

        return $this;
    }

    public function getError()
    {
        return $this->error;
    }

    public function setError($error)
    {
        $this->error = $error;

        return $this;
    }

    public function getTarget()
    {
        return $this->target;
    }

    public function setTarget($target)
    {
        $this->target = $target;

        return $this;
    }
}
