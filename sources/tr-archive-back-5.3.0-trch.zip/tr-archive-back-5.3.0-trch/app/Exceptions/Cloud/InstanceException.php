<?php

namespace App\Exceptions\Cloud;

class InstanceException extends \Exception
{
}
