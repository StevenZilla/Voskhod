<?php

namespace App\Exceptions;

class PasswordExpiredException extends BaseException
{
    //Класс-исключение для сброса пароля
}
