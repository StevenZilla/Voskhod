<?php

namespace App\Exceptions\SystemRoleException;

use App\Exceptions\CustomException;

class SystemRoleException extends CustomException
{
    //
}
