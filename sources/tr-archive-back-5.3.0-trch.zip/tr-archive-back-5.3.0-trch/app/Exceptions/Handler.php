<?php

namespace App\Exceptions;

use App\Exceptions\AuthException\LoginException;
use App\Exceptions\Cloud\InstanceException;
use App\Exceptions\ComponentException\ComponentException;
use App\Exceptions\CustomJsonException\CustomJsonException;
use App\Exceptions\DossierException\DossierException;
use App\Exceptions\EdException\EdException;
use App\Exceptions\LogicStatus\LogicStatusException;
use App\Exceptions\RegisterException\RegisterException;
use App\Exceptions\UserException\UserException;
use App\Models\Ed\Ed;
use App\Services\Ed\RenameFilesEd;
use App\Services\FilesystemManager\MediaStorage;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Exceptions\PostTooLargeException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  Throwable  $exception
     * @return void
     */
    public function report(Throwable $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Throwable  $e
     * @return Response | JsonResponse
     */
    public function render($request, Throwable $e)
    {
        $guidOIK = null;
        if ($request->hasSession()) {
            $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        } elseif ($request->headers->has('uid')) {
            $guidOIK = $request->headers->get('uid');
        }

        if (str_contains($e->getMessage(), 'Undefined table') && stripos($request->route()->uri, 'api/ead/account') !== false) {
            Log::error('Не смогли определить подключение к бд');

            return response()->json([
                'code' => 401,
                'message' => 'Отсутсвтует подключение к бд. Авторизуйтесь.',
            ], 401);
        }

        if (str_contains($e->getMessage(), 'Undefined index: driver')) {
            $message = 'Не смогли получить конфиги для подключения к бд. Отсутствует подключение к базе данных.';
            Log::critical($message);

            return response()->json([
                'code' => 401,
                'message' => 'Отсутсвтует подключение к бд. Авторизуйтесь.',
            ], 401);
        }

        if (str_contains($request->getRequestUri(), '/api/login')) {
            if (str_contains($e->getMessage(), 'Undefined table:')) {
                $msg = 'Отсуствует таблица "user" в базе данных';

                if (!empty($guidOIK)) {
                    $msg .= " при подключению к оику {$guidOIK}";
                }

                return response()->json([
                    'code' => 400,
                    'message' => $msg,
                ], 400);
            }
        }

        if ($e instanceof ConnectException) {
            if ((str_contains($e->getMessage(), 'Connection timed out'))) {
                $timeout = config('vipnet.connect_timeout');

                return response()->json([
                    'code' => 400,
                    'message' => "Не смогли подключиться к VipNet. Время ожидания {$timeout} секунд вышло",
                ], 400);
            }
        }

        if ($e instanceof BadRequestException) {
            return response()->json($e->getMessage(), 400);
        }

        if ($e instanceof NotFoundHttpException) {
            return response()->json([
                'code' => 404,
                'message' => 'Страница не найдена.',
            ], 404);
        }
        if ($e instanceof ModelNotFoundException) {
            # TODO если клиент посыпится, вернуть 400
            return response()->json([
                'code' => 404,
                'message' => $e->getMessage(),
            ], 404);
        }

        if ($e instanceof MailException) {
            return response()->json([
                'code' => 201,
                'message' => $e->getMessage(),
            ], 201);
        }

        if ($e instanceof PermissionException) {
            $message = $e->getMessage();

            return response()->json([
                'code' => 403,
                'message' => $message,
            ], 403);
        }

        if ($e instanceof BaseException) {
            $message = $e->getMessage();

            return response()->json([
                'code' => 400,
                'message' => $message,
            ], 400);
        }

        if ($e instanceof LogicStatusException) {
            $data['code'] = $e->getCode();
            $data['message'] = $e->getMessage();
            $data['target'] = $e->getTarget();
            $data['logic_status_code'] = $e->getLogicStatusCode();

            return response()->json($data, 400);
        }

        if ($e instanceof InstanceException) {
            return response()->json([
                'code' => $e->getCode(),
                'message' => $e->getMessage() ?? 400,
            ], $e->getCode());
        }


        if ($e instanceof SendMailException) {
            $message = $e->getMessage();

            return response()->json([
                'code' => 400,
                'message' => $message,
            ], 400);
        }

        if ($e instanceof PostTooLargeException) {
            dd($e);
            return response()->json([
                'code' => 400,
                'message' => 'Максимальный размер файла не должен превышать ~500mb',
            ], 400);
        }

        if ($e instanceof LoginException) {
            return response()->json([
                'code' => 401,
                'message' => $e->getMessage(),
            ], 401);
        }

        if ($e instanceof UserException) {
            return response()->json([
                'code' => 400,
                'message' => $e->getMessage(),
                'target' => 'USER',
            ], 400);
        }

        if ($e instanceof \Illuminate\Auth\AuthenticationException || $e->getMessage() === 'Unauthenticated.' || str_contains($e->getMessage(), 'Unauthenticated.')) {
            return response()->json([
                'code' => 401,
                'message' => 'Необходимо авторизоваться.',
            ], 401);
        }

        if ($e instanceof EdException) {
            if ($request->getMethod() === 'PUT') {
                $document = Ed::findOrFail($request->route()->parameter('id'));
                $guid = $document->getUidWithFile();
                $path = "ead/{$guid}/";
                $directory = MediaStorage::files($path);
                if (!empty($directory) && count($directory) > 0) {
                    foreach ($directory as $file) {
                        $renameFilesEd = new RenameFilesEd();
                        $renameFilesEd->make($file, null, true);
                    }
                }
            }
            $target = 'EAD';

            return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => $target, 'error' => $e->getError()], 400);
        }

        if ($e instanceof ComponentException) {
            return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => 'COMPONENT'], 400);
        }
        if ($e instanceof DossierException) {
            return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => $e->getTarget(), 'error' => $e->getError()], 400);
        }
        if ($e instanceof RegisterException) {
            return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => 'REGISTER'], 400);
        }

        if ($e instanceof CustomJsonException) {
            return response()->json(
                ['code' => 400, 'message' => $e->getMessage(), 'target' => $e->getTarget(), 'error' => $e->getError()],
                400
            );
        }

        if ($e instanceof QueryException) {
            $target = null;
            $error = null;
            $statusCode = 400;
            if (str_contains($e->getMessage(), 'ed_num_reg_date_unique')) {
                $message = 'Нарушение уникальности значений ЭД. Поля num и reg_date должны быть уникальными.';
                $target = 'EAD';
            } elseif (str_contains($e->getMessage(), 'archive_name_short_name_email_head_phone_unique')) {
                $message = 'Группа полей: Имя, Короткое имя, Email, Телефон должна быть уникальна.';
                $target = 'ARCHIVE';
                $error = [
                    'name' => 'Поле не прошло уникальность среди группы полей Имя, Короткое имя, Email, Телефон',
                    'short_name' => 'Поле не прошло уникальность среди группы полей Имя, Короткое имя, Email, Телефон',
                    'email' => 'Поле не прошло уникальность среди группы полей Имя, Короткое имя, Email, Телефон',
                    'head_phone' => 'Поле не прошло уникальность среди группы полей Имя, Короткое имя, Email, Телефон',
                ];
            } elseif (str_contains($e->getMessage(), 'component_access_check_is_null')) {
                $message = 'Нарушение ограничений значений у доступа к компонентам. component_access не может быть пустым, пользователь или системная роль должна быть заполнена.';
                $target = 'COMPONENT';
                $error = [
                    'component_access' => 'Не может быть пустым',
                ];
            } elseif (str_contains($e->getMessage(), 'component_parameter_value_component_access_id_component_parameter_id_unique')) {
                $message = 'Нарушение уникальности значений у параметров компонента. Поля value и id должны быть уникальными';
                $target = 'COMPONENT';
                $error = [
                    'id' => 'Поле должно быть уникальным',
                    'value' => 'Поле должно быть уникальным',
                ];
            } elseif (str_contains($e->getMessage(), 'dossier_index_source_id_unique')) {
                $message = 'Нарушение уникальности значений у дел. Поля index и source_id  должны быть уникальны.';
                $target = 'DOSSIER';
            } elseif (str_contains($e->getMessage(), 'ed_in_register_ed_id_register_id_register_part_id_unique')) {
                $message = 'Нарушение уникальности значений у связи документа и описи. Документ, опись и раздел описи дублируются.';
                $target = 'REGISTER';
            } elseif (str_contains($e->getMessage(), 'ed_in_register_ed_id_register_id_unique')) {
                $message = 'Нарушение уникальности значений у связи документа и описи. Документ и опись дублируются.';
                $target = 'REGISTER';
            } elseif (str_contains($e->getMessage(), 'nomenclature_num_unique')) {
                $message = 'Не уникальный номер';
                $target = 'NOMENCLATURE';
                $error = [
                    'num' => 'Не уникальный номер',
                ];
            } elseif (str_contains($e->getMessage(), 'register_file_register_id_signer_id_unique')) {
                $message = 'Нарушение уникальности значений у файлов описи. У файлов описи подписант должен быть уникальным';
                $target = 'REGISTER';
                $error = [
                    'register_file_id' => 'Нарушение уникальности значений файла описи',
                    'signer_id' => 'Подписант файлов новой описи должен быть уникальным',
                ];
            } elseif (str_contains($e->getMessage(), 'register_part_register_id_name_parent_id_unique')) {
                $message = 'Нарушение уникальности значений у разделов описи. У разделов описи название раздела должно быть уникальным';
                $target = 'REGISTER';
                $error = [
                    'register_part.name' => 'Название раздела должно быть уникальным',
                ];
            } elseif (str_contains($e->getMessage(), 'register_part_register_id_name_parent_id_unique')) {
                $message = 'Нарушение уникальности значений у разделов описи. У разделов описи название раздела должно быть уникальным';
                $target = 'REGISTER';
            } elseif (str_contains($e->getMessage(), 'register_num_year_unique')) {
                $message = 'Опись с таким номером и годом уже существует.';
                $error = [
                    'num' => 'Нарушена группа уникальности на год и номер описи',
                    'year' => 'Нарушена группа уникальности на год и номер описи',
                ];
                $target = 'REGISTER';
            } elseif (str_contains($e->getMessage(), 'sert_one_use_sert_id_sert_use_id_unique')) {
                $message = 'Нарушение уникальности значений у использовании сертифика. Использование сертифика уникально';
                $target = 'SERT';
            } elseif (str_contains($e->getMessage(), 'session_session_id_unique')) {
                $message = 'Нарушение уникальности значений у сессий пользователя. Идентификатор сессии уже существует.';
                $target = 'SESSION';
                $error = [
                    'id' => 'Значение поля должно быть уникальным',
                ];
            } elseif (str_contains($e->getMessage(), 'signer_user_id_signer_role_id_unique')) {
                $message = 'Нарушение уникальности значений у подписантов. Пользователь и роль подписанта должны быть уникальны.';
                $target = 'SIGNER';
                $error = [
                    'user_id' => 'Не прошло уникальность группы пользователя и подписанта',
                    'role_id' => 'Не прошло уникальность группы пользователя и подписанта',
                ];
            } elseif (str_contains($e->getMessage(), 'system_role_name_unique')) {
                $message = 'Нарушение уникальности значений у системной роли. Название системной роли должно быть уникальным';
                $target = 'SYSTEM_ROLE';
                $error = [
                    'name' => 'Название системной роли должно быть уникальным',
                ];
            } elseif (str_contains($e->getMessage(), 'user_login_unique')) {
                $message = 'Нарушение уникальности значений у пользователя. Поле login должно быть уникальным';
                $error = [
                    'login' => 'Значения поля должно быть уникальным',
                ];
                $target = 'USER';
            } elseif (str_contains($e->getMessage(), 'SQLSTATE[08006]') && str_contains($e->getMessage(), 'connection to server at "127.0.0.1", port 5432 failed:')) {
                $statusCode = 500;
                $message = 'Отсутствует подключение к базе данных.';
            } else {
                $statusCode = 500;
                $message = 'Возникла ошибка с ограничением базы данных.';
                $errorText = trim(preg_replace('/(.+?(ОШИБКА\:=?))|(?>\(SQL:).*/i', ' ', $e->getMessage()));
                $error = mb_strtoupper(mb_substr($errorText, 0, 1)) . mb_substr($errorText, 1);
            }
            Log::critical($message);

            return response()->json(['code' => $statusCode, 'target' => $target, 'error' => $error, 'message' => $message], $statusCode);
        }

        if ($e instanceof ValidationException) {
            if (str_contains($e->getMessage(), 'The given data was invalid') && !empty($e->errors()['login'][0])) {
                $second = preg_replace('/[^\d+]/i', '', $e->errors()['login'][0]);
                $message = "Слишком много попыток входа в систему. Попробуйте авторизоваться через {$second} секунд.";
                Log::alert($message);
            } else {
                $message = $e->getMessage();
            }

            return response()->json(['code' => 401, 'message' => $message], 401);
        }

        if ($e instanceof \ErrorException) {
            return response()->json(['code' => 400, 'message' => $e->getMessage()], 400);
        }

        return parent::render($request, $e);
    }
}
