<?php

namespace App\Exceptions;

use Exception;

class ConnectionJobException extends Exception
{
    //
}
