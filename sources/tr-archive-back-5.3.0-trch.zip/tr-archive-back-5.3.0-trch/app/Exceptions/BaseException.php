<?php

namespace App\Exceptions;

class BaseException extends \Exception
{
    //
}
