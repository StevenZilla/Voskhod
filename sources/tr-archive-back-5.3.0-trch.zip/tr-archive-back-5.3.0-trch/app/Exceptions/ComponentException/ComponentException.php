<?php

namespace App\Exceptions\ComponentException;

use App\Exceptions\CustomException;

class ComponentException extends CustomException
{
    //
}
