<?php

namespace App\Exceptions\DossierException;

use App\Exceptions\CustomException;

class DossierException extends CustomException
{
    //
}
