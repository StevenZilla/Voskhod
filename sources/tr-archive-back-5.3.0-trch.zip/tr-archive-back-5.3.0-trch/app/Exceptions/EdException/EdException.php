<?php

namespace App\Exceptions\EdException;

use App\Exceptions\CustomException;

class EdException extends CustomException
{
    //
}
