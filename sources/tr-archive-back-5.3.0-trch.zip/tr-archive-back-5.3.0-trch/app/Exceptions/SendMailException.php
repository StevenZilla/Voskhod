<?php

namespace App\Exceptions;

use Exception;

class SendMailException extends Exception
{
    //
}
