<?php

namespace App\Exceptions\LogicStatus;

use Exception;
use Throwable;

class LogicStatusException extends Exception
{
    private $logicStatusCode;
    private $target;

    public function __construct(string $message, string $target, int $logicStatusCode = 400, int $code = 400, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);

        $this->logicStatusCode = $logicStatusCode;
        $this->target = mb_strtoupper($target);
    }

    public function getLogicStatusCode() : int
    {
        return $this->logicStatusCode;
    }

    public function getTarget() : string
    {
        return $this->target;
    }
}