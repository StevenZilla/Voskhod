<?php

namespace App\Exceptions\NomenclatureException;

use App\Exceptions\CustomException;

class NomenclatureException extends CustomException
{
    //
}
