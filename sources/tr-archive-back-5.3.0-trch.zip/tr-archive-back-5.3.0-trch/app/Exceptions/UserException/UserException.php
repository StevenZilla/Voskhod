<?php

namespace App\Exceptions\UserException;

use App\Exceptions\CustomException;

class UserException extends CustomException
{
    //
}
