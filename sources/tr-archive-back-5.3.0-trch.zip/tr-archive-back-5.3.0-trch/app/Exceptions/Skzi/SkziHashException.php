<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziHashException extends Exception
{
    // 
}