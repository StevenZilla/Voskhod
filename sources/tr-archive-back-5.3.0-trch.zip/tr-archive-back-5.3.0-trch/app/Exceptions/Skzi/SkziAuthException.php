<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziAuthException extends Exception
{
    // 
}