<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziDriverException extends Exception
{
    // 
}