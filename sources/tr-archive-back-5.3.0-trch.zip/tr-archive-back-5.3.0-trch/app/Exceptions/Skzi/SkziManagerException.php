<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziManagerException extends Exception
{
    // 
}