<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziVerifySignException extends Exception
{
    // 
}