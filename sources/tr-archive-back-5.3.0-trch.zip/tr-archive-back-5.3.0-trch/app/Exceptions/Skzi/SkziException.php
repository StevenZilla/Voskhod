<?php

namespace App\Exceptions\Skzi;

use App\Exceptions\BaseException;

class SkziException extends BaseException
{
}