<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziByteSequenceException extends Exception
{
    // 
}