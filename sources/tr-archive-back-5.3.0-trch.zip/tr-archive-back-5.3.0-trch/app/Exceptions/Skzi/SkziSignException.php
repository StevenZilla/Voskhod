<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziSignException extends Exception
{
    // 
}