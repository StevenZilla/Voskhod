<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziMchdException extends Exception
{
    // 
}