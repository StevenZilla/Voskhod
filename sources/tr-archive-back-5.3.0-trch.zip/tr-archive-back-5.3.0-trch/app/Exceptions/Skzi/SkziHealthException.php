<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziHealthException extends Exception
{
    // 
}