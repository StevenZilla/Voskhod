<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziAvailabilityException extends Exception
{
    // 
}