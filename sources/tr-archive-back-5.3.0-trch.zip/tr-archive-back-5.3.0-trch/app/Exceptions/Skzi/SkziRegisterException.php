<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziRegisterException extends Exception
{
    // 
}