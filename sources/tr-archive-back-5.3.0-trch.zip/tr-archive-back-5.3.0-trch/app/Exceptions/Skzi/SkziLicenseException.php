<?php

namespace App\Exceptions\Skzi;

use Exception;

class SkziLicenseException extends Exception
{
    // 
}