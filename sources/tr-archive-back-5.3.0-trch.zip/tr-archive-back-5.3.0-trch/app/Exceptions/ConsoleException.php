<?php

namespace App\Exceptions;

class ConsoleException extends BaseException
{
}
