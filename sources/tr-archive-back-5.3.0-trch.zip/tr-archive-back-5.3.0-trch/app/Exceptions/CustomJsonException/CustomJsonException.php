<?php

namespace App\Exceptions\CustomJsonException;

use App\Exceptions\CustomException;

class CustomJsonException extends CustomException
{
    //
}
