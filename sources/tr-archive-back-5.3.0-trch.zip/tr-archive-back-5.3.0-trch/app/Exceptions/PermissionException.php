<?php

namespace App\Exceptions;

class PermissionException extends BaseException
{
    //Класс для исключений ошибки доступа
}
