<?php

namespace App\Exceptions\AuthException;

use App\Exceptions\CustomException;

class LoginException extends CustomException
{
}
