<?php

namespace App\Facades;

use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Support\Facades\Facade;

/**
 * Class DatabaseConnectionFacade
 * @method static bool isLocalConnectDB() Проверяет тип подключения
 * @method static string getIdAppOnDB() Возвращает идентификатор приложения из БД
 * @method static setDataConnection(string $guidMedo = null) Устанавливает основное подключение к БД
 * @method static setDataConnectionWithIdApp(string $idApp) Устанавливает подключение по Идентификатору Приложения
 * @method static array getAllGuidMedo()Возвращает массив GUID МЭДО всех инстанций
 * @method static string getGuidMedo(string $idApp) Возвращает GUID МЭДО для конкретной инстанции по Идентификатору приложения
 * @method static string getIdApp(string $guidMedo = null) Возвращает Идентификатор приложения для конкретной инстанции по GUID МЭДО
 *
 * @see ConnectionDB
 */
class DatabaseConnectionFacade extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'database_connection.facade';
    }
}
