<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * SKZIServiceFacade
 * 
 * @method static string getName()
 * @method static bool checkHealth()
 * @method static int getLicense()
 * @method static string getVersion()
 * @method static bool sign(string $filePath, object $sert, string $signType = 'CAdES-BES')
 * @method static bool verifySign(string $filePath, object $sert, string $signType)
 * @method static bool verifySignThumbprint(string $filePath, object $sert, string $signType = "CAdES-BES")
 * @method static bool verifySignFile(string $filePath, string $fileSign, string $signType)
 * @method static array getCertificateRegister()
 * @method static array getCertificates()
 * @method static string makeByteSequence($files, $fileByteSequence)
 * @method static bool moveMchd(string $absolutePathToMchd, string $absolutePathToSave)
 * 
 * 
 * 
 * @see \App\Services\Skzi\SkziService
 */
class SKZIServiceFacade extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'skzi_service.manager';
    }
}
