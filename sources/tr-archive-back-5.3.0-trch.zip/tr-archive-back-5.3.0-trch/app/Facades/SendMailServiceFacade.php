<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @method static void send()
 * @method static object mail($to, $subject, $body, $view = null, $guid = null, array $attach = null)
 * 
 * @see App\Services\Mail\SendMailService
 */
class SendMailServiceFacade extends Facade
{
    protected static function getFacadeAccessor()
    {
        return 'sendMailService.service';
    }
}
