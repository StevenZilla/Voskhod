<?php

namespace App\Http\Middleware;

use Illuminate\Contracts\Encryption\Encrypter as EncrypterContract;
use Illuminate\Cookie\Middleware\EncryptCookies as Middleware;

class EncryptCookies extends Middleware
{
    private $notificationServiceCoockie = "uc_notification_local";

    public function __construct(EncrypterContract $encrypter)
    {
        $this->encrypter = $encrypter;
        $this->except[] = env('NOTIFICATION_COOKIE_NAME','uc_notification_local');
    }
    /**
     * The names of the cookies that should not be encrypted.
     *
     * @var array
     */
    protected $except = [];
}
