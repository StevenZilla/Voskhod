<?php

namespace App\Http\Middleware;

use AdamBrett\ShellWrapper\Runners\System;
use App\Models\System\SystemParam;
use Closure;
use Illuminate\Http\Request;

class AddHeaders
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);
        $response->header('tr-archive-version', SystemParam::where('code', 'version_po')->first()->value);
        return $response;
    }
}
