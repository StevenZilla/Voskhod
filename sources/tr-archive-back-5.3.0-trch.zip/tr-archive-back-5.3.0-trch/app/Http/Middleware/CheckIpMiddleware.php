<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Support\Facades\Log;

class CheckIpMiddleware
{
    /**
     * Handle an incoming request.
     * Проверяет ip текущего пользователя, если он не совпадает, то не дает получить доступ к ресурсу.
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!$request->headers->has('authorization')) {
            $userIp = $request->session()->pull('user_ip', null);

            if (! empty($userIp)) {
                if ($userIp == $request->getClientIp()) {
                    $request->session()->put('user_ip', $request->getClientIp());
                } else {
                    Log::warning("С предыдущего запроса IP пользователя не совпадает. Старое айпи пользователя {$userIp}, текущее айпи пользователя {$request->getClientIp()}");
                    throw new AuthenticationException('Unauthenticated.');
                }
            } else {
                Log::warning('С предыдущего запроса IP пользователя не сохранился.');
                throw new AuthenticationException('Unauthenticated.');
            }
        }

        return $next($request);
    }
}
