<?php

namespace App\Http\Middleware;

use App\Exceptions\AuthException\LoginException;
use App\Models\Session\Session;
use Closure;
use Illuminate\Http\Request;

class Check2FAMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if ($request->hasSession() && $request->session()->has('session_id')) {
            $user = \Illuminate\Support\Facades\Auth::user();
            $session = Session::where('id', request()->session()->get('session_id'))->first();

            if (! is_null($user->is_2fa) && ! $user->is_2fa) {
                return $next($request);
            } elseif (! empty($session->getAttribute('2fa_code')) && $session->getAttribute('2fa_code_end_time') && ! $session->is_trust) {
                throw new LoginException('Введите код отправленный вам на почту');
            }
        }

        return $next($request);
    }
}
