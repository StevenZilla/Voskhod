<?php

namespace App\Http\Middleware;

use App\Exceptions\AuthException\LoginException;
use App\Exceptions\BaseException;
use App\Models\User\User;
use Closure;
use Illuminate\Auth\Middleware\AuthenticateWithBasicAuth;
use Illuminate\Support\Facades\Log;

class AuthenticateWithBasicAuthMiddleware extends AuthenticateWithBasicAuth
{
    public function handle($request, Closure $next, $guard = null, $field = null)
    {
        try {
            if (!empty(request()->header('authorization'))) {
                $pattern = '/Basic\s+([a-zA-Z0-9\/+=]+)/i';
                preg_match($pattern, request()->header('authorization'), $matches);
                $decodeBase64 = base64_decode($matches[1]);
                $dataValues = explode(':', $decodeBase64);

                if (count($dataValues) !== 2) {
                    throw new BaseException('Неправильно передан заголовок Authorization. Значение должно быть: Basic и дальше данные пользователя.');
                }

                $salt = User::where('login', $dataValues[0])->pluck('salt')->first();
                $value = $dataValues[1];

                $request->headers->set('authorization', 'Basic ' . base64_encode("{$dataValues[0]}:{$value}{$salt}"));
                $request->headers->set('PHP_AUTH_PW', "{$value}{$salt}");

                $this->auth->guard($guard)->basic($field ?: 'email');
            }

            return $next($request);
        } catch (\Exception $exception) {
            Log::error("Не смогли авторизоваться в системе. Ошибка:\n{$exception}");
            throw new LoginException('Не удалось выполнить вход. Пожалуйста, проверьте правильность введенного логина и пароля.');
        }
    }
}
