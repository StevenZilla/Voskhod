<?php

namespace App\Http\Middleware;

use App\Jobs\Audit\AuditJob;
use App\Models\Event\EventType;
use App\Models\Permission\ActionPermission;
use Closure;
use Illuminate\Support\Facades\Auth;

class AuditMiddleware
{
    public function handle($request, Closure $next)
    {
        $response = $next($request);

        if ($response->getStatusCode() >= 400) {
            $data = [];
            $appealUser = 'sub:user';
            if (! Auth::check()) {
                $infoUser = 'Неавторизованный пользователь';
            } else {
                $user = Auth::user();
                $data['user_type'] = 'App\Models\User\User';
                $data['user_id'] = $user->id;

                $infoUser = $user->appeal_user;
            }

            $data['is_success'] = false;
            $data['event'] = 'failed_request';
            $data['template'] = "{$appealUser} запросил";

            if (!empty($request->route()->getAction('permissions'))) {
                $action = $request->route()->getAction('permissions')[0];
                $actionDescription = ActionPermission::where('tech_name', $action)->pluck('description')->first();

                if (!empty($actionDescription)) {
                    $actionDescription = mb_strtolower(mb_substr($actionDescription, 0, 1, 'UTF-8'), 'UTF-8')
                            . mb_substr($actionDescription, 1, mb_strlen($actionDescription), 'UTF-8');

                    $data['template'] .= ' ' . $actionDescription;
                } else {
                    $data['template'] .= " доступ к {$request->getPathInfo()}";
                }
            }

            if (in_array($response->getStatusCode(), [401, 403])) {
                $data['event_type_id'] = EventType::getIdAuthorization();
                $data['template'] .= ' У пользователя нет прав доступа к этому ресурсу или он не авторизован.';
            } else {
                $method = mb_strtolower($request->getMethod());

                switch ($method) {
                    case 'post':
                        $data['event_type_id'] = EventType::getIdCreated();
                        $data['template'] .= ' Не валидное тело запроса на создание этого ресурса.';
                        break;
                    case 'put':
                    case 'patch':
                        $data['event_type_id'] = EventType::getIdUpdated();
                        $data['template'] .= ' Не валидное тело запроса на обновление этого ресурса.';
                        break;
                    case 'delete':
                        $data['event_type_id'] = EventType::getIdDeleted();
                        $data['template'] .= ' Не валидное тело запроса на удаление этого ресурса.';
                        break;
                    default:
                        $data['event_type_id'] = EventType::getIdViewed();
                        $data['template'] .= ' Не валидный запроса на просморт этого запроса.';
                        break;
                }
            }

            $data['url'] = $request->fullUrl();
            $data['old_values'] = '[]';
            $data['new_values'] = json_encode($request->all(), JSON_UNESCAPED_UNICODE);
            $data['ip_address'] = $request->getClientIp();
            $data['user_agent'] = $request->userAgent();

            $subData['subject_id'] = $data['user_id'] ?? null;
            $subData['subject_name'] = $infoUser;
            $subData['subject_code'] = 'user';

            $objData['object_id'] = null;
            $objData['object_name'] = null;
            $objData['object_code'] = null;

            $data['markers'] = json_encode([
                'subject' => $subData,
                'object' => [$objData],
            ], JSON_UNESCAPED_UNICODE);

            if (! empty(request()->header('uid'))) {
                $uidInstance = request()->header('uid');
            } else {
                $uidInstance = null;
            }

            $dataMarkers = json_decode($data['markers'], true);
            $data['message'] = preg_replace("/sub:{$dataMarkers['subject']['subject_code']}/", $dataMarkers['subject']['subject_name'], $data['template']);

            AuditJob::dispatch($data, $uidInstance)->onQueue('insert_audit_job');
        }

        return $response;
    }
}
