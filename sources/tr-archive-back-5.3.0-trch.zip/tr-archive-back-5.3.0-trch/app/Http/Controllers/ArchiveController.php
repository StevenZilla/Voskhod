<?php

namespace App\Http\Controllers;

use App\Http\Requests\Archive\StoreArchivesRequest;
use App\Http\Requests\DirectoryRequest;
use App\Http\Resources\HandBooks\Archive\IndexResource;
use App\Models\HandBooks\Archive;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class ArchiveController extends Controller
{
    /**
     * @param DirectoryRequest $request
     * @return IndexResource
     */
    public function index(DirectoryRequest $request)
    {
        $archives = Archive::Filters($request)
            ->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($archives);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Collection|Model|JsonResponse
     */
    public function show($id)
    {
        try {
            return Archive::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Архива с переданным id '.$id.' не существует');
        }
    }

    public function store(StoreArchivesRequest $request)
    {
        $inputsArchives = $request->get('archives');
        try {
            $createdArchives = DB::transaction(function () use ($inputsArchives) {
                $createdArchives = [];
                foreach ($inputsArchives as $inputArchive) {
                    if (! array_key_exists('id', $inputArchive)) {
                        $newArchive = new Archive();
                        $newArchive->name = $inputArchive['full_name'];
                        $newArchive->short_name = $inputArchive['value'];
                        $newArchive->description = $inputArchive['descr'] ?? null;
                        $newArchive->code = $inputArchive['code'];
                        $newArchive->email = $inputArchive['email'] ?? null;
                        $newArchive->address = $inputArchive['address'] ?? null;
                        $newArchive->head = $inputArchive['head'] ?? null;
                        $newArchive->head_phone = $inputArchive['head_phone'] ?? null;
                        $newArchive->actual_date = Carbon::now()->toDateString();
                        $newArchive->is_actual = true;
                        $newArchive->save();
                        $createdArchives[] = $newArchive->id;
                    }
                }

                return $createdArchives;
            });
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => 'Дублируются данные архивов'], 400);
        }

        return response()->json(['code' => 201, 'message' => $createdArchives], 201);
    }
}
