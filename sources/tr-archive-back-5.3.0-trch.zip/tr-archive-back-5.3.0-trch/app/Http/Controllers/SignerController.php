<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\SignerRequest;
use App\Http\Requests\SignerUpdateRequest;
use App\Http\Resources\HandBooks\Signer\IndexResource;
use App\Models\Signer\Signer;
use App\Models\Signer\SignerRole;

class SignerController extends BaseController
{
    /**
     * @param SignerRequest $request
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function index(SignerRequest $request)
    {
        $signers = Signer::filters($request)
            ->orders($request)
            ->autopaginate($request);
        return new IndexResource($signers);
    }

    /**
     * @param SignerUpdateRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(SignerUpdateRequest $request)
    {
        try {
            if ($request->exists('signers')) {
                foreach ($request->signers as $dataSigner) {
                    if (! empty($dataSigner['id'])) {
                        $signer = Signer::findOrFail($dataSigner['id']);
                        if (isset($dataSigner['role_id'])) {
                            $signer->signer_role_id = $dataSigner['role_id'];
                        }
                        $signer->update($dataSigner);
                    } else {
                        $signer = new Signer($dataSigner);
                        $signer->signer_role_id = $dataSigner['role_id'];
                        $signer->save();
                    }
                }
            } else {
                throw new BaseException('Не существует обязательного параметра signers в переданном json-теле');
            }
        } catch (BaseException $e) {
            return response()->json(['code' => 400, 'message' => 'Ошибка, такого подписанта или роли не существует, либо у пользователя уже есть подписант с такой ролью'], 400);
        }

        return response()->json(['code' => 201, 'message' => $signer->id], 201);
    }

    public function getSignerRoles()
    {
        return SignerRole::orderByRaw('participant_role.name collate "C" asc')->get();
    }
}
