<?php

namespace App\Http\Controllers;

use App\Http\Requests\ReportController\StoreRequest;
use App\Jobs\CreateReportJob;
use App\Models\Register\Register;
use App\Models\Report\Report;
use App\Models\Report\StatusReport;
use App\Services\ReportController\ReportRegisterService;
use App\Services\ReportController\ReportService;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        return ['reports' => Report::withFilter($request)->withGroup($request)];
    }

    public function show(int $id)
    {
        return Report::findOrFail($id);
    }

    public function store(StoreRequest $request)
    {
        $status = StatusReport::where('code', 'new')->pluck('id')->first();

        $reports = [];

        foreach ($request->type as $type) {
            $reportQuery = Report::where('object_type', $type)
                    ->where('object_id', $request->register_id)
                    ->where('status_id', StatusReport::where('code', 'success')->pluck('id')->first());

            if ($this->checkDate($reportQuery)) {
                $report = $reportQuery->first();
                $reports[] = $report->id;
            } else {
                $report = new Report();
                $report->path = '';
                $report->object_id = $request->register_id;
                $report->object_type = $type;
                $report->status_id = $status;
                $report->form_date = now();
                $report->save();

                $reports[] = $report->id;

                CreateReportJob::dispatch($request->register_id, $type, $report)->onQueue('create_report');
            }
        }

        return ['code' => 202, 'message' => $reports];
    }

    private function checkDate($report)
    {
        if ($report->exists()) {
            if ($report->pluck('form_date')->first() > Register::find($report->pluck('object_id')->first())->updated_at) {
                return true;
            }
        }

        return false;
    }
}
