<?php

namespace App\Http\Controllers\Act;

use App\Http\Controllers\Controller;
use App\Services\Act\ActService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(ActService $service)
    {
        $this->service = $service;
    }
}
