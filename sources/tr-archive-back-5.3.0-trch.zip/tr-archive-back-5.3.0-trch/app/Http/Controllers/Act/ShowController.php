<?php

namespace App\Http\Controllers\Act;

use App\Http\Controllers\Controller;
use App\Http\Resources\Act\ShowResource;
use App\Models\Act\AcceptAct;
use Illuminate\Http\Request;

class ShowController extends BaseController
{
    public function __invoke(int $id) {
        try {
           $act = AcceptAct::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Акта с переданным id '.$id.' не существует');
        }
        return new ShowResource($act);
    }
}
