<?php

namespace App\Http\Controllers\Act;

use App\Http\Controllers\Controller;
use App\Http\Resources\Act\ActResource;
use App\Http\Resources\Act\IndexResource;
use App\Models\Act\AcceptAct;
use Illuminate\Http\Request;

class IndexController extends BaseController
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request) {
        $acts = AcceptAct::Filters($request)
            ->orderDefault($request, 'id', 'DESC', '')
            ->orders($request)
            ->autoPaginate($request);
            return new IndexResource($acts);
    }
}
