<?php

namespace App\Http\Controllers;

use App\Http\Requests\DirectoryRequest;
use App\Models\Register\RegisterType;

class RegisterTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param DirectoryRequest $request
     * @return array
     */
    public function index(DirectoryRequest $request)
    {
        return [
            'register_types' => RegisterType::withFilter($request)->orderBy(RegisterType::$defaultOrderColumn)->get(),
        ];
    }
}
