<?php

namespace App\Http\Controllers;

use App\Services\FilesystemManager\MediaStorage;
use XmlValidator\XmlValidator;

class XmlAkController extends Controller
{
    protected $path_to_folder;
    protected $path_out_folder;
    protected $path_result;
    protected $absolute_path_to_media;
    protected $storage;

    protected $path_system_params;

    protected $guid;
    protected $message_guid;

    /**
     * Массив временных файлов.
     * @var array
     */
    protected $tempFiles = [];

    /**
     * @param $id
     * @param $path
     * @return \Illuminate\Http\JsonResponse|void
     * @throws \Throwable
     */
    public function createXmlMagazineAk($id, $path = 'media')
    {
        $filename = 'test.xml';
        $fullPath = $path.'/'.$filename;

        $versionXSD = config('app.version_xsd');
        $xsd = basename(MediaStorage::disk('public_xsd')->getAdapter()->getPathPrefix())."/{$versionXSD}/ak_log_{$versionXSD}.xsd";
        $xsdAbsolutePath = MediaStorage::disk('public_xsd')->getAdapter()->getPathPrefix()."{$versionXSD}/ak_log_{$versionXSD}.xsd";

        $data = [];

        $data['operationType'] = 'Создана квитанция';
        $data['operationDateTime'] = (new \DateTime())->format('c');
        $data['operationStatus'] = 'true';
        $data['operationResult'] = 'Проверка пройдена успешно';

        $xml = view('xml.ak')->with(['data' => $data, 'absolutePath' => $path])->render();

        $xmlValidator = new XmlValidator();
        $xmlValidator->validate($xml, $xsd);
        if (! $xmlValidator->isValid()) {
            foreach ($xmlValidator->errors as $error) {
                return response()->json(['code' => 500, 'message' => $error->message], 500);
            }
        }

        MediaStorage::put($path, $xml);
        $this->tempFiles[] = $this->path_to_folder.'/'.$filename;

        $fp = fopen($fullPath, 'w');
        fwrite($fp, $xml);
        fclose($fp);
    }
}
