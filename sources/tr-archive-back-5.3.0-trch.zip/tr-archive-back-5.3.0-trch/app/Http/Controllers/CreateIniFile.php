<?php

namespace App\Http\Controllers;

use App\Models\Tk\Tk;
use App\Services\FilesystemManager\MediaStorage;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class CreateIniFile extends Controller
{
    /**
     * @param $id
     * @param $path
     * @return \Illuminate\Http\JsonResponse
     */
    public static function createIniFile($id, $path = '/tk')
    {
        try {
            $tk = Tk::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('ТК с переданным id '.$id.' не существует');
        }

        if (empty($tk->ed)) {
            return response()->json(['code' => 500, 'message' => 'Ошибка! Отсутствует ed_id у TK'], 500);
        }

        if (! MediaStorage::has($path)) {
            MediaStorage::makeDirectory($path);
        }

        $ini = basename(MediaStorage::getAdapter()->getPathPrefix()).$path.'/envelope.ini';

        $title = '[ПИСЬМО КП ПС СЗИ]'.PHP_EOL;
        $iniMess = [
            'ТЕМА' => $tk->ed->name,
            'АВТООТПРАВКА' => 1,
            'ШИФРОВАНИЕ' => 0,
            'ЭЦП' => 1,
            'ДОСТАВЛЕНО' => 1,
            'ПРОЧТЕНО' => 0,
            'ДАТА' => Carbon::now()->format('Y-m-d H:i:s'),
            'АДРЕСАТЫ' => [
                'M_MINSV_D~MEDOGU',
            ],
            'ФАЙЛЫ' => [
                'document.edc.zip',
                'container.xml',
            ],
        ];

        $data = [];
        foreach ($iniMess as $key => $val) {
            if (is_array($val)) {
                $data[] = "[$key]";
                foreach ($val as $skey => $sval) {
                    if (is_array($sval)) {
                        foreach ($sval as $_skey => $_sval) {
                            if (is_numeric($_skey)) {
                                $data[] = $skey.'[] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                            } else {
                                $data[] = $skey.'['.$_skey.'] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                            }
                        }
                    } else {
                        $data[] = $skey.' = '.(is_numeric($sval) ? $sval : (ctype_upper($sval) ? $sval : '"'.$sval.'"'));
                    }
                }
            } else {
                $data[] = $key.' = '.(is_numeric($val) ? $val : (ctype_upper($val) ? $val : '"'.$val.'"'));
            }
        }

        $fp = fopen($ini, 'w');
        if (! $fp) {
            return response()->json(['code' => 500, 'message' => 'Ошибка при создании файла'], 500);
        }

        $strIni = $title.implode(PHP_EOL, $data).PHP_EOL;
        fwrite($fp, iconv('', 'Windows-1251', $strIni));
        fclose($fp);

        return response()->json(['code' => 201, 'message' => 'Файл успешно создан. Путь: '.$ini], 500);
    }
}
