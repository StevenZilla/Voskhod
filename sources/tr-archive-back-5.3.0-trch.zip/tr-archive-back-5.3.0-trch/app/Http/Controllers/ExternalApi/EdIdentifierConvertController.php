<?php

namespace App\Http\Controllers\ExternalApi;

use App\Exceptions\LogicStatus\LogicStatusException;
use Exception;
use App\Models\Ed\Ed;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\ExternalApi\EdIdentifierConvertResource;

class EdIdentifierConvertController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $guid_arch)
    {
        $errorMsg = "Ошибка. ЭАД с идентификатором {$guid_arch} не существует";

        try {
            $id = Ed::where('guid_arch', $guid_arch)->withTrashed()->select(['id'])->first();
        } catch (Exception $e) {
            throw new LogicStatusException($errorMsg, 'ED', 4404, 404);
        }

        return response(new EdIdentifierConvertResource($id), 200);
    }
}
