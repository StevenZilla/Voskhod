<?php

namespace App\Http\Controllers\ExternalApi;

use Exception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegister;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\ExternalApi\AcceptRegisterIdentifierConvertResource;

class AcceptRegisterIdentifierConvertController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request, $guid_arch)
    {
        $errorMsg = "Ошибка. Сдаточной описи с идентификатором {$guid_arch} не существует";
        try {
            $id = AcceptRegister::where('guid_arch', $guid_arch)->select(['id'])->first();
        } catch (Exception $e) {
            throw new ModelNotFoundException($errorMsg);
        }
        if (empty($id)) {
            throw new ModelNotFoundException($errorMsg);
        }
        return response(new AcceptRegisterIdentifierConvertResource($id), 200);
    }
}
