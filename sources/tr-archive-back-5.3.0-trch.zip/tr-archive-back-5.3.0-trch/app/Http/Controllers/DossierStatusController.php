<?php

namespace App\Http\Controllers;

use App\Models\Dossier\DossierStatus;

class DossierStatusController extends BaseController
{
    /**
     * @return array
     */
    public function index()
    {
        return ['dossier_statuses' => DossierStatus::get()];
    }
}
