<?php

namespace App\Http\Controllers;

use App\Models\DecisionType;
use Illuminate\Http\Request;

class DecisionTypeController extends Controller
{
    public function index(Request $request)
    {
        $decision_type = DecisionType::withFilter($request)->withOrder($request)->withOrderDefault($request)->get();

        return ['decision_types' => $decision_type];
    }
}
