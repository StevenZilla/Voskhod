<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestInstallCertController extends Controller
{
    /**
     * @param Request $request
     * @return false|string|null
     */
    public function install(Request $request)
    {
        $pathToFile = '/home/user/cert/test_cert_2.pfx';

        $command = "/opt/cprocsp/bin/amd64/certmgr -install -store umy -file {$pathToFile} -pfx -pin {$request->pin} -silent";

        $return = shell_exec($command);

        return $return;
    }
}
