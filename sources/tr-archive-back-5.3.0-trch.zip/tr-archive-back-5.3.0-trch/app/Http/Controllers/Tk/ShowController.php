<?php

namespace App\Http\Controllers\Tk;

use App\Http\Controllers\Controller;
use App\Http\Requests\TkShowRequest;
use App\Http\Resources\Tk\IndexResource;
use App\Models\Tk\Tk;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class ShowController extends Controller
{

    public function __invoke(TkShowRequest $request)
    {
        try {
            $tk = Tk::
            filters($request)
                ->orderDefault($request, 'sort', 'DESC', 'collate "C"')
                ->orders($request)->autoPaginate($request);
//                ->withPaginate($request);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }
        return new IndexResource($tk);
//        return $tk;
    }
}
