<?php

namespace App\Http\Controllers\Tk;

use App\Http\Controllers\Controller;
use App\Http\Requests\TkSignRequest;
use App\Models\Tk\Tk;
use App\Services\FilesystemManager\MediaStorage;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CreateSignTkController extends Controller
{

    public function __invoke(TkSignRequest $request, $id)
    {
        $inputs['extension'] = $request->sig->getClientOriginalExtension();

        $data = Validator::make($inputs, [
            'extension' => 'required|in:sig',
        ]);

        if ($data->fails()) {
            return response()->json(['code' => 403, 'message' => $data->errors()], 403);
        }

        try {
            $tk = Tk::findOrFail($id);
        } catch (ModelNotFoundException $ex) {
            return response()->json(['code' => 400, 'message' => 'ТК/АК не найден'], 400);
        }

        $sig = $request->file('sig');

        $path = MediaStorage::putFileAs('tk/'.$tk->id.'/'.$tk->guid.'.edc', $sig, $tk->id.'.sig');
        $publicPath = basename(MediaStorage::getAdapter()->getPathPrefix()).'/'.$path;

        $tk->sign_end_date = $request->sign_end_date;
        $tk->ep_path = $publicPath;
        $tk->save();

        return response()->json(['code' => 204, 'message' => $publicPath], 204);
    }
}
