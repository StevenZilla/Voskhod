<?php

namespace App\Http\Controllers\Tk;

use App\Http\Controllers\Controller;
use App\Models\Tk\Tk;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class ShowByIdController extends Controller
{

    public function __invoke($id)
    {
        try {
            $tk = Tk::query()->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }
        return $tk;
    }
}
