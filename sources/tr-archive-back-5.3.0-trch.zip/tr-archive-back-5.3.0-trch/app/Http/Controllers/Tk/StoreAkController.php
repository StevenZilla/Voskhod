<?php

namespace App\Http\Controllers\Tk;

use App\Exceptions\BaseException;
use App\Exceptions\TkException\TkException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Tk\CreateAkRequest;
use App\Jobs\CreateEdAk;
use App\Jobs\CreateRegisterAk;
use App\Models\Ed\Ed;
use App\Models\HandBooks\Fund;
use App\Models\Register\Register;
use App\Models\Sert\Sert;
use App\Models\System\SystemParam;
use App\Models\Tk\Tk;
use App\Models\Tk\TkStatus;
use App\Models\Tk\TkType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StoreAkController extends Controller
{

	public function __invoke(CreateAkRequest $request)
	{
		$uid = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;

		$inputs = $request->all();
		//        $inputs['form_date'] = Carbon::now()->toDateTimeString();
		$inputs['in_out'] = false;
		$inputs['user_id'] = Auth::id();
		$inputs['tk_status_id'] = TkStatus::where('name', 'передан во временное хранилище')
			->pluck('id')->first();

		try {
			$tk = DB::transaction(function () use ($inputs, $request, $uid) {
                $systemParam = SystemParam::where('code', 'system_signature')->first();
                $thumbprint = $systemParam ? $systemParam->value : null;
                $sert = Sert::where('thumbprint', $thumbprint)->first();

                if (empty($thumbprint) || empty($sert)) {
                    throw  new BaseException('Технологическая подпись для текущего пользователя в системе не найдена');
                }

                if (!$sert->checkValidatePeriod($sert, $request->server('REQUEST_TIME'))) {
                    throw new BaseException('Срок действия сертификата истек или же еще не наступил');
                }
//        Не актуально более, автоматическое подписание технологической подписью  TRARCHIVE-55
//                if (!$sert->checkSerUse('eds_ak')) {
//                    if ($request->exists('register_id')) {
//                        throw new BaseException('Невозможно утвердить опись, переданный сертификат не обладает необходимыми правилами использования');
//                    } else {
//                        throw new BaseException('Невозможно утвердить ЭД, переданный сертификат не обладает необходимыми правилами использования');
//                    }
//                }

				$dataEd = [];
				if (!empty($request->ed_id) || !empty($request->register_by_ed_id)) {
					$type = TkType::where('code', 'document')->first(['code', 'id']);

					if (!empty($request->register_by_ed_id)) {
						$dataEd = Ed::leftJoin('dossier_in_register', 'ed.dossier_id', 'dossier_in_register.dossier_id')
							->where('dossier_in_register.register_id', $request->register_by_ed_id)->get(['ed.*']);
					} else {
						$dataEd[] = Ed::where('id', $request->ed_id)->first();
					}
				} elseif (!empty($request->register_id)) {
					$type = TkType::where('code', 'register')->first(['code', 'id']);
				}

				$inputs['tk_type'] = $type->id;
				$inputs['tk_status_id'] = TkStatus::where('code', 'transferred_temporary_storage')->pluck('id')->first();

				if ($type->code === 'document') {
					if (!empty($dataEd)) {
						if (!empty($inputs['register_by_ed_id'])) {
							$register = Register::findOrFail($inputs['register_by_ed_id']);
							unset($inputs['register_by_ed_id']);
						}
						foreach ($dataEd as $ed) {
							$inputs['ed_id'] = $ed->id;
							$tk = new Tk($inputs);

							if (empty($inputs->archive_id)) {
								if (!empty($register)) {
									$tk->archive_id = $register->archive_id;
									$tk->fund_id = $register->fund_id;
								} else {
									$registers = $ed->registers;
									if (!empty($registers) && count($registers)) {
										$tk->archive_id = $registers[0]->archive_id;
										$tk->fund_id = $registers[0]->fund_id;
									} else {
										$fundDefault = Fund::where('is_default', true)->first();
										if (!empty($fundDefault)) {
											$tk->fund_id = $fundDefault->id;
											$tk->archive_id = $fundDefault->archive->id;
										}
									}
								}
							}

							$tk->save();

							CreateEdAk::dispatch($tk, $thumbprint, $uid)->onQueue('create_ed_ak_job');
						}
					}
				} elseif ($type->code === 'register') {
					$tk = new Tk($inputs);
					$register = Register::findOrFail($request->register_id);

					if (empty($inputs->archive_id)) {
						$tk->archive_id = $register->archive_id;
						$tk->fund_id = $register->fund_id;
					}

					$tk->save();
					CreateRegisterAk::dispatch($tk, $thumbprint, $uid)->onQueue('create_register_ak_job');
				} else {
					throw new BaseException('Не смогли определить что отправляем во временное хранилище');
				}

				return $tk;
			});
		} catch (TkException $e) {
			return response()->json(['code' => 424, 'message' => $e->getMessage()], 424);
		} catch (\Exception $e) {
			if (str_contains($e->getMessage(), 'SQLSTATE[')) {
				$message = 'Нарушение ограничения базы данных';
				Log::alert('Ошибка при создании АК, нарушение ограничения базы данных');
				Log::error("\n Ошибка  {$e->getMessage()} \n");
			} else {
				$message = $e->getMessage();
				Log::warning('Ошибка при создании АК');
			}

			return response()->json(['code' => 400, 'message' => $message], 400);
		}

		return response()->json(['code' => 202, 'message' => ['id' => $tk->id, 'form_date' => $tk->form_date]], 202);
	}
}
