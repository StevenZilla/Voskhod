<?php

namespace App\Http\Controllers\Tk;

use App\Http\Controllers\Controller;
use App\Http\Requests\ChangeGuidTKRequest;
use App\Models\Tk\Tk;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class ChangeGuidController extends Controller
{

    public function __invoke(ChangeGuidTKRequest $request, $id)
    {
        try {
            $tk = Tk::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }

        $tk->message_guid = $request->message_guid;
        $tk->save();

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }
}
