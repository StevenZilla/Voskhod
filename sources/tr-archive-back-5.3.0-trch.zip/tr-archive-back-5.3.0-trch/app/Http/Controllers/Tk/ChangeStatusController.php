<?php

namespace App\Http\Controllers\Tk;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Tk\ChangesStatusTkOnRegisterRequest;
use App\Models\Tk\Tk;
use Illuminate\Http\Request;

class ChangeStatusController extends Controller
{

    public function __invoke(ChangesStatusTkOnRegisterRequest $request, $id)
    {
        try {
            $tk = Tk::findOrFail($id);
        } catch (BaseException $e) {
            return response()->json(['code' => 500, 'message' => 'ТК/АК не найден'], 500);
        }

        $tk->tk_status_id = $request->status_id;

        if ($tk->save()) {
            return response()->json(['code' => 201, 'message' => 'ok'], 201);
        } else {
            return response()->json(['code' => 500, 'message' => 'Статус не изменился.'], 500);
        }
    }
}
