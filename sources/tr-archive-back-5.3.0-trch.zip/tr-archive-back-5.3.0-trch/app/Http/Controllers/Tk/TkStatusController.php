<?php

namespace App\Http\Controllers\Tk;

use App\Models\Tk\TkStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TkStatusController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $tkStatus = TkStatus::withDefaultFilter($request)->withFilter($request)->get();

        return [
            'tk_statuses' => $tkStatus->sortBy('name')->values(),
        ];
    }
}
