<?php

namespace App\Http\Controllers\OpenSearch\V2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\OpenSearch\OpenSearchProxyService;

class ProxyController extends Controller
{

    public function __invoke(Request $request)
    {
        $proxyService = new OpenSearchProxyService();
        return $proxyService->proxy($request);
    }
}
