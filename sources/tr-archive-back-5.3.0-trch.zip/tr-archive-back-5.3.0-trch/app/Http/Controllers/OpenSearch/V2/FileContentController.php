<?php

namespace App\Http\Controllers\OpenSearch\V2;

use Illuminate\Http\Request;
use OpenSearch\ClientBuilder;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use App\Http\Controllers\OpenSearch\BaseController;

class FileContentController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        try {
        return $this->fileContentService->proxyFileContent($request);
        } catch (\Exception $e) {
            Log::channel('opensearch_single')->error("Ошибка получения контента файлов ".$e->getMessage());
            return response(null,204);
        }
    }
}
