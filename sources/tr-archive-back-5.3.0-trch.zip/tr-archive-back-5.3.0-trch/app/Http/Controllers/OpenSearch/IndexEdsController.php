<?php

namespace App\Http\Controllers\OpenSearch;

use App\Models\System\SystemParam;
use Illuminate\Http\Request;

class IndexEdsController extends BaseController
{
    public function __invoke(Request $request)
    {
        $prefixOik = config('opensearch.prefix_index');
        $index = $prefixOik . '_' . SystemParam::where('code', 'identificator_app')->pluck('value')->first() . '_eds';
        $dataJson = explode("}\n{", $request->getContent());
        $jsonData = end($dataJson);
        $jsonData = (mb_substr($jsonData, 0, 1) === '{') ? $jsonData : '{' . $jsonData;

        return $this->service->getDataEds($index, $jsonData);
    }
}
