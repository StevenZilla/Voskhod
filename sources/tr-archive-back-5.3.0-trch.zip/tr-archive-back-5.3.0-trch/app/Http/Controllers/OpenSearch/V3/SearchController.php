<?php

namespace App\Http\Controllers\OpenSearch\V3;

use stdClass;
use Illuminate\Http\Request;
use OpenSearch\ClientBuilder;
use Illuminate\Support\Carbon;
use App\Models\System\SystemParam;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Permission\Permission;
use App\Services\Subdivision\SubdivisionService;
use App\Http\Controllers\OpenSearch\BaseController;

class SearchController extends BaseController
{
    private $client;
    public function __invoke(Request $request)
    {
        $config = config('opensearch');
        $client = new ClientBuilder();
        $client->setHosts([$config['host']]);
        $client->setBasicAuthentication($config['login'], $config['password']);
        if (!$config['ssl_verification']) {
            $client->setSSLVerification($config['ssl_verification']);
        }
        $this->client = $client->build();

        $queryOptions = config('opensearch.query_options');
        $prefixOik = config('opensearch.prefix_index');
        $appIdentifier = SystemParam::where('code', 'identificator_app')->pluck('value')->first();
        $index =  $prefixOik . '_' . $appIdentifier . '_eds';
        $indexPopularQuery =  $prefixOik . '_' . $appIdentifier . '_query';
        $this->queryBuilderService->setQueryOption($queryOptions);
        $this->queryBuilderService->setPagination($request->size, $request->from);
        // $this->queryBuilderService->setIndex($index);
        $this->queryBuilderService->setIndexPopularQuery($indexPopularQuery);
        $this->queryBuilderService->setSearch($request->search);
        $this->queryBuilderService->setFilters($request->filters);
        $this->queryBuilderService->setPermissions($this->useDsp(), $this->checkSubdivision());
        $body = $this->queryBuilderService->build();
        Log::channel('opensearch_single')->debug("Запрос в opensearch: \n\n" . json_encode($body, JSON_UNESCAPED_UNICODE) . "\n\n");
        $result = $this->client->search(['index' => $index, 'body' => $body]);
        $this->updateQuery($indexPopularQuery, $request->search);
        return $result;
    }

    private function useDsp()
    {
        if(Auth::user()->is_superuser) { // супер пользователь
            return true;
        }

        $permissionsUser = Permission::where('v2', 'ead:dsp')
            ->where('v0', 'user:' . Auth::user()->login)
            ->whereIn('v3', ['true', 'false'])
            ->first();
        if (!empty($permissionsUser)) {
            return $permissionsUser->v3 == "true" ? true : false;
        } else {
            $systemRoles = Auth::user()->systemRole->pluck('code');
            $systemRoles = $systemRoles->map(function ($code) {
                return 'role:' . $code;
            });

            $permissionsGroup = Permission::where('v2', 'ead:dsp')
                ->whereIn('v0', $systemRoles)
                ->orderBy('updated_at', 'desc')
                ->orderBy('id', 'desc')
                ->whereIn('v3', ['true', 'false'])
                ->first();
            if (!empty($permissionsGroup)) {
                return  $permissionsGroup->v3 == "true" ? true : false;
            }
        }
        return false;
    }

    private function checkSubdivision()
    {
        $dataSubdivision = SubdivisionService::getSubdivisionForAuthUser(Auth::user());
        return $dataSubdivision;
    }

    private function updateQuery($indexPopularQuery, $search)
    {
        if (!empty($search)) {
            $searchBase64 = hash('sha256', $search);

            $body = new stdClass();

            $body->query = $search;
            $body->user_id = Auth()->id();
            $body->timestamp = Carbon::now();



            $query = [
                'id' => $searchBase64,
                'index' => $indexPopularQuery,
                'body' => json_encode($body)
            ];
            try {
                $this->client->create($query);
            } catch (\Exception $e) {
                Log::channel('opensearch_single')->error("Ошибка при создании индекс/записи в индекс-" . $query['index'] . 
                "id документа: " . $searchBase64 .
                "\nзапрос: \n" . 
                "PUT {$indexPopularQuery}/_doc/$searchBase64 \n".
                $query['body'] . "\n\n" . $e->getMessage() . "\n\n");
            }
        }
    }


}
