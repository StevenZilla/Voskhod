<?php

namespace App\Http\Controllers\OpenSearch;

use App\Http\Controllers\Controller;
use App\Services\OpenSearch\OpenSearchService;
use App\Services\OpenSearch\OpenSearchProxyService;
use App\Services\OpenSearch\OpenSearchFileContentService;
use App\Services\OpenSearch\OpenSearchQueryBuilderService;

class BaseController extends Controller
{
    public $service = null;
    public $proxyService = null;
    public $fileContentService = null;
    public $queryBuilderService = null;

    public function __construct(OpenSearchQueryBuilderService $queryBuilderService, OpenSearchService $service, OpenSearchFileContentService $fileContentService, OpenSearchProxyService $proxyService)
    {
        $this->service = $service;
        $this->proxyService = $proxyService;
        $this->fileContentService = $fileContentService;
        $this->queryBuilderService = $queryBuilderService;
    }
}
