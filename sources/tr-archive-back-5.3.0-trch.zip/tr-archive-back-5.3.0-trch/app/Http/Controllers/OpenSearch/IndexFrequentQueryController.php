<?php

namespace App\Http\Controllers\OpenSearch;

use App\Models\System\SystemParam;
use Illuminate\Http\Request;

class IndexFrequentQueryController extends BaseController
{
    public function __invoke(Request $request)
    {
        $prefixOik = config('opensearch.prefix_index');
        $index = $prefixOik.'_'.SystemParam::where('code', 'identificator_app')->pluck('value')->first().'_popular_query';
        return $this->service->getFrequentQuery($index, $request->getContent());
    }
}