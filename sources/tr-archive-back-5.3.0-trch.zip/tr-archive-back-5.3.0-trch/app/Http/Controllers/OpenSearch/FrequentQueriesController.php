<?php

namespace App\Http\Controllers\OpenSearch;

use Illuminate\Http\Request;
use App\Models\System\SystemParam;
use App\Http\Controllers\Controller;
use App\Services\OpenSearch\OpenSearchProxyService;

class FrequentQueriesController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $prefixOik = config('opensearch.prefix_index');
        $proxyService = new OpenSearchProxyService();
        $index = $prefixOik . '_' . SystemParam::where('code', 'identificator_app')->pluck('value')->first() . '_query';
        return $proxyService->frequentQueries($index, $request);
    }
}
