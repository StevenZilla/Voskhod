<?php

namespace App\Http\Controllers\Archives;

use App\Http\Controllers\Controller;
use App\Http\Requests\Archive\StoreArchiveRequest;
use App\Models\HandBooks\Archive;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class StoreController extends Controller
{
    public function __invoke(StoreArchiveRequest $request)
    {
        $data = $request->validated();
        try {
            $createdArchive = DB::transaction(function () use ($request, $data) {
                $archive = new Archive();
                $archive['name'] = $data['full_name'];
                $archive['short_name'] = $data['value'];
                $archive['description'] = $data['descr'] ?? null;
                $archive['code'] = $data['code'];
                $archive['email'] = $data['email'] ?? null;
                $archive['address'] = $data['address'] ?? null;
                $archive['head'] = $data['head'] ?? null;
                $archive['head_phone'] = $data['head_phone'] ?? null;
                $archive['actual_date'] = Carbon::now()->toDateString();
                $archive['is_actual'] = true;
                $archive->save();

                return $archive->id;
            });
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => 'Дублируются данные архивов'], 400);
        }

        return response()->json(['code' => 201, 'message' => $createdArchive], 201);
    }
}
