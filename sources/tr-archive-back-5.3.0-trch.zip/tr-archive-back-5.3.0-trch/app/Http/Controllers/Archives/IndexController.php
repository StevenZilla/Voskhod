<?php

namespace App\Http\Controllers\Archives;

use App\Http\Controllers\Controller;
use App\Http\Requests\Archive\IndexArchiveRequest;
use App\Models\HandBooks\Archive;

class IndexController extends Controller
{
    public function __invoke(IndexArchiveRequest $request)
    {
        return $archives = Archive::withFilters($request)
            ->withOrderDefault($request)
            ->withOrder($request)
            ->withPaginate($request);
    }
}
