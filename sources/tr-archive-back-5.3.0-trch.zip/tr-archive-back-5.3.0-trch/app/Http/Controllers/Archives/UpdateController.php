<?php

namespace App\Http\Controllers\Archives;

use App\Http\Controllers\Controller;
use App\Http\Requests\Archive\UpdateArchiveRequest;
use App\Models\HandBooks\Archive;
use Carbon\Carbon;

class UpdateController extends Controller
{
    public function __invoke(int $id, UpdateArchiveRequest $request)
    {
        $data = $request->validated();
        try {
            $archive = Archive::findOrFail($id);
        } catch (\Exception $e) {
            return  response(['code' => '404', 'message' => 'Архив не найден'], 404);
        }
        $newData['name'] = $data['full_name'];
        $newData['short_name'] = $data['value'];
        $newData['description'] = $data['descr'] ?? null;
        $newData['code'] = $data['code'];
        $newData['email'] = $data['email'] ?? null;
        $newData['address'] = $data['address'] ?? null;
        $newData['head'] = $data['head'] ?? null;
        $newData['head_phone'] = $data['head_phone'] ?? null;
        $newData['actual_date'] = Carbon::now()->toDateString();
        $newData['is_actual'] = true;
        $archive->update($newData);
        return response(null, 204);
    }
}
