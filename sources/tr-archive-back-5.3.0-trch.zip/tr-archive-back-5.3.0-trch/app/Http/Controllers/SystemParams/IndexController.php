<?php

namespace App\Http\Controllers\SystemParams;

use App\Http\Controllers\Controller;
use App\Http\Resources\SystemParams\IndexResource;
use App\Models\System\SystemCategory;
use Illuminate\Http\Request;

class IndexController extends Controller
{
	public function __invoke(Request $request)
	{
		$params = SystemCategory::with('system_params')->get();
		return new IndexResource($params);
	}

}
