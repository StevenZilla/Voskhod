<?php

namespace App\Http\Controllers\SystemParams;

use stdClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\SystemParams\BaseController;

class UpdateController extends BaseController
{
    public function __invoke(int $id, Request $request)
    {
        $systemParam = $this->validateService->validate($id, $request);
        $data = $request->all();
        $param = new stdClass();
        $param->data = $data;
        $param->value = $data['value'];
        $param->code = $systemParam->code;
        $param->systemParam = $systemParam;

        DB::transaction(function () use ($param) {
            $beforeFunction = "" . $param->code . "BeforeUpdate";
            if (method_exists($this->service, $beforeFunction)) {
                $param = call_user_func([$this->service, $beforeFunction], $param);
            } else {
                $param = call_user_func([$this->service, "SystemParamBeforeUpdate"], $param);
            }

            $updateFunction = "" . $param->code . "Update";
            if (method_exists($this->service, $updateFunction)) {
                $param = call_user_func([$this->service, $updateFunction], $param);
            } else {
                $param = call_user_func([$this->service, "SystemParamUpdate"], $param);
            }

            $afterFunction = "" . $param->code . "AfterUpdate";
            if (method_exists($this->service, $afterFunction)) {
                $param = call_user_func([$this->service, $afterFunction], $param);
            } else {
                $param = call_user_func([$this->service, "SystemParamAfterUpdate"], $param);
            }
        });

        if (!empty($param->response)) {
            return $param->response;
        } else {
            return response(['code' => 500, 'message' => 'Произошла ошибка при обновлении данных'], 500);
        }
    }
}
