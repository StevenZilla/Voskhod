<?php
namespace App\Http\Controllers\SystemParams;





use App\Http\Controllers\Controller;
use App\Services\SystemParams\SystemParamsService;
use App\Services\SystemParams\SystemParamValidationService;

class BaseController extends Controller
{
    public $service = null;
    public $validateService = null;

    public function __construct(SystemParamsService $service, SystemParamValidationService $validateService)
    {
        $this->service = $service;
        $this->validateService = $validateService;
    }
}
