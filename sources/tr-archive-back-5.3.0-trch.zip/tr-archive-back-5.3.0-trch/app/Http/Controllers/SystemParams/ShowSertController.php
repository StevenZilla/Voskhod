<?php

namespace App\Http\Controllers\SystemParams;

use App\Models\Sert\Sert;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\System\SystemParam;
use App\Http\Controllers\Controller;
use App\Http\Resources\SystemParams\ShowSertResource;

class ShowSertController extends Controller
{
    public function __invoke(Request $request)
    {
        $typeSkzi = SystemParam::getSkziType();
        $serts = Sert::with('mchd')->Filters($request)
        ->where('start_date', '<=', Carbon::now())
        ->where('end_date', '>=', Carbon::now())
        ->whereNotNull('user_id')
        ->where('skzi_id',$typeSkzi)
        ->where('is_active',true)
        ->orders($request)
        ->get();
        return response(['signs'=>ShowSertResource::collection($serts)],200);
    }
}
