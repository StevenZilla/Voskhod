<?php

namespace App\Http\Controllers;

use App\Http\Requests\Upload\UploadStoreRequest;
use App\Jobs\Upload\UploadNomenclatureJob;
use App\Models\Upload\Upload;
use App\Models\Upload\UploadStatus;
use App\Services\FilesystemManager\MediaStorage;
use Illuminate\Support\Facades\DB;

class UploadController extends Controller
{
    /**
     * @param UploadStoreRequest $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function store(UploadStoreRequest $request)
    {
        try {
            $responseIds = DB::transaction(function () use ($request) {
                $responseIds = [];
                if (! empty($request->type)) {
                    $status = UploadStatus::where('code', 'new')->pluck('id')->first();
                    foreach ($request->allFiles()['files'] as $file) {
                        $uploadModel = new Upload();
                        $uploadModel->status_id = $status;
                        $uploadModel->type = $request->type;
                        $uploadModel->save();

                        $storage = MediaStorage::disk();
                        $dataFile = $storage->saveFileWithRequest($uploadModel, $file, $request->type);

                        $uploadModel->file = $dataFile['pathToFile'];
                        $uploadModel->save();

                        $responseIds[] = $uploadModel->id;

                        if ($request->type == 'nomenclature') {
                            UploadNomenclatureJob::dispatch($uploadModel)->onQueue('upload_nomenclature_job');
                        }
                    }
                }

                return $responseIds;
            });

            if (count($responseIds) > 0) {
                return response()->json(['code' => 202, 'message' => $responseIds], 202);
            }
        } catch (\Exception $e) {
            return response()->json(['code' => 400, 'message' => 'Не смогли загрузить номенклатуру из СЭД'], 400);
        }
    }

    public function index()
    {
        return ['upload' => Upload::get()];
    }

    public function show(int $id)
    {
        return Upload::findOrFail($id)->getStatus();
    }
}
