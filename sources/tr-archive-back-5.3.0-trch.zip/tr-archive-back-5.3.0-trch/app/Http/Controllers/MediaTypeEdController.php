<?php

namespace App\Http\Controllers;

use App\Models\HandBooks\MediaTypeED;

class MediaTypeEdController extends Controller
{
    public function index()
    {
        return MediaTypeEd::get();
    }
}
