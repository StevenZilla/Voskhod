<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\User\IndexResource;
use App\Http\Resources\User\IndexWithPaginateResource;
use App\Http\Resources\User\UserResource;
use App\Models\User\User;
use Illuminate\Http\Request;

class IndexController extends Controller
{

    public function __invoke(Request $request)
    {
        if ($request->has('all') && $request->get('all') != 'false') {
            $users = User::filters($request)
                ->orderDefault($request, 'fio', 'asc', 'collate "C"')
                ->orders($request)->get();
            return new IndexResource($users);
        } else {
            $users = User::filters($request)
                ->orderDefault($request, 'fio', 'asc', 'collate "C"')
                ->orders($request)->autoPaginate($request);
            return new IndexWithPaginateResource($users);
        }
    }
}
