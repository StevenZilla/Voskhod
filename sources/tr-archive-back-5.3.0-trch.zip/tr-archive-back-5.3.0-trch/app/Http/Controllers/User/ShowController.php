<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\User\ShowResource;
use App\Models\User\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowController extends Controller
{
    /**
     * @param int $id
     * @return ShowResource
     */
    public function __invoke(int $id)
    {
        try {
            $user = User::with(
                'userRole',
                'userRole.systemRole',
                'serts',
                'serts.sertOneUse',
                'serts.sertOneUse.use',
                'serts.mchd',
            )->findOrFail($id);

            return new ShowResource($user);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Пользователя с переданным id ' . $id . ' не существует');
        }
    }
}
