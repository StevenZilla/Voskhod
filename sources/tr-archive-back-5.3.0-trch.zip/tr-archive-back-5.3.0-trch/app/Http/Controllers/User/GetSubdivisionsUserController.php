<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\GetSubdivisionsUserRequest;
use App\Http\Resources\User\GetSubdivisionsUserResource;
use App\Models\Subdivisions\Subdivisions;
use Carbon\Carbon;

class GetSubdivisionsUserController extends Controller
{
    public function __invoke(GetSubdivisionsUserRequest $request, $id)
    {
        $now = Carbon::now();
        $subdivisions = Subdivisions::join('user_in_subdivision', 'subdivision.id', '=', 'user_in_subdivision.subdivision_id')
            ->join('user', 'user_in_subdivision.user_id', '=', 'user.id')
            ->where('user.id', '=', $id)
            ->where('user_in_subdivision.start_date', '<', $now)
            ->where('user_in_subdivision.end_date', '>', $now)
            ->whereNull('user_in_subdivision.deleted_at')
            ->filters($request)
            ->orderDefault($request, 'order', 'asc')
            ->orders($request)
            ->select("subdivision.*", "user_in_subdivision.*", "subdivision.id as sub_id")
            ->get([]);

        if ($subdivisions->isEmpty()) return response()->json(['subdivisions' => []], 200);

        return new GetSubdivisionsUserResource($subdivisions);
    }

}