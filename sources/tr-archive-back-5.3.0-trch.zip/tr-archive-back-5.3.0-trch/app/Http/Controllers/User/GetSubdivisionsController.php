<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\User\GetSubdivisionsResource;
use App\Models\Subdivisions\Subdivisions;

class GetSubdivisionsController extends Controller
{
    public function __invoke()
    {
        $subdivisions = Subdivisions::permissions()
            ->where('is_org', false)
            ->get();

        return new GetSubdivisionsResource($subdivisions);
    }

}