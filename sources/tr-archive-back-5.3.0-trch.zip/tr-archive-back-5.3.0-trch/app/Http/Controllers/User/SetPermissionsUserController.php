<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Permissions\SetPermissionOnUser;
use App\Models\Permission\Permission as PermissionModel;
use App\Models\Permission\RoutePermission;
use App\Models\User\User;
use Illuminate\Http\Request;

class SetPermissionsUserController extends Controller
{
    /**
     * @param SetPermissionOnUser $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(SetPermissionOnUser $request, $id)
    {
        if (! empty($request->permissions) && count($request->permissions) > 0) {
            if (User::where('id', $id)->where('is_superuser', true)->exists()) {
                return response()->json([
                    'code' => 400,
                    'message' => 'Нельзя пользователю установить права, потому что пользователь является супер-юзером.',
                ], 400);
            }

            $userLogin = User::where('id', $id)->pluck('login')->first();
            foreach ($request->permissions as $permission) {
                $route = RoutePermission::where('name', $permission)->pluck('route')->first();
                PermissionModel::addPolicy($userLogin, $route, $permission, 'true');
            }
        }

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }
}
