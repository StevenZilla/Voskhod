<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Permission\ActionPermission;
use App\Models\Permission\Permission as PermissionModel;
use App\Models\Permission\RoutePermission;
use App\Models\User\User;
use Illuminate\Http\Request;

class DeletePermissionUserController extends Controller
{
    public function __invoke($id, $techName)
    {
        if (! ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        if (! User::where('id', $id)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Пользователь отсутствует в системе.',
            ], 400);
        }

        if (User::where('id', $id)->where('is_superuser', true)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Нельзя пользователю удалить права доступа, потому что пользователь является супер-юзером.',
            ], 400);
        }

        $userLogin = User::where('id', $id)->pluck('login')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::deletePolicy($userLogin, $route, $techName);

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }
}
