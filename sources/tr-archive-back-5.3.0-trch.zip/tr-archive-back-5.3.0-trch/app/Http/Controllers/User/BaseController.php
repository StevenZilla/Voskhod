<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\User\UserUpdateService;
use App\Services\User\UserUpdateValidateService;

class BaseController extends Controller
{
    public $updateService = null;
    public $validateService = null;
    public function __construct(UserUpdateService $updateService, UserUpdateValidateService $validateService)
    {
        $this->updateService = $updateService;
        $this->validateService = $validateService;
    }
}
