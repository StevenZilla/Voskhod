<?php

namespace App\Http\Controllers\User;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpdateSubdivisionUserRequest;
use App\Models\Subdivisions\UserInSubdivision;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UpdateSubdivisionUserController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param UpdateSubdivisionUserRequest $request
     * @param $id
     * @param $subdivision_id
     * @return JsonResponse
     */
    public function __invoke(UpdateSubdivisionUserRequest $request, $id, $subdivision_id)
    {
        try {
            DB::transaction(
                function () use ($request, $id, $subdivision_id) {
                    $user_in_subdivision = UserInSubdivision::where('user_id', '=', $id)
                        ->where('subdivision_id', '=', $subdivision_id)
                        ->first();
                    if (!$user_in_subdivision) {
                        throw new BaseException('Нет записи о данном пользователе в данной организации');
                    }

                    if ($request->has('start_date'))
                        $startDate = Carbon::parse($request->get('start_date'))->format('Y-m-d');
                    else
                        $startDate = Carbon::now()->setTime(0, 0);

                    if ($request->has('end_date'))
                        $endDate = Carbon::parse($request->get('end_date'))->format('Y-m-d');
                    else
                        $endDate = Carbon::now()->addYears(100)->setTime(0, 0);

                    if ($startDate < Carbon::now()->format('Y-m-d')) {
                        throw new BaseException('Дата начала действия не может быть меньше текущего дня');
                    }

                    if ($endDate < $startDate) {
                        throw new BaseException('Дата окончания действия не может быть меньше даты начала');
                    }

                    $user_in_subdivision->start_date = $startDate;
                    $user_in_subdivision->end_date = $endDate;
                    $user_in_subdivision->save();
                }
            );
        } catch (Exception $e) {
            if ($e instanceof BaseException) {
                $msg = 'Произошла ошибка при редактировании пользователю подразделения: ' . $e->getMessage();
                $status = 500;
            } else {
                $msg = 'Неизвестная ошибка: ' . $e->getMessage();
                $status = 400;
            }

            Log::error($msg);
            return response()->json(['code' => $status, 'message' => $msg], $status);
        }

        Log::info('Редактирование пользователю подразделения прошло успешно');
        return response()->json(['code' => 202, 'message' => 'ok'], 202);
    }
}
