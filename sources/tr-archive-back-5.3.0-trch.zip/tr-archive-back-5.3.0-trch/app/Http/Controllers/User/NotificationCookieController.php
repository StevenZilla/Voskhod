<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\Notification\NotificationService;
use App\Http\Resources\User\GetInfoCurrentUserResource;

class NotificationCookieController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        try {
            $cookie = NotificationService::generateEncryptNotificationCookie();

            $cookieKey = env('NOTIFICATION_COOKIE_NAME', 'uc_notification');
            \Cookie::queue(\Cookie::make($cookieKey, $cookie, env('SESSION_LIFETIME')));
            return response(null, 204);
        } catch (BaseException $e) {
            Log::warning('Не получилось получить информацию текущего пользователя или сгенерировать данные');
            return response()->json(['code' => 400, 'message' => 'Произошла ошибка. Не получилось получить информацию текущего пользователя или сгенерировать данные'], 400);
        }
    }
}
