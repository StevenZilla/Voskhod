<?php

namespace App\Http\Controllers\User;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\AssignSubdivisionRequest;
use App\Models\Subdivisions\Subdivisions;
use App\Models\Subdivisions\UserInSubdivision;
use App\Models\User\User;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AssignSubdivisionController extends Controller
{
    public function __invoke(AssignSubdivisionRequest $request, $id)
    {
        try {
            $user = User::find($id);
            if ($user->is_superuser) {
                throw new BaseException('Пользователь является супер-юзером, мы не можем назначить ему подразделения.');
            }

            $userInSubdivisionId = DB::transaction(function () use ($id, $request, $user) {
                if ($request->has('start_date'))
                    $startDate = Carbon::parse($request->get('start_date'))->format('Y-m-d');
                else
                    $startDate = Carbon::now()->setTime(0, 0);

                if ($request->has('end_date'))
                    $endDate = Carbon::parse($request->get('end_date'))->format('Y-m-d');
                else
                    $endDate = Carbon::now()->addYears(100)->setTime(0, 0);

                if ($startDate < Carbon::now()->format('Y-m-d')) {
                    throw new BaseException('Дата начала действия не может быть меньше текущего дня');
                }

                if ($endDate < $startDate) {
                    throw new BaseException('Дата окончания действия не может быть меньше даты начала');
                }

                $subdivision = Subdivisions::find($request->get('subdivision_id'));

                $isSubdivisionActive = $user
                    ->subdivisions()
                    ->where('subdivision.id', '=', $subdivision->id)
                    ->where('user_in_subdivision.end_date', '>=', Carbon::now())
                    ->where('user_in_subdivision.start_date', '<=', Carbon::now())
                    ->get();
                if (!$isSubdivisionActive->isEmpty()) {
                    throw new BaseException('Добавляемое подразделение уже есть у пользователя и оно активно');
                }

                // удаляем связи с подразделениями, если добавляем организацию.
                // удаляем связь с организацией, если добавляем подразделение
                $subdivisionsToDelete = $user->subdivisions()->where('is_org', !$subdivision->is_org)->pluck('subdivision.id');
                UserInSubdivision::where('user_id', '=', $user->id)
                    ->whereIn('subdivision_id', $subdivisionsToDelete)
                    ->delete();

                return UserInSubdivision::create([
                    'user_id' => $user->id,
                    'subdivision_id' => $subdivision->id,
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                ]);
            });
        } catch (Exception $e) {
            if ($e instanceof BaseException) {
                $msg = 'Произошла ошибка при назначении пользователю подразделения: '. $e->getMessage();
                $status = 500;

                Log::alert('Ошибка при назначении пользователю подразделения');
                return response()->json(['code' => $status, 'message' => $msg], $status);
            }
            return response()->json(['code' => 400, 'message' => 'Неизвестная ошибка'], 400);
        }

        return response()->json(['code' => 201, 'message' => $userInSubdivisionId], 201);
    }
}