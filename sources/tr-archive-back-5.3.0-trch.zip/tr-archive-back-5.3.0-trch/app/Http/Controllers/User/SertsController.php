<?php

namespace App\Http\Controllers\User;

use App\Models\User\User;
use App\Exceptions\BaseException;
use App\Http\Controllers\User\BaseController;
use App\Http\Requests\User\UpdateSertsRequest;

class SertsController extends BaseController
{
    public function __invoke($id, UpdateSertsRequest $request)
    {
        $data = $request->validated();
        try {
            $user = User::findOrFail($id);
        } catch (\Exception $e) {
            throw new BaseException("Ошибка. Пользователь с идентификатором {$id} не найден в системе");
        }
        $serts = $data['serts'];
        $this->validateService->validateUpdateSerts($id, $serts);
        $this->updateService->sertsUpdate($user, $serts);
        return response(null, 204);
    }
}
