<?php

namespace App\Http\Controllers\User;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Resources\User\GetInfoCurrentUserResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GetInfoCurrentUserController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke()
    {
        try {
            $authUser = Auth::user();
            $currentUser = new GetInfoCurrentUserResource($authUser);
            return response($currentUser,200);

        } catch (BaseException $e) {
            Log::warning('Не получилось получить информацию текущего пользователя');

            return response()->json(['code' => 400, 'message' => 'Произошла ошибка. Не получилось получить информацию текущего пользователя '.$e->getMessage()], 400);
        }
    }
}
