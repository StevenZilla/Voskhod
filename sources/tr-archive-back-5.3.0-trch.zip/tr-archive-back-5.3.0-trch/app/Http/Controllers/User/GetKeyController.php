<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GetKeyController extends Controller
{

    public function __invoke()
    {
        var_dump(env('NOTIFICATION_KEY'));
    }
}
