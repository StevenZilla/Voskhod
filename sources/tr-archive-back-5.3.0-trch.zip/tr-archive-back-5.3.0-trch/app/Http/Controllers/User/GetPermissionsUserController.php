<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\User\Permission\PermissionCategoryResource;
use App\Models\Permission\Permission;
use App\Models\PermissionCategory;
use Illuminate\Http\Request;

class GetPermissionsUserController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id)
    {
        return  PermissionCategoryResource::collection(PermissionCategory::get())->collection;
    }
}
