<?php

namespace App\Http\Controllers\User;

use App\Models\User\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Resources\User\ShowUserSertsResource;
use Illuminate\Support\Facades\Auth;

class ShowUserSertsController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $user = Auth()->user();
        $serts = $user->serts()->with('mchd', 'sertUse', 'sertOneUse')->Filters($request)->where('start_date', '<=', Carbon::now())->where('end_date', '>=', Carbon::now())->where('is_active', true) ->orderBy('sert.cn', 'asc')->get();
        $serts = ShowUserSertsResource::collection($serts);
        return response(['serts' => $serts], 200);
    }
}
