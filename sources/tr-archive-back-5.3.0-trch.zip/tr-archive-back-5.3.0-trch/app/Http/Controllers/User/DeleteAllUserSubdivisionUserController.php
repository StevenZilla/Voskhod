<?php

namespace App\Http\Controllers\User;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Models\Subdivisions\UserInSubdivision;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DeleteAllUserSubdivisionUserController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param \Request $request
     * @param $id
     * @param $subdivision_id
     * @return JsonResponse
     */
    public function __invoke(\Request $request, $id)
    {
        try {
            DB::transaction(function () use ($request, $id) {
                UserInSubdivision::where('user_id', '=', $id)
                    ->delete();
            }
            );
        } catch (\Exception $e) {
            if ($e instanceof BaseException) {
                $msg = 'Произошла ошибка при удалении пользователю всех подразделений: ' . $e->getMessage();
                $status = 500;
            } else {
                $msg = 'Неизвестная ошибка: ' . $e->getMessage();
                $status = 400;
            }

            Log::error($msg);
            return response()->json(['code' => $status, 'message' => $msg], $status);
        }

        Log::info('Удаление пользователю всех подразделений прошло успешно');
        return response()->json(['code' => 204, 'message' => 'ok'], 204);
    }
}
