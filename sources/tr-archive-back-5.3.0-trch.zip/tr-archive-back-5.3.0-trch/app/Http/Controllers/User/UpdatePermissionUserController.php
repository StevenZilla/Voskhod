<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Permissions\UpdatePermissionOnUser;
use App\Models\Permission\ActionPermission;
use App\Models\Permission\Permission as PermissionModel;
use App\Models\Permission\RoutePermission;
use App\Models\User\User;

class UpdatePermissionUserController extends Controller
{
    /**
     * @param UpdatePermissionOnUser $request
     * @param $id
     * @param $techName
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(UpdatePermissionOnUser $request, $id, $techName)
    {
        if (!ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        if (!User::where('id', $id)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Пользователь отсутствует в системе.',
            ], 400);
        }

        if (User::where('id', $id)->where('is_superuser', true)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Нельзя пользователю обновить права, потому что пользователь является супер-юзером.',
            ], 400);
        }

        $userLogin = User::where('id', $id)->pluck('login')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::addPolicy($userLogin, $route, $techName, $request->rule, 'user');

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }
}
