<?php

namespace App\Http\Controllers\User;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UpdateSubdivisionUserRequest;
use App\Models\Subdivisions\UserInSubdivision;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DeleteSubdivisionUserController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param \Request $request
     * @param $id
     * @param $subdivision_id
     * @return JsonResponse
     */
    public function __invoke(\Request $request, $id, $subdivision_id)
    {
        try {
            DB::transaction(function () use ($request, $id, $subdivision_id) {
                UserInSubdivision::where('user_id', '=', $id)
                    ->where('subdivision_id', '=', $subdivision_id)
                    ->delete();
            }
            );
        } catch (\Exception $e) {
            if ($e instanceof BaseException) {
                $msg = 'Произошла ошибка при удалении пользователю подразделения: ' . $e->getMessage();
                $status = 500;
            } else {
                $msg = 'Неизвестная ошибка: ' . $e->getMessage();
                $status = 400;
            }

            Log::error($msg);
            return response()->json(['code' => $status, 'message' => $msg], $status);
        }

        Log::info('Удаление пользователю подразделения прошло успешно');
        return response()->json(['code' => 204, 'message' => 'ok'], 204);
    }
}