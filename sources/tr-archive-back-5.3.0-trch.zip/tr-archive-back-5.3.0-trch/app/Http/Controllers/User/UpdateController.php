<?php

namespace App\Http\Controllers\User;

use Carbon\Carbon;
use App\Models\Sert\Sert;
use App\Models\User\User;
use App\Models\User\UserRole;
use App\Models\Sert\SertOneUse;
use App\Exceptions\BaseException;
use App\Services\Mchd\MchdService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Services\CheckDate\CheckDate;
use App\Http\Requests\User\UpdateUserRequest;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UpdateController extends Controller
{

    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(UpdateUserRequest $request, $id)
    {
        try {
            DB::transaction(function () use ($id, $request) {
                if ($request->exists('end_date') && $request->exists('start_date')) {
                    $messageCheckDate = CheckDate::checkStartEndDate($request->get('start_date'), $request->get('end_date'));

                    if ($messageCheckDate !== 'true') {
                        $msg = 'При редактировании пользователя проверка даты начала/окончания действия пользователя не прошла. ';
                        throw new BaseException($msg . $messageCheckDate);
                    }
                }

                $user = User::findOrFail($id);
                $user->updatePatch($request, $user);

                if ($request->has('system_roles')) {
                    foreach ($request->get('system_roles') as $key => $system_role) {
                        if (!empty($system_role['start_date']) && !empty($system_role['end_date'])) {
                            $messageCheckDate = CheckDate::checkStartEndDate($system_role['start_date'], $system_role['end_date']);

                            if ($messageCheckDate !== 'true') {
                                $msg = 'При редактировании пользователя проверка даты начала/окончания действия роли пользователя не прошла. ';
                                throw new BaseException($msg . $messageCheckDate);
                            }
                        }

                        if (empty($system_role['end_date'])) {
                            $system_role['end_date'] = Carbon::now()->addYears(100)->toDateTimeString();
                        }

                        if (empty($system_role['start_date'])) {
                            $system_role['start_date'] = Carbon::now()->toDateTimeString();
                        }

                        if (!empty($system_role['id'])) {
                            $user_role = UserRole::findOrFail($system_role['id']);

                            if (!($user_role->checkChangesSystemRole($system_role['role_id']))) {
                                throw new BaseException('Нельзя изменить идентификатор системной роли у системной роли пользователя. Ошибка в \'system_roles.' . $key . '\'');
                            }

                            if (!($user_role->checkUserID($user->id))) {
                                throw new BaseException('Системной роли пользователя отличается пользователь, которого мы редактируем');
                            }

                            if (!($user_role->updateUserRole($system_role))) {
                                throw new BaseException('Системная роль пользователя(id = ' . $system_role['id'] . ') не обновилась.');
                            }
                        } else {
                            $user_role = new UserRole();

                            if (!($user_role->storeUserRole($user->id, $system_role))) {
                                throw new BaseException('Системная роль пользователя не создалась. Ошибка в \'system_roles.' . $key . '\'');
                            }
                        }

                        $not_delete_user_role[] = $user_role->id;
                    }
                }

                $arr = $request->all();

                if ($request->has('serts')) {
                    foreach ($request->get('serts') as $key => $sert_val) {
                        SertOneUse::where('sert_id', '=', $sert_val['id'])->delete();

                        try {
                            $sert = Sert::findOrFail($sert_val['id']);
                        } catch (ModelNotFoundException $e) {
                            throw new ModelNotFoundException('Сертификата с переданным id ' . $sert_val['id'] . ' не существует');
                        }

                        if (!($sert->sertChangesThumbprint($sert_val, $user->id))) {
                            throw new BaseException('Системная роль пользователя(id = ' . $sert_val['id'] . ') не обновилась.');
                        }

                        $not_delete_sert[] = $sert->id;

                        if (!empty($sert_val['use'])) {
                            foreach ($sert_val['use'] as $key_use => $use) {
                                if (false) { // Временная реализация, пока не подтянется клиент
                                    $sert_one_use = SertOneUse::findOrFail($use['id']);

                                    if (!($sert_one_use->updateSertOneUse($sert->id, $use))) {
                                        throw new BaseException('Идентификатор одного назначения сертификата(id = ' . $use['id'] . ') не обновился');
                                    }
                                } else {
                                    $sert_one_use = new SertOneUse();

                                    if (!SertOneUse::where('sert_id', $sert->id)->where('sert_use_id', $use['use_id'])->exists()) {
                                        if (!($sert_one_use->storeSertOneUse($sert->id, $use))) {
                                            throw new BaseException('Идентификатор одного назначения сертификата не создался. Ошибка в \'serts.' . $key . '.use' . $key_use . '\'');
                                        }
                                    }
                                }

                                $not_delete_sert_use[] = $sert_one_use->id;
                            }
                        }

                        $sert = $sert->fresh();
                        if (isset($sert_val['mchd'])) {
                            MchdService::create($sert_val['mchd'], $sert);
                        }

                        SertOneUse::where('sert_id', $sert->id)->whereNotIn('sert_one_use.id', $not_delete_sert_use ?? [])
                            ->delete();
                    }
                }
            });
        } catch (\Exception $e) {
            if (str_contains($e->getMessage(), 'No query results for model [App\Models\User]')) {
                $msg = 'Такого пользователя не существует';
                $status = 400;

                Log::alert('Ошибка при редактировании пользователя, такого пользователя не существует');
            } elseif (str_contains($e->getMessage(), 'duplicate key value violates unique constraint "mchd_num_sert_id_unique"')) {
                $msg = 'МЧД с таким номер доверенности и идентификатором сертификата уже существует';
                $status = 400;

                Log::alert('Ошибка при редактировании пользователя, МЧД с таким номер доверенности и идентификатором сертификата уже существует');
            }  elseif (str_contains($e->getMessage(), 'user_email_unique')) {
                $msg = 'Невозможно отредактировать пользователя, поле email не уникальное в системе';
                $status = 400;

                Log::alert('Ошибка при редактировании пользователя, МЧД с таким номер доверенности и идентификатором сертификата уже существует');
            } else {
                $msg = 'Произошла ошибка при редактировании пользователя: ' . $e->getMessage();
                $status = 500;

                Log::warning('Ошибка при редактировании пользователя');
            }

            return response()->json(['code' => $status, 'message' => $msg], $status);
        }

        return response()->json(['code' => 201, 'message' => $id], 201);
    }
}
