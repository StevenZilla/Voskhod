<?php

namespace App\Http\Controllers\User\V2;

use App\Models\User\User;
use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use App\Http\Controllers\User\BaseController;

class UpdateController extends BaseController
{
    //TODO Рефакторинг обновления сущности пользователя. Продумать архитектуру (изменить с patch на put запрос, разделить на отдельные эндпоинты (назначение сертификатов (готово), добавление роли пользователю, добавление подразделений(не помню, возможно готово), добавление прав доступа(готово)))
    public function __invoke($id, Request $request)
    {
        try {
            $user = User::findOrFail($id);
        } catch (\Exception $e) {
            throw new BaseException("Ошибка. Пользователь с идентификатором {$id} не найден в системе");
        }
    }
}
