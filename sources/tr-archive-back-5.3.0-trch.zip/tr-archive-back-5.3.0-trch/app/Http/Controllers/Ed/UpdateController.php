<?php

namespace App\Http\Controllers\Ed;

use App\Services\Ed\CheckRequiredEd;
use Carbon\Carbon;
use App\Models\Ed\Ed;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\Ed\EdUpdatePatchRequest;
use App\Services\SetTempSavePeriod\SetTempSavePeriod;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UpdateController extends BaseController
{
    /**
     * @param EdUpdatePatchRequest $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(EdUpdatePatchRequest $request, $id)
    {
        try {
            $document = Ed::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('ЭД с переданным id ' . $id . ' не существует');
        }

        if (!empty($request->getContent())) {
            $data = json_decode($request->getContent(), true);
            $validator = Validator::make($data, $request->rules());
            if ($validator->fails()) {
                return response()->json(['code' => 400, 'message' => $validator->errors()], 400);
            }
            if (!empty($data['ed_status_id']) && $data['ed_status_id'] === 5 && !$document->checkStatusProcessed()) {
                return response()->json(['code' => 412, 'message' => 'Не возможно установить статус \'Обработано\', у ЭД отсутствует источник или дело'], 412);
            }

            $data['update_date'] = Carbon::now()->toDateTimeString();
            DB::transaction(function () use ($document, $data) {
                $document->update($data);

                $dossier = !empty($data['dossier_id']) ? $data['dossier_id'] : null;
                CheckRequiredEd::checkRequiredEd($document, $dossier);

                SetTempSavePeriod::setTempSavePeriodEd($document);
            });
        }

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }
}
