<?php

namespace App\Http\Controllers\Ed;

use App\Models\Ed\Ed;
use App\Models\Tk\TkStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Ed\IndexResource;
use App\Services\ConstantDataHelper\ConstantDataHelper;

class IndexController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request)
    {
        $eds = Ed::with(
            'tempSaveTypeId',
            'source',
            'lastTk',
            'lastTk.status',
            'lastAk',
            'lastAk.status',
            'edStatus',
            'saveType',
            'getMediaType',
            'subdivision',
            'dossier',
            'dossier.source',
            'dossier.status',
            'attributeValue',
            'attributeValue.attribute',
            'file',
            'file.role',
            'file.extension',
            'file.rel',
            'file.rel.extension',
            'cipherIsActive'
        )
            ->permissions()
            ->filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($eds);
    }
}
