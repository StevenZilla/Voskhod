<?php

namespace App\Http\Controllers\Ed;

use App\Http\Controllers\Controller;
use App\Services\Ed\EdService;
use App\Services\Ed\EdValidateService;

class BaseController extends Controller
{
    public $service = null;
    public $validationService = null;

    public function __construct(EdService $service, EdValidateService $validationService)
    {
        $this->service = $service;
        $this->validationService = $validationService;
    }
}
