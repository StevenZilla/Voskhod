<?php

namespace App\Http\Controllers\Ed;

use App\Exceptions\BaseException;
use App\Exceptions\CustomJsonException\CustomJsonException;
use App\Exceptions\EdException\EdException;
use App\Http\Requests\Ed\EdStoreRequest;
use App\Http\Requests\Ed\EdVerifyRequest;
use App\Jobs\ConverterFileJob;
use App\Models\Ed\Ed;
use App\Models\Ed\EdStatus;
use App\Models\File\File;
use App\Models\HandBooks\MediaTypeED;
use App\Models\System\SystemParam;
use App\Services\Ed\CheckRequiredEd;
use App\Services\Ed\CreateAttrValueService;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\SetTempSavePeriod\SetTempSavePeriod;
use App\Services\Subdivision\SubdivisionService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Webpatser\Uuid\Uuid;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(EdStoreRequest $request)
    {
        $requestVerify = EdVerifyRequest::capture($request);
        $checkEpFiles = $this->service->verifySignature($requestVerify);

        if (SystemParam::getForbidInvalidEp() && !isset($checkEpFiles['code']) > 0) {
            throw new BaseException('Прием документов с невалидной ЭЦП запрещен.');
        }

        $data = json_decode($request->input('data'), true);

        $data['create_date'] = Carbon::now()->toDateTimeString();

        if (empty($data['media_type_id'])) {
            $data['media_type_id'] = MediaTypeED::where('name', 'Электронный вид')->pluck('id')->first();
        }

        if (empty($data['ed_status_id'])) {
            $data['ed_status_id'] = EdStatus::where('code', 'new')->pluck('id')->first();
        }

        if (isset($data['dossier_id'])) {
            $lastEd = Ed::where('dossier_id', $data['dossier_id'])->orderBy('created_at', 'DESC')->pluck('order_ed_in_dossier')->first() + 1;
            $data['order_ed_in_dossier'] = $lastEd;

            if (!empty($data['subdivision_id'])) {
                if (SubdivisionService::divisionOfEdAndDossierComparison($data['subdivision_id'], $data['dossier_id'])) {
                    throw new BaseException("Не можем привязать дело с идентификатором - {$data['dossier_id']}. Потому что дело имеет другое подразделение.");
                }
            }
        }

        if (!empty($data['subdivision_id'])) {
            SubdivisionService::checkSubdivision($data['subdivision_id']);
        } else {
            $data['subdivision_id'] = SubdivisionService::getSubdivisionForEd();
        }

        $ed = DB::transaction(function () use ($data, $request, $checkEpFiles) {
            $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
            $document = new Ed($data);

            $document->save();
            SetTempSavePeriod::setTempSavePeriodEd($document);
            $files = $request->all()['files_new'] ?? $request->all()['files'];
            $iterations = [];
            if (is_array($files) || is_object($files)) {
                $guid = Uuid::generate()->string;
                foreach ($files as $file) {
                    $isCorrectFile = false;
                    $index = -1;
                    foreach ($data['files'] as $fileInfo) {
                        $index++;
                        if ($fileInfo['file'] === $file->getClientOriginalName()) {
                            $isCorrectFile = true;
                            break;
                        }
                    }
                    if (!$isCorrectFile) {
                        Log::critical("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");
                        break;
                    }

                    if ($file->isValid()) {
                        $dataFile = MediaStorage::saveFileWithRequest($document, $file);
                        $messageError = '';
                        if (!empty($checkEpFiles) && !empty($checkEpFiles['error'])) {
                            foreach ($checkEpFiles['error'] as $epFile) {
                                if ($epFile['file_name'] === $file->getClientOriginalName()) {
                                    $messageError = $epFile['message'];
                                }
                            }
                        }
                        $fileModel = new File([
                            'name' => $dataFile['fileName'],
                            'size' => $file->getSize(), /// 1024 / 1024
                            'role_id' => $data['files'][$index]['fr_id'], // Взять из data
                            'ed_id' => $document->id,
                            'message_error' => $messageError,
                            'path' => $dataFile['pathToFile'],
                        ]);
                        $fileModel->setExtensionId($fileModel->getExtensionByName($fileInfo['file']));
                        $fileModel->save();
                        $curIdFiles[$data['files'][$index]['file']] = $fileModel->id;

                        $parentFileArray[$data['files'][$index]['file']] = $dataFile['fileName'];

                        if ($fileModel->role_id == 1) {
                            $iterations["data_to_array.files.{$index}.fr_id"][] = "Файл {$file->getClientOriginalName()} имеет роль документ.";
                            ConverterFileJob::dispatch($fileModel, $dataFile['pathToFile'], $guidOIK)->onQueue('converter_file_job');
                        }
                    }
                }

                $countFileWithRoleOne = File::where('role_id', 1)->where('ed_id', $document->id)->count();
                if ($countFileWithRoleOne > 1) {
                    if (!empty($iterations) && count($iterations) > 0) {
                        throw new CustomJsonException('Электронных документов с ролью "Документ" больше одного', $iterations, 'EAD');
                    } else {
                        throw new BaseException('Электронных документов с ролью "Документ" больше одного');
                    }
                } elseif ($countFileWithRoleOne < 1) {
                    throw new BaseException('Электронных документов с ролью "Документ" не существует');
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($parentFileArray[$file['parent_file']])) {
                        $listParentNewName[$file['parent_file']] = $parentFileArray[$file['parent_file']];
                    }
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($listParentNewName[$file['parent_file']])) {
                        $parentFile = File::where([
                            'name' => $listParentNewName[$file['parent_file']],
                            'ed_id' => $document->id,
                        ])->get();

                        DB::table($fileModel->getRelTableName())->insert([
                            'f1_id' => $curIdFiles[$file['file']],
                            'f2_id' => $parentFile[0]->id,
                        ]);
                    }
                }
            }

            if (!empty($data['attr'])) {
                foreach ($data['attr'] as $key => $item) {
                    $attrValueService = new CreateAttrValueService();
                    $idAttr[] = $attrValueService->make($item, $document->id);

                    if (end($idAttr) == false) {
                        $error['attr.' . $key] = 'Значение атрибута должно совпадать с выбранным типом';
                    }
                }
                if (!empty($error)) {
                    throw new EdException('Разные типы данных у атрибутов', $error, 'EAD');
                }
            }

            $dossier = !empty($data['dossier_id']) ? $data['dossier_id'] : null;
            CheckRequiredEd::checkRequiredEd($document, $dossier);

            return $document;
        });

        return response()->json(['code' => 201, 'message' => $ed->id], 201);
    }
}
