<?php

namespace App\Http\Controllers\Ed;

use App\Exceptions\BaseException;
use App\Exceptions\CustomJsonException\CustomJsonException;
use App\Exceptions\EdException\EdException;
use App\Http\Controllers\XmlRegisterController;
use App\Http\Requests\Ed\EdEditRequest;
use App\Http\Requests\Ed\EdVerifyRequest;
use App\Jobs\ConverterFileJob;
use App\Models\Attribute\AttributeValue;
use App\Models\Ed\Ed;
use App\Models\Ed\EdStatus;
use App\Models\File\File;
use App\Models\HandBooks\MediaTypeED;
use App\Models\System\SystemParam;
use App\Models\Tk\TkStatus;
use App\Services\Ed\CheckRequiredEd;
use App\Services\Ed\CreateAttrValueService;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\SetTempSavePeriod\SetTempSavePeriod;
use App\Services\Subdivision\SubdivisionService;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FullUpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(EdEditRequest $request, $id)
    {
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;

        $requestVerify = EdVerifyRequest::capture($request);
        $checkEpFiles = $this->service->verifySignature($requestVerify);
        if (SystemParam::getForbidInvalidEp() && !isset($checkEpFiles['code']) > 0) {
            throw new BaseException('Прием документов с невалидной ЭЦП запрещен.');
        }

        try {
            $document = Ed::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('ЭД с переданным id ' . $id . ' не существует');
        }

        if ($document->checkDossierStatus()) {
            return response()->json([
                'code' => 400,
                'message' => 'Документ нельзя редактировать, потому что дело закрыто',
            ], 400);
        }

        if ($document->lastTk()->whereIn('tk_status_id', [
            TkStatus::getIdSentToChKhED(),
            TkStatus::getIdDeliveredToChKhED(),
            TkStatus::getIdAcceptedToChKhED(),
            TkStatus::getIdInProcessingToChKhED(),
        ])->exists()) {
            Log::warning("У документа[{$id}] есть последний ТК со статусом ЦХЭДА");

            return response()->json([
                'code' => 400,
                'message' => 'У документа существует последний ТК со статусом ЦХЭДА',
            ], 400);
        }

        if ($document->registerOnApproval()) {
            Log::warning("У документа[{$id}] существует опись, которая имеет статус \"На утверждении\"");

            return response()->json([
                'code' => 400,
                'message' => 'У документа существует опись, которая имеет статус "На утверждении"',
            ], 400);
        }

        if ($document->registerOnStatusChed()) {
            Log::warning("Временное ограничение! У документа[{$id}] последняя опись со статусом ЦХЭДА");

            return response()->json([
                'code' => 400,
                'message' => 'Временное ограничение! У документа последняя опись со статусом ЦХЭДА',
            ], 400);
        }

        if (!$document->itWoktWithEd()) {
            Log::warning('Редактирование документа не возможно. У документа есть тк со статусом: ' . $document->lastTk->status->name);

            return response()->json([
                'code' => 400,
                'message' => 'Редактирование документа не возможно. У документа есть тк со статусом: ' . $document->lastTk->status->name,
            ], 400);
        }

        $data = json_decode($request->input('data'), true);

        if (empty($data['ed_status_id'])) {
            $data['ed_status_id'] = EdStatus::where('code', 'new')->pluck('id')->first();
        }

        if (!empty($data['dossier_id'])) {
            if (!empty($data['subdivision_id'])) {
                if (SubdivisionService::divisionOfEdAndDossierComparison($data['subdivision_id'], $data['dossier_id'])) {
                    throw new BaseException("Не можем привязать дело с идентификатором - {$data['dossier_id']}. Потому что дело имеет другое подразделение.");
                }
            }
        }

        if (!empty($data['subdivision_id'])) {
            SubdivisionService::checkSubdivision($data['subdivision_id']);
        } else {
            $data['subdivision_id'] = SubdivisionService::getSubdivisionForEd();
        }

        DB::transaction(function () use ($data, $request, $document, $checkEpFiles, $guidOIK) {
            $document->update($data);
            SetTempSavePeriod::setTempSavePeriodEd($document);
            if (!empty($data['attr'])) {
                foreach ($data['attr'] as $key => $item) {
                    $attrValueService = new CreateAttrValueService();
                    $idAttr[] = $attrValueService->make($item, $document->id);

                    if (end($idAttr) == false) {
                        $error['attr.' . $key] = 'Значение атрибута должно совпадать с выбранным типом';
                    }
                }
                if (!empty($error)) {
                    throw new EdException('Разные типы данных у атрибутов', $error, 'EAD');
                }
            }

            if (empty($data['media_type_id'])) {
                $data['media_type_id'] = MediaTypeED::where('name', 'Электронный вид')->pluck('id')->first();
            }

            AttributeValue::where('ed_id', $document->id)->whereNotIn('id', !empty($idAttr) ? $idAttr : [])->delete();

            $checkArray = ['source_id', 'source_ed_id', 'temp_save_period', 'updated_at'];

            if (count(array_diff_key($document->getChanges(), array_flip($checkArray))) > 0) {
                $checkCountUpdateEAD = true;
            }

            if ($edInRegister = $document->lastEdInRegister) {
                $register = $edInRegister->register;

                if (!$register->itWoktWithEd()) {
                    $register->resend_tk = true;
                }

                if ($register->lastAk) {
                    if ($register->lastAk->status->name == 'передан во временное хранилище') {
                        $register->resend_ak = true;
                    }
                }

                if (!empty($register->registerFile) && count($registerFiles = $register->registerFile) > 0) {
                    foreach ($registerFiles as $file) {
                        if ($file->type == 1 && !empty($file->path)) {
                            (new XmlRegisterController($register, $file))->createRegisterDescrXml();
                        } elseif ($file->type == 2) {
                            $file->sign_date = null;
                        }
                    }

                    $register->update_date = Carbon::now()->toDateTimeString();
                }

                $register->save();
            }

            $this->service->checkExistsFileOfRequest($data['files'], $request->all('files')['files']);

            $skipFiles = [];
            if (!empty($data['files'])) {
                $iterations = [];
                if (!empty($request->file('files')) && count($request->file('files')) > 0) {
                    $files = $request->all()['files_new'] ?? $request->all()['files'];
                    if (!empty($files)) {
                        foreach ($files as $file) {
                            $isCorrectFile = false;
                            $index = -1;
                            foreach ($data['files'] as $fileInfo) {
                                $index++;
                                if ($fileInfo['file'] === $file->getClientOriginalName()) {
                                    $isCorrectFile = true;
                                    break;
                                }
                            }

                            if (!$isCorrectFile) {
                                $skipFiles[] = $file->getClientOriginalName();
                                Log::critical("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");

                                throw new BaseException("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");
                                break;
                            }

                            if (!$file->isValid()) {
                                throw new BaseException($file->getClientOriginalName() . ' файл не валидный');
                            }
                        }
                    }
                }

                $path = MediaStorage::getDirectoryModel($document->file()->first('path'), 'path');

                foreach ($data['files'] as $keyFileInfo => $fileInfo) {
                    $checkPossibilityAdding = false;
                    if (!empty($fileInfo['id'])) {
                        try {
                            $fileModel = File::findOrFail($fileInfo['id']);
                        } catch (ModelNotFoundException $e) {
                            throw new ModelNotFoundException('Файла с переданным id ' . $fileInfo['id'] . ' не существует');
                        }
                        $fileModel->role_id = $fileInfo['fr_id']; // Взять из data

                        if ($fileModel->role_id !== $fileInfo['fr_id']) {
                            $checkCountUpdateEAD = true;
                        }

                        $checkPossibilityAdding = true;
                    } else {
                        $checkCountUpdateEAD = true;
                        $fileModel = new File();

                        if (!empty($files)) {
                            foreach ($files as $file) {
                                if ($file->getClientOriginalName() === $fileInfo['file']) {
                                    $checkPossibilityAdding = true;
                                    $dataFile = MediaStorage::saveFileWithRequest($document, $file);
                                    $messageError = '';
                                    if (!empty($checkEpFiles) && !empty($checkEpFiles['error'])) {
                                        foreach ($checkEpFiles['error'] as $epFile) {
                                            if ($epFile['file_name'] === $file->getClientOriginalName()) {
                                                $messageError = $epFile['message'];
                                            }
                                        }
                                    }

                                    $fileModel->name = $dataFile['fileName'];
                                    $fileModel->size = $file->getSize();
                                    $fileModel->role_id = $fileInfo['fr_id']; // Взять из data
                                    $fileModel->ed_id = $document->id;
                                    $fileModel->message_error = $messageError;
                                    $fileModel->path = $dataFile['pathToFile'];

                                    $iterations["data_to_array.files.{$keyFileInfo}.fr_id"][] = "Файл {$file->getClientOriginalName()} имеет роль документ.";
                                }
                            }
                        }
                    }

                    if ($checkPossibilityAdding) {
                        $fileNameArray = explode('.', $fileInfo['file']);
                        $extension = array_pop($fileNameArray);

                        $fileModel->setExtensionId($extension);
                        $fileModel->save();

                        if ($fileModel->role_id == 1 && $fileModel->viewer_path == null) {
                            ConverterFileJob::dispatch($fileModel, $path, $guidOIK)->onQueue('converter_file_job');
                        }

                        $curIdFiles[$fileInfo['file']] = $fileModel->id;

                        $parentFileArray[$fileInfo['file']] = $resultNameFile ?? $fileModel->name;

                        $idFile[] = $fileModel->id;
                    }
                }

                if (isset($idFile)) {
                    $otherFiles = File::where('ed_id', $document->id)->whereNotIn('id', $idFile)->get(['id', 'path', 'viewer_path']);
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($parentFileArray[$file['parent_file']])) {
                        $listParentNewName[$file['parent_file']] = $parentFileArray[$file['parent_file']];
                    }
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($listParentNewName[$file['parent_file']])) {
                        if (!empty($otherFiles)) {
                            $parentFile = File::where([
                                'name' => $listParentNewName[$file['parent_file']],
                                'ed_id' => $document->id,
                            ])->whereNotIn('id', array_keys($otherFiles->getDictionary()))->first();

                            if (empty($curIdFiles[$file['file']])) {
                                throw new BaseException('Файл ' . $file['file'] . ' не приложен');
                            } else {
                                DB::table('file_file')->insert([
                                    'f1_id' => $curIdFiles[$file['file']],
                                    'f2_id' => $parentFile->id,
                                ]);
                            }
                        }
                    } elseif (!empty($file['id'])) {
                        $modelFile = File::where('id', $file['id'])
                            ->where('name', $file['file'])->where('ed_id', $document->id)
                            ->first();

                        if (!empty($modelFile) && !empty($modelFile->rel())) {
                            $modelFile->rel()->detach();
                        }
                    }
                }

                if (!empty($otherFiles)) {
                    foreach ($otherFiles as $otherFile) {
                        if (!empty($otherFile->rel())) {
                            $otherFile->rel()->detach();
                        }

                        $otherFile->delete();
                        $checkCountUpdateEAD = true;
                    }
                }

                $countFileWithRoleOne = File::where('role_id', 1)->where('ed_id', $document->id)->count();
                if ($countFileWithRoleOne > 1) {
                    if (!empty($iterations) && count($iterations) > 0) {
                        throw new CustomJsonException('Электронных документов с ролью "Документ" больше одного', $iterations, 'EAD');
                    } else {
                        throw new BaseException('Электронных документов с ролью "Документ" больше одного');
                    }
                } elseif ($countFileWithRoleOne < 1) {
                    if (!empty($data['files'])) {
                        foreach ($data['files'] as $fileKey => $file) {
                            if ($file['fr_id'] === 1) {
                                throw new EdException('Файл ' . $file['file'] . ' с ролью документ не приложен', ['files.' . $fileKey . 'name' => 'Файл не приложен']);
                            }
                        }
                    }
                    throw new BaseException('Электронных документов с ролью "Документ" не существует');
                }

                if (!empty($otherFiles)) {
                    $deleteFiles = MediaStorage::prefixFiles($otherFiles->pluck('path')->all());
                }

                if (!empty($deleteFiles)) {
                    MediaStorage::delete($deleteFiles);
                }
            }

            $dossier = !empty($data['dossier_id']) ? $data['dossier_id'] : null;
            CheckRequiredEd::checkRequiredEd($document, $dossier);

            if (!empty($checkCountUpdateEAD)) {
                if ($document->lastAk) {
                    $document->resend_ak = true;
                }
                // $document->update_date = Carbon::now()->toDateTimeString();
            }
            $document->update_date = Carbon::now()->toDateTimeString();
            $document->save();
        });

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }
}
