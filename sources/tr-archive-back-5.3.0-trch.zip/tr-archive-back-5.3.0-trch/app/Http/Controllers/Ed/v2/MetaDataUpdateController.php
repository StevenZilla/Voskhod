<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Models\Ed\Ed;
use App\Services\Ed\EadFLK;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MetaDataUpdateController extends BaseController
{
    public function __invoke(Request $request, $id)
    {
        $input = $request->all();
        $this->validationService->updateEdValidate($input, $id);

        DB::transaction(function () use ($input, $id) {
            $flkEad = new EadFLK($input, [], [], $id);
            $ed = $flkEad->flk();
            $ed->save();
            return $ed;
        });

        return response(['code' => 204, 'message' => null], 204);
    }

}