<?php

namespace App\Http\Controllers\Ed\v2;

use App\Exceptions\AuthException\LoginException;
use App\Exceptions\LogicStatus\LogicStatusException;
use Exception;
use App\Models\Ed\Ed;
use App\Models\Ed\EdStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Services\FilesystemManager\MediaStorage;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DestroyController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    private $ed;


    public function __invoke(Request $request, $id)
    {
        try {
            $this->ed = Ed::permissions()->withTrashed()->with('tk', 'file', 'file.fileContent', 'edStatus')->findOrFail($id);
        } catch (Exception $e) {
            $errorMsg = "Ошибка. ЭАД с идентификатором {$id} не существует в системе.";
            Log::channel('ed_destroy')->error($errorMsg);
            throw new LogicStatusException($errorMsg, 'ED', 4404, 404);
        }

        $edStatuses = EdStatus::whereIn('code', ['new', 'draft'])->pluck('id')->all();
        if (!in_array($this->ed->ed_status_id, $edStatuses)) {
            $errorMsg = "Ошибка. ЭАД с идентификатором {$id} имеет статус '{$this->ed->edStatus->name}'. Возможно удалить ЭАД в статусе 'Черновик' или 'Новый'";
            Log::channel('ed_destroy')->error($errorMsg);
            throw new LogicStatusException($errorMsg, 'ED', 4101);
        }

            if ($this->ed->tk->isNotEmpty()) {
            $tk = $this->ed->tk->first();
            $errorMsg = "Ошибка. ЭАД с идентификатором {$id} связана с ТК с идентификатором {$tk->id}. Подлежат удалению ЭАД без связи с ТК";
            Log::channel('ed_destroy')->error($errorMsg);
            throw new LogicStatusException($errorMsg, 'ED', 4102);
        }

        try {
            $this->deleteEd();
            Log::channel('ed_destroy')->info("Успешно удалён ЭАД с идентификатором {$id}.");
            return response()->json([], 204);
        } catch(Exception $e) {
            $errorMsg = "Ошибка. Невозможно удалить ЭАД с идентификатором {$id} ";
            Log::channel('ed_destroy')->error($errorMsg);
            throw new LogicStatusException($errorMsg, 'ED', 4100);
        }

    }

    private function deleteEd()
    {
        DB::transaction(function () {
            $fileModels = $this->ed->file;
            $files = $fileModels->pluck('path')->all();

            foreach($fileModels as $fileModel){
                $fileModel->fileContent()->forceDelete();
            }
            $this->ed->file()->forceDelete();
            $this->ed->forceDelete();

            if (!empty($files)) {
                $this->deleteFiles($files);
            }
        });
    }

    private function deleteFiles(array $deleteFiles)
    {
        $directoryFiles = [];
        foreach ($deleteFiles as $deleteFile) {
            if (MediaStorage::isFile($deleteFile)) {
                $directoryFiles[] = MediaStorage::getDirectoryFile($deleteFile);
                MediaStorage::deletePath($deleteFile);
            } elseif (MediaStorage::isDirectory($deleteFile)) {
                $directoryFiles[] = $deleteFile;
            } else {
                Log::channel('ed_destroy')->info("Удаляем файлы из ЭД и файл отсутствует {$deleteFile} в файловом хранилище.");
            }
        }

        if (!empty($directoryFiles)) {
            $directoryFiles = array_unique($directoryFiles);
            foreach ($directoryFiles as $directoryFile) {
                $files = MediaStorage::getAllOnStorage($directoryFile,false);
                if (count($files) === 0) {
                    MediaStorage::deleteDirectory($directoryFile);
                }
            }
        }
        $realpath = $deleteFiles[0];
        MediaStorage::deleteDirectory(pathinfo($realpath)['dirname']);
    }
}
