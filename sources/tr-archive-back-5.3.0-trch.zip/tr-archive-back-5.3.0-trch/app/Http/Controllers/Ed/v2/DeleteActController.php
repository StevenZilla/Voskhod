<?php

namespace App\Http\Controllers\Ed\v2;

use App\Models\Ed\Ed;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Ed\v2\DeleteActResource;

class DeleteActController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id)
    {
        $ed = Ed::with('deleteAct')->where('id', $id)->first();
        if (!empty($ed)) {
            if (!empty($ed->deleteAct)) {
                return  response(new DeleteActResource($ed->deleteAct), 200);
            }
        }
    }
}
