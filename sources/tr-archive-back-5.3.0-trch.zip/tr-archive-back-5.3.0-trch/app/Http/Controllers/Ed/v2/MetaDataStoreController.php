<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Models\Ed\Ed;
use App\Services\Ed\EadFLK;
use App\Services\Ed\EdValidateService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MetaDataStoreController extends BaseController
{

    public function __invoke(Request $request)
    {
        $input = $request->all();
        $this->validationService->storeEdValidate($input);

        $ed = DB::transaction(function () use ($input) {
            $flkEad = new EadFLK($input);
            $ed = $flkEad->flk();
            $ed->save();
            return $ed;
        });

        return response()->json(['code' => 201, 'message' => $ed->id], 201);
    }

}