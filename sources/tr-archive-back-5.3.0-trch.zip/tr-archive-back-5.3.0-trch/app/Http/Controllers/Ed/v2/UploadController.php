<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Services\Antivirus\AntivirusService;
use App\Services\Ed\EdUploadService;
use Illuminate\Http\Request;

class UploadController extends BaseController
{
    public function __invoke(Request $request, EdUploadService $service)
    {
        $files = $request->allFiles()['files'];
        // AntivirusService::validateAllFiles($files);
        return $service->upload($files);
    }
}
