<?php

namespace App\Http\Controllers\Ed\v2;

use App\Exceptions\PermissionException;
use App\Http\Controllers\Controller;
use App\Http\Resources\Ed\FileV2Resource;
use App\Models\File\File;

class FilesShowController extends Controller
{
    /**
     * @param $id
     * @return array
     * @throws PermissionException
     */
    public function __invoke($id)
    {
        $files = File::permissions()
            ->where('ed_id', $id)
            ->get();

        if (empty($files)) {
            throw new PermissionException('Доступ запрещен');
        }
        return ['files' => FileV2Resource::collection($files)];
    }
}