<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Services\Ed\EadFLK;
use App\Services\Files\FileService;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FileVerifyController extends BaseController
{
    public function __invoke(Request $request)
    {
        $input = $request->all();
        $this->validationService->updateFilesValidate($input);

        try {
            $fileService = new FileService(json_decode($input['data'], true)['files'], $input['files'] ?? []);
            $resultVerifySignature = $fileService->verifySignature();
            $fileService->checkFiles($resultVerifySignature);
            return response('', 204);

        } catch (\Exception $e) {
            if ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                $dataError = json_decode($e->getMessage(), true);
                if (!empty($dataError)) {
                    if (!empty($dataError['code'])) {
                        unset($dataError['code']);
                    }

                    if (!empty($dataError['message'])) {
                        unset($dataError['message']);
                    }

                    if (!empty($dataError['target'])) {
                        unset($dataError['target']);
                    }

                    return response()->json($dataError, 200);
                } else {
                    return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => 'FILE'], 400);
                }
            }
        }
    }

}