<?php

namespace App\Http\Controllers\Ed\v2;

use App\Models\Ed\Ed;
use App\Exceptions\BaseException;
use App\Exceptions\PermissionException;
use App\Http\Controllers\Ed\BaseController;
use App\Http\Resources\Ed\MetaDataShowResource;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class MetaDataShowController extends BaseController
{
    /**
     * @param $id
     * @return MetaDataShowResource
     * @throws PermissionException
     */
    public function __invoke($id)
    {
        try {
        $ed = Ed::permissions()->withTrashed()->with('source', 'dossier', 'dossier.paperInfo')
            ->findOrFail($id);
        }catch (Exception $e) {
            throw new ModelNotFoundException ("Ошибка. ЭАД с идентификатором {$id} не существует в системе.");
        }

        //if ($ed->trashed()) {
          //  $deleteAct = $ed->deleteAct;
            //throw new BaseException("Ошибка. Электронный документ документ был удалён на основании акта об уничтожении № {$deleteAct->num} за {$deleteAct->year} год");
        //}

        if (empty($ed)) {
            throw new PermissionException('Доступ запрещен');
        }
        return new MetaDataShowResource($ed);
    }
}
