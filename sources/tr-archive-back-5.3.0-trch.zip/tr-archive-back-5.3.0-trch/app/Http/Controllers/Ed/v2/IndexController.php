<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Http\Resources\Ed\v2\IndexResource;
use App\Models\Ed\Ed;
use Illuminate\Http\Request;

class IndexController extends BaseController
{
    public function __invoke(Request $request)
    {
        $eds = Ed::with(
            'cipherIsActive',
            'edStatus',
            'getMediaType',
            'subdivision',
            'source',
            'lastTk',
            'lastTk.status',
            )
            ->permissions()
            ->filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($eds);
    }
}