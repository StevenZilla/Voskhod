<?php

namespace App\Http\Controllers\Ed\v2;

use App\Services\Ed\EadFLK;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Ed\BaseController;
use App\Services\Antivirus\AntivirusService;

class FileUpdateController extends BaseController
{
    public function __invoke(Request $request, $id)
    {
        $input = $request->all();

        if (empty($input['files'])) {
            $input['files'] = [];
        }

        $this->validationService->updateFilesValidate($input);
        if (!empty($request->allFiles()['files'])) {
            AntivirusService::validateAllFiles($request->allFiles()['files']);
        }

        try {
            DB::transaction(function () use ($input, $id) {
                $flk = new EadFLK([], json_decode($input['data'], true)['files'], $input['files'], $id);
                $flk->flk()->save();
                $flk->removeFilesEd();
            });
        } catch (\Exception $e) {
            if ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                $data = json_decode($e->getMessage(), true);
                if (!empty($data)) {
                    return response()->json($data, 400);
                } else {
                    return response()->json(['code' => 400, 'message' => $e->getMessage(), 'target' => 'FILE'], 400);
                }
            }
        }

        return response('', 204);
    }
}
