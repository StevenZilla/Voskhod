<?php

namespace App\Http\Controllers\Ed;

use App\Exceptions\BaseException;
use App\Models\Ed\Ed;
use App\Models\Tk\TkStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Exceptions\PermissionException;
use App\Http\Resources\Ed\ShowResource;

class ShowController extends Controller
{
    /**
     * @param $id
     * @return ShowResource
     * @throws PermissionException
     */
    public function __invoke($id)
    {
        $ed = Ed::permissions()->with('source', 'dossier', 'dossier.diKind', 'dossier.diKind.diSavePeriod', 'attributeValue', 'attributeValue.attribute', 'file', 'file.role', 'file.extension', 'file.rel')
        ->withTrashed()
            ->find($id);

        if($ed->trashed()){
            $deleteAct = $ed->deleteAct;
            throw new BaseException("Ошибка. Электронный документ документ был удалён на основании акта об уничтожении № {$deleteAct->num} за {$deleteAct->year} год");
        }


        if (empty($ed)) {
            throw new PermissionException('Доступ запрещен');
        }
        return new ShowResource($ed);
    }
}
