<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\ShowByThumbRequest;
use App\Http\Requests\Sign\CheckValidBeforeDateFromFileRequest;
use App\Http\Requests\SignFileRequest;
use App\Http\Requests\VerifyFileRequest;
use App\Models\Sert\Sert;
use App\Services\CryptoProSign\CryptoProSign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CryptoSignController extends BaseController
{
    /**
     * @param ShowByThumbRequest $request
     * @return array
     */
    public function getExtraParamsByThumb(ShowByThumbRequest $request)
    {
        try {
            $cryptoSign = new CryptoProSign();

            $data = $cryptoSign->showExtraParams($request->get('thumbprint'));
        } catch (BaseException $e) {
            Log::notice("В системе отсутствует отпечаток {$request->get('thumbprint')}");

            return ['err' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine()];
        }

        return ['data' => $data];
    }

    /**
     * @param ShowByThumbRequest $request
     * @return array
     */
    public function showSignByThumb(ShowByThumbRequest $request)
    {
        try {
            $cryptoSign = new CryptoProSign();

            $data = $cryptoSign->showSignByThumb($request->get('thumbprint'));
        } catch (BaseException $e) {
            Log::notice("В системе отсутствует отпечаток {$request->get('thumbprint')}");

            return ['err' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine(), 'trace' => $e->getTraceAsString()];
        }

        return ['data' => $data];
    }

    /**
     * @param Request $request
     * @return array[]
     */
    public function showSigns(Request $request)
    {
        $signs = Sert::withFilters($request)->withOrder($request)->get();

        $result = null;
        if ($signs->count()) {
            foreach ($signs as $sign) {
                $result[] = [
                    'id' => $sign->id,
                    'subject' => $sign->subject,
                    'thumbprint' => $sign->thumbprint,
                    'num' => $sign->num,
                    'name' => $sign->name,
                    'start_date' => $sign->start_date,
                    'end_date' => $sign->end_date,
                    'user_id' => $sign->user_id,
                ];
            }
        }

        return ['signs' => $result];
    }

    /**
     * @param SignFileRequest $request
     * @return array
     */
    public function signFile(SignFileRequest $request)
    {
        $cryptoSign = new CryptoProSign();

        try {
            $pass = config('app.cert_pass') ? config('app.cert_pass') : '1111';
            $res = $cryptoSign->signWithExtReplace($request->get('file'), $request->get('thumbprint'), $pass, $request->get('prefix'));
        } catch (BaseException $e) {
            return ['err' => $e->getMessage()];
        }

        return ['msg' => $res ? 'Подпись файла прошла успешно' : 'Ошибка подписи файла', 'payload' => $cryptoSign->errorMsg];
    }

    /**
     * @param VerifyFileRequest $request
     * @return array|string[]
     */
    public function verify(VerifyFileRequest $request)
    {
        $cryptoSign = new CryptoProSign();

        try {
            $res = $cryptoSign->verifySign($request->get('file'), $request->get('thumbprint'));
        } catch (BaseException $e) {
            return ['err' => $e->getMessage()];
        }

        return ['msg' => $res ? 'Проверка подписи прошла успешно' : 'Ошибка проверки подписи'];
    }

    /**
     * @param CheckValidBeforeDateFromFileRequest $request
     * @return array|string[]
     */
    public function getValidBeforeDateFromFile(CheckValidBeforeDateFromFileRequest $request)
    {
        $cryptoSign = new CryptoProSign();

        try {
            $res = $cryptoSign->getValidBeforeFromSignedFile($request->get('file'), $request->get('signed_file'));
        } catch (BaseException $e) {
            return ['err' => $e->getMessage()];
        }

        return ['msg' => $res ? "Сертификат действителен до: $res" : 'Не удалось проверить дату окончания подписи'];
    }
}
