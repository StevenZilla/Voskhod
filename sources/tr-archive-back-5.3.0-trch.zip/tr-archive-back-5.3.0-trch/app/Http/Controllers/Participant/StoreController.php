<?php

namespace App\Http\Controllers\Participant;

use App\Http\Requests\Participant\StoreParticipantRequest;
use App\Models\Participant\Participant;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StoreController
{
	public function __invoke(StoreParticipantRequest $request): JsonResponse
	{
		$data = $request->validated();
		try {
			$participant = DB::transaction(function () use ($data) {
				$participant = new Participant();
				$participant['position'] = $data['position'];
				$participant['signer_role_id'] = $data['role_id'];
				$participant['user_id'] = $data['user_id'];
				if (!empty($data['is_actual'])) {
					$participant['is_actual'] = $data['is_actual'];
				}
				$participant->save();

				return $participant;
			}
			);
		} catch (Exception $e) {
			DB::rollback();

			Log::error("Ошибка! Подписант не создан. $e");

			return response()->json(['code' => 400, 'message' => 'Подписант не создан'], 400);
		}
		DB::commit();

		return response()->json(['code' => 201, 'message' => $participant->id], 201);
	}

}