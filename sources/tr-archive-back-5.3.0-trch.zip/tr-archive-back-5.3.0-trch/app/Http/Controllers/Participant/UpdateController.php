<?php

namespace App\Http\Controllers\Participant;

use App\Http\Requests\Participant\UpdateParticipantRequest;
use App\Models\Participant\Participant;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UpdateController
{
	public function __invoke(int $id, UpdateParticipantRequest $request)
	{
		$data = $request->validated();
		try {
			$participant = DB::transaction(function () use ($id, $data) {
				$participant = Participant::findOrFail($id);
				$participant['position'] = $data['position'];
				$participant['signer_role_id'] = $data['role_id'];
				$participant['user_id'] = $data['user_id'];
				if (!empty($data['is_actual'])) {
					$participant['is_actual'] = $data['is_actual'];
				}
				$participant->update();

				return $participant;
			}
			);
		} catch (ModelNotFoundException $e) {
			DB::rollback();

			Log::error("Ошибка! Подписант не найден. $e");

			return response()->json(['code' => 404, 'message' => 'Подписант не найден'], 404);
		} catch (Exception $e) {
			DB::rollback();

			Log::error("Ошибка! Подписант не обновлён. $e");

			return response()->json(['code' => 400, 'message' => 'Подписант не обновлён'], 400);
		}
		DB::commit();

		return response()->json(['code' => 200], 200);
	}

}