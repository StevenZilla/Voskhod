<?php

namespace App\Http\Controllers\Participant;

use App\Http\Requests\Participant\IndexParticipantRequest;
use App\Models\Participant\Participant;
use App\Models\Signer\Signer;

class IndexController
{
	public function __invoke(IndexParticipantRequest $request)
	{
		return Participant::withFilters($request)
			->withOrder($request)
			->withPaginate($request);
	}
}