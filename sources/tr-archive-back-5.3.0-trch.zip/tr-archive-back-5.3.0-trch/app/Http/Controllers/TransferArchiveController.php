<?php

namespace App\Http\Controllers;

use App\Models\System\SystemParam;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Throwable;
use ZanySoft\Zip\Zip;

class TransferArchiveController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws Throwable
     */
    public function transferArchive(Request $request)
    {
        $path = config('filesystems.medo_in');;

        if (empty($path)) {
            return response()->json([
                'code' => 400,
                'message' => 'У "Входящие контейнеры МЭДО" отсутствует путь.',
            ], 400);
        }

        $files = $request->file('zip');

        foreach ($files as $file) {
            $dir = $path.'/'.$file->getClientOriginalName();
            $pathDir = $path.'/'.str_replace('.zip', '', $file->getClientOriginalName());

            File::makeDirectory($pathDir, intval(config('permissions.directory'), 8));

            File::move($file, $dir);

            $zip = Zip::open($dir);

            $zip->extract($pathDir);
            $zip->close();

            File::delete($dir);

            if (File::isDirectory($dir)) {
                return response()->json([
                    'code' => 400,
                    'message' => 'Архив не удалился. Путь, где храниться архив: '.$path,
                ], 400);
            }
        }

        return response()->json([
            'code' => 201,
            'message' => 'Все хорошо! Файл загружен в '.$path,
        ], 201);
    }
}
