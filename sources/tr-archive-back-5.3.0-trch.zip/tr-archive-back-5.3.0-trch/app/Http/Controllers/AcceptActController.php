<?php

namespace App\Http\Controllers;

use App\Models\Act\AcceptAct;
use Illuminate\Http\Request;

class AcceptActController extends Controller
{
    public function index(Request $request)
    {
        return AcceptAct::withOrderDefault($request)->withOrder($request)->withFilter($request)->get();
    }

    public function show($id)
    {
        return AcceptAct::findOrFail($id);
    }
}
