<?php

namespace App\Http\Controllers\Support;

use App\Jobs\Support\CreateTaskSendEmailJob;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Support\SupportMessage;
use App\Http\Requests\Support\MakeReqRequest;
use App\Services\FilesystemManager\MediaStorage;

class MakeReqController extends Controller
{

    public function __invoke(MakeReqRequest $request)
    {
        $req = DB::transaction(function () use ($request) {
            $data = $request->validated();
            $req = new SupportMessage();
            $req->user_id = Auth::user()->id;
            $req->is_sent = false;
            $req->email = $data['email'];
            $req->comment = $data['comment'];
            $req->create_date = Carbon::now();
            $req->save();
            $req->num = $req->id;
            if (!empty ($data['file'])) {
                $path = "support/{$req->id}/screen";
                MediaStorage::makeDirectory($path);
                if (file_exists($data['file']->getPathname())) {
                    $filePath = MediaStorage::copyFileWithRequest($data['file'], $path);
                }
                $req->file_path = $filePath;
            }
            $req->save();
            return $req;
        });
        $job = new CreateTaskSendEmailJob(null,$req->id);
        $job->dispatch()->onQueue('send_mail_job');
        return response(null,201);
    }
}
