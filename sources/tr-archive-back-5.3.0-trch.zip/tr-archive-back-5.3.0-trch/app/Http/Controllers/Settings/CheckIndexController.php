<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Http\Resources\Settings\CheckResource;
use App\Models\System\SystemParam;

class CheckIndexController extends Controller
{
    public function __invoke()
    {
        $settings = SystemParam::whereIn('code', [
            'identificator_app',
            'fund',
            'prohibit_taking_ed_with_invalid_ep',
            'check_ead_files_mchd',
            'mchd',
            'antivirus_enabled',
            'mchd_check_in_tk',
            'mchd_check_xml_and_out_tk',
            'mchd_check_sert_user_assign',
            'version_po'
        ])->get()->pluck('value', 'code');

        return new CheckResource($settings);
    }
}
