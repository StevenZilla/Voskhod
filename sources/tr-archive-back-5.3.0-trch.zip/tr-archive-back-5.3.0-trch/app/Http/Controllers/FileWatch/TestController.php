<?php

namespace App\Http\Controllers\FileWatch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\FileWatch\Watch;
use Illuminate\Support\Facades\Log;

class TestController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $directory = "/vaw/www/files";

        Watch::path($directory)->onAnyChange(function (string $type, string $path) {
            if ($type === Watch::EVENT_TYPE_FILE_CREATED) {
                echo "file {$path} was created";
                Log::info("file {$path} was created");
            }
        })->start();
    }
}
