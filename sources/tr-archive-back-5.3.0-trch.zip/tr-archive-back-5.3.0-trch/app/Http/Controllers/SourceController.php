<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\Source\SourceRequest;
use App\Http\Resources\HandBooks\Source\IndexResource;
use App\Models\HandBooks\Source;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SourceController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function index(Request $request)
    {
        $sources = Source::Filters($request)
            ->orderDefault($request, 'actual_date', 'asc', '')
            ->Orders($request)
            ->autoPaginate($request);

        return new IndexResource($sources);
    }

    /**
     * @param SourceRequest $request
     * @return JsonResponse
     */
    public function update(SourceRequest $request)
    {
        try {
            DB::transaction(function () use ($request) {
                $inputsSources = $request->get('sources');
                foreach ($inputsSources as $inputsSource) {
                    if (! empty($inputsSource['id'])) {
                        try {
                            $source = Source::findOrFail($inputsSource['id']);
                        } catch (ModelNotFoundException $e) {
                            return response()->json([
                                'code' => 400,
                                'message' => 'Источник не найден',
                            ], 400);
                        }
                        $source->actual_date = Carbon::now()->toDateTimeString();
                        if (isset($inputsSource['value'])) {
                            $inputsSource['name'] = strval($inputsSource['value']);
                        }
                        if (isset($inputsSource['descr'])) {
                            $inputsSource['description'] = strval($inputsSource['descr']);
                        }
                        $source->update($inputsSource);
                    } else {
                        $source = new Source();
                        $source->actual_date = Carbon::now()->toDateTimeString();
                        $source->name = $inputsSource['value'];
                        $source->is_actual = $inputsSource['is_actual'];
                        if (! empty($inputsSource['descr'])) {
                            $source->description = $inputsSource['descr'];
                        }
                        $source->save();
                    }
                }
            });
        } catch (BaseException $e) {
            Log::warning('Ошибка! Источник не отредактирован');

            return response()->json(['code' => 400, 'message' => 'Ошибка во время транзакции редактирования источника: '.$e], 400);
        }

        return response()->json(['code' => 201, 'message' => 'Источники успешно отредактированы или созданы'], 201);
    }
}
