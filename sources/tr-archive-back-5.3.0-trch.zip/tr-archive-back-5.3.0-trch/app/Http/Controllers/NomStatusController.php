<?php

namespace App\Http\Controllers;

use App\Models\Nomenclature\NomStatus;
use Illuminate\Http\Request;

class NomStatusController extends Controller
{
    public function index(Request $request)
    {
        return ['nom_statuses' => NomStatus::withFilter($request)->withOrderDefault($request)->get()];
    }
}
