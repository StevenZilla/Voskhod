<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Controllers\Controller;
use App\Http\Requests\Nomenclature\NomenclatureGetRequest;
use App\Http\Resources\Nomenclature\IndexResource;
use App\Models\Nomenclature\Nomenclature;

class IndexController extends Controller
{
    public function __invoke(NomenclatureGetRequest $request)
    {
        $nomenclatures = Nomenclature::with('status', 'lastTk')->Filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->Orders($request)
            // ->groupBy('nomenclature.id')
            ->autoPaginate($request);
        return new IndexResource($nomenclatures);
    }
}
