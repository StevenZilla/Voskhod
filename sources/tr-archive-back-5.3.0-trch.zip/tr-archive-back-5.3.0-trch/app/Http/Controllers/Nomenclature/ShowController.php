<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Controllers\Controller;
use App\Http\Resources\Nomenclature\ShowResource;
use App\Models\Nomenclature\Nomenclature;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowController extends Controller
{

    public function __invoke($id)
    {
        try {
            $nomenclature = Nomenclature::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Номенклатуры с переданным id ' . $id . ' не существует');
        }

        return new ShowResource($nomenclature);
    }
}
