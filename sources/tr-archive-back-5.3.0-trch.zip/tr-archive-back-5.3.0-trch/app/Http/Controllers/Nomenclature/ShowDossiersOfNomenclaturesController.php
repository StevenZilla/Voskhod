<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Controllers\Controller;
use App\Http\Requests\Nomenclature\GetDossiersOfNomenclatures;
use App\Models\Nomenclature\Nomenclature;
use App\Models\Nomenclature\NomPart;
use App\Services\SQL\SqlQuery;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowDossiersOfNomenclaturesController extends Controller
{

    public function __invoke($id, GetDossiersOfNomenclatures $request)
    {
        try {
            $nomenclature = Nomenclature::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Номенклатуры с переданным id ' . $id . ' не существует');
        }
        $dossiers = [];

        if ($request->has('nom_part_id')) {
            $resultQuery = SqlQuery::showDossiersOfNomenclatures($request);
            $listId = [];

            foreach ($resultQuery as $res) {
                $listId[] = $res->id;
            }

            $nomParts = NomPart::whereIn('id', $listId)->get();
        } else {
            $nomParts = $nomenclature->nomParts;
        }

        foreach ($nomParts as $nomPart) {
            foreach ($nomPart->dossierInNomBelongsToMany as $dossier) {
                $dossierFormat = $dossier->showDossiersOfNomenclatures();

                $dossiers[] = $dossierFormat;
            }
        }

        return ['dossiers' => $dossiers ?? null];
    }
}
