<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Requests\NomenclatureUpdateRequest;
use App\Models\Nomenclature\Nomenclature;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UpdateController extends BaseController
{
    public function __invoke(NomenclatureUpdateRequest $request, $id)
    {
        $data = $request->validated();
        $data['id'] = $id;
        try {
            $nomenclature = Nomenclature::findOrFail($id);
            $this->validationService->updateValidate($data);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Номенклатуры с переданным id ' . $id . ' не существует');
        }

        $this->service->updateNomenclature($nomenclature, $data);

        return response(['code' => 204, 'message' => null], 204);
    }
}
