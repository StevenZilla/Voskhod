<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Requests\Nomenclature\UploadRequest;
use App\Http\Controllers\Nomenclature\BaseController;
use App\Models\Upload\UploadStatus;
use Illuminate\Support\Facades\Log;

class UploadController extends BaseController
{
    public function __invoke(UploadRequest $request)
    {
        $result = $this->uploadService->upload($request);
        if ($result['type'] == 'nomenclature') {
            $result['uploadModel']->status_id = UploadStatus::where('code', 'completed')->pluck('id')->first();
            $result['uploadModel']->save();
            return response(['nomenclature_id' => $result['model']->id, 'code' => 201], 201);
        }
        if ($result['type'] == 'upload') {
            $result['uploadModel']->status_id = UploadStatus::where('code', 'wait')->pluck('id')->first();
            $result['uploadModel']->save();
            return response(['upload_id' => $result['uploadModel']->id, 'code' => 202], 202);
        }
        return response(['message' => 'Неизвестная ошибка', 'code' => 500], 500);
    }
}
