<?php

namespace App\Http\Controllers\Nomenclature\NomParts\v3;

use App\Http\Resources\Nomenclature\NomPart\v3\AggregateResource;
use App\Models\Nomenclature\NomPart;
use App\Services\SQL\SqlQuery;
use App\Http\Controllers\Nomenclature\BaseController;
use App\Http\Requests\Nomenclature\NomPartRequest;
use App\Services\Nomenclature\NomenclatureService;

class AggregateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(NomPartRequest $request, $id)
    {
        $nom_parts = NomPart::with('dossierInNomBelongsToMany', 'dossierInNom')
            ->where('nom_id', $id)
            ->permissions()
            ->Filters($request)
            ->get();

        $results = SqlQuery::showAggregateNomPart($id);
        $partList = NomenclatureService::formatPath($results);
        $visibleDossiers = $request->has('is_visible_dossiers');
        $nom_parts->map(function ($part) use ($visibleDossiers, $partList) {
            $part->is_visible_dossiers = $visibleDossiers;
            $part->path = $partList[$part->id] ?? null;
            return $part;
        });
        if ($request->has('is_visible_dossiers')) {
            $nom_parts = $this->service->extendModelAggregate($nom_parts);
        }
        return response(['nom_parts' => AggregateResource::collection($nom_parts)], 200);
    }
}
