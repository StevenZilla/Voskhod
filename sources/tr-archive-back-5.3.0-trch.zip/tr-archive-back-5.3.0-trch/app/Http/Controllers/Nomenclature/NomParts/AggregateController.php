<?php

namespace App\Http\Controllers\Nomenclature\NomParts;



use Illuminate\Http\Request;
use App\Services\SQL\SqlQuery;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Nomenclature\BaseController;
use App\Models\Nomenclature\Nomenclature;
use App\Http\Requests\Nomenclature\NomPartRequest;
use App\Services\Nomenclature\NomenclatureService;
use App\Http\Resources\Nomenclature\AggregateResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class AggregateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(NomPartRequest $request, $id)
    {
        try {
            $nomenclature = Nomenclature::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Номенклатуры с переданным id ' . $id . ' не существует');
        }
        $nom_parts = $nomenclature->nomParts()->with('dossierInNomBelongsToMany', 'dossierInNom')->Filters($request)->get();

        $results = SqlQuery::showAggregateNomPart($id);
        $partList = NomenclatureService::formatPath($results);
        $visibleDossiers = $request->has('is_visible_dossiers');
        $nom_parts->map(function ($part) use ($visibleDossiers, $partList) {
            $part->is_visible_dossiers = $visibleDossiers;
            $part->path = $partList[$part->id] ?? null;
            return $part;
        });
        if ($request->has('is_visible_dossiers')) {
            $nom_parts = $this->service->extendModelAggregate($nom_parts);
        }
        return response(['nom_parts' => AggregateResource::collection($nom_parts)], 200);
    }
}
