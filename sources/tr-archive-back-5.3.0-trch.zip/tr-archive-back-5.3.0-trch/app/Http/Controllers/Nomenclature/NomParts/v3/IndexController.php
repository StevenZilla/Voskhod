<?php

namespace App\Http\Controllers\Nomenclature\NomParts\v3;

use App\Http\Controllers\Controller;
use App\Http\Requests\Nomenclature\GetNomPartRequest;
use App\Http\Resources\Nomenclature\NomPart\v3\IndexResource;
use App\Models\Nomenclature\NomPart;

class IndexController extends Controller
{
    /**
     * @param $nomId
     * @param GetNomPartRequest $request
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function __invoke($nomId, GetNomPartRequest $request)
    {
        $nomParts = NomPart::with('nomPart')
            ->where('nom_id', $nomId)
            ->permissions()
            ->Filters($request)
            ->orderBy('nom_part.num')
            ->get();

        if ($nomParts->count()) {
            $collectionNomParts = IndexResource::collection($nomParts);
        } else {
            $collectionNomParts = [];
        }

        return ['nom_parts' => $collectionNomParts];
    }
}
