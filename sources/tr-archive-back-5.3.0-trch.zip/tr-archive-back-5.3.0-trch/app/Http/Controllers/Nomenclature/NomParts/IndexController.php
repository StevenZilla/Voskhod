<?php

namespace App\Http\Controllers\Nomenclature\NomParts;



use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Nomenclature\NomPart;
use App\Http\Requests\Nomenclature\GetNomPartRequest;
use App\Http\Resources\Nomenclature\NomPart\IndexResource;

class IndexController extends Controller
{
    /**
     * @param $nomId
     * @param GetNomPartRequest $request
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function __invoke($nomId, GetNomPartRequest $request)
    {
        $nomParts = NomPart::with('nomPart')
            ->Filters($request)
            ->where('nom_id', $nomId)
            ->orderBy('nom_part.num')
            ->get();
        if ($nomParts->count() > 0) {
            return ['nom_parts' => IndexResource::collection($nomParts)];
        } else {
            return response()->json([
                'code' => 404,
                'message' => 'У номенклатуры отсутствует разделы',
            ], 404);
        }
    }
}
