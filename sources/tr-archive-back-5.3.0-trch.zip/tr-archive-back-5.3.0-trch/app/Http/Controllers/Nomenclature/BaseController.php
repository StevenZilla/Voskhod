<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Controllers\Controller;
use App\Services\Nomenclature\NomenclatureService;
use App\Services\Nomenclature\NomenclatureUploadService;
use App\Services\Nomenclature\NomenclatureValidateService;

class BaseController extends Controller
{
    public $service = null;
    public $validationService = null;
    public $uploadService = null;
    public function __construct(NomenclatureService $service, NomenclatureValidateService $validationService, NomenclatureUploadService $uploadService)
    {
        $this->service = $service;
        $this->validationService = $validationService;
        $this->uploadService = $uploadService;
    }
}
