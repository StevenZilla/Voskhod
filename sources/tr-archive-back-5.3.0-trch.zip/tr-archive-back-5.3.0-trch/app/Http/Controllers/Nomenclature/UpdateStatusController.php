<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Requests\Nomenclature\UpdateStatusRequest;
use App\Models\Nomenclature\Nomenclature;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UpdateStatusController extends BaseController
{
    public function __invoke(UpdateStatusRequest $request, $id)
    {
        try {
            $nomenclature = Nomenclature::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Номенклатуры с переданным id ' . $id . ' не существует');
        }
        $statusCode = $request->get('status');
        $this->service->updateStatusNomenclature($nomenclature, $statusCode);

        return response()->json([
            'code' => 201,
            'message' => $id
        ], 201);
    }
}
