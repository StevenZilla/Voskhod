<?php

namespace App\Http\Controllers\Nomenclature\v3;

use App\Http\Requests\Nomenclature\StoreNomenclatureRequest;
use App\Services\Subdivision\SubdivisionService;

class StoreController extends BaseController
{
    public function __invoke(StoreNomenclatureRequest $request)
    {
        $inputs = $request->all();
        $this->validationService->storeValidate($inputs);
        $nomenclature = $this->service->storeNomenclature($inputs);

        return response()->json(['code' => 201, 'message' => $nomenclature->id], 201);
    }
}
