<?php

namespace App\Http\Controllers\Nomenclature\v3;

use App\Http\Controllers\Nomenclature\BaseController as Controller;
use App\Services\Nomenclature\v3\NomenclatureUploadService;
use App\Services\Nomenclature\v3\NomenclatureService;
use App\Services\Nomenclature\v3\NomenclatureValidateService;

class BaseController extends Controller
{
    public $service = null;
    public $validationService = null;
    public $uploadService = null;
    public function __construct(NomenclatureService $service, NomenclatureValidateService $validationService, NomenclatureUploadService $uploadService)
    {
        $this->service = $service;
        $this->validationService = $validationService;
        $this->uploadService = $uploadService;
    }
}
