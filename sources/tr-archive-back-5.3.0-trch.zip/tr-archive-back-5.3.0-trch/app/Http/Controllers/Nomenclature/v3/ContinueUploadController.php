<?php

namespace App\Http\Controllers\Nomenclature\v3;

use Exception;
use App\Models\Upload\Upload;
use App\Models\Nomenclature\Nomenclature;
use App\Http\Requests\Nomenclature\ContinueUploadRequest;

class ContinueUploadController extends BaseController
{
    public function __invoke(ContinueUploadRequest $request)
    {
        $data = $request->validated();
        $files = explode(',', $data['upload_id']);
        $uploadModels = [];
        foreach ($files as $file) {
            try {
                $uploadModels[] = Upload::findOrFail($data['upload_id']);
            } catch (Exception $e) {
                return response(['message' => 'Файла с таким идентификатором не существует', 'code' => 400], 400);
            }
        }
        $updatedIds = [];
        foreach ($uploadModels as $file) {
            $nomenclatureData = json_decode($file->data, true);
            $nomenclatureData['change_reason'] = $data['change_reason'];
            $this->validationService->updateValidate($nomenclatureData);
            $nomenclature = Nomenclature::find($nomenclatureData['id']);
            $result = $this->service->updateNomenclature($nomenclature, $nomenclatureData);
            $updatedIds[] = $result->id;
        }
        return response(['nomenclature_id' => $result->id, 'code' => 200], 201);
    }
}
