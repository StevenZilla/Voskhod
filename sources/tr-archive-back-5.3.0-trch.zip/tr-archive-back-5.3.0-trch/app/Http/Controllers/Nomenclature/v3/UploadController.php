<?php

namespace App\Http\Controllers\Nomenclature\v3;

use App\Http\Requests\Nomenclature\UploadRequest;
use App\Http\Controllers\Nomenclature\v3\BaseController;

class UploadController extends BaseController
{
    public function __invoke(UploadRequest $request)
    {
        $files = $request->allFiles()['files'];
        $result = $this->uploadService->upload($files);

        if ($result['type'] == 'nomenclature') {
            foreach ($result['files'] as $file) {
                $nomId[] = $file->createdNom->id;
            }
            $nomId = implode(',', $nomId);
            return response(['nomenclature_id' => $nomId, 'code' => 201], 201);
        }

        if ($result['type'] == 'upload') {
            return response(['upload_id' => $result['uploadModels'], 'code' => 202], 202);
        }

        return response(['message' => 'Не смогли распарсить архив с номенклатурой.', 'code' => 500], 500);
    }
}
