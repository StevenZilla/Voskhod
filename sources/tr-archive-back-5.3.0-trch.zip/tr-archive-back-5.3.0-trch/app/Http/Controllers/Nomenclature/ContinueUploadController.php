<?php

namespace App\Http\Controllers\Nomenclature;

use Exception;
use App\Models\Upload\Upload;
use App\Models\Nomenclature\Nomenclature;
use App\Http\Requests\Nomenclature\ContinueUploadRequest;

class ContinueUploadController extends BaseController
{
    public function __invoke(ContinueUploadRequest $request)
    {
        $data = $request->validated();
        try {
            $file = Upload::findOrFail($data['upload_id']);
        } catch (Exception $e) {
            return response(['message' => 'Файла с таким идентификатором не существует', 'code' => 400], 400);
        }
        $nomenclatureData = json_decode($file->data, true);
        $nomenclatureData['change_reason'] = $data['change_reason'];
        $this->validationService->updateValidate($nomenclatureData);
        $nomenclature = Nomenclature::find($nomenclatureData['id']);
        $result = $this->service->updateNomenclature($nomenclature, $nomenclatureData);
        return response(['nomenclature_id' => $result->id, 'code' => 201], 201);
    }
}
