<?php

namespace App\Http\Controllers;

use App\Http\Requests\DirectoryRequest;
use App\Http\Requests\Fund\StoreFundsRequest;
use App\Http\Requests\Fund\UpdateFundRequest;
use App\Http\Requests\FundRequest;
use App\Http\Resources\HandBooks\Fund\IndexResource;
use App\Models\HandBooks\Fund;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class FundController extends Controller
{
    /**
     * @param FundRequest $request
     * @return IndexResource
     */
    public function index(FundRequest $request)
    {
        $funds = Fund::with('archive')
            ->Filters($request)
            ->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->Orders($request)
            ->autoPaginate($request);

        return new IndexResource($funds);
    }

    /**
     * @param FundRequest $request
     * @return IndexResource
     */
    public function indexV2(FundRequest $request)
    {
        $funds = Fund::with('archive')
            ->Filters($request)
            ->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->Orders($request)
            ->autoPaginate($request);

        return new IndexResource($funds);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Collection|Model|JsonResponse
     */
    public function show($id)
    {
        try {
            $fund = Fund::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Фонда с переданным id '.$id.' не существует');
        }

        return $fund;
    }

    public function store(StoreFundsRequest $request)
    {
        $inputsFunds = $request->get('funds');
        try {
            DB::transaction(function () use ($inputsFunds) {
                foreach ($inputsFunds as $inputFund) {
                    if (! array_key_exists('id', $inputFund)) {
                        $newFund = new Fund();
                        $newFund->name = $inputFund['value'];
                        $newFund->num = $inputFund['num'];
                        $newFund->description = $inputFund['descr'];
                        $newFund->code = $inputFund['code'];
                        $newFund->actual_date = Carbon::now()->toDateString();
                        $newFund->is_actual = true;
                        $newFund->is_default = false;
                        $newFund->archive_id = $inputFund['archive_id'];
                        $newFund->save();
                    }
                }

                if (! (Fund::where('is_default', true)->exists())) {
                    $fund = Fund::inRandomOrder()->first();
                    $fund->is_default = true;
                    $fund->save();
                }

                return true;
            });
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => 'Дублируются данные фондов'], 400);
        }

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }

    public function update(UpdateFundRequest $request, int $id)
    {
        $data = $request->all();

        if (! empty($data['descr'])) {
            $data['description'] = $data['descr'];
            unset($data['descr']);
        }

        if (! empty($data['value'])) {
            $data['name'] = $data['value'];
            unset($data['value']);
        }

        if (! empty($data['is_default'])) {
            Fund::where('is_default', true)
                ->where('id', '!=', $id)
                ->update(['is_default' => false]);
        }

        if (! Fund::where('id', $id)->exists()) {
            return response()->json(['code' => 201, 'message' => $id], 201);
        }

        Fund::where('id', $id)->update($data);

        return response()->json(['code' => 201, 'message' => $id], 201);
    }
}
