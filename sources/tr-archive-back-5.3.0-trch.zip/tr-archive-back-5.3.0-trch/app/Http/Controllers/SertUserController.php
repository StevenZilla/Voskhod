<?php

namespace App\Http\Controllers;

use App\Models\Sert\Sert;
use App\Models\Sert\SertUse;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Request;

class SertUserController extends BaseController
{
    /**
     * @param Request $request
     * @return array
     * Возвращает сертификаты текущего пользователя
     */
    public function showForUser(Request $request)
    {
        $serts =
            Auth::user()->serts()
            ->where('start_date', '<=', Carbon::now())
            ->where('end_date', '>=', Carbon::now())
            ->orderBy('sert.name', 'asc')->get();

        $resultSerts = Sert::sertForUser($serts);

        return ['serts' => $resultSerts ? $resultSerts : []];
    }

    /**
     * @return SertUse[]|\Illuminate\Database\Eloquent\Collection
     * Возвращает возможные использования сертификатов
     */
    public function signUses()
    {
        return SertUse::all();
    }
}
