<?php

namespace App\Http\Controllers\AcceptRegister\Agreement;

use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use Illuminate\Database\Eloquent\Collection;
use App\Models\AcceptRegister\AcceptRegister;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\AcceptRegister\Agreement\IndexResource;
use App\Models\AcceptRegister\Agreement\AcceptRegisterAgreementType;

class IndexController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $acceptRegister =  AcceptRegister::with('agreements', 'agreements.status', 'agreements.fileComment', 'agreements.user', 'agreements.decisionType')
                ->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new BaseException("Сдаточной описи с идентификатором {$id} не существует.");
        }
        $acceptRegisterAgreements = $acceptRegister->agreements->where('type_id', AcceptRegisterAgreementType::getTypeArchivist());
        $acceptRegisterApproval = $acceptRegister->agreements->where('type_id', AcceptRegisterAgreementType::getTypeOIKHead());

        $data = new Collection();
        $data = $data->put('agreements', IndexResource::collection($acceptRegisterAgreements));
        $data = $data->put('approval', IndexResource::collection($acceptRegisterApproval));
        $buttons = $this->service->viewButtons($acceptRegister, $acceptRegisterAgreements, $acceptRegisterApproval);
        // if ($actualAgreement != null) {
        // $buttons = new ButtonsResource($actualAgreement);
        $data = $data->put("view_buttons", $buttons);
        // }
        return response($data, 200);
    }
}
