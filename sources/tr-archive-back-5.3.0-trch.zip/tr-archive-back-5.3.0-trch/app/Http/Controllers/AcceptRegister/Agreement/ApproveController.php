<?php

namespace App\Http\Controllers\AcceptRegister\Agreement;

use Illuminate\Http\Request;
use App\Facades\SKZIServiceFacade;

class ApproveController extends BaseController
{
    public function __invoke($id, Request $request)
    {
        SKZIServiceFacade::checkHealth();
        $data = $request->all();
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        $this->service->setGuid($guidOIK);
        $this->service->approve($id, $data);
        return response(null, 204);
    }
}
