<?php

namespace App\Http\Controllers\AcceptRegister\Agreement;

use Illuminate\Http\Request;
use App\Facades\SKZIServiceFacade;
use App\Http\Requests\AcceptRegister\Agreement\DecisionRequest;

class DecisionController extends BaseController
{
    public function __invoke($id, DecisionRequest $request)
    {
        if (!empty($request->allFiles()['files_comment'])) {
            $this->service->setFiles($request->allFiles()['files_comment']);
        }
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        $this->service->setGuid($guidOIK);
        $data = $request->all();
        unset($data['files_comment']);
        $this->service->setDecision($id, $data);
        return response(null, 204);
    }
}
