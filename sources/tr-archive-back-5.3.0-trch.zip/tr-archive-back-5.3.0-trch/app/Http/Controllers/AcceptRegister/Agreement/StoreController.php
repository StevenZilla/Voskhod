<?php

namespace App\Http\Controllers\AcceptRegister\Agreement;

use Illuminate\Http\Request;

class StoreController extends BaseController
{
    public function __invoke(Request $request, $id)
    {
        $inputs = $request->all();
        $this->service->storeValidate($id);
        $agreement = $this->service->storeAgreement($id, $inputs);
        return response(['message' => $agreement->id, 'code' => 201], 201);
    }
}
