<?php

namespace App\Http\Controllers\AcceptRegister\Agreement;

use App\Http\Controllers\Controller;
use App\Services\AcceptRegister\Agreement\AgreementService;

class BaseController extends Controller
{
    public $service = null;
    public function __construct(AgreementService $service)
    {
        $this->service = $service;
    }
}
