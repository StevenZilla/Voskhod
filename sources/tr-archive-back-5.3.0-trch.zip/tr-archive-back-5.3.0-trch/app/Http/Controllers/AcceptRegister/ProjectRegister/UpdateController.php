<?php

namespace App\Http\Controllers\AcceptRegister\ProjectRegister;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegister;
use App\Models\AcceptRegister\AcceptRegisterProject;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\AcceptRegister\ProjectRegister\UpdateRequest;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, UpdateRequest $request)
    {
        $inputs = $request->all();
        $inputs['id'] = $id;
        $this->validationService->updateValidate($inputs);
        $acceptRegister = $this->service->updateAcceptRegister($inputs);
        return response(['message' => $acceptRegister->id, 'code' => 204], 204);
    }
}
