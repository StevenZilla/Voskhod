<?php

namespace App\Http\Controllers\AcceptRegister\ProjectRegister;

use App\Http\Controllers\Controller;
use App\Http\Requests\AcceptRegister\ProjectRegister\StoreRequest;
use Illuminate\Http\Request;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StoreRequest $request)
    {
        $inputs = $request->all();
        $this->validationService->storeValidate($inputs);
        $acceptRegister = $this->service->storeAcceptRegister($inputs);
        return response(['message' => $acceptRegister->id, 'code' => 201], 201);
    }
    // В сводной описи Документов временного срока хранения не будет (сводная та которая сейчас)
    // У сдаточной описи, дела,  раздела номенклатуры и ЭАД будет признак подразделения
    // Сдаточная опись должна иметь в обязательном порядке подразделение
    // При указании подразделения в описи,  появится возможность использовать кнопку  добавления всех дел в опись по подразделению + кнопка с  возможностью выбрать в ВО дела относящиеся к данному подразделению.  ( Т.Е. добавить/исключить дела из ВО списка добавления дел к описи относящихся к данному подразделению)

    // Подразделения сделать иерархически - 1 уровень - сама организация, 2 - подразделения организация (требуется уточнение) или линейно (1 уровень) Ждем ответа!!! - 2 уровня - сама организация + подразделения. в БД реализуем линейно

}
