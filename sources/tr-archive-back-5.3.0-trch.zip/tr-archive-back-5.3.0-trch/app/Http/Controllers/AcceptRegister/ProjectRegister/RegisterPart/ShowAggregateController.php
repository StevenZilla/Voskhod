<?php

namespace App\Http\Controllers\AcceptRegister\ProjectRegister\RegisterPart;

use Illuminate\Http\Request;
use App\Models\AcceptRegister\AcceptRegisterProject;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Controllers\AcceptRegister\ProjectRegister\BaseController;
use App\Http\Resources\AcceptRegister\ProjectRegister\RegisterPart\DossierResource;
use App\Http\Resources\AcceptRegister\ProjectRegister\RegisterPart\ShowAggregateResource;

class ShowAggregateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $acceptRegister = AcceptRegisterProject::with('parts', 'parts.dossiers','parts.dossiers.eds', 'dossiers', 'dossiers.mediaType', 'parts.dossiers.saveType', 'dossierInAcceptRegisterOnRegisterPartNull')->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response(["message" => "Описи с идентификатором {$id} не существует.", "code" => 404], 404);
        }
        $acceptRegisterParts = $acceptRegister->parts;

        $acceptRegisterPartsTree  = $acceptRegisterParts;
        // $acceptRegisterPartsTree = $this->service->getAcceptRegisterPartsTree($acceptRegisterParts);
        $dossiers = $acceptRegister->acceptRegisterBindDossiers()->withTrashed()->get();
        $dossiers = DossierResource::collection($dossiers)->collection;
        $firstObj = $this->service->getAcceptRegisterDossier($dossiers);
        $acceptRegisterPartsTree->prepend($firstObj);
        $acceptRegisterPartsTreeResource = ShowAggregateResource::collection($acceptRegisterPartsTree);
        return response(["accept_register_parts" => $acceptRegisterPartsTreeResource], 200);
    }
}
