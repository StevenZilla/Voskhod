<?php

namespace App\Http\Controllers\AcceptRegister\ProjectRegister;

use App\Http\Controllers\Controller;
use App\Http\Resources\AcceptRegister\ProjectRegister\IndexResource;
use App\Models\AcceptRegister\AcceptRegister;
use App\Models\AcceptRegister\AcceptRegisterProject;
use App\Models\AcceptRegister\AcceptRegisterStatus;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $acceptRegister = AcceptRegisterProject::with('registerStatus', 'subdivision')
            ->permissions()
            ->where('accept_register_status_id', '!=', AcceptRegisterStatus::getStatusApproved())->Filters($request)
            // ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->Orders($request)
            ->autoPaginate($request);
        return new IndexResource($acceptRegister);
    }
}
