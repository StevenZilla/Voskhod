<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegisterStatus;
use App\Models\AcceptRegister\AcceptRegisterApproved;
use App\Http\Resources\AcceptRegister\ApprovedRegister\IndexResource;

class IndexController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request)
    {
        $acceptRegister = AcceptRegisterApproved::with('registerStatus')->Filters($request)
            // ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->Orders($request)
            ->where('accept_register_status_id',  AcceptRegisterStatus::getStatusApproved())->Filters($request)
            ->autoPaginate($request);

        return new IndexResource($acceptRegister);
    }
}
