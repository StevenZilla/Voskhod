<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister\Statistic;

use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegisterStatus;
use App\Services\AcceptRegister\AcceptRegisterService;
use App\Services\AcceptRegister\AcceptRegisterStatisticService;
use App\Services\AcceptRegister\AcceptRegisterValidateService;

class BaseController extends Controller
{
    public $service = null;
    public function __construct(AcceptRegisterStatisticService $service)
    {
        $this->service = $service;
    }
}
