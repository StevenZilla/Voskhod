<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister\Statistic;



use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use Illuminate\Support\Collection;
use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegister;
use App\Models\AcceptRegister\AcceptRegisterStatus;
use App\Models\AcceptRegister\AcceptRegisterApproved;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class StatisticController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $acceptRegister = AcceptRegister::with('registerStatus', 'dossiers', 'dossiers.eds', 'parts', 'parts.dossiers')->findOrFail($id); //->where('accept_register_status_id', AcceptRegisterStatus::getStatusApproved())
        } catch (ModelNotFoundException $e) {
            throw new BaseException("Сдаточной описи с идентификатором {$id} не существует");
        }
        $edStatistic = [];
        $dossiers = $acceptRegister->dossiers()->with('eds')->get(); // список дел сдаточной описи\
        $eds = new Collection();
        foreach ($dossiers as $dossier) {
            $eds = $eds->merge($dossier->eds);
        }
        $allCount = $eds->count(); // общее количество ЭД в сдаточной описи
        $eds->map(function ($ed) {
            $date = new Carbon($ed->reg_date);
            $ed->year = $date->year;
            return $ed;
        });
        $edsGroupByYear = $eds->groupBy('year');

        foreach ($edsGroupByYear as $year => $ed) {
            $edStatistic[] = ['year' => $year, 'count_ed' => $ed->count()];
        }
        $statistic = [
            'count_ed_in_register' => $allCount,
            'statistic_ed_in_register_by_year' => [
                'ed_in_dossiers_info' => $edStatistic,
            ]
        ];
        return response($statistic, 200);
    }
}
