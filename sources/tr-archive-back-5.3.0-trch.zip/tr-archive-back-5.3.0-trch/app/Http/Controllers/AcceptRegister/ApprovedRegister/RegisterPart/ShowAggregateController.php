<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister\RegisterPart;



use Illuminate\Http\Request;
use App\Models\AcceptRegister\AcceptRegisterProject;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Controllers\AcceptRegister\ProjectRegister\BaseController;
use App\Http\Resources\AcceptRegister\ProjectRegister\RegisterPart\DossierResource;
use App\Http\Resources\AcceptRegister\ProjectRegister\RegisterPart\ShowAggregateResource;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\ItemNotFoundException;

class ShowAggregateController extends BaseController
{
    /**
     * @param $id
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\JsonResponse|\Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $structureSnapshot = AcceptRegisterProject::where('id', $id)->pluck('structure_snapshot')->firstOrFail();
        } catch (\Exception $e) {
            if ($e instanceof ItemNotFoundException) {
                return response(["message" => "Описи с идентификатором {$id} не существует.", "code" => 404], 404);
            } else {
                Log::error('Не смогли разобрать ошибку при получении утвержденной сдаточной описи с идентификатором - ' . $id . '. Ошибка: ' . $e . PHP_EOL);
                return response(["message" => 'Не смогли разобрать ошибку при получении утвержденной сдаточной описи с идентификатором - ' . $id, "code" => 400], 400);
            }
        }

        return response()->json(json_decode($structureSnapshot));
    }
}
