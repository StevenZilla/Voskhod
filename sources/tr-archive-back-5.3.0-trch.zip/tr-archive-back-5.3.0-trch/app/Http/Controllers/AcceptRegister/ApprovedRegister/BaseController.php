<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister;

use App\Http\Controllers\Controller;
use App\Services\AcceptRegister\AcceptRegisterService;
use App\Services\AcceptRegister\AcceptRegisterValidateService;

class BaseController extends Controller
{
    public $service = null;
    public $validationService = null;
    public function __construct(AcceptRegisterService $service, AcceptRegisterValidateService $validationService)
    {
        $this->service = $service;
        $this->validationService = $validationService;
    }
}
