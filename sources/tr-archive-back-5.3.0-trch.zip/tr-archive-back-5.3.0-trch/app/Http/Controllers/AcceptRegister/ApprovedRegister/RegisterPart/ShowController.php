<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister\RegisterPart;



use Illuminate\Http\Request;
use App\Http\Controllers\AcceptRegister\ProjectRegister\BaseController;
use App\Http\Resources\AcceptRegister\ProjectRegister\RegisterPart\ShowResource;
use App\Models\AcceptRegister\AcceptRegisterPart;

class ShowController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        $acceptRegisterParts = AcceptRegisterPart::where('accept_register_id', $id)->get();
        $acceptRegisterPartsTree = $this->service->getAcceptRegisterPartsTree($acceptRegisterParts);
        return response(["accept_register_parts" => ShowResource::collection($acceptRegisterPartsTree)], 200);
    }
}
