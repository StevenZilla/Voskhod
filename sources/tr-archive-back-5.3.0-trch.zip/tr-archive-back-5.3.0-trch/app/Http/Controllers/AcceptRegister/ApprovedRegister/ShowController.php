<?php

namespace App\Http\Controllers\AcceptRegister\ApprovedRegister;

use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Models\AcceptRegister\AcceptRegisterApproved;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\AcceptRegister\ApprovedRegister\ShowResource;

class ShowController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $acceptRegister = AcceptRegisterApproved::with('registerStatus', 'author')->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new BaseException("Проекта описи с идентификатором {$id} не существует");
        }
        return new ShowResource($acceptRegister);
    }
}
