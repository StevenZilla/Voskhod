<?php

namespace App\Http\Controllers\Antivirus;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Antivirus\AntivirusStatuses;
use App\Services\Antivirus\AntivirusService;
use App\Http\Requests\Antivirus\CheckRequest;

class CheckController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(CheckRequest $request)
    {
        $files = $request->allFiles()['files'];
        if (!empty($files)) {
            $response = AntivirusService::check($files);
            $antivirusStatuses = AntivirusStatuses::all();
            if (!empty($response)) {
                $files = json_decode($response->body());
                if (!empty($files)) {
                    $files = $files->files;
                    foreach ($files as $key => $file) {
                        $status = $antivirusStatuses->where('service_code', $file->checkResultStatus)->first() ?? $antivirusStatuses->where('code', 'error')->first();
                        $files[$key]->status = [
                            'name' => $status->name,
                            'short_name' => $status->short_name,
                            'code' => $status->code,
                        ];
                        unset($files[$key]->path);
                        unset($files[$key]->absolutePath);
                        unset($files[$key]->host);
                        unset($files[$key]->ipServer);
                        unset($files[$key]->checkResultStatus);
                    }
                    return response(['files' => $files], 200);
                } else {
                    return response(['message' => 'Ошибка проверки файлов', 'code' => 500], 500);
                }
            } else {
                return response(null, 204);
            }
        }
    }
}
