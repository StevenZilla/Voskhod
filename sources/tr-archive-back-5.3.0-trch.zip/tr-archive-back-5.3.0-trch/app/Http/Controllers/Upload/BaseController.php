<?php

namespace App\Http\Controllers\Upload;

use App\Http\Controllers\Controller;
use App\Services\Upload\UploadService;

class BaseController extends Controller
{
    public $service = null;
    public $validationService = null;
    public function __construct(UploadService $service)
    {
        $this->service = $service;
    }
}
