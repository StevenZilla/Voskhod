<?php

namespace App\Http\Controllers\Upload;

use Illuminate\Http\Request;
use App\Models\Upload\UploadStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Upload\UploadStoreV2Request;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(UploadStoreV2Request $request)
    {
        try {
            if (!empty($request->type)) {
                $this->service->saveFiles($request);
            }
        } catch (\Exception $e) {
            return response(['code' => 400, 'message' => 'Не смогли загрузить номенклатуру из СЭД'], 400);
        }
    }
}
