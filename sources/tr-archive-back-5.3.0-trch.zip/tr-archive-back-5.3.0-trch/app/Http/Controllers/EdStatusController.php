<?php

namespace App\Http\Controllers;

use App\Http\Requests\DirectoryRequest;
use App\Models\Ed\EdStatus;

class EdStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param DirectoryRequest $request
     * @return array
     */
    public function index(DirectoryRequest $request)
    {
        return [
            'ed_statuses' => EdStatus::withFilter($request)->orderBy(EdStatus::$defaultOrderColumn)->get(),
        ];
    }
}
