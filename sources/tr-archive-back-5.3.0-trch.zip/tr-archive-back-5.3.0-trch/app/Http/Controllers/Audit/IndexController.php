<?php

namespace App\Http\Controllers\Audit;

use App\Http\Controllers\Controller;
use App\Http\Resources\Audit\IndexResource;
use App\Models\Audit\Audit;
use App\Models\Audit\AuditNamespace;
use Illuminate\Http\Request;
use Log;

class IndexController extends BaseController
{
    public function __invoke(Request $request)
    {
        try {
            $audits = Audit::filters($request)
                ->orderDefault($request, 'created_at', 'desc', '')
                ->orders($request)
                ->autoPaginate($request);
            $audits = $this->service->extendModelAddCategory($audits);
            $audits = $this->service->extendModelFormatResourceMetaData($audits);

            return new IndexResource($audits);
        } catch (\Exception $e) {
            // dump($e);
            Log::error($e->getMessage());
            return response(null, 500);
        }
    }
}
