<?php

namespace App\Http\Controllers\Audit;

use App\Models\Event\EventType;
use App\Http\Controllers\Controller;
use App\Http\Resources\Audit\EventTypeHandBookResource;


class EventTypeController extends Controller
{

    public function __invoke()
    {
        $eventTypes = EventType::get();
        return EventTypeHandBookResource::collection($eventTypes)->collection;
    }
}
