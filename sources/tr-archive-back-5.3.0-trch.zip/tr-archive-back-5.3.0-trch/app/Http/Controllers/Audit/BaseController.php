<?php

namespace App\Http\Controllers\Audit;

use App\Http\Controllers\Controller;
use App\Services\Audit\AuditService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(AuditService $service)
    {
        $this->service = $service;
    }
}
