<?php

namespace App\Http\Controllers\Audit;

use App\Models\Audit\Audit;
use App\Http\Controllers\Controller;
use App\Models\Audit\AuditNamespace;
use App\Http\Resources\Audit\ShowResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowController extends BaseController
{
    public function __invoke(int $id)
    {
        try {
            $audit = Audit::findOrfail($id);
            $audit = $this->service->extendModelShowResource($audit);
        } catch (ModelNotFoundException $e) {
            return response(['code' => 400, 'message' => __('main.audit.notFound', ['id' => $id])], 400);
        }
        return new ShowResource($audit);
    }
}
