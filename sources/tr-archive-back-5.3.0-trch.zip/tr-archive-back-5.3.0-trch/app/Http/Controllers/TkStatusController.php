<?php

namespace App\Http\Controllers;

use App\Http\Requests\DirectoryRequest;
use App\Models\Tk\TkStatus;

class TkStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param DirectoryRequest $request
     * @return array
     */
    public function index(DirectoryRequest $request)
    {
        $tkStatus = TkStatus::withDefaultFilter($request)->withFilter($request)->get();

        return [
            'tk_statuses' => $tkStatus->sortBy('name')->values(),
        ];
    }
}
