<?php

namespace App\Http\Controllers\Register;

use App\Http\Controllers\Controller;
use App\Http\Requests\Register\RegisterGetRequest;
use App\Models\Register\Register;
use App\Http\Resources\Register\IndexResource;

class IndexController extends Controller
{
    /**
     * @param RegisterGetRequest $request
     * @return IndexResource
     */
    public function __invoke(RegisterGetRequest $request)
    {
        $registers = Register::with('archive', 'registerType', 'fund')
            ->filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($registers);
    }
}
