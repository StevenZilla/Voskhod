<?php

namespace App\Http\Controllers\Register\ProjectRegister;

use App\Http\Controllers\Register\BaseController;
use App\Models\Register\Register;
use App\Models\Register\RegisterStatus;

class DeleteController extends BaseController
{

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke($id)
    {
        $register = Register::findOrFail($id);
        $register->changeState('register_status_id', RegisterStatus::getRemovedStatus());

        return response()->json(['code' => 200, 'message' => $id]);
    }
}
