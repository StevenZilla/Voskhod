<?php

namespace App\Http\Controllers\Register\ProjectRegister\RegisterPart;

use App\Models\Register\RegisterPart;
use App\Http\Requests\RegisterPartRequest;

use App\Http\Controllers\Register\BaseController;
use App\Http\Resources\Register\ProjectRegister\RegisterPart\ShowProjectResource;

class ShowController extends BaseController
{

    /**
     * @param RegisterPartRequest $request
     * @param $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function __invoke(RegisterPartRequest $request, $id)
    {
        $query = RegisterPart::where('register_id', '=', $id);

        if ($request->has('id')) {
            $register_parts = $query->where('id', '=', $request->id);
        }

        $register_parts = $query->orderBy('time')->get();
        $registerPartsResource = ShowProjectResource::collection($register_parts)->collection;
        return response(['register_parts' => $registerPartsResource], 200);
    }
}
