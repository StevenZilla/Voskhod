<?php

namespace App\Http\Controllers\Register\ProjectRegister\RegisterPart;

use App\Services\SQL\SqlQuery;
use App\Models\Register\Register;
use App\Http\Requests\RegisterPartRequest;
use App\Http\Controllers\Register\BaseController;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\Register\ProjectRegister\RegisterPart\DossierInRegisterResource;
use App\Http\Resources\Register\ProjectRegister\RegisterPart\ShowProjectAggregateResource;


class ShowAggregateController extends BaseController
{
    /**
     * @param RegisterPartRequest $request
     * @param $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function __invoke(RegisterPartRequest $request, $id)
    {
        try {
            $register = Register::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Описи с переданным id ' . $id . ' не существует');
        }

        $resultEds = [];
        $dossierInRegisterOnRegisterPartNull = $register->dossierInRegisterOnRegisterPartNull;
        if (!$request->has('id')) {
            $dossier = DossierInRegisterResource::collection($dossierInRegisterOnRegisterPartNull);
        } else {
            $dossier = [];
        }

        $tmpObj['id'] = null;
        $tmpObj['is_dossiers'] = !empty($resultEds);
        $tmpObj['dossiers'] = $dossier;

        $results = SqlQuery::showAggregateRegisterPart($request->id);

        $register_parts = $register->registerPart()->orderBy('register_part.time')
            ->withFilters($request)->get();
        $register_parts = $register_parts->map(function ($register_part) use ($results) {
            $register_part->extra  = ['results' => $results];
            return $register_part;
        });
        $registerParts = ShowProjectAggregateResource::collection($register_parts)->collection;
        $registerParts->prepend($tmpObj);

        return response(['register_parts' => $registerParts], 200);
    }
}
