<?php

namespace App\Http\Controllers\Register\ProjectRegister;

use App\Exceptions\BaseException;
use App\Http\Controllers\Register\BaseController;
use App\Http\Requests\Register\RegisterV2UpdateRequest;
use App\Models\Dossier\DossierInRegister;
use App\Models\Register\Register;
use App\Models\Register\RegisterPart;
use App\Services\Register\Statistic\RegisterStatisticService;
use App\Services\Tree\IterateTree;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UpdateController extends BaseController
{
    /**
     * @param RegisterV2UpdateRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(RegisterV2UpdateRequest $request, int $id)
    {
        try {
            $register = Register::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Опись с переданным id: '.$id.' не существует');
        }

        $registerId = DB::transaction(function () use ($request, $register) {
            $update = $request->all();
            $update['update_date'] = Carbon::now()->toDateTimeString();

            if (! empty($register->lastTk)
                && $register->lastTk->status->code === 'admitted_ched') {
                $update['resend_tk'] = true;
            }

            if (! empty($register->lastAk)
                && $register->lastAk->status->code === 'transferred_temporary_storage') {
                $update['resend_ak'] = true;
            }

            $dataDossierId = [];
            if ($request->has('dossier_ids')) {
                $orderInDossier = DossierInRegister::createMultipleItems($request->get('dossier_ids'), $register->id);
                $dataDossierId = $request->get('dossier_ids');
            }

            if (! empty($request->register_parts) && count($request->register_parts) > 0) {
                $resultIterateTree = IterateTree::iterateTreeOnRegisterPart($register, $request->register_parts, $orderInDossier ?? 1);
            }

            if (! empty($resultIterateTree['dossierID'])) {
                $dataDossierId = array_merge($resultIterateTree['dossierID'], $dataDossierId);
            }

            RegisterPart::deletedRegisterPart($register->id, $resultIterateTree['partID'] ?? []);
            DossierInRegister::whereNotIn('dossier_id', $dataDossierId)->where('register_id', $register->id)->delete();

            if (! $register->dossierInRegister()->exists()) {
                throw new BaseException('Опись не может быть обновлена без ЭД. Прикрепите дело или электронный документ.');
            }

            $register->update($update);

            RegisterStatisticService::insertStatisticRegister($register);

            return $register->id;
        });

        return response()->json(['code' => 200, 'message' => $registerId], 200);
    }
}
