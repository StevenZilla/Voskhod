<?php

namespace App\Http\Controllers\Register\ProjectRegister;

use App\Exceptions\BaseException;
use App\Http\Controllers\Register\BaseController;
use App\Http\Requests\Register\RegisterV2StoreRequest;
use App\Jobs\CreateReportJob;
use App\Jobs\Statistic\RegisterStatisticEdInYearJob;
use App\Models\Dossier\DossierInRegister;
use App\Models\Register\Register;
use App\Services\Register\Statistic\RegisterStatisticService;
use App\Services\Tree\IterateTree;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    /**
     * @param RegisterV2StoreRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(RegisterV2StoreRequest $request)
    {
        $registerId = DB::transaction(function () use ($request) {
            $inputs = $request->all();
            $inputs['create_date'] = Carbon::now()->toDateTimeString();
            $inputs['user_id'] = Auth::id();

            $register = Register::create($inputs);

            if ($request->has('dossier_ids')) {
                $orderInDossier = DossierInRegister::createMultipleItems($request->get('dossier_ids'), $register->id);
            }

            if (! empty($request->register_parts) && count($request->register_parts) > 0) {
                IterateTree::iterateTreeOnRegisterPart($register, $request->register_parts, $orderInDossier ?? 1);
            }

            if (! $register->dossierInRegister()->exists()) {
                throw new BaseException('Опись не может быть создана без ЭД. Прикрепите дело или электронный документ.');
            }

            RegisterStatisticService::insertStatisticRegister($register);

            return $register->id;
        });

        return response()->json(['code' => 201, 'message' => $registerId], 201);
    }
}
