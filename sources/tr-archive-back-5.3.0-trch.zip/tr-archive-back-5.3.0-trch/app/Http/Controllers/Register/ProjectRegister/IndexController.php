<?php

namespace App\Http\Controllers\Register\ProjectRegister;

use App\Http\Controllers\Register\IndexController as RegisterController;
use App\Http\Requests\Register\RegisterGetRequest;
use App\Http\Resources\Register\IndexResource;
use App\Models\Project\RegisterProject;

class IndexController extends RegisterController
{
    /**
     * @param RegisterGetRequest $request
     * @return IndexResource
     */
    public function __invoke(RegisterGetRequest $request)
    {
        $registers = RegisterProject::with('archive', 'registerType',  'fund', 'lastEpkAgreement', 'user', 'lastAk', 'lastTk', 'lastEkAgreement', 'lastEkAgreement.participants', 'lastEkAgreement.participants.user')
            ->permissions()
            ->filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($registers);
    }
}
