<?php

namespace App\Http\Controllers\Register\ProjectRegister;

use App\Http\Controllers\Register\BaseController;
use App\Http\Resources\Register\ShowResource;
use App\Models\Project\RegisterProject;
use App\Models\Register\Register;
use App\Models\Register\RegisterStatus;

class ShowController extends BaseController
{
    /**
     * @param int $id
     * @param Register|null $register
     * @return ShowResource|\Illuminate\Http\JsonResponse|void
     */
    public function __invoke(int $id, Register $register = null)
    {
        if (empty($register)) {
            $registerWithPermissions = RegisterProject::with('archive', 'registerType', 'fund', 'lastTk', 'lastAk')
                ->permissions()
                ->find($id);

            $register = Register::with('archive', 'registerType', 'fund', 'lastTk', 'lastAk')
                ->find($id);

            if (!empty($registerWithPermissions) && !empty($register)) {
                return new ShowResource($register);
            }

            if (empty($registerWithPermissions)) {
                if (!empty($register) && in_array($register->register_status_id, RegisterStatus::getApprovedStatuses())) {
                    return response()->json(['code' => 404, 'message' => 'Проекта  описи переведен  в  утвержденные'], 404);
                } else {
                    return response()->json(['code' => 403, 'message' => 'Доступ запрещен'], 403);
                }
            }
        }
    }
}
