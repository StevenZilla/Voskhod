<?php

namespace App\Http\Controllers\Register\ApprovedRegister;

use App\Http\Controllers\Register\IndexController as RegisterController;
use App\Http\Requests\Register\RegisterGetRequest;
use App\Http\Resources\Register\ApprovedRegister\IndexResource;
use App\Models\Register\RegisterApproved;
use App\Services\SQL\SqlQuery;

class IndexController extends RegisterController
{
    /**
     * @param RegisterGetRequest $request
     * @return IndexResource
     */
    public function __invoke(RegisterGetRequest $request)
    {
        $registers = RegisterApproved::with('archive', 'registerType', 'fund', 'tk')
            ->permissions()
            ->filters($request)
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($registers);
    }
}
