<?php

namespace App\Http\Controllers\Register\ApprovedRegister\RegisterPart;

use App\Models\Register\Register;
use App\Http\Requests\RegisterPartRequest;
use App\Http\Controllers\Register\BaseController;
use App\Http\Resources\Register\ApprovedRegister\RegisterPart\DossierInRegisterResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\Register\ApprovedRegister\RegisterPart\ShowApprovedAggregateResource;

class ShowAggregateController extends BaseController
{
    /**
     * @param RegisterPartRequest $request
     * @param $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function __invoke(RegisterPartRequest $request, $id)
    {
        try {
            $register = Register::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Описи с переданным id ' . $id . ' не существует');
        }

        $register_parts = $register->registerPart()->orderBy('register_part.time')
            ->withFilters($request)->get(['id']);

        $dossierInRegisterOnRegisterPartNull = $register->dossierInRegisterOnRegisterPartNull;
        if (!$request->has('id')) {
            $dossier = DossierInRegisterResource::collection($dossierInRegisterOnRegisterPartNull);
        } else {
            $dossier = [];
        }

        $tmpObj['id'] = null;
        $tmpObj['is_dossiers'] = !empty($resultEds);
        $tmpObj['dossiers'] = $dossier;

        $registerParts = ShowApprovedAggregateResource::collection($register_parts)->additional([''])->collection;
        $registerParts->prepend($tmpObj);

        return response(['register_parts' => $registerParts], 200);
    }
}
