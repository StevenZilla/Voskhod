<?php

namespace App\Http\Controllers\Register\ApprovedRegister\RegisterPart;

use App\Http\Controllers\Register\BaseController;
use App\Http\Requests\RegisterPartRequest;
use App\Http\Resources\Register\ApprovedRegister\RegisterPart\ShowApprovedResource;
use App\Models\Register\RegisterPart;

class ShowController extends BaseController
{
    /**
     * @param RegisterPartRequest $request
     * @param $id
     * @return null[]
     */
    public function __invoke(RegisterPartRequest $request, $id)
    {
        $query = RegisterPart::where('register_id', '=', $id);

        if ($request->has('id')) {
            $register_parts = $query->where('id', '=', $request->id);
        }

        $register_parts = $query->orderBy('time')->get();
        $register_parts_resource = ShowApprovedResource::collection($register_parts);
        return ['register_parts' => $register_parts_resource ?: null];
    }
}
