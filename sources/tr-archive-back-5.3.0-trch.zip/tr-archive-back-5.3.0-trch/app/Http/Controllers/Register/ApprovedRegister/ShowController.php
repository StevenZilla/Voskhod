<?php

namespace App\Http\Controllers\Register\ApprovedRegister;



use App\Http\Controllers\Register\BaseController;
use App\Http\Resources\Register\ShowResource;
use App\Models\Project\RegisterProject;
use App\Models\Register\Register;
use App\Models\Register\RegisterApproved;
use App\Models\Register\RegisterStatus;

class ShowController extends BaseController
{
    /**
     * @param int $id
     * @param Register|null $register
     * @return ShowResource|\Illuminate\Http\JsonResponse
     */
    public function __invoke(int $id, Register $register = null)
    {
        if (empty($register)) {
            $registerWithPermissions = RegisterApproved::with('archive', 'registerType', 'fund', 'lastTk', 'lastAk')
                ->permissions()
                ->find($id);

            $register = Register::with('archive', 'registerType', 'fund', 'lastTk', 'lastAk')
                ->find($id);

            if (!empty($registerWithPermissions) && !empty($register)) {
                return new ShowResource($register);
            }

            if (empty($registerWithPermissions)) {
                if (!empty($register) && !in_array($register->register_status_id, RegisterStatus::getApprovedStatuses())) {
                    return response()->json(['code' => 404, 'message' => 'Существует только проект сводной описи'], 404);
                } elseif (empty($register)) {
                    return response()->json(['code' => 404, 'message' => 'Сводная опись отсутствует в системе.'], 404);
                } else {
                    return response()->json(['code' => 403, 'message' => 'Доступ запрещен'], 403);
                }
            }
        }
    }
}
