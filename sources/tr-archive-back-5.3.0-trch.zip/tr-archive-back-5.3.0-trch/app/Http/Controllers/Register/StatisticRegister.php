<?php

namespace App\Http\Controllers\Register;

use App\Models\Statistic\StatisticRegister as StatisticRegisterModel;
use App\Http\Resources\Register\StatisticRegister as StatisticRegisterResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class StatisticRegister extends BaseController
{
    /**
     * @param $id
     * @return StatisticRegisterResource
     */
    public function __invoke($id)
    {
        $statisticRegister = StatisticRegisterModel::where('register_id', $id)->first();

        if (empty($statisticRegister)) {
            return null;
        }

        return new StatisticRegisterResource($statisticRegister);
    }
}
