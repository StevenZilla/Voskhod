<?php

namespace App\Http\Controllers\Register;

use App\Http\Resources\Register\ShowResource;
use App\Models\Register\Register;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowController extends BaseController
{

    /**
     * @param $id
     * @return ShowResource
     */
    public function __invoke($id)
    {
        try {
            $register = Register::with('archive', 'registerType', 'fund', 'lastTk', 'lastAk')
                ->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Описи с переданным id '.$id.' не существует');
        }

        return new ShowResource($register);
    }
}
