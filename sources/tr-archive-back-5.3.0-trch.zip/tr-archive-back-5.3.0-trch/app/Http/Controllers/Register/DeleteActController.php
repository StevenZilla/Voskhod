<?php

namespace App\Http\Controllers\Register;

use App\Services\Register\RegisterService;
use App\Http\Controllers\Controller;
use App\Http\Resources\Register\DeleteActResource;
use Illuminate\Http\Response;

class DeleteActController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param $id
     * @return Response
     */
    public function __invoke($id)
    {
        $deleteAct = RegisterService::getDeleteActs($id);
        return response(['delete_acts' => DeleteActResource::collection($deleteAct)], 200);
    }
}
