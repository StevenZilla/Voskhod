<?php

namespace App\Http\Controllers\Register;

use App\Http\Controllers\Controller;
use App\Services\Register\RegisterService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(RegisterService $service)
    {
        $this->service = $service;
    }
}
