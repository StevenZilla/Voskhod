<?php

namespace App\Http\Controllers;

use App\Models\HandBooks\SaveType;
use Illuminate\Http\Request;

class SaveTypeController extends Controller
{
    public function index(Request $request)
    {
        return ['save_types' => SaveType::withFilter($request)->withOrderDefault($request)->get()];
    }
}
