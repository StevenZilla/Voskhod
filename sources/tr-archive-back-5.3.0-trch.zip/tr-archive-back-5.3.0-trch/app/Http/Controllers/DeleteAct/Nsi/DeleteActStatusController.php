<?php

namespace App\Http\Controllers\DeleteAct\Nsi;

use App\Http\Controllers\Controller;
use App\Http\Resources\DeleteAct\Nsi\DeleteActStatusResource;
use App\Models\DeleteAct\DeleteActStatus;
use Illuminate\Http\Request;

class DeleteActStatusController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        return response(DeleteActStatusResource::collection(DeleteActStatus::get()));
    }
}
