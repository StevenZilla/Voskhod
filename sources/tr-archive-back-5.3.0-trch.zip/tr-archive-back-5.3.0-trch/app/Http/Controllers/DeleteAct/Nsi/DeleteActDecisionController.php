<?php

namespace App\Http\Controllers\DeleteAct\Nsi;

use App\Http\Controllers\Controller;
use App\Http\Resources\DeleteAct\Nsi\DeleteActDecisionResource;
use App\Models\DeleteAct\DeleteAct;
use App\Models\DeleteAct\DeleteActDecisionType;
use Illuminate\Http\Request;

class DeleteActDecisionController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        return response(DeleteActDecisionResource::collection(DeleteActDecisionType::get()));
    }
}
