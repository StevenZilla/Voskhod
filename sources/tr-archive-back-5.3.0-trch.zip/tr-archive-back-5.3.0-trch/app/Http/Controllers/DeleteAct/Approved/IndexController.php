<?php

namespace App\Http\Controllers\DeleteAct\Approved;

use Illuminate\Http\Request;
use App\Models\DeleteAct\DeleteActStatus;
use App\Models\DeleteAct\DeleteActApproved;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Resources\DeleteAct\Approved\IndexResource;

class IndexController extends BaseController
{
    public function __invoke(Request $request)
    {
        $deleteActs = DeleteActApproved::with('deleteActStatus')->where(
            'delete_act_status_id',
            DeleteActStatus::getStatusApproved()
        )->filters($request)
            ->permissions()
            ->orderDefault($request, 'num', 'asc', 'collate "C"')->orders($request)->autoPaginate($request);
        return new IndexResource($deleteActs);
    }
}
