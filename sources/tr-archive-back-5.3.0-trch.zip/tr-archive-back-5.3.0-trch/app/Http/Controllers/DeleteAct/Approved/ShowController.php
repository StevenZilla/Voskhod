<?php

namespace App\Http\Controllers\DeleteAct\Approved;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Resources\DeleteAct\Approved\ShowResource;

class ShowController extends BaseController
{
    public function __invoke($id, Request $request)
    {
        $data = $this->service->showApproved($id);
        return response(new ShowResource($data), 200);
    }
}
