<?php

namespace App\Http\Controllers\DeleteAct;

use Illuminate\Http\Request;
use App\Models\DeleteAct\DeleteAct;
use App\Http\Controllers\Controller;
use App\Http\Resources\DeleteAct\IndexResource;

class IndexController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $deleteActs = DeleteAct::with('deleteActStatus')->filters($request)
            ->permissions()
            ->orderDefault($request, 'num', 'asc', 'collate "C"')->orders($request)->get();
        return new IndexResource($deleteActs);
    }
}
