<?php

namespace App\Http\Controllers\DeleteAct\Project;

use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Resources\DeleteAct\Project\ShowResource;

class ShowController extends BaseController
{
    public function __invoke($id, Request $request)
    {
        $data = $this->service->showProject($id);
        return response(new ShowResource($data), 200);
    }
}
