<?php

namespace App\Http\Controllers\DeleteAct\Project;

use App\Models\Ed\Ed;
use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
use App\Http\Controllers\Controller;
use App\Models\Dossier\DossierStatus;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Resources\DeleteAct\Project\Parts\PartsEdResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsDossierResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsRegisterResource;

class ExpiredDocumentsListViewController extends Controller
{

    // список описей, дел и документов для отрисовки на фронте без изменений в БД

    public function __invoke($id, Request $request)
    {
        if ($request->has('eds')) {
            $edsId = $request->input('eds');
            $edsId = str_replace(['[', ']'], '', $edsId);
            $edsId = trim($edsId, ',');
            $edsId = explode(',', $edsId);
            // dump($edsId);
            $eds = Ed::with('dossier', "getMediaType")->whereNotNull("temp_save_period")->whereIn('id', $edsId)->get();
            $edsList = new Collection();
            $registers = [];
            $dossierIds = $eds->pluck("dossier_id", "id");
            $dossiersList = new Collection();
            $dossiers = Dossier::with("dossierInRegister", "diKind", "saveType")->whereIn("id", $dossierIds)->where("dossier.dossier_status_id", DossierStatus::getIdClosed())->get();
            foreach ($dossiers as $key => $dossier) {
                $tmp = [];
                $tmp = $eds->where('dossier_id', $dossier->id);
                $dossiers[$key]->edsList = $tmp;
                $register = $dossier->register;
                if (!$register->isEmpty()) {
                    $register = $dossier->register->first();
                    $dossier->order_in_register = $dossier->dossierInRegister->first()->order_in_register;
                    if (isset($registers[$register->id])) {
                        $register = $registers[$register->id];
                        unset($dossier['register']);
                        $tmp_dossiers = $register->dossiersList;
                        $tmp_dossiers[] = $dossier;
                        $register->dossiersList = $tmp_dossiers;
                    } else {
                        $tmpDossier = [];
                        $tmpDossier[] = $dossier;
                        unset($dossier['register']);
                        $register->dossiersList = $tmpDossier;
                    }

                    if (isset($registers[$register->id])) {
                        $register = $registers[$register->id];
                        $register->edsList = $register->edsList->merge($tmp); //array_merge($register->edsList, $tmp);
                    } else {
                        $tmpDossier = [];
                        $tmpDossier[] = $dossier;
                        $register->edsList = $tmp;
                    }
                    $registers[$register->id] = $register;
                } else {
                    $edsList = $edsList->merge($tmp);
                    unset($dossier->register);
                    $dossiersList->push($dossier);
                }
            }

            $registerCollection = new Collection($registers);
            $partEds = PartsEdResource::collection($edsList);
            $partsRegister = PartsRegisterResource::collection($registerCollection);
            $partsDossier = PartsDossierResource::collection($dossiersList);
            return response(['registers' => $partsRegister, 'dossiers' => $partsDossier, 'eds' => $partEds], 200);
        }
    }
}
