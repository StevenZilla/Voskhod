<?php

namespace App\Http\Controllers\DeleteAct\Project;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Requests\DeleteAct\Project\UpdateRequest;

class UpdateController extends BaseController
{
    public function __invoke($id, UpdateRequest $request)
    {
        $data = $request->validated();
        $this->validateService->updateValidate($id, $data);
        $this->service->update($id, $data);
        // если статус акта - доработка замечаний архивиста - перевести  в статус проект
    }
}
