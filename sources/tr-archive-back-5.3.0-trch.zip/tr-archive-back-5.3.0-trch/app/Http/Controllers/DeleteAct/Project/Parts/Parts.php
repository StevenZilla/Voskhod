<?php

namespace App\Http\Controllers\DeleteAct\Project\Parts;

use App\Models\Ed\Ed;
use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
// use App\Models\Register\Register;
// use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\Dossier\DossierStatus;
use Illuminate\Database\Eloquent\Collection;
// use App\Http\Resources\DeleteAct\Project\Parts\PartsResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsEdResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsDossierResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsRegisterResource;

class Parts extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        $eds = Ed::with(["dossier" => function ($q) {
            $q->withTrashed();
        }, "getMediaType"])->withTrashed()->where("delete_act_id", $id)->get();
        $edsList = new Collection();
        $registers = [];
        $dossierIds = $eds->pluck("dossier_id", "id");
        $dossiersList = new Collection();
        $dossiers = Dossier::with("dossierInRegister", "diKind", "saveType")->withTrashed()->whereIn("id", $dossierIds)->where("dossier.dossier_status_id", DossierStatus::getIdClosed())->get();
        foreach ($dossiers as $key => $dossier) {
            $tmp = [];
            $tmp = $eds->where('dossier_id', $dossier->id);
            // $dossiers[$key]->edsList = $tmp;
            $register = $dossier->register;

            if (!$register->isEmpty()) {
                $register = $dossier->register->first();
                $dossier->order_in_register = $dossier->dossierInRegister->first()->order_in_register;
                if (isset($registers[$register->id])) {
                    $register = $registers[$register->id];
                    unset($dossier['register']);
                    $tmp_dossiers = $register->dossiersList;
                    $tmp_dossiers[] = $dossier;
                    $register->dossiersList = $tmp_dossiers;
                } else {
                    $tmpDossier = [];
                    $tmpDossier[] = $dossier;
                    unset($dossier['register']);
                    $register->dossiersList = $tmpDossier;
                }

                if (isset($registers[$register->id])) {
                    $register = $registers[$register->id];
                    // unset($dossier['register']);
                    $register->edsList = $register->edsList->merge($tmp); //array_merge($register->edsList, $tmp);
                } else {
                    $tmpDossier = [];
                    $tmpDossier[] = $dossier;
                    // unset($dossier['register']);
                    $register->edsList = $tmp;
                }
                $registers[$register->id] = $register;
            } else {
                // $dossier->edsList = $tmp->toArray();
                $edsList = $edsList->merge($tmp);
                unset($dossier->register);
                $dossiersList->push($dossier);
            }
        }

        $registerCollection = new Collection($registers);
        $partEds = PartsEdResource::collection($edsList);
        $partsRegister = PartsRegisterResource::collection($registerCollection);
        $partsDossier = PartsDossierResource::collection($dossiersList);
        return response(['registers' => $partsRegister, 'dossiers' => $partsDossier, 'eds' => $partEds], 200);
    }
}
