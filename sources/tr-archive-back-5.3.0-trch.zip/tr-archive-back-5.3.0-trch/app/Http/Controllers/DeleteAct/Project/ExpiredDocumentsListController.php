<?php

namespace App\Http\Controllers\DeleteAct\Project;

use App\Models\Ed\Ed;
use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
use App\Http\Controllers\Controller;
use App\Models\Dossier\DossierStatus;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Resources\DeleteAct\Project\Parts\PartsEdResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsDossierResource;
use App\Http\Resources\DeleteAct\Project\Parts\PartsRegisterResource;
use App\Http\Resources\DeleteAct\Project\ExpiredDocumentsList\DossierResource;
use App\Http\Resources\DeleteAct\Project\ExpiredDocumentsList\RegisterResource;

class ExpiredDocumentsListController extends Controller
{

    // список описей, дел и документов с истёкшим сроком хранения

    public function __invoke($id, Request $request)
    {
        $eds = Ed::with('dossier', "getMediaType")->whereNotNull("temp_save_period")->whereIn('delete_act_id', [$id, null])->get();
        $edsList = new Collection();
        $registers = [];
        $dossierIds = $eds->pluck("dossier_id", "id");
        $dossiersList = new Collection();
        $dossiers = Dossier::with("dossierInRegister", "diKind", "saveType")->whereIn("id", $dossierIds)->where("dossier.dossier_status_id", DossierStatus::getIdClosed())->get();
        foreach ($dossiers as $key => $dossier) {
            $tmp = [];
            $tmp = $eds->where('dossier_id', $dossier->id);
            $dossiers[$key]->edsList = $tmp;
            $register = $dossier->register;
            if (!$register->isEmpty()) {
                $register = $dossier->register->first();
                $dossier->order_in_register = $dossier->dossierInRegister->first()->order_in_register;
                if (isset($registers[$register->id])) {
                    $register = $registers[$register->id];
                    unset($dossier['register']);
                    $tmp_dossiers = $register->dossiersList;
                    $tmp_dossiers[] = $dossier;
                    $register->dossiersList = $tmp_dossiers;
                } else {
                    $tmpDossier = [];
                    $tmpDossier[] = $dossier;
                    unset($dossier['register']);
                    $register->dossiersList = $tmpDossier;
                }

                if (isset($registers[$register->id])) {
                    $register = $registers[$register->id];
                    $register->edsList = $register->edsList->merge($tmp); //array_merge($register->edsList, $tmp);
                } else {
                    $tmpDossier = [];
                    $tmpDossier[] = $dossier;
                    $register->edsList = $tmp;
                }
                $registers[$register->id] = $register;
            } else {
                $edsList = $edsList->merge($tmp);
                unset($dossier->register);
                $dossiersList->push($dossier);
            }
        }
        $registerCollection = new Collection($registers);
        $partsRegister = RegisterResource::collection($registerCollection);
        $partsDossier = DossierResource::collection($dossiersList);
        return response(['registers' => $partsRegister, 'dossiers' => $partsDossier], 200);
    }
}
