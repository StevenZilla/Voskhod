<?php

namespace App\Http\Controllers\DeleteAct\Project;

use Illuminate\Http\Request;
use App\Models\DeleteAct\DeleteAct;
use App\Models\DeleteAct\DeleteActStatus;
use App\Models\DeleteAct\DeleteActProject;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Resources\DeleteAct\Project\IndexResource;

class IndexController extends BaseController
{
    public function __invoke(Request $request)
    {
        $deleteActs = DeleteActProject::with('deleteActStatus')->where(
            'delete_act_status_id',
            '!=',
            DeleteActStatus::getStatusApproved()
        )->filters($request)
            ->permissions()
            ->orderDefault($request, 'num', 'asc', 'collate "C"')->orders($request)->autoPaginate($request);
        return new IndexResource($deleteActs);
    }
}
