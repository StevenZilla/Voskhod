<?php

namespace App\Http\Controllers\DeleteAct;



use App\Http\Controllers\Controller;
use App\Services\DeleteAct\AgreementService;
use App\Services\DeleteAct\AgreementValidationService;
use App\Services\DeleteAct\DeleteActService;
use App\Services\DeleteAct\DeleteActValidateService;
use App\Services\Dossier\DossierService;

class BaseController extends Controller
{
    public $service = null;
    public $validateService = null;
    public $agreementService = null;
    public $agreementValidationService = null;

    public function __construct(DeleteActService $service, DeleteActValidateService $validateService, AgreementService $agreementService, AgreementValidationService $agreementValidationService)
    {
        $this->service = $service;
        $this->validateService = $validateService;
        $this->agreementService = $agreementService;
        $this->agreementValidationService = $agreementValidationService;
    }
}
