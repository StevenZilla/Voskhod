<?php

namespace App\Http\Controllers\DeleteAct\Agreements;

use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Requests\DeleteAct\Agreements\SetAffirmativeDecisionRequest;

class SetAffirmativeDecisionController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * Согласование руководителем подразделения ОИК
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, SetAffirmativeDecisionRequest $request)
    {
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        $this->agreementService->setGuid($guidOIK);
        if (!empty($request->allFiles()['files_comment'])) {
            $this->agreementService->setFiles($request->allFiles()['files_comment']);
        }
        $data = $request->all();
        unset($data['files_comment']);
        $this->agreementValidationService->canSetAffirmativeValidate($id, $data);
        $this->agreementService->setAffirmativeDecision($id, $data);
        return response(null, 204);
    }
}
