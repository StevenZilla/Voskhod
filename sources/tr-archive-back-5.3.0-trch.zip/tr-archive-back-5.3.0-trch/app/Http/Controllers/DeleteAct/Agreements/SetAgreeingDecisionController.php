<?php

namespace App\Http\Controllers\DeleteAct\Agreements;


use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;

class SetAgreeingDecisionController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * Согласование акта
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        $this->agreementService->setGuid($guidOIK);
        if (!empty($request->allFiles()['files_comment'])) {
            $this->agreementService->setFiles($request->allFiles()['files_comment']);
        }
        $data = $request->all();
        unset($data['files_comment']);
        $this->agreementValidationService->canSetAgreeingDecisionValidate($id);
        $this->agreementService->setAgreeingDecision($id, $data);
        return response(null, 204);
    }
}
