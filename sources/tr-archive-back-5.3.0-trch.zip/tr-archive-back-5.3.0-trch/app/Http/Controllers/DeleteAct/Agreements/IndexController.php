<?php

namespace App\Http\Controllers\DeleteAct\Agreements;


use Exception;
use Illuminate\Http\Request;
use App\Exceptions\BaseException;
use App\Models\DeleteAct\DeleteAct;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Collection;
use App\Models\DeleteAct\Agreement\DeleteActAgreementType;
use App\Http\Resources\DeleteAct\Agreements\IndexResource;
use App\Http\Resources\DeleteAct\Agreements\OikHeadIndexResource;
use App\Http\Resources\DeleteAct\Agreements\ExpertCommissionIndexResource;
use App\Services\DeleteAct\AgreementService;

class IndexController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $deleteAct = DeleteAct::with(
                "agreements",
                "agreements.status",
                "agreements.user",
                "agreements.decisionType",
                "agreements.file_ep_signer",
                "agreements.agreementType",
                "agreements.deleteActParticipantInAgreement",
                "agreements.deleteActParticipantInAgreement.participant",
                "agreements.deleteActParticipantInAgreement.participant.user",
                "agreements.signers",
                "agreements.signers.user"
            )->findOrFail($id);
        } catch (Exception $e) {
            throw new BaseException("Акта об уничтожение ЭД с идентификатором {$id} не существует");
        }
        $deleteActExpertCommission = $deleteAct->agreements->where('type_id', DeleteActAgreementType::getTypeExpertCommission());




        $deleteActOikHead = $deleteAct->agreements->where('type_id', DeleteActAgreementType::getTypeOikHead());
        $data = new Collection();
        $data = $data->put('expert_commission', ExpertCommissionIndexResource::collection($deleteActExpertCommission));
        $data = $data->put('oik_head', OikHeadIndexResource::collection($deleteActOikHead));

        $agreementService = new AgreementService();
        $agreementService->setDeleteAct($deleteAct);

        $data = $data->put('view_buttons', [
            'can_agreeing' => $agreementService->canAgreeingButton(),
            'can_affirmative' => $agreementService->canAffirmativeButton(),
            'can_approve' => $agreementService->canApproveButton()
        ]);
        return response($data, 200);
    }
}
