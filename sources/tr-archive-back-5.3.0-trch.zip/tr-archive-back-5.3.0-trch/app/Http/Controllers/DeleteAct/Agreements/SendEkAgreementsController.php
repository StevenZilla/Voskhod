<?php

namespace App\Http\Controllers\DeleteAct\Agreements;


use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;

class SendEkAgreementsController extends BaseController
{
    /**
     * Handle the incoming request.
     * @param int $id
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        $this->agreementValidationService->sendEkAgreementsValidate($id);
        $this->agreementService->sendEkAgreement($id);
        return response(null, 204);
    }
}
