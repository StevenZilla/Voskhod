<?php

namespace App\Http\Controllers\DeleteAct\Agreements;

use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Requests\DeleteAct\Agreements\StoreRequest;

class StoreController extends BaseController
{
    public function __invoke($id, StoreRequest $request)
    {
        $data = $request->validated();
        $deleteAct = $this->agreementValidationService->storeValidate($id, $data);
        $deleteActAgreement = $this->agreementService->store($id, $data);
        return response(['message' => $deleteActAgreement->id, 'code' => 201], 201);
    }
}
