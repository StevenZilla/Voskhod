<?php

namespace App\Http\Controllers\DeleteAct\Agreements;

use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Requests\DeleteAct\Agreements\UpdateRequest;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, UpdateRequest $request)
    {
        $data = $request->validated();
        $this->agreementValidationService->updateValidate($id, $data);
        $this->agreementService->update($id, $data);
        return response(null, 200);
    }
}
