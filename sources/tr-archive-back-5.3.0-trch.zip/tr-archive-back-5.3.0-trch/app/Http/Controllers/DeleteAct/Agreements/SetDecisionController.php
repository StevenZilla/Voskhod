<?php

namespace App\Http\Controllers\DeleteAct\Agreements;

use Illuminate\Http\Request;
use App\Http\Controllers\DeleteAct\BaseController;
use App\Http\Requests\DeleteAct\Agreements\SetDecisionRequest;

class SetDecisionController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * Утверждение руководителем ОИК
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, SetDecisionRequest $request)
    {
        // dd($request);
        $data = $request->validated();
        $this->agreementValidationService->canSetDecisionValidate($id);
        $this->agreementService->setDecision($id, $data);
    }
}
