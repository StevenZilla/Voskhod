<?php

namespace App\Http\Controllers;

use App\Http\Requests\ShowEdInRegisterRequest;
use App\Models\Register\Register;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class EdInRegisterController extends Controller
{
    /**
     * @param ShowEdInRegisterRequest $request
     * @param $id
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function show(ShowEdInRegisterRequest $request, $id)
    {
        if (! $request->has('is_no_child')) {
            try {
                $edInRegisters = Register::findOrFail($id)->edInRegisterWithSort()
                    ->withFilters($request)->autoPaginate($request);
            } catch (ModelNotFoundException $e) {
                throw new ModelNotFoundException('Связи между ЭД и описи с переданным id '.$id.' не существует');
            }
        } else {
            try {
                $edInRegisters = Register::findOrFail($id)->edInRegisterWithSort()
                    ->where('register_part_id', $request->register_part_id ?? $request->id)
                    ->withFilters($request)->autoPaginate($request);
            } catch (ModelNotFoundException $e) {
                throw new ModelNotFoundException('Связи между ЭД и описи с переданным id '.$id.' не существует');
            }
        }

        $edInRegistersToArray = $edInRegisters->toArray();
        foreach ($edInRegisters as $key => $edInRegister) {
            $edInRegistersToArray['ed_in_registers'][$key] = $edInRegister->formatEd();

            if (empty($edInRegistersToArray['ed_in_registers'][$key])) {
                unset($edInRegistersToArray['ed_in_registers'][$key]);
            }
        }
        $edInRegistersToArray['ed_in_registers'] = array_values($edInRegistersToArray['ed_in_registers']);

        return $edInRegistersToArray;
    }
}
