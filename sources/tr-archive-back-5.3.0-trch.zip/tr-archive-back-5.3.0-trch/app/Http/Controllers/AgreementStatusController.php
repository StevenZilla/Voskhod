<?php

namespace App\Http\Controllers;

use App\Models\AgreementStatus;
use Illuminate\Http\Request;

class AgreementStatusController extends Controller
{
    public function index(Request $request)
    {
        $agreement_status = AgreementStatus::withFilters($request)->withOrder($request)->withOrderDefault($request)->get();

        return ['agreement_statuses' => $agreement_status];
    }
}
