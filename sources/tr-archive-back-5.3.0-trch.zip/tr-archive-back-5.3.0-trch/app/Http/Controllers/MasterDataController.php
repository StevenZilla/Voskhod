<?php

namespace App\Http\Controllers;

use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class MasterDataController extends BaseController
{
    /**
     * @return array|\Illuminate\Http\JsonResponse
     * Возвращает инстанции из мастера подключения
     */
    public function getOik()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            try {
                $sqlGetOik = 'select * from get_oik;';
                $infoConnection = DB::connection('master')->table('get_oik')->exists()
                    ? DB::connection('master')->select($sqlGetOik)
                    : null;

                if (! empty($infoConnection)) {
                    $resultOiks = array_map(function ($inf) {
                        return [
                            'name' => $inf->name,
                            'description' => $inf->description,
                            'uid' => $inf->guid,
                            'id_app' => $inf->id_app,
                        ];
                    }, $infoConnection);

                    return ['oiks' => $resultOiks];
                } else {
                    return response()->json(['code' => 204,  'message' => 'Нет данных'], 204);
                }
            } catch (\Exception $exception) {
                Log::error("Не смогли получить список инстанций.\n\n{$exception}");

                return response()->json(['code' => 400, 'message' => 'Не смогли получить список инстанций.'], 400);
            }
        } else {
            $params = SystemParam::whereIn('code', ['name_oik', 'guid_oik_in_medo', 'identificator_app'])->pluck('value', 'code')->all();
            return ['oiks' => [
                [
                    'name' => $params['name_oik'],
                    'description' => 'Локальный тр-архив',
                    'uid' => $params['guid_oik_in_medo'],
                    'id_app' => $params['identificator_app'],
                ],
            ]];
        }
    }
}
