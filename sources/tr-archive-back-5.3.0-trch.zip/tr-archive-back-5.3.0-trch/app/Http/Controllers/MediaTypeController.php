<?php

namespace App\Http\Controllers;

use App\Models\HandBooks\MediaTypeDossier;

class MediaTypeController extends Controller
{
    public function index()
    {
        return MediaTypeDossier::get();
    }
}
