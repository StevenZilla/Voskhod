<?php

namespace App\Http\Controllers;

use App\Services\SessionService;
use Illuminate\Http\Request;

class EpController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function makeEp(Request $request)
    {
        $checkSession = SessionService::checkSession($request->sessionId);
        if ($checkSession->getStatusCode() === 400) {
            return response()->json(['code' => 400, 'message' => 'Сессия неактивна'], 400);
        }
    }
}
