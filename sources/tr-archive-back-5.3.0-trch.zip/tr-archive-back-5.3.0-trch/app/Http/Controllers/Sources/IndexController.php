<?php

namespace App\Http\Controllers\Sources;

use App\Http\Requests\Source\IndexSourceRequest;
use App\Models\HandBooks\Source;

class IndexController
{
    public function __invoke(IndexSourceRequest $request)
    {
        return Source::withFilters($request)
            ->withOrderDefault($request)
            ->withOrder($request)
            ->withPaginate($request);
    }
}
