<?php

namespace App\Http\Controllers\Sources;

use App\Http\Requests\Source\StoreSourceRequest;
use App\Models\HandBooks\Source;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;

class StoreController
{
    public function __invoke(StoreSourceRequest $request)
    {
        $data = $request->validated();
        try {
            $source = new Source();
            $source['actual_date'] = Carbon::now()->toDateTimeString();
            $source['name'] = $data['value'];
            $source['code'] = $data['code'];
            $source['description'] = $data['descr'];
            $source->save();

            return response()->json(['code' => 201, 'message' => $source->id], 201);
        } catch (Exception $e) {
            Log::error("Ошибка! Источник не создан. $e");

            return response()->json(['code' => 400, 'message' => 'Дублируются данные источника'], 400);
        }
    }
}
