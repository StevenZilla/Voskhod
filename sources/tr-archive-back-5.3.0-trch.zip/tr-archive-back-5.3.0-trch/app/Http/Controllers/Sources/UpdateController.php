<?php

namespace App\Http\Controllers\Sources;

use App\Http\Requests\Source\UpdateSourceRequest;
use App\Models\HandBooks\Source;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;

class UpdateController
{
    public function __invoke(int $id, UpdateSourceRequest $request)
    {
        $data = $request->validated();
        try {
            $source = Source::findOrFail($id);
            $newData['name'] = $data['value'];
            $newData['description'] = $data['descr'];
            $newData['code'] = $data['code'];
            $newData['actual_date'] = Carbon::now()->toDateTimeString();
            $source->update($newData);

            return response(['code' => 200, 'message' => $id], 200);
        } catch (Exception $e) {
            Log::error("Ошибка! Источник не отредактирован. $e");

            return response(['code' => 404, 'message' => 'Источник не найден'], 404);
        }
    }
}
