<?php

namespace App\Http\Controllers;

use App\Http\Requests\DirectoryRequest;
use App\Models\Message\MessageType;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;

class MessageTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param DirectoryRequest $request
     * @return array
     */
    public function index(DirectoryRequest $request)
    {
        return [
            'message_types' => MessageType::withFilter($request)
                ->withOrderDefault($request)
                ->withOrder($request)
                ->get(),
        ];
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Collection|Model|JsonResponse
     */
    public function show($id)
    {
        try {
            $messageType = MessageType::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Типа сообщения с переданным id '.$id.' не существует');
        }

        return $messageType;
    }
}
