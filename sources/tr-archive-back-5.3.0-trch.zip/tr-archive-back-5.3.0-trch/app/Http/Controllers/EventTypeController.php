<?php

namespace App\Http\Controllers;

use App\Models\Event\EventType;

class EventTypeController extends BaseController
{
    /**
     * @return mixed
     */
    public function index()
    {
        return EventType::get();
    }
}
