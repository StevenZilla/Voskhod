<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Http\Requests\VipNet\VipNetSignRequest;
use App\Services\VipNet\VipNet;
use Illuminate\Http\Request;

class SignController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(VipNetSignRequest $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->signWithRequest($request->allFiles()['files'], $request->get('data'));
    }
}
