<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Http\Requests\VipNet\VipNetCheckHashR34112012512Request;
use App\Http\Requests\VipNet\VipNetHashR34112012512Request;
use App\Http\Requests\VipNet\VipNetSignRequest;
use App\Http\Requests\VipNet\VipNetVerifyInfoRequest;
use App\Services\VipNet\VipNet;

class VipNetController extends Controller
{
    public function getCerts()
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->getCerts();
    }

    public function sign(VipNetSignRequest $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->signWithRequest($request->allFiles()['files'], $request->get('data'));
    }

    public function verifyInfo(VipNetVerifyInfoRequest $request)
    {
        $fileSig = ! empty($request->allFiles()['fileSig']) ? $request->allFiles()['fileSig'] : null;

        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->verifyInfoWithRequest($request->allFiles()['file'], $fileSig);
    }

    public function hashR34112012512(VipNetHashR34112012512Request $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->hashR34112012512WithRequest($request->allFiles()['file']);
    }

    public function checkHashR34112012512(VipNetCheckHashR34112012512Request $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->checkHashR34112012256WithRequest($request->allFiles()['file'], $request->get('hash'));
    }
}
