<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Http\Requests\VipNet\VipNetCheckHashR34112012512Request;
use App\Services\VipNet\VipNet;
use Illuminate\Http\Request;

class CheckHashR34112012512Controller extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(VipNetCheckHashR34112012512Request $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->checkHashR34112012256WithRequest($request->allFiles()['file'], $request->get('hash'));
    }
}
