<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Http\Requests\VipNet\VipNetVerifyInfoRequest;
use App\Services\VipNet\VipNet;
use Illuminate\Http\Request;

class VerifyInfoController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(VipNetVerifyInfoRequest $request)
    {
        $fileSig = ! empty($request->allFiles()['fileSig']) ? $request->allFiles()['fileSig'] : null;

        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->verifyInfoWithRequest($request->allFiles()['file'], $fileSig);
    }
}
