<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Http\Requests\VipNet\VipNetHashR34112012512Request;
use App\Services\VipNet\VipNet;
use Illuminate\Http\Request;

class HashR34112012512Controller extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(VipNetHashR34112012512Request $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->hashR34112012512WithRequest($request->allFiles()['file']);
    }
}
