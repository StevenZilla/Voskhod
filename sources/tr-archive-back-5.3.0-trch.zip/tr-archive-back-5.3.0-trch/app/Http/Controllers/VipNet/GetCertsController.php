<?php

namespace App\Http\Controllers\VipNet;

use App\Http\Controllers\Controller;
use App\Services\VipNet\VipNet;
use Illuminate\Http\Request;

class GetCertsController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $vipnet = new VipNet();
        $vipnet->auth();

        return $vipnet->getCerts();
    }
}
