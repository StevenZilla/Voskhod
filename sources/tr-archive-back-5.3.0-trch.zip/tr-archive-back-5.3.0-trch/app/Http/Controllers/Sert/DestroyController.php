<?php

namespace App\Http\Controllers\Sert;

use Exception;
use App\Models\Sert\Sert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DestroyController extends Controller
{

    public function __invoke($id)
    {
        try {
            $sert = Sert::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Сертификата с переданным id ' . $id . ' не существует');
        }

        try {
            $sert->delete();
        } catch(Exception $e) {
            Log::error("Ошибка удаления сертификата" . $e);
            return response("Ошибка удаления сертификата");
        }
        return response(null,200);
    }
}
