<?php

namespace App\Http\Controllers;

use App\Models\AgreementType;
use Illuminate\Http\Request;

class AgreementTypeController extends Controller
{
    public function index(Request $request)
    {
        $agreement_type = AgreementType::withFilters($request)->withOrder($request)->withOrderDefault($request)->get()->toArray();

        return ['agreement_types' => $agreement_type];
    }
}
