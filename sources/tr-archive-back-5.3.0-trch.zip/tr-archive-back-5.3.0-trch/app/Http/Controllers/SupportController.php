<?php

namespace App\Http\Controllers;

use App\Models\System\SystemParam;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\SupportRequest;
use App\Facades\SendMailServiceFacade;

class SupportController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(SupportRequest $request)
    {
        $data = $request->validated();
        $nameOik = SystemParam::where('code','name_oik')->pluck('value')->first();
        $subject = "Обращение пользователя системы «Архив»: $nameOik";
        $data['name_oik'] = $nameOik;
        $data['user'] = Auth::user();
        $email = SystemParam::where('code','support_email')->pluck('value')->first();
        if(!empty( $data['file'])){
            $attach[] = [
                'path' => $data['file']->getPathName(),
                'name' => $data['file']->getClientOriginalName(),
                'type'=> $data['file']->getMimeType(),
            ];
        } else {
            $attach = null;
        }
        unset($data['file']);
        SendMailServiceFacade::mail($email,  $subject, $data,'emails.supportMailable',null, $attach)->sendSync();
        return response(null,204);
    }
}
