<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Exceptions\CustomJsonException\CustomJsonException;
use App\Exceptions\EdException\EdException;
use App\Exceptions\PermissionException;
use App\Http\Requests\Ed\EdEditRequest;
use App\Http\Requests\Ed\EdGetRequest;
use App\Http\Requests\Ed\EdStoreRequest;
use App\Http\Requests\Ed\EdUpdatePatchRequest;
use App\Http\Requests\Ed\EdVerifyRequest;
use App\Jobs\ConverterFileJob;
use App\Models\Attribute\AttributeValue;
use App\Models\Ed\Ed;
use App\Models\Ed\EdStatus;
use App\Models\File\File;
use App\Models\File\FileRole;
use App\Models\HandBooks\MediaTypeED;
use App\Models\System\SystemParam;
use App\Models\Tk\TkStatus;
use App\Services\CheckFileForSignature;
use App\Services\Converter\ChangesNameFile;
use App\Services\Ed\CheckRequiredEd;
use App\Services\Ed\CreateAttrValueService;
use App\Services\FilesystemManager\MediaStorage;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use SplFileInfo;
use Webpatser\Uuid\Uuid;

class EdController extends BaseController
{
    /**
     * Display a listing of the resource.
     * @param EdGetRequest $request
     * @return array|JsonResponse
     */
    public function index(EdGetRequest $request)
    {
        $eds = Ed::with('source', 'dossier', 'attributeValue', 'attributeValue.attribute', 'file', 'file.role', 'file.extension', 'file.rel')
            ->permissions()
            ->orderDefault($request, 'num', 'asc', 'collate "C"')
            ->filters($request)
            ->orders($request)
            ->autoPaginate($request);

        return $eds;
    }

    /**
     * Store a newly created resource in storage.
     * @param EdStoreRequest $request
     * @return JsonResponse
     */
    public function store(EdStoreRequest $request)
    {
        $requestVerify = EdVerifyRequest::capture($request);
        $checkEpFiles = $this->verifySignature($requestVerify);
        if (SystemParam::getForbidInvalidEp() && !isset($checkEpFiles['code']) > 0) {
            throw new BaseException('Прием документов с невалидной ЭЦП запрещен.');
        }

        $data = json_decode($request->input('data'), true);

        $data['create_date'] = Carbon::now()->toDateTimeString();

        if (empty($data['media_type_id'])) {
            $data['media_type_id'] = MediaTypeED::where('name', 'Электронный вид')->pluck('id')->first();
        }

        if (empty($data['ed_status_id'])) {
            $data['ed_status_id'] = EdStatus::where('code', 'new')->pluck('id')->first();
        }

        if (isset($data['dossier_id'])) {
            $lastEd = Ed::where('dossier_id', $data['dossier_id'])->orderBy('created_at', 'DESC')->pluck('order_ed_in_dossier')->first() + 1;
            $data['order_ed_in_dossier'] = $lastEd;
        }

        $ed = DB::transaction(function () use ($data, $request, $checkEpFiles) {
            $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
            $document = new Ed($data);
            $document->save();
            $files = $request->all()['files_new'] ?? $request->all()['files'];
            $iterations = [];
            if (is_array($files) || is_object($files)) {
                $guid = Uuid::generate()->string;
                foreach ($files as $file) {
                    $isCorrectFile = false;
                    $index = -1;
                    foreach ($data['files'] as $fileInfo) {
                        $index++;
                        if ($fileInfo['file'] === $file->getClientOriginalName()) {
                            $isCorrectFile = true;
                            break;
                        }
                    }
                    if (!$isCorrectFile) {
                        Log::critical("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");
                        break;
                    }

                    if ($file->isValid()) {
                        $dataFile = MediaStorage::saveFileWithRequest($document, $file);
                        $messageError = '';
                        if (!empty($checkEpFiles) && !empty($checkEpFiles['error'])) {
                            foreach ($checkEpFiles['error'] as $epFile) {
                                if ($epFile['file_name'] === $file->getClientOriginalName()) {
                                    $messageError = $epFile['message'];
                                }
                            }
                        }
                        $fileModel = new File([
                            'name' => $dataFile['fileName'],
                            'size' => number_format($file->getSize(), 10),
                            'role_id' => $data['files'][$index]['fr_id'], // Взять из data
                            'ed_id' => $document->id,
                            'message_error' => $messageError,
                            'path' => $dataFile['pathToFile'],
                        ]);
                        $fileModel->setExtensionId($fileModel->getExtensionByName($fileInfo['file']));
                        $fileModel->save();
                        $curIdFiles[$data['files'][$index]['file']] = $fileModel->id;

                        $parentFileArray[$data['files'][$index]['file']] = $dataFile['fileName'];

                        if ($fileModel->role_id == 1) {
                            $iterations["data_to_array.files.{$index}.fr_id"][] = "Файл {$file->getClientOriginalName()} имеет роль документ.";
                            ConverterFileJob::dispatch($fileModel, $dataFile['pathToFile'], $guidOIK)->onQueue('converter_file_job');
                        }
                    }
                }

                $countFileWithRoleOne = File::where('role_id', 1)->where('ed_id', $document->id)->count();
                if ($countFileWithRoleOne > 1) {
                    if (!empty($iterations) && count($iterations) > 0) {
                        throw new CustomJsonException('Электронных документов с ролью "Документ" больше одного', $iterations, 'EAD');
                    } else {
                        throw new BaseException('Электронных документов с ролью "Документ" больше одного');
                    }
                } elseif ($countFileWithRoleOne < 1) {
                    throw new BaseException('Электронных документов с ролью "Документ" не существует');
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($parentFileArray[$file['parent_file']])) {
                        $listParentNewName[$file['parent_file']] = $parentFileArray[$file['parent_file']];
                    }
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($listParentNewName[$file['parent_file']])) {
                        $parentFile = File::where([
                            'name' => $listParentNewName[$file['parent_file']],
                            'ed_id' => $document->id,
                        ])->get();

                        DB::table($fileModel->getRelTableName())->insert([
                            'f1_id' => $curIdFiles[$file['file']],
                            'f2_id' => $parentFile[0]->id,
                        ]);
                    }
                }
            }

            if (!empty($data['attr'])) {
                foreach ($data['attr'] as $key => $item) {
                    $attrValueService = new CreateAttrValueService();
                    $idAttr[] = $attrValueService->make($item, $document->id);

                    if (end($idAttr) == false) {
                        $error['attr.' . $key] = 'Значение атрибута должно совпадать с выбранным типом';
                    }
                }
                if (!empty($error)) {
                    throw new EdException('Разные типы данных у атрибутов', $error, 'EAD');
                }
            }

            $dossier = !empty($data['dossier_id']) ? $data['dossier_id'] : null;
            CheckRequiredEd::checkRequiredEd($document, $dossier);

            return $document;
        });

        return response()->json(['code' => 201, 'message' => $ed->id], 201);
    }

    /**
     * Проверяет: совпадают ли метаданные переданных фалов с реальными названиями файлов.
     * @return bool
     */
    public function checkOriginalNameOfFiles($files, $data): bool
    {
        if (is_array($files) || is_object($files)) {
            foreach ($files as $file) {
                $isCorrectFile = false;
                foreach ($data['files'] as $fileInfo) {
                    if ($fileInfo['file'] === $file->getClientOriginalName()) {
                        $isCorrectFile = true;
                        break;
                    }
                }
                if (!$isCorrectFile) {
                    Log::critical("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");

                    return false;
                }
            }
        }

        return true;
    }

    public function verifySignature(EdVerifyRequest $request)
    {
        $guidOIK = session()->has('uid') ? session()->get('uid') : null;

        $systemForbidInvalidEp = SystemParam::getForbidInvalidEp();
        $resultData = [];
        $data = json_decode($request->input('data'), true);
        //Проверяем названия файлов из метаданных с реальным
        if (!empty($request->all()['files'])) {
            $files = $request->all()['files'];
            if (!$this->checkOriginalNameOfFiles($files, $data)) {
                $message = 'Реальные названия файлов не совпадают с метаданными';

                return response()->json(['code' => 400, 'message' => $message], 400);
            }
        }

        //Проверяем расширение переданных подписей, если в системных параметрах прием невалидной подписи запрещен, то выводим ошибку,
        // о несовместимости расширений, если нет, то продолжаем работу
        $extensionFileSigner = $this->checkExtensionFileSigner($data['files']);
        if (!empty($data['files']) && !empty($extensionFileSigner)) {
            $resultCheckExtensionFiles = $extensionFileSigner;
            $resultCheckExtensionFiles = array_merge(['is_forbid_invalid_ep' => $systemForbidInvalidEp], $resultCheckExtensionFiles);

            return $resultCheckExtensionFiles;
        } elseif (!empty($data['files'])) {
            //Ищем файлы с ролью "подпись"
            $roleSignatureId = FileRole::where('name', 'Подпись')->first()->id;
            $filesResult = [];

            //Проверка на существование родительского файла у подписи
            $arrayParentName = [];
            foreach ($data['files'] as $dataFile) {
                if (empty($dataFile['parent_file'])) {
                    $arrayParentName[] = $dataFile['file'];
                }
            }

            foreach ($data['files'] as $key => $dataFile) {
                if ($dataFile['fr_id'] === $roleSignatureId) {
                    if (empty($dataFile['parent_file'])) {
                        throw new HttpResponseException(response()->json([
                            'is_forbid_invalid_ep' => $systemForbidInvalidEp,
                            'code' => 400,
                            'message' => 'Валидация не пройдена',
                            'target' => 'EAD',
                            'error' => ["data_to_array.files.{$key}.parent_file" => 'Отсутствует родительский файл'],
                        ], 400));
                    } elseif (!in_array($dataFile['parent_file'], $arrayParentName)) {
                        throw new HttpResponseException(response()->json([
                            'is_forbid_invalid_ep' => $systemForbidInvalidEp,
                            'code' => 400,
                            'message' => 'Валидация не пройдена',
                            'target' => 'EAD',
                            'error' => ["data_to_array.files.{$key}.parent_file" => "Родительский файл {$dataFile['parent_file']} отсутствует"],
                        ], 400));
                    }

                    if (!empty($files) && empty($dataFile['id'])) {
                        foreach ($files as $keyFiles => $file) {
                            if ($dataFile['file'] === $file->getClientOriginalName()) {
                                $filesResult[$key]['signer'] = $file;
                                break;
                            }
                        }
                    } elseif (!empty($dataFile['id'])) {
                        try {
                            $signerFile = File::findOrFail($dataFile['id']);
                        } catch (ModelNotFoundException $e) {
                            throw new ModelNotFoundException('Файл с переданным id ' . $dataFile['id'] . ' не существует');
                        }
                        $filesResult[$key]['signer'] = [
                            'fileName' => $signerFile->name,
                            'filePath' => $signerFile->path,
                        ];
                    }

                    //Начинаем поиск родительского файла
                    foreach ($data['files'] as $parentDataFile) {
                        if ($parentDataFile['file'] === $dataFile['parent_file']) {
                            if (!empty($parentDataFile['id'])) {
                                try {
                                    $exitParentFile = File::findOrFail($parentDataFile['id']);
                                } catch (ModelNotFoundException $e) {
                                    throw new ModelNotFoundException('Файл с переданным id ' . $parentDataFile['id'] . ' не существует');
                                }
                                $filesResult[$key]['usualyFile'] = [
                                    'fileName' => $exitParentFile->name,
                                    'filePath' => $exitParentFile->path,
                                ];
                            } elseif (!empty($files) && empty($dataFile['id'])) {
                                foreach ($files as $parentFile) {
                                    if ($parentDataFile['file'] === $parentFile->getClientOriginalName()) {
                                        $filesResult[$key]['usualyFile'] = $parentFile;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //Сохраняем файлы
            if (!empty($filesResult)) {
                foreach ($filesResult as $key => $fileResult) {
                    $path = "tmpCheckSignerForFiles/$key/";
                    if (isset($fileResult['signer']) && $fileResult['signer'] instanceof UploadedFile) {
                        $resultNameFileSigner = ChangesNameFile::changesNameFile($fileResult['signer']->getClientOriginalName());
                        MediaStorage::disk('tmp')->putFileAs($path, $fileResult['signer'], $resultNameFileSigner); //Сохраняем временные файлы в tmp
                        $filesResult[$key]['signer'] = [
                            'fileName' => $fileResult['signer']->getClientOriginalName(),
                            'filePath' => $fileResult['signer']->getPathname(),
                        ];
                    }
                    if (isset($fileResult['usualyFile']) && $fileResult['usualyFile'] instanceof UploadedFile) {
                        $resultNameUsualyFile = ChangesNameFile::changesNameFile($fileResult['usualyFile']->getClientOriginalName());
                        MediaStorage::disk('tmp')->putFileAs($path, $fileResult['usualyFile'], $resultNameUsualyFile);
                        $filesResult[$key]['usualyFile'] = [
                            'fileName' => $fileResult['usualyFile']->getClientOriginalName(),
                            'filePath' => $fileResult['usualyFile']->getPathname(),
                        ];
                    }
                }
            }

            //Проверяем сохраненные файлы на возможность подписания ими
            foreach ($filesResult as $file) {
                if ((isset($file['usualyFile']) && is_array($file['usualyFile'])) &&
                    (isset($file['signer']) && is_array($file['signer']))
                ) {
                    $resultData[] = CheckFileForSignature::checkFileForSignature($file['usualyFile'], $file['signer']);
                }
            }

            $resultData = $this->getResultCheckEPWithErrors($resultData);

            try {
                MediaStorage::disk('tmp')->deleteDirectory('tmpCheckSignerForFiles'); // Удаляем временное хранилище
            } catch (BaseException $e) {
                Log::warning("Удалить временную дирректорию 'tmpCheckSignerForFiles' для проверки подписей в tmp не удалось, ошибка: " . $e->getMessage());
            }

            if (empty($resultData)) {
                return ['code' => 204];
            } else {
                return ['is_forbid_invalid_ep' => $systemForbidInvalidEp, 'error' => $resultData];
            }
        }
    }

    public function checkExtensionFileSigner($dataFiles)
    {
        $configExtentions = config('app.ed_need_extension');
        $needExtension = explode(',', $configExtentions);
        $signatureId = FileRole::where('name', 'Подпись')->first()->id;
        $result = [];

        foreach ($dataFiles as $file) {
            $extendionFile = new SplFileInfo($file['file']);
            if (!in_array($extendionFile->getExtension(), $needExtension) && $file['fr_id'] === $signatureId) {
                $result['error'][] = ['file_name' => $file['file'], 'message' => 'Неверный формат файла подписи',  'status' => false];
            }
        }

        return $result;
    }

    public function getResultCheckEPWithErrors($resultEp)
    {
        $result = [];
        foreach ($resultEp as $item) {
            if ($item['status'] === false) {
                $result[] = $item;
            }
        }

        return $result;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Collection|Model|JsonResponse
     */
    public function show($id)
    {
        $document = Ed::permissions()->with('source', 'dossier', 'attributeValue', 'attributeValue.attribute', 'file', 'file.role', 'file.extension', 'file.rel')
            ->find($id);

        if (empty($document)) {
            throw new PermissionException('Доступ запрещен');
        }

        return $document->detailtoArray();
    }

    private function checkExistsFileOfRequest($dataFiles, $realFiles)
    {
        foreach ($dataFiles as $dataFile) {
            if (!isset($dataFile['id'])) {
                foreach ($realFiles as $key => $realFile) {
                    if ($realFile->getClientOriginalName() === $dataFile['file']) {
                        break;
                    }
                    if (!empty($realFile) && count($realFiles) === $key + 1) {
                        throw new EdException('Файл ' . $dataFile['file'] . ' не приложен и не существует в БД');
                    }
                }
            }
        }
    }

    /**
     * Edit resource.
     * @param EdEditRequest $request
     * @return JsonResponse
     */
    public function fullUpdate(EdEditRequest $request, $id)
    {
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;

        $requestVerify = EdVerifyRequest::capture($request);
        $checkEpFiles = $this->verifySignature($requestVerify);
        if (SystemParam::getForbidInvalidEp() && !isset($checkEpFiles['code']) > 0) {
            throw new BaseException('Прием документов с невалидной ЭЦП запрещен.');
        }

        try {
            $document = Ed::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('ЭД с переданным id ' . $id . ' не существует');
        }

        if ($document->checkDossierStatus()) {
            return response()->json([
                'code' => 400,
                'message' => 'Документ нельзя редактировать, потому что дело закрыто',
            ], 400);
        }

        if ($document->lastTk()->whereIn('tk_status_id', [
            TkStatus::getIdSentToChKhED(),
            TkStatus::getIdDeliveredToChKhED(),
            TkStatus::getIdAcceptedToChKhED(),
            TkStatus::getIdInProcessingToChKhED(),
        ])->exists()) {
            Log::warning("У документа[{$id}] есть последний ТК со статусом ЦХЭДА");

            return response()->json([
                'code' => 400,
                'message' => 'У документа существует последний ТК со статусом ЦХЭДА',
            ], 400);
        }

        if ($document->registerOnApproval()) {
            Log::warning("У документа[{$id}] существует опись, которая имеет статус \"На утверждении\"");

            return response()->json([
                'code' => 400,
                'message' => 'У документа существует опись, которая имеет статус "На утверждении"',
            ], 400);
        }

        if ($document->registerOnStatusChed()) {
            Log::warning("Временное ограничение! У документа[{$id}] последняя опись со статусом ЦХЭДА");

            return response()->json([
                'code' => 400,
                'message' => 'Временное ограничение! У документа последняя опись со статусом ЦХЭДА',
            ], 400);
        }

        if (!$document->itWoktWithEd()) {
            Log::warning('Редактирование документа не возможно. У документа есть тк со статусом: ' . $document->lastTk->status->name);

            return response()->json([
                'code' => 400,
                'message' => 'Редактирование документа не возможно. У документа есть тк со статусом: ' . $document->lastTk->status->name,
            ], 400);
        }

        $data = json_decode($request->input('data'), true);

        if (empty($data['ed_status_id'])) {
            $data['ed_status_id'] = EdStatus::where('code', 'new')->pluck('id')->first();
        }

        DB::transaction(function () use ($data, $request, $document, $checkEpFiles, $guidOIK) {
            $document->update($data);

            if (!empty($data['attr'])) {
                foreach ($data['attr'] as $key => $item) {
                    $attrValueService = new CreateAttrValueService();
                    $idAttr[] = $attrValueService->make($item, $document->id);

                    if (end($idAttr) == false) {
                        $error['attr.' . $key] = 'Значение атрибута должно совпадать с выбранным типом';
                    }
                }
                if (!empty($error)) {
                    throw new EdException('Разные типы данных у атрибутов', $error, 'EAD');
                }
            }

            if (empty($data['media_type_id'])) {
                $data['media_type_id'] = MediaTypeED::where('name', 'Электронный вид')->pluck('id')->first();
            }

            AttributeValue::where('ed_id', $document->id)->whereNotIn('id', !empty($idAttr) ? $idAttr : [])->delete();

            $checkArray = ['source_id', 'source_ed_id', 'temp_save_period', 'updated_at'];

            if (count(array_diff_key($document->getChanges(), array_flip($checkArray))) > 0) {
                $checkCountUpdateEAD = true;
            }

            if ($edInRegister = $document->lastEdInRegister) {
                $register = $edInRegister->register;

                if (!$register->itWoktWithEd()) {
                    $register->resend_tk = true;
                }

                if ($register->lastAk) {
                    if ($register->lastAk->status->name == 'передан во временное хранилище') {
                        $register->resend_ak = true;
                    }
                }

                if (!empty($register->registerFile) && count($registerFiles = $register->registerFile) > 0) {
                    foreach ($registerFiles as $file) {
                        if ($file->type == 1 && !empty($file->path)) {
                            (new XmlRegisterController($register, $file))->createRegisterDescrXml();
                        } elseif ($file->type == 2) {
                            $file->sign_date = null;
                        }
                    }

                    $register->update_date = Carbon::now()->toDateTimeString();
                }

                $register->save();
            }

            $this->checkExistsFileOfRequest($data['files'], $request->all('files')['files']);

            $skipFiles = [];
            if (!empty($data['files'])) {
                $iterations = [];
                if (!empty($request->file('files')) && count($request->file('files')) > 0) {
                    $files = $request->all()['files_new'] ?? $request->all()['files'];
                    if (!empty($files)) {
                        foreach ($files as $file) {
                            $isCorrectFile = false;
                            $index = -1;
                            foreach ($data['files'] as $fileInfo) {
                                $index++;
                                if ($fileInfo['file'] === $file->getClientOriginalName()) {
                                    $isCorrectFile = true;
                                    break;
                                }
                            }

                            if (!$isCorrectFile) {
                                $skipFiles[] = $file->getClientOriginalName();
                                Log::critical("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");

                                throw new BaseException("Название файла[{$file->getClientOriginalName()}] отсутствуют в метаданных");
                                break;
                            }

                            if (!$file->isValid()) {
                                throw new BaseException($file->getClientOriginalName() . ' файл не валидный');
                            }
                        }
                    }
                }

                $path = MediaStorage::getDirectoryModel($document->file()->first('path'), 'path');

                foreach ($data['files'] as $keyFileInfo => $fileInfo) {
                    $checkPossibilityAdding = false;
                    if (!empty($fileInfo['id'])) {
                        try {
                            $fileModel = File::findOrFail($fileInfo['id']);
                        } catch (ModelNotFoundException $e) {
                            throw new ModelNotFoundException('Файла с переданным id ' . $fileInfo['id'] . ' не существует');
                        }
                        $fileModel->role_id = $fileInfo['fr_id']; // Взять из data

                        if ($fileModel->role_id !== $fileInfo['fr_id']) {
                            $checkCountUpdateEAD = true;
                        }

                        $checkPossibilityAdding = true;
                    } else {
                        $checkCountUpdateEAD = true;
                        $fileModel = new File();

                        if (!empty($files)) {
                            foreach ($files as $file) {
                                if ($file->getClientOriginalName() === $fileInfo['file']) {
                                    $checkPossibilityAdding = true;
                                    $dataFile = MediaStorage::saveFileWithRequest($document, $file);
                                    $messageError = '';
                                    if (!empty($checkEpFiles) && !empty($checkEpFiles['error'])) {
                                        foreach ($checkEpFiles['error'] as $epFile) {
                                            if ($epFile['file_name'] === $file->getClientOriginalName()) {
                                                $messageError = $epFile['message'];
                                            }
                                        }
                                    }

                                    $fileModel->name = $dataFile['fileName'];
                                    $fileModel->size = $file->getSize();
                                    $fileModel->role_id = $fileInfo['fr_id']; // Взять из data
                                    $fileModel->ed_id = $document->id;
                                    $fileModel->message_error = $messageError;
                                    $fileModel->path = $dataFile['pathToFile'];

                                    $iterations["data_to_array.files.{$keyFileInfo}.fr_id"][] = "Файл {$file->getClientOriginalName()} имеет роль документ.";
                                }
                            }
                        }
                    }

                    if ($checkPossibilityAdding) {
                        $fileNameArray = explode('.', $fileInfo['file']);
                        $extension = array_pop($fileNameArray);

                        $fileModel->setExtensionId($extension);
                        $fileModel->save();

                        if ($fileModel->role_id == 1 && $fileModel->viewer_path == null) {
                            ConverterFileJob::dispatch($fileModel, $path, $guidOIK)->onQueue('converter_file_job');
                        }

                        $curIdFiles[$fileInfo['file']] = $fileModel->id;

                        $parentFileArray[$fileInfo['file']] = $resultNameFile ?? $fileModel->name;

                        $idFile[] = $fileModel->id;
                    }
                }

                if (isset($idFile)) {
                    $otherFiles = File::where('ed_id', $document->id)->whereNotIn('id', $idFile)->get(['id', 'path', 'viewer_path']);
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($parentFileArray[$file['parent_file']])) {
                        $listParentNewName[$file['parent_file']] = $parentFileArray[$file['parent_file']];
                    }
                }

                foreach ($data['files'] as $file) {
                    if (!empty($file['parent_file']) && !empty($listParentNewName[$file['parent_file']])) {
                        if (!empty($otherFiles)) {
                            $parentFile = File::where([
                                'name' => $listParentNewName[$file['parent_file']],
                                'ed_id' => $document->id,
                            ])->whereNotIn('id', array_keys($otherFiles->getDictionary()))->first();

                            if (empty($curIdFiles[$file['file']])) {
                                throw new BaseException('Файл ' . $file['file'] . ' не приложен');
                            } else {
                                DB::table('file_file')->insert([
                                    'f1_id' => $curIdFiles[$file['file']],
                                    'f2_id' => $parentFile->id,
                                ]);
                            }
                        }
                    } elseif (!empty($file['id'])) {
                        $modelFile = File::where('id', $file['id'])
                            ->where('name', $file['file'])->where('ed_id', $document->id)
                            ->first();

                        if (!empty($modelFile) && !empty($modelFile->rel())) {
                            $modelFile->rel()->detach();
                        }
                    }
                }

                if (!empty($otherFiles)) {
                    foreach ($otherFiles as $otherFile) {
                        if (!empty($otherFile->rel())) {
                            $otherFile->rel()->detach();
                        }

                        $otherFile->delete();
                        $checkCountUpdateEAD = true;
                    }
                }

                $countFileWithRoleOne = File::where('role_id', 1)->where('ed_id', $document->id)->count();
                if ($countFileWithRoleOne > 1) {
                    if (!empty($iterations) && count($iterations) > 0) {
                        throw new CustomJsonException('Электронных документов с ролью "Документ" больше одного', $iterations, 'EAD');
                    } else {
                        throw new BaseException('Электронных документов с ролью "Документ" больше одного');
                    }
                } elseif ($countFileWithRoleOne < 1) {
                    if (!empty($data['files'])) {
                        foreach ($data['files'] as $fileKey => $file) {
                            if ($file['fr_id'] === 1) {
                                throw new EdException('Файл ' . $file['file'] . ' с ролью документ не приложен', ['files.' . $fileKey . 'name' => 'Файл не приложен']);
                            }
                        }
                    }
                    throw new BaseException('Электронных документов с ролью "Документ" не существует');
                }

                if (!empty($otherFiles)) {
                    $deleteFiles = MediaStorage::prefixFiles($otherFiles->pluck('path')->all());
                }

                if (!empty($deleteFiles)) {
                    MediaStorage::delete($deleteFiles);
                }
            }

            $dossier = !empty($data['dossier_id']) ? $data['dossier_id'] : null;
            CheckRequiredEd::checkRequiredEd($document, $dossier);

            if (!empty($checkCountUpdateEAD)) {
                if ($document->lastAk) {
                    $document->resend_ak = true;
                }
                $document->update_date = Carbon::now()->toDateTimeString();
            }
            $document->save();
        });

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }

    /**
     * Edit resource.
     * @param EdUpdatePatchRequest $request
     * @param $id
     * @return JsonResponse
     */
    public function update(EdUpdatePatchRequest $request, $id)
    {
        try {
            $document = Ed::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('ЭД с переданным id ' . $id . ' не существует');
        }

        if (!empty($request->getContent())) {
            $data = json_decode($request->getContent(), true);
            $validator = Validator::make($data, $request->rules());
            if ($validator->fails()) {
                return response()->json(['code' => 400, 'message' => $validator->errors()], 400);
            }
            if (!empty($data['ed_status_id']) && $data['ed_status_id'] === 5 && !$document->checkStatusProcessed()) {
                return response()->json(['code' => 412, 'message' => 'Не возможно установить статус \'Обработано\', у ЭД отсутствует источник или дело'], 412);
            }

            $document->update($data);
        }

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }
}
