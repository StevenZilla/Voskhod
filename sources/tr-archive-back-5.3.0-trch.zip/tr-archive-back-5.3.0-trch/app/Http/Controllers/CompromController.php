<?php

namespace App\Http\Controllers;

use App\Http\Requests\EditCompromRequest;
use App\Http\Resources\CompromController\GetPasswordsResource;
use App\Models\User\CompromPassword;
use Illuminate\Http\Request;

class CompromController extends Controller
{
    public function getPasswords(Request $request)
    {
        $comproms = CompromPassword::WithFilter($request)->get();

        return GetPasswordsResource::collection($comproms);
    }

    public function editComprom(EditCompromRequest $request)
    {
        $data = $request->all();

        if (! empty($data) && count($data)) {
            foreach ($data as $key => $item) {
                if (isset($item['id'])) {
                    $comprom = CompromPassword::findOrFail($item['id']);
                } else {
                    $comprom = new CompromPassword();
                }

                $comprom->password = $item['value'];
                $comprom->save();
            }
        }

        return response()->json(['code' => 201, 'message' => 'true'], 201);
    }
}
