<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\ChangeGuidTKRequest;
use App\Http\Requests\Tk\ChangesStatusTkOnRegisterRequest;
use App\Http\Requests\Tk\CreateAkRequest;
use App\Http\Requests\TkRequest;
use App\Http\Requests\TkShowRequest;
use App\Http\Requests\TkSignRequest;
use App\Jobs\CreateEdAk;
use App\Jobs\CreateEdTk;
use App\Jobs\CreateNomTk;
use App\Jobs\CreateRegisterAk;
use App\Jobs\CreateRegisterTk;
use App\Models\Ed\Ed;
use App\Models\HandBooks\Fund;
use App\Models\Register\Register;
use App\Models\Sert\Sert;
use App\Models\System\SystemParam;
use App\Models\Tk\Tk;
use App\Models\Tk\TkStatus;
use App\Models\Tk\TkType;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\Tk\SystemParamsService;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Webpatser\Uuid\Uuid;

class TkController extends BaseController
{
    private function getThumbprint($request)
    {
        $systemParam = SystemParam::where('code', 'system_signature')->first();
        $thumbprint = $systemParam ? $systemParam->value : null;
        $sert = Sert::where('thumbprint', $thumbprint)->first();

        if (empty($thumbprint) || empty($sert)) {
            throw  new BaseException('Технологическая подпись для текущего пользователя в системе не найдена');
        }
        if (!$sert->checkValidatePeriod($sert, $request->server('REQUEST_TIME'))) {
            throw new BaseException('Срок действия сертификата истек или же еще не наступил');
        }

        return $thumbprint;
    }
    /**
     * Create a new resource.
     *
     * @param TkRequest $request
     * @return JsonResponse
     */
    public function storeTk(TkRequest $request)
    {
        $uid = ! empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        try {
            $tk = DB::transaction(function () use ($request, $uid) {
                $idMedoSenderDepartment = SystemParam::where('code', 'id_medo_sender_department')->pluck('value')->first();
                if (! Uuid::validate($idMedoSenderDepartment)) {
                    throw new BaseException('Невалидное значение у "Идентификатор МЭДО отправителя (ведомства)".');
                }

                $thumbprint = $this->getThumbprint($request);

//                Не актуально более, автоматическое подписание технологической подписью  TRARCHIVE-55
//                $sert = Sert::where('thumbprint', $request->thumbprint)->first();
//                if (! $sert->checkSerUse('eds_tk')) {
//                    throw new BaseException('Невозможно отправить транспортный контейнер в ЦХЭД, потому что переданный сертификат не обладает необходимыми правилами использования');
//                }

                if (! SystemParamsService::isInputPathFilled()) {
                    throw new BaseException(SystemParamsService::EMPTY_INPUT_MSG);
                }

                if (! SystemParamsService::isInputPathExists()) {
                    throw new BaseException(SystemParamsService::EXISTS_INPUT_MSG);
                }

                if (! SystemParamsService::isOutputPathFilled()) {
                    throw new BaseException(SystemParamsService::EMPTY_OUTPUT_MSG);
                }

                if (! SystemParamsService::isOutputPathExists()) {
                    throw new BaseException(SystemParamsService::EXISTS_OUTPUT_MSG);
                }

                $inputs = $request->all();
                $inputs['form_date'] = Carbon::now()->toDateTimeString();
                $inputs['send_date'] = Carbon::now()->toDateTimeString();
                $inputs['in_out'] = false;
                $inputs['user_id'] = Auth::id();

                $dataEd = [];
                if (! empty($request->ed_id) || ! empty($request->register_by_ed_id)) {
                    $type = TkType::where('code', 'document')->first(['code', 'id']);

                    if (! empty($request->register_by_ed_id)) {
                        $dataEd = Ed::leftJoin('dossier_in_register', 'ed.dossier_id', 'dossier_in_register.dossier_id')
                            ->where('dossier_in_register.register_id', $request->register_by_ed_id)->get(['ed.*']);
                    } else {
                        $dataEd[] = Ed::where('id', $request->ed_id)->first();
                    }
                } elseif (! empty($request->register_id)) {
                    $type = TkType::where('code', 'register')->first(['code', 'id']);
                } elseif (! empty($request->nom_id)) {
                    $type = TkType::where('code', 'nomenclature')->first(['code', 'id']);
                }

                $inputs['tk_type'] = $type->id;
                $inputs['tk_status_id'] = TkStatus::where('name', 'отправлен в ЦХЭД')->pluck('id')->first();

                if ($type->code === 'document') {
                    if (! empty($dataEd)) {
                        if (! empty($inputs['register_by_ed_id'])) {
                            $register = Register::findOrFail($inputs['register_by_ed_id']);
                            unset($inputs['register_by_ed_id']);
                        }

                        foreach ($dataEd as $ed) {
                            $inputs['ed_id'] = $ed->id;
                            $tk = new Tk($inputs);

                            if ($ed->registerInChed()) {
                                if (empty($inputs->archive_id)) {
                                    if (! empty($tk->ed->lastEdInRegister)) {
                                        if (empty($register)) {
                                            $register = $tk->ed->lastEdInRegister->register;
                                        }

                                        $tk->archive_id = $register->archive_id;
                                        $tk->fund_id = $register->fund_id;
                                    } else {
                                        $msg = "Электронный документы с id = {$request->ed_id} не имеет описей, чтобы получить \"Архив\" и \"Фонд\" для отправки в ЦХЭД.";
                                        throw new BaseException($msg);
                                    }
                                }

                                $tk->save();

                                CreateEdTk::dispatch($tk, $thumbprint, $uid)->onQueue('create_ed_tk_job');
                            } else {
                                throw new BaseException('У ЭД отсутсвует опись со статусом ТК "Принят в ЦХЭД" или resend_tk не равен "false" или "null"');
                            }
                        }
                    }
                } elseif ($type->code === 'register') {
                    $tk = new Tk($inputs);

                    $register = Register::findOrFail($request->register_id);

                    if (! empty($register->lastTk->status) &&
                        ($register->lastTk->status->name === 'отправлен в ЦХЭД' ||
                            $register->lastTk->status->name === 'доставлен в ЦХЭД' ||
                            $register->lastTk->status->name === 'в обработке в ЦХЭД' ||
                            $register->lastTk->status->name === 'принят в ЦХЭД') &&
                        ($register->lastTk->form_date > $register->update_date)) {
                        throw new BaseException("Опись с ID = {$register->id} не может быть отправлена в ЦХЭД, DESCRIPTION:
                         отправить можно только один раз, user_id = {$tk->user_id}");
                    }

                    if (empty($inputs->archive_id)) {
                        $tk->archive_id = $register->archive_id;
                        $tk->fund_id = $register->fund_id;
                    }

                    if (! empty($register->lastTk->status) && $register->lastTk->status->name === 'принят в ЦХЭД') {
                        $register->lastTk->tk_status_id = TkStatus::where('name', 'заменен в ЦХЭД')->pluck('id')->first();
                        $register->lastTk->save();
                    }

                    $tk->save();

                    CreateRegisterTk::dispatch($tk, $thumbprint, $uid)->onQueue('create_register_tk_job');
                } elseif ($type->code === 'nomenclature') {
                    if (empty($inputs->archive_id)) {
                        $fundId = SystemParam::where('code', 'fund')->pluck('value')->first();
                        $fund = Fund::findOrFail($fundId);

                        $inputs['archive_id'] = $fund->archive_id;
                        $inputs['fund_id'] = $fund->id;
                    }

                    $tk = new Tk($inputs);
                    $tk->save();

                    CreateNomTk::dispatch($tk, $thumbprint, $uid)->onQueue('create_nomenclature_tk_job');
                } else {
                    throw new BaseException('Не смогли определить что отправляем в ЦХЭД');
                }

                return $tk;
            });
        } catch (\Exception $e) {
            if (str_contains($e->getMessage(), 'SQLSTATE[')) {
                $message = 'Нарушение ограничения базы данных';
                Log::alert('Ошибка при создании ТК, нарушение ограничения базы данных');
            } else {
                $message = $e->getMessage();
                Log::warning('Ошибка при создании ТК');
            }

            return response()->json(['code' => 400, 'message' => $message], 400);
        }

        return response()->json(['code' => 202, 'message' => ['id' => $tk->id, 'form_date' => $tk->form_date]], 202);
    }

    /**
     * @param CreateAkRequest $request
     * @return JsonResponse
     */
    public function storeAk(CreateAkRequest $request)
    {
        $uid = ! empty($request->header()['uid']) ? $request->header()['uid'][0] : null;

        $inputs = $request->all();
        $inputs['form_date'] = Carbon::now()->toDateTimeString();
        $inputs['in_out'] = false;
        $inputs['user_id'] = Auth::id();
        $inputs['tk_status_id'] = TkStatus::where('name', 'передан во временное хранилище')
            ->pluck('id')->first();

        try {
            $tk = DB::transaction(function () use ($inputs, $request, $uid) {
//                Не актуально более, автоматическое подписание технологической подписью  TRARCHIVE-55
//                if ($request->has('thumbprint')) {
//                    $sert = Sert::where('thumbprint', $request->thumbprint)->first();
//                    if (! empty($sert) && ! $sert->checkSerUse('eds_ak')) {
//                        if ($request->exists('register_id')) {
//                            throw new BaseException('Невозможно утвердить опись, переданный сертификат не обладает необходимыми правилами использования');
//                        } else {
//                            throw new BaseException('Невозможно утвердить ЭД, переданный сертификат не обладает необходимыми правилами использования');
//                        }
//                    }
//                } else {
//                    throw new BaseException('Невозможно отправить на ВХ, потому что не передали сертификат');
//                }

                $thumbprint = $this->getThumbprint($request);

                $dataEd = [];
                if (! empty($request->ed_id) || ! empty($request->register_by_ed_id)) {
                    $type = TkType::where('code', 'document')->first(['code', 'id']);

                    if (! empty($request->register_by_ed_id)) {
                        $dataEd = Ed::leftJoin('dossier_in_register', 'ed.dossier_id', 'dossier_in_register.dossier_id')
                            ->where('dossier_in_register.register_id', $request->register_by_ed_id)->get(['ed.*']);
                    } else {
                        $dataEd[] = Ed::where('id', $request->ed_id)->first();
                    }
                } elseif (! empty($request->register_id)) {
                    $type = TkType::where('code', 'register')->first(['code', 'id']);
                }

                $inputs['tk_type'] = $type->id;
                $inputs['tk_status_id'] = TkStatus::where('code', 'transferred_temporary_storage')->pluck('id')->first();

                if ($type->code === 'document') {
                    if (! empty($dataEd)) {
                        if (! empty($inputs['register_by_ed_id'])) {
                            $register = Register::findOrFail($inputs['register_by_ed_id']);
                            unset($inputs['register_by_ed_id']);
                        }
                        foreach ($dataEd as $ed) {
                            $inputs['ed_id'] = $ed->id;
                            $tk = new Tk($inputs);

                            if (empty($inputs->archive_id)) {
                                if (! empty($register)) {
                                    $tk->archive_id = $register->archive_id;
                                    $tk->fund_id = $register->fund_id;
                                } else {
                                    $registers = $ed->registers;
                                    if (! empty($registers) && count($registers)) {
                                        $tk->archive_id = $registers[0]->archive_id;
                                        $tk->fund_id = $registers[0]->fund_id;
                                    } else {
                                        $fundDefault = Fund::where('is_default', true)->first();
                                        if (! empty($fundDefault)) {
                                            $tk->fund_id = $fundDefault->id;
                                            $tk->archive_id = $fundDefault->archive->id;
                                        }
                                    }
                                }
                            }

                            $tk->save();

                            CreateEdAk::dispatch($tk, $thumbprint, $uid)->onQueue('create_ed_ak_job');
                        }
                    }
                } elseif ($type->code === 'register') {
                    $tk = new Tk($inputs);
                    $register = Register::findOrFail($request->register_id);

                    if (empty($inputs->archive_id)) {
                        $tk->archive_id = $register->archive_id;
                        $tk->fund_id = $register->fund_id;
                    }

                    $tk->save();
                    CreateRegisterAk::dispatch($tk, $thumbprint, $uid)->onQueue('create_register_ak_job');
                } else {
                    throw new BaseException('Не смогли определить что отправляем во временное хранилище');
                }

                return $tk;
            });
        } catch (\Exception $e) {
            if (str_contains($e->getMessage(), 'SQLSTATE[')) {
                $message = 'Нарушение ограничения базы данных';
                Log::alert('Ошибка при создании АК, нарушение ограничения базы данных');
            } else {
                $message = $e->getMessage();
                Log::warning('Ошибка при создании АК');
            }

            return response()->json(['code' => 400, 'message' => $message], 400);
        }

        return response()->json(['code' => 202, 'message' => ['id' => $tk->id, 'form_date' => $tk->form_date]], 202);
    }

    /**
     * @param TkSignRequest $request
     * @param $id
     * @return JsonResponse
     */
    public function createSignTK(TkSignRequest $request, $id)
    {
        $inputs['extension'] = $request->sig->getClientOriginalExtension();

        $data = Validator::make($inputs, [
            'extension' => 'required|in:sig',
        ]);

        if ($data->fails()) {
            return response()->json(['code' => 403, 'message' => $data->errors()], 403);
        }

        try {
            $tk = Tk::findOrFail($id);
        } catch (ModelNotFoundException $ex) {
            return response()->json(['code' => 400, 'message' => 'ТК/АК не найден'], 400);
        }

        $sig = $request->file('sig');

        $path = MediaStorage::putFileAs('tk/'.$tk->id.'/'.$tk->guid.'.edc', $sig, $tk->id.'.sig');
        $publicPath = basename(MediaStorage::getAdapter()->getPathPrefix()).'/'.$path;

        $tk->sign_end_date = $request->sign_end_date;
        $tk->ep_path = $publicPath;
        $tk->save();

        return response()->json(['code' => 204, 'message' => $publicPath], 204);
    }

    /**
     * @param TkShowRequest $request
     * @return array|JsonResponse
     */
    public function show(TkShowRequest $request)
    {
        try {
            $tk = Tk::
            filters($request)
                ->orderDefault($request, 'sort', 'DESC', 'collate "C"')
                ->orders($request)
                ->withPaginate($request);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }

        return $tk;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     */
    public function showById($id)
    {
        try {
            $tk = Tk::query()->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }

        return $tk;
    }

    /**
     * @param ChangeGuidTKRequest $request
     * @param $id
     * @return JsonResponse
     */
    public function changeGuid(ChangeGuidTKRequest $request, $id)
    {
        try {
            $tk = Tk::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'code' => 404,
                'message' => 'ТК/АК не найден',
            ], 404);
        }

        $tk->message_guid = $request->message_guid;
        $tk->save();

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }

    /**
     * @param ChangesStatusTkOnRegisterRequest $request
     * @param $id
     * @return JsonResponse
     */
    public function changesStatus(ChangesStatusTkOnRegisterRequest $request, $id)
    {
        try {
            $tk = Tk::findOrFail($id);
        } catch (BaseException $e) {
            return response()->json(['code' => 500, 'message' => 'ТК/АК не найден'], 500);
        }

        $tk->tk_status_id = $request->status_id;

        if ($tk->save()) {
            return response()->json(['code' => 201, 'message' => 'ok'], 201);
        } else {
            return response()->json(['code' => 500, 'message' => 'Статус не изменился.'], 500);
        }
    }
}
