<?php

namespace App\Http\Controllers\CryptoSign;

use App\Models\Sert\Sert;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use App\Http\Resources\CryptoSign\ShowSignResource;
use Illuminate\Database\Eloquent\Builder;

class ShowSignController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $serts = Sert::with('mchd')->Filters($request)
        
        ->where('start_date', '<=', Carbon::now())
            ->where('end_date', '>=', Carbon::now())
            ->where('is_active', true)
            ->when(empty($request->all()), function (Builder $query) {
                $query->where('user_id', '=', null);
            })
            ->orders($request)->get();
        $response = ShowSignResource::collection($serts);
        return ['signs' => $response];
    }
}
