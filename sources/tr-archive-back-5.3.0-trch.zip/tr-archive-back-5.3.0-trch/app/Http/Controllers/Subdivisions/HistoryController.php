<?php

namespace App\Http\Controllers\Subdivisions;

use App\Http\Requests\Subdivision\IndexSubdivisionRequest;
use App\Http\Resources\Subdivision\HistorySubdivisionsResource;
use App\Models\Subdivisions\Subdivisions;

class HistoryController extends BaseController
{
    public function __invoke(IndexSubdivisionRequest $request)
    {
        $subdivisions = Subdivisions::Filters($request)
            ->orderDefault($request, 'order', 'asc', '')
            ->where('subdivision.is_active', false)
            ->Orders($request)
            ->get();

        return new HistorySubdivisionsResource($subdivisions);
    }
}
