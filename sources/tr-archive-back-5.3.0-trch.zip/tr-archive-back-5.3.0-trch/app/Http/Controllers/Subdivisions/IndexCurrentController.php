<?php

namespace App\Http\Controllers\Subdivisions;

use App\Http\Requests\Subdivision\IndexSubdivisionRequest;
use App\Http\Resources\Subdivision\IndexSubdivisionsResource;
use App\Models\Subdivisions\Subdivisions;

class IndexCurrentController extends BaseController
{
    public function __invoke(IndexSubdivisionRequest $request) {
        $subdivisions = Subdivisions::where('is_org', '=', false)
            ->where('is_active', '=', true)
            ->withOrderDefault($request)
            ->get();
        return new IndexSubdivisionsResource($subdivisions);
    }
}