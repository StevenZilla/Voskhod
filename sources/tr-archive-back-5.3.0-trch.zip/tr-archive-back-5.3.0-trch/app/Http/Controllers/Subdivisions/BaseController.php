<?php

namespace App\Http\Controllers\Subdivisions;

use App\Services\Subdivision\SubdivisionService;
use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    public $service;
    public function __construct(SubdivisionService $subdivisionService)
    {
        $this->service = $subdivisionService;
    }
}
