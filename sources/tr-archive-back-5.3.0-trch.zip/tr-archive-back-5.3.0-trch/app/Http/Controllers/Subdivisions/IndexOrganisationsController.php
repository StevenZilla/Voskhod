<?php

namespace App\Http\Controllers\Subdivisions;

use App\Http\Requests\Subdivision\IndexSubdivisionRequest;
use App\Http\Resources\Subdivision\IndexOrganisationsResource;
use App\Models\Subdivisions\Subdivisions;

class IndexOrganisationsController extends BaseController
{
    public function __invoke(IndexSubdivisionRequest $request)
    {
        $organisations = Subdivisions::Filters($request)
            ->Orders($request)
            ->where('is_org', '=', true)
            ->get();
        return new IndexOrganisationsResource($organisations);
    }
}
