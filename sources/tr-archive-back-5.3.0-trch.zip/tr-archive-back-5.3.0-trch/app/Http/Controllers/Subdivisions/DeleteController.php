<?php

namespace App\Http\Controllers\Subdivisions;

use App\Exceptions\BaseException;
use App\Models\AcceptRegister\AcceptRegister;
use App\Models\Dossier\Dossier;
use App\Models\Ed\Ed;
use App\Models\Nomenclature\NomPart;
use App\Services\Subdivision\SubdivisionLiquidateValidationService;
use App\Services\Subdivision\SubdivisionService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Subdivisions\Subdivisions;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DeleteController extends BaseController
{
    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @throws BaseException
     */
    public function __invoke(Request $request, $id)
    {
        $subdivision = Subdivisions::where('id', $id)
            ->with('users', 'eds', 'dossiers', 'acceptRegister', 'nomParts')
            ->first();

        if (empty($subdivision)) {
            throw new ModelNotFoundException('Подразделения с переданным id ' . $id . ' не существует');
        }

        if ($subdivision->is_org) {
            throw new BaseException("Не можем удалить подразделение {$subdivision->code} {$subdivision->name}, потому что переданное подразделение является организацией.");
        }

        $isCanDeleteFlag = SubdivisionService::canDeleteFlag($subdivision);
        if (!$isCanDeleteFlag) {
            throw new BaseException("Не можем удалить подразделение {$subdivision->code} {$subdivision->name}, потому что существют связи с другими сущностями.");
        }

        $subdivision->forceDelete();

        return response()->json([], 204);
    }
}
