<?php

namespace App\Http\Controllers\Subdivisions;

use App\Exceptions\BaseException;
use App\Models\AcceptRegister\AcceptRegister;
use App\Models\Dossier\Dossier;
use App\Models\Ed\Ed;
use App\Models\Nomenclature\NomPart;
use App\Services\Subdivision\SubdivisionLiquidateValidationService;
use App\Services\Subdivision\SubdivisionService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Subdivisions\Subdivisions;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class LiquidationController extends BaseController
{
    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @throws BaseException
     */
    public function __invoke(Request $request, $id)
    {
        $liquidateSubdivision = Subdivisions::where('id', $id)
            ->with('eds', 'dossiers', 'acceptRegister', 'nomParts')
            ->first();

        if (empty($liquidateSubdivision)) {
            throw new ModelNotFoundException('Подразделения с переданным id ' . $id . ' не существует');
        }

        if ($liquidateSubdivision->is_org) {
            throw new BaseException("Не можем деактивировать/ликвидировать подразделение {$liquidateSubdivision->code} {$liquidateSubdivision->name}, потому что переданное подразделение является организацией.");
        }

        $isCanLiquidateFlag = SubdivisionService::canLiquidateFlag($liquidateSubdivision);
        if (!$isCanLiquidateFlag) {
            throw new BaseException("Не можем деактивировать/ликвидировать подразделение {$liquidateSubdivision->code} {$liquidateSubdivision->name}, потому что существет дело со статусом \"Закрыто\".");
        }

        $isNeedMoveSubdivision = SubdivisionService::isNeedMove($liquidateSubdivision);

        if ($isNeedMoveSubdivision) {
            $validate = new SubdivisionLiquidateValidationService();
            $validate->validateLiquidate($request->all());
        }

        try {
            DB::transaction(function () use ($request, $liquidateSubdivision, $isNeedMoveSubdivision) {
                $liquidateSubdivision->is_active = false;
                $liquidateSubdivision->delete_year = Carbon::now()->format('Y');

                if ($isNeedMoveSubdivision) {
                    $subdivision = Subdivisions::findOrFail($request->all()['new_subdivision_id']);
                    $liquidateSubdivision->note = "Объекты перешли к подразделению {$subdivision->code} {$subdivision->name}";
                }

                $liquidateSubdivision->save();

                if ($isNeedMoveSubdivision && !empty($subdivision)) {
                    $dataNomParts = $liquidateSubdivision->nomParts;
                    if (!empty($dataNomParts) && $dataNomParts->count() > 0) {
                        NomPart::whereIn('id', $dataNomParts->pluck('id')->toArray())->update(['subdivision_id' => $subdivision->id]);
                        $liquidateSubdivision->liquidationSubdivisionNomPart()->syncWithoutDetaching($dataNomParts->pluck('id')->toArray());
                    }

                    $dataDossiers = $liquidateSubdivision->dossiers;
                    if (!empty($dataDossiers) && $dataDossiers->count() > 0) {
                        Dossier::whereIn('id', $dataDossiers->pluck('id')->toArray())->update(['subdivision_id' => $subdivision->id]);
                        $liquidateSubdivision->liquidationSubdivisionDossier()->syncWithoutDetaching($dataDossiers->pluck('id')->toArray());
                    }

                    $dataEds = $liquidateSubdivision->eds;
                    if (!empty($dataEds) && $dataEds->count() > 0) {
                        Ed::whereIn('id', $dataEds->pluck('id')->toArray())->update(['subdivision_id' => $subdivision->id]);
                        $liquidateSubdivision->liquidationSubdivisionEd()->syncWithoutDetaching($dataEds->pluck('id')->toArray());
                    }

                    $dataAcceptRegisters = $liquidateSubdivision->acceptRegisters;
                    if (!empty($dataAcceptRegisters) && $dataAcceptRegisters->count() > 0) {
                        AcceptRegister::whereIn('id', $dataAcceptRegisters->pluck('id')->toArray())->update(['subdivision_id' => $subdivision->id]);
                        $liquidateSubdivision->liquidationSubdivisionAcceptRegister()->syncWithoutDetaching($dataAcceptRegisters->pluck('id')->toArray());
                    }
                }

                return true;
            });
        } catch (\Exception $exception) {
            Log::error("Произошла ошибка при деактивации/ликвидации подразделения.\nОшибка: {$exception}");
            return response()->json(['code' => 400, 'message' => "Не смогли деактивировать/ликвидировать подразделение. {$exception->getMessage()}"], 400);
        }

        return response()->json([], 204);
    }
}
