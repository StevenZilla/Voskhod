<?php

namespace App\Http\Controllers\Subdivisions;

use App\Exceptions\BaseException;
use App\Http\Requests\Subdivision\UpdateSubdivisionRequest;
use App\Models\Subdivisions\Subdivisions;
use App\Services\Subdivision\SubdivisionService;

class UpdateController extends BaseController
{
    public function __invoke(UpdateSubdivisionRequest $request, string $id) {
        $subdivision = Subdivisions::find($id);
        if ($subdivision->is_org === true){
            return response(['code' => 405, 'message' => 'Нельзя обновить организацию'], 405);
        }

        $isCanEditFlag = SubdivisionService::canEditFlag($subdivision);
        if (!$isCanEditFlag) {
            throw new BaseException("Не можем редактировать подразделение {$subdivision->code} {$subdivision->name}, потому что существет дело со статусом \"Закрыто\".");
        }

        $data = $request->validated();
        $subdivision->update($data);

        return response()->json([], 204);
    }
}