<?php

namespace App\Http\Controllers\Subdivisions;

use App\Http\Requests\Subdivision\StoreSubdivisionRequest;
use App\Models\Subdivisions\Subdivisions;

class StoreController extends BaseController
{
    /**
     * @param StoreSubdivisionRequest $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function __invoke(StoreSubdivisionRequest $request)
    {
        $data = $request->validated();

        $subdivision = new Subdivisions($data);
        $subdivision->order = Subdivisions::orderBy('order', 'desc')->pluck('order')->first() + 1;
        $subdivision->save();

        return response(['code' => 201, 'message' => $subdivision->id], 201);
    }
}