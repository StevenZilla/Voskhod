<?php

namespace App\Http\Controllers\Subdivisions;

use App\Http\Requests\Subdivision\IndexSubdivisionRequest;
use App\Http\Resources\Subdivision\IndexSubdivisionsResource;
use App\Models\Subdivisions\Subdivisions;

class IndexController extends BaseController
{
    public function __invoke(IndexSubdivisionRequest $request)
    {
        $subdivisions = Subdivisions::Filters($request)
            ->with('eds', 'dossiers', 'acceptRegister', 'nomParts')
            ->orderDefault($request, 'is_org', 'desc', '')
            ->Orders($request)
            ->get();

        return new IndexSubdivisionsResource($subdivisions);
    }
}
