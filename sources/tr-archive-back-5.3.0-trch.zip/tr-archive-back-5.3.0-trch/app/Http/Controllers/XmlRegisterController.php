<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Models\System\SystemParam;
use App\Services\FilesystemManager\MediaStorage;
use Illuminate\Support\Facades\Log;
use Webpatser\Uuid\Uuid;
use XmlValidator\XmlValidator;

class XmlRegisterController extends Controller
{
    protected $register;
    protected $registerFile;

    /**
     * Путь до папки с архивом и passport (внутри public_media).
     */
    protected $path_to_register_folder;
    protected $path_result;
    protected $absolute_path_to_media;
    protected $storage;
    protected $guidOik;

    /**
     * Массив временных файлов.
     * @var array
     */
    protected $tempFiles = [];

    /**
     * @param $register
     * @param $registerFile
     * @param $guidOik
     */
    public function __construct($register, $registerFile, $guidOik = null)
    {
        $this->register = $register;
        $this->registerFile = $registerFile;
        $this->storage = MediaStorage::disk('public_media');
        $this->absolute_path_to_media = $this->storage->getAdapter()->getPathPrefix();

        $this->guidOik = $guidOik;

        $this->makeDirectory();
    }

    /**
     * Создает папку, в которой будет храниться архив.
     */
    protected function makeDirectory()
    {
        $guid = Uuid::generate()->string;
        $this->path_to_register_folder = "register/{$guid}";
        $this->path_result = basename(MediaStorage::getAdapter()->getPathPrefix()).$this->path_to_register_folder;
        $this->storage->makeDirectory($this->path_to_register_folder);
    }

    /**
     * @return string
     * @throws \Throwable
     */
    public function createRegisterDescrXml()
    {
        $filename = config('ched.inventory_for_ched');
        $path = $this->absolute_path_to_media.$this->path_to_register_folder;
        $fullPath = $path.'/'.$filename;

        $versionXml = config('app.version_xsd');
        $xsd = basename(MediaStorage::disk('public_xsd')->getAdapter()->getPathPrefix())."/{$versionXml}/tk_inventory_{$versionXml}.xsd";
        $xsdAbsolutePath = MediaStorage::disk('public_xsd')->getAdapter()->getPathPrefix()."{$versionXml}/tk_inventory_{$versionXml}.xsd";

        $data = [];

        $data['register'] = $this->register->toArray();
        $data['register']['create_date'] = date('Y-m-d', strtotime($this->register->create_date));
        if (SystemParam::where('name', 'Наименование ПО')->count() > 0) {
            $data['software_name'] = SystemParam::where('name', 'Наименование ПО')->first()->value;
        }
        if (SystemParam::where('name', 'Версия ПО')->count() > 0) {
            $data['software_version'] = SystemParam::where('name', 'Версия ПО')->first()->value;
        }
        if (SystemParam::where('name', SystemParam::$idOIK)->count() > 0) {
            $data['organization_id'] = SystemParam::where('name', SystemParam::$idOIK)->first()->value;
        }
        $data['archiveName'] = $this->register->archive[0]->name;

        $archive = $this->register->archive[0];
        if (empty($archive->code)) {
            $errorMessageFund = "Не можем отправить опись {$data['register']['name']}[{$data['register']['id']}] на утверждение, потому что у фонда {$archive->name} отсутствует поле code";
            Log::critical($errorMessageFund);
            throw new BaseException($errorMessageFund);
        }

        $data['archiveId'] = $archive->code;
        $data['inventoryType'] = 1;
        $data['inventoryKind'] = $this->register->registerType->code_xml;
        $data['fundNumber'] = $this->register->fund[0]->num;

        $fund = $this->register->fund[0];
        if (empty($fund->code)) {
            $errorMessageFund = "Не можем отправить опись {$data['register']['name']}[{$data['register']['id']}] на утверждение, потому что у фонда {$fund->name} отсутствует поле code";
            Log::critical($errorMessageFund);
            throw new BaseException($errorMessageFund);
        }

        $data['fundId'] = $fund->code;
        $data['registerPart'] = $this->register->registerPart;

        foreach ($this->register->signers as $signer) {
            $data['signers'][$signer->id]['role'] = $signer->role ? $signer->role->code_xml : null;
            $data['signers'][$signer->id]['position'] = $signer->position;
            $data['signers'][$signer->id]['fio'] = $signer->user->fio;
            $data['signers'][$signer->id]['sign_date'] = date('Y-m-d', strtotime($signer->pivot->sign_date));
        }

        $data['cases_for_register'] = $this->register->getDossiersRegister();
        $data['eds_inventory_documents'] = $this->register->getDossiersRegisterPart();

        $xml = view('xml.register')->with(['data' => $data, 'absolutePath' => $path])->render();

        $xmlValidator = new XmlValidator();
        $xmlValidator->validate($xml, $xsd);
        if (! $xmlValidator->isValid()) {
            $errors = [];
            foreach ($xmlValidator->errors as $error) {
                $strError = '';
                foreach ((array) $error as $keyEr => $er) {
                    $strError = "{$keyEr}: {$er}".PHP_EOL;
                }
                $errors[] = $strError;
            }
            $registerId = $this->register->id;
            $msg = "Не смогли создать INVENTORY.xml для описи[$registerId] в ".\Carbon\Carbon::now()->toDateTimeString();
            Log::critical($msg);
            throw new BaseException($msg);
        }

        $dom = new \DOMDocument();
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->loadXML($xml);

        $dom->save($fullPath);

        $registerFile = $this->register->registerFileWhereTypeOne;
        $registerFile->path = $this->path_to_register_folder.'/'.$filename;

        $registerFile->save();

        return $fullPath;
    }
}
