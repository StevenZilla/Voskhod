<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\Agreement\AgreementEpkPatchRequest;
use App\Http\Requests\Agreement\AgreementReviewEpkPatchRequest;
use App\Http\Requests\Agreement\IndexGetRequest;
use App\Http\Requests\AgreementRequest\AgreementStoreRequest;
use App\Http\Requests\AgreementRequest\AgreementUpdateDecisionRequest;
use App\Http\Requests\AgreementRequest\AgreementUpdateRequest;
use App\Jobs\AgreementAkApproved;
use App\Jobs\AgreementEcJob;
use App\Jobs\AgreementEpk;
use App\Jobs\AgreementEpkAk;
use App\Jobs\AgreementEpkTk;
use App\Jobs\AgreementReviewEpk;
use App\Jobs\AgreementTkApproved;
use App\Models\Agreement;
use App\Models\AgreementType;
use App\Models\ParticipantInAgreement;
use App\Models\Register\Register;
use App\Models\Register\RegisterFile;
use App\Models\Register\RegisterStatus;
use App\Models\Signer\Signer;
use App\Models\Signer\SignerRole;
use App\Models\System\SystemParam;
use App\Models\System\SystemRole;
use App\Models\Tk\Tk;
use App\Models\Tk\TkType;
use App\Services\FilesystemManager\MediaStorage;
use Carbon\Carbon;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File as FileManager;
use Illuminate\Support\Facades\Log;

class AgreementController extends Controller
{
    public function index(IndexGetRequest $request)
    {
        if ($request->has('is_group') && $request->has('register_id')) {
            $data['ek'] = Agreement::withFilters($request)
                ->where('type_id', AgreementType::where('code', 'oic_expert_commission')->pluck('id')->first())
                ->where('is_actual', false)
                ->orderBy('agreement.order')->get();
            $data['epk'] = Agreement::withFilters($request)
                ->where('type_id', AgreementType::where('code', 'epc')->pluck('id')->first())
                ->where('is_actual', false)
                ->orderBy('agreement.order')->get();

            $actualAgreements = Agreement::withFilters($request)
                ->where('is_actual', true)
                ->orderBy('agreement.id')
                ->get();

            if (!empty($actualAgreements->toArray())) {
                foreach ($actualAgreements as $actualAgreement) {
                    $dataAgreement = $actualAgreement->toArray();

                    if ($actualAgreement['type']->code === 'oic_expert_commission') {
                        $data['ek']->push($dataAgreement);
                    } elseif ($actualAgreement['type']->code === 'epc') {
                        $data['epk']->push($dataAgreement);
                    }
                }
                $data['view_buttons'] = $actualAgreements->last()->getViewButtons();
            }

            $registerFile = RegisterFile::where('register_id', $request->get('register_id'))
                ->where('is_actual', true)->where('system_role_id', SystemRole::where('code', 'supervisor')->pluck('id')->first())
                ->first();
            $dataChief = null;

            if (!empty($registerFile)) {
                $dataChief['fio'] = $registerFile->user->fio;
                $dataChief['register_id'] = $registerFile->register_id;
                $dataChief['sign_date'] = $registerFile->sign_date;
                $dataChief['path_xml_register'] = basename($registerFile->register->path_xml_register);
                $dataChief['path_ep'] = basename($registerFile->path);
                $dataChief['path_mchd'] = basename($registerFile->path_mchd);

                $dataChief['uri_xml_register'] = $registerFile->register->uri_path_xml_register;
                $dataChief['uri_path_ep'] = $registerFile->uri;
                $dataChief['uri_path_mchd'] = $registerFile->uriMchd;
            }

            $data['chief'] = $dataChief;

            return $data;
        } else {
            return Agreement::withFilters($request)->get();
        }
    }

    public function show($id)
    {
        return Agreement::getDetailInfo($id);
    }

    public function store(AgreementStoreRequest $request)
    {
        try {
            $agreement = DB::transaction(function () use ($request) {
                $type = AgreementType::where('id', $request->get('type_id'))->first();

                if ($type->code !== 'oic_expert_commission') {
                    Log::debug('Создаем согласование ЭПК с типом не равным "Экспертная комиссия ОИК". Временная фича.');
                }

                $register = Register::findOrFail($request->get('register_id'));
                $register->changeState('register_status_id', RegisterStatus::getProjectStatus());

                $agreement = new Agreement();
                $agreement->create_date = Carbon::now()->toDateTimeString();
                $agreement->register_id = $request->get('register_id');
                $agreement->type_id = $type->id;
                $agreement->approval_period_till = $request->get('approval_period_till');

                $agreement->save();

                $countApproving = 0; // обязательно наличие утверждающего
                $countCoordinating = 0;  // хотя бы 1 согласующего
                if ($request->has('participants') && !empty($request->get('participants'))) {
                    foreach ($request->get('participants') as $item) {
                        $participant = Signer::findOrFail($item);

                        if ($participant->signer_role_id === SignerRole::where('code', 'approver')->pluck('id')->first()) {
                            $isApproving = true;
                            $countApproving++;
                        } else {
                            $isApproving = false;
                            $countCoordinating++;
                        }

                        $participantInAgreement = new ParticipantInAgreement();
                        $participantInAgreement->agreement_id = $agreement->id;
                        $participantInAgreement->is_approving = $isApproving;
                        $participantInAgreement->participant_id = $participant->id;
                        $participantInAgreement->save();
                    }
                }

                if ($countApproving < 1) {
                    throw new BaseException('Не можем создать Согласование Описи, потому что отсутствует участник с ролью "Утверждающий"');
                }

                if ($countCoordinating < 1) {
                    throw new BaseException('Не можем создать Согласование Описи, потому что отсутствует хотя бы 1 согласующий');
                }

                return $agreement->id;
            });

            return response()->json(['code' => 201, 'message' => $agreement]);
        } catch (\Exception $e) {
            Log::error('Не смогли создать Согласование ЭПК');

            return response()->json(['code' => 400, 'message' => $e->getMessage()]);
        }
    }

    public function update(AgreementUpdateRequest $request, $id)
    {
        try {
            $agreement = DB::transaction(function () use ($request, $id) {
                if (!empty($request->get('participants')['deleted_participants'])) {
                    ParticipantInAgreement::where('agreement_id', $id)->whereIn('participant_id', $request->get('participants'))->delete();
                }

                if ($request->approval_period_till) {
                    $agreement = Agreement::find($id);
                    $agreement->approval_period_till = $request->approval_period_till;
                    $agreement->save();
                }

                $countApproving = 0; // обязательно наличие утверждающего
                $countCoordinating = 0;  // хотя бы 1 согласующего
                if (!empty($request->get('participants')['new_participants'])) {
                    foreach ($request->get('participants')['new_participants'] as $item) {
                        $participant = Signer::findOrFail($item);

                        if ($participant->signer_role_id === SignerRole::where('code', 'approver')->pluck('id')->first()) {
                            $isApproving = true;
                            $countApproving++;
                        } else {
                            $isApproving = false;
                            $countCoordinating++;
                        }

                        $participantInAgreement = new ParticipantInAgreement();
                        $participantInAgreement->agreement_id = $id;
                        $participantInAgreement->is_approving = $isApproving;
                        $participantInAgreement->participant_id = $participant->id;
                        $participantInAgreement->save();
                    }
                }

                if ($countApproving < 1) {
                    throw new BaseException('Не можем создать Согласование Описи, потому что отсутствует участник с ролью "Утверждающий"');
                }

                if ($countCoordinating < 1) {
                    throw new BaseException('Не можем создать Согласование Описи, потому что отсутствует хотя бы 1 согласующий');
                }

                return $id;
            });

            return response()->json(['code' => 201, 'message' => $agreement]);
        } catch (\Exception $e) {
            Log::error('Не смогли обновить участников Согласование ЭПК');

            return response()->json(['code' => 400, 'message' => 'Не смогли обновить участников Согласование ЭПК']);
        }
    }

    public function updateDecision(AgreementUpdateDecisionRequest $request, $id)
    {
        try {
            if (!empty($request->allFiles()['files_comment'])) {
                $files = [];
                $time = Carbon::now()->timestamp;
                MediaStorage::makeDirectory("tmp/decision_{$time}");

                foreach ($request->allFiles()['files_comment'] as $fileComment) {
                    if (file_exists($fileComment->getPathname())) {
                        $path = MediaStorage::copyFileWithRequest($fileComment, "tmp/decision_{$time}");
                        $files[] = $path;
                    }
                }
            }

            AgreementEpk::dispatch(
                $id,
                Auth::user(),
                SystemRole::where('code', 'expert')->pluck('id')->first(),
                $request->request->all(),
                $files ?? null
            )->onQueue('agreement_epk_job');

            return response()->json(['code' => 200, 'message' => 'ok'], 200);
        } catch (\Exception $e) {
            Log::error("Не смогли вынести решение для проекта описи. Сообщение с ошибкой: {$e->getMessage()}");

            if (!empty($tmpDirDecision) && file_exists($tmpDirDecision)) {
                FileManager::deleteDirectories($tmpDirDecision);
            }

            if ($e instanceof BaseException) {
                return response()->json([
                    'code' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            } elseif ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                return response()->json(['code' => 400, 'message' => 'Не создать решение к проекту описи'], 400);
            }
        }
    }

    public function updateEk($id)
    {
        try {
            $agreement = Agreement::findOrFail($id);

            AgreementEcJob::dispatch($agreement)
                ->onQueue('agreement_approved_ec_job');
        } catch (\Exception $e) {
            Log::error('Не cмогли изменить статус решения к проекту описи');

            if ($e instanceof BaseException) {
                return response()->json([
                    'code' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            } elseif ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                return response()->json(['code' => 400, 'message' => 'Не cмогли изменить статус решения к проекту описи'], 400);
            }
        }

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }

    public function updateEpk(AgreementEpkPatchRequest $request, int $id)
    {
        $medoOut = config("filesystems.medo_out");
        if (empty($medoOut)) {
            throw new BaseException('Не заполнен системный параметр «Исходящие контейнеры МЭДО», обратитесь к администратору');
        }

        if (!file_exists($medoOut)) {
            throw new BaseException("Директория, которая указана «Исходящие контейнеры МЭДО» - {$medoOut}, не существует. Обратитесь к администратору");
        }

        $agreementEp = Agreement::findOrFail($id);

        if (!$agreementEp->is_actual) {
            throw new BaseException('Не можем отправить проект описи во временное хранилище, потому что текущее согласование не актуально');
        }

        $tk = new Tk();
        $tk->in_out = false;
        $tk->tk_type = TkType::where('code', 'agreement')->pluck('id')->first();
        $tk->save();

        $systemParam = SystemParam::where('code', 'system_signature')->first();
        $thumbprint = $systemParam ? $systemParam->value : null;
        $sert = Sert::where('thumbprint', $thumbprint)->first();
        if (empty($thumbprint) || empty($sert)) {
            throw  new BaseException('Технологическая подпись для текущего пользователя в системе не найдена');
        }
        if (!$sert->checkValidatePeriod($sert, $request->server('REQUEST_TIME'))) {
            throw new BaseException('Срок действия сертификата истек или же еще не наступил');
        }

        AgreementEpkTk::dispatch($agreementEp, $tk, $thumbprint)
            ->onQueue('create_epk_ak_job');

        return response()->json(['code' => 201, 'message' => ['id' => $tk->id, 'form_date' => $tk->form_date]], 201);
    }

    public function updateEpkAk(AgreementEpkPatchRequest $request, int $id)
    {
        $medoOut = config("filesystems.medo_out");
        if (empty($medoOut)) {
            throw new BaseException('Не заполнен системный параметр «Исходящие контейнеры МЭДО», обратитесь к администратору');
        }

        if (!file_exists($medoOut)) {
            throw new BaseException("Директория, которая указана «Исходящие контейнеры МЭДО» - {$medoOut}, не существует. Обратитесь к администратору");
        }

        $agreementEp = Agreement::findOrFail($id);

        if (!$agreementEp->is_actual) {
            throw new BaseException('Не можем отправить проект описи в ЦХЭД, потому что текущее согласование не актуально');
        }

        $tk = new Tk();
        $tk->in_out = false;
        $tk->tk_type = TkType::where('code', 'agreement')->pluck('id')->first();
        $tk->save();

        $thumbprint = SystemParam::where('code', 'system_signature')->first()->value;
        AgreementEpkAk::dispatch($agreementEp, $tk, $thumbprint)
            ->onQueue('create_epk_ak_job');

        return response()->json(['code' => 201, 'message' => ['id' => $tk->id, 'form_date' => $tk->form_date]], 201);
    }

    public function updateReviewEpk(AgreementReviewEpkPatchRequest $request, $id)
    {
        try {
            AgreementReviewEpk::dispatch(
                $id,
                Auth::user(),
                SystemRole::where('code', 'compiler')->pluck('id')->first(),
                $request->all()
            )->onQueue('agreement_review_epk_job');

            return response()->json(['code' => 200, 'message' => 'ok'], 200);
        } catch (\Exception $e) {
            Log::error('Не получилось отправить согласование опись на проверку доработок ЭПК');

            if ($e instanceof BaseException) {
                return response()->json([
                    'code' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            } elseif ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                return response()->json(['code' => 400, 'message' => 'Не получилось отправить согласование опись на проверку доработок ЭПК'], 400);
            }
        }
    }

    public function updateApprovedTk(AgreementReviewEpkPatchRequest $request, $id)
    {
        try {
            AgreementTkApproved::dispatch(
                $id,
                Auth::user(),
                SystemRole::where('code', 'supervisor')->pluck('id')->first(),
                $request->all()
            )->onQueue('agreement_tk_approved_job');

            return response()->json(['code' => 200, 'message' => 'ok'], 200);
        } catch (\Exception $e) {
            Log::error('Не получилось утвердить опись и отправить в ЦХЭД');

            if ($e instanceof BaseException) {
                return response()->json([
                    'code' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            } elseif ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                return response()->json(['code' => 400, 'message' => 'Не получилось утвердить опись и отправить в ЦХЭД'], 400);
            }
        }
    }

    public function updateApprovedAk(AgreementReviewEpkPatchRequest $request, $id)
    {
        try {
            AgreementAkApproved::dispatch(
                $id,
                Auth::user(),
                SystemRole::where('code', 'supervisor')->pluck('id')->first(),
                $request->all()
            )->onQueue('agreement_ak_approved_job');

            return response()->json(['code' => 200, 'message' => 'ok'], 200);
        } catch (\Exception $e) {
            Log::error('Не получилось утвердить опись и отправить во временное хранилище');

            if ($e instanceof BaseException) {
                return response()->json([
                    'code' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            } elseif ($e instanceof HttpResponseException) {
                throw $e;
            } else {
                return response()->json(['code' => 400, 'message' => 'Не получилось утвердить опись и отправить во временное хранилище'], 400);
            }
        }
    }
}
