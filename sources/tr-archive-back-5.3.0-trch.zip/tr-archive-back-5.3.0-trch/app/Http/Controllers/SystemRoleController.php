<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Exceptions\SystemRoleException\SystemRoleException;
use App\Http\Requests\Permissions\SetPermissionOnUser;
use App\Http\Requests\Permissions\UpdatePermissionOnUser;
use App\Http\Requests\SystemRole\SystemRoleStoreRequest;
use App\Http\Requests\SystemRole\SystemRoleUpdateRequest;
use App\Models\Permission\ActionPermission;
use App\Models\Permission\Permission as PermissionModel;
use App\Models\Permission\RoutePermission;
use App\Models\System\SystemRole;
use App\Services\CheckDate\CheckDate;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SystemRoleController extends Controller
{
    /**
     * @param SystemRoleStoreRequest $request
     * @return JsonResponse
     */
    public function store(SystemRoleStoreRequest $request)
    {
        try {
            $systemRole = DB::transaction(function () use ($request) {
                try {
                    $inputs = $request->all();

                    if (! empty($inputs['start_date']) && ! empty($inputs['end_date'])) {
                        $messageCheckDate = CheckDate::checkStartEndDate($inputs['start_date'], $inputs['end_date']);

                        if ($messageCheckDate !== 'true') {
                            $msg = 'При создании системной роли проверка начала/окончания действия системной роли не прошла. ';
                            throw new BaseException($msg.$messageCheckDate);
                        }
                    }

                    if (! $request->exists('end_date')) {
                        $inputs['end_date'] = Carbon::now()->addYears(100)->toDateTimeString();
                    }

                    if (! $request->exists('start_date')) {
                        $inputs['start_date'] = Carbon::now()->toDateTimeString();
                    }

                    $systemRole = new SystemRole();

                    $systemRole->name = $inputs['name'];
                    $systemRole->description = $inputs['descr'];
                    $systemRole->start_date = $inputs['start_date'];
                    $systemRole->end_date = $inputs['end_date'];
                    $systemRole->priority = $inputs['priority'];
                    $systemRole->save();
                } catch (BaseException $e) {
                    if (str_contains($e->getMessage(), 'system_role_name_unique')) {
                        Log::alert('Нарушение ограничение уникальность поля названия в системной роли');
                        throw new BaseException('Поле name в системных ролях должно быть уникальным');
                    } else {
                        Log::warning('Не удалось создать системную роль');

                        throw new BaseException('Не удалось создать системную роль '.$e->getMessage());
                    }
                }

                return $systemRole;
            });
        } catch (BaseException $e) {
            if (str_contains($e->getMessage(), 'SQLSTATE[')) {
                $message = 'Нарушение ограничения базы данных';
                Log::alert('Ошибка при создании системной роли, нарушение ограничения базы данных');
            } else {
                Log::warning('Ошибка при создании системной роли');

                $message = $e->getMessage();
            }

            return response()->json(['code' => 400, 'message' => $message], 400);
        }

        return response()->json(['code' => 201, 'message' => $systemRole->id], 201);
    }

    /**
     * @param SystemRoleUpdateRequest $request
     * @param $id
     * @return JsonResponse
     * @throws BaseException
     */
    public function update(SystemRoleUpdateRequest $request, $id)
    {
        try {
            $systemRole = SystemRole::findOrFail($id);
        } catch (SystemRoleException $e) {
            throw new SystemRoleException('Системной роли с переданным идентификатором не существует.');
        }

        try {
            $systemRoleID = DB::transaction(function () use ($request, $systemRole) {
                $update = $request->all();

                if (! empty($update['start_date']) && ! empty($update['end_date'])) {
                    $messageCheckDate = CheckDate::checkStartEndDate($update['start_date'], $update['end_date']);

                    if ($messageCheckDate !== 'true') {
                        $msg = 'При обновлении системной роли проверка начала/окончания действия доступа компонента не прошла. ';
                        throw new BaseException($msg.$messageCheckDate);
                    }
                }

                if (! $request->exists('end_date')) {
                    $update['end_date'] = Carbon::now()->addYears(100)->toDateTimeString();
                }

                if (! $request->exists('start_date')) {
                    $update['start_date'] = Carbon::now()->toDateTimeString();
                }

                $update['description'] = $update['descr'];
                unset($update['descr']);

                $systemRole->update($update);

                return $systemRole->id;
            });
        } catch (BaseException $e) {
            if (str_contains($e->getMessage(), 'system_role_name_unique')) {
                $message = 'Нарушение ограничение уникальность поля названия в системной роли';
                Log::alert('Ошибка. Нарушение ограничение уникальность поля названия в системной роли');
            } elseif (str_contains($e->getMessage(), 'SQLSTATE[')) {
                $message = 'Нарушение ограничения базы данных';
                Log::alert('Ошибка при редактировании системной роли.');
            } else {
                $message = $e->getMessage();
                Log::warning('Ошибка при редактировании системной роли.');
            }

            return response()->json(['code' => 400, 'message' => $message], 400);
        }

        return response()->json(['code' => 201, 'message' => $systemRoleID], 201);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $systemRoles = SystemRole::filters($request)->orders($request)->get();

        return ['system_roles' => $systemRoles];
    }

    /**
     * @param Request $request
     * @param $id
     * @return JsonResponse
     */
    public function show(Request $request, $id)
    {
        try {
            $systemRole = SystemRole::findOrFail($id);
        } catch (BaseException $e) {
            return response()->json([
                'code' => 400,
                'message' => 'Системная роль не найдена',
            ], 400);
        }

        return $systemRole->showSystemRole();
    }

    public function getPermission($id)
    {
        $role = SystemRole::findOrFail($id);

        return PermissionModel::getPermissionForRole($role->code);
    }

    public function setPermissions(SetPermissionOnUser $request, $id)
    {
        if (! empty($request->permissions) && count($request->permissions) > 0) {
            $role = SystemRole::where('id', $id)->pluck('code')->first();
            foreach ($request->permissions as $permission) {
                $route = RoutePermission::where('name', $permission)->pluck('route')->first();
                PermissionModel::addPolicy($role, $route, $permission, 'true', 'role');
            }
        }

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }

    public function updatePermission(UpdatePermissionOnUser $request, $id, $techName)
    {
        if (! ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        $role = SystemRole::where('id', $id)->pluck('code')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::addPolicy($role, $route, $techName, $request->rule, 'role');

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }

    public function deletePermission($id, $techName)
    {
        if (! ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        $role = SystemRole::where('id', $id)->pluck('code')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::deletePolicy($role, $route, $techName, 'role');

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }
}
