<?php

namespace App\Http\Controllers;

use App\Http\Requests\SystemParamsRequest;
use App\Models\HandBooks\Fund;
use App\Models\System\SystemCategory;
use App\Models\System\SystemParam;
use App\Services\System\SetLaunchStart;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
use Webpatser\Uuid\Uuid;

class SystemParamController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param SystemParamsRequest $request
     * @return array|JsonResponse
     */
    public function index()
    {
        $result = [];
        $result['system_params'] = SystemCategory::orderBy('id')->get()->toArray();
        if (SystemCategory::$warningMessage) {
            $result['warning'] = array_values(SystemCategory::$warningMessage);
        }

        return $result;
    }

    /**
     * @param SystemParamsRequest $request
     * @param $id
     * @return JsonResponse
     */
    public function update(SystemParamsRequest $request, $id)
    {
        $newValue = $request->value;
        $guidParams = ['guid_oik_in_medo', 'guid_organization_recipient_document_ched_in_medo'];
        try {
            $systemParam = SystemParam::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Системного параметра с переданным id ' . $id . ' не существует');
        }

        if (in_array($systemParam->code, $guidParams)) {
            $guid = mb_strtolower($newValue);

            if (!Uuid::validate($guid)) {
                return response()->json(['code' => 400, 'message' => 'Uid не прошел проверку валидацию.'], 400);
            }
        } elseif ($systemParam->code === 'fund') {
            $fund = Fund::findOrFail($newValue);
            $fund->is_default = true;
            $fund->save();
        } elseif (in_array($systemParam->code, ['type_skzi', 'vipnet_host', 'vipnet_login', 'vipnet_password'])) {
            if (request()->hasSession() && request()->session()->has('vipnet')) {
                request()->session()->forget('vipnet');
            }
        } elseif ($systemParam->code === 'count_used_passwords') {
            if (!preg_match('/^[0-9]{1,255}$/', $newValue)) {
                return response()->json(['code' => 400, 'message' => 'Значение должно быть числом.'], 400);
            }
        } elseif ($systemParam->code === 'period_check_renewals_ak') {
            SetLaunchStart::setLaunchStart($systemParam, $newValue);
        } elseif ($systemParam->code === 'file_storage_path') {
            Cache::forget(SystemParam::where('code', 'guid_oik_in_medo')->pluck('value')->first());
        } elseif ($systemParam->code === 'in_containers_medo') {
            $path = $newValue;
            $path = str_split($path, 1);
            try {
                $countPath = count($path) - 1;



                if ($path[$countPath] != "/") {
                    array_push($path, '/');
                }
                if ($path[0] != "/") {
                    array_unshift($path, '/');
                }


                $path = implode($path);
                $newValue = $path;
                if (!file_exists($path)) {
                    return response(['message' => 'Каталог ' . $path . ' не существует', 'code' => 404], 404);
                }
            } catch (Exception $e) {
                return response(["message" => "Значение Входящей директории МЭДО указанно неверно.", "code" => 400], 400);
            }
        }

        $systemParam->value = $guid ?? $newValue;
        $systemParam->save();

        if ($systemParam->wasChanged('value')) {
            return response()->json(['code' => 201, 'message' => 'Данные успешно изменены'], 201);
        } else {
            return response()->json(['code' => 200, 'message' => 'Данные не были изменены'], 200);
        }
    }
}
