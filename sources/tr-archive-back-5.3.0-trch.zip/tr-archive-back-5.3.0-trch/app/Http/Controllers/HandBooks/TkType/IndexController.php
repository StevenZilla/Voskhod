<?php

namespace App\Http\Controllers\HandBooks\TkType;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\TkType\IndexResource;
use App\Models\Tk\TkType;
use Illuminate\Http\Request;

class IndexController extends Controller
{
	public function __invoke(Request $request)
	{
		$types = TkType::all();
		return new IndexResource($types);
	}
}
