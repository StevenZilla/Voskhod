<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Http\Requests\HandBooks\Archive\UpdateArchiveRequest;

/**
 * UpdateController class for updating Archive data.
 */
class UpdateController extends BaseController
{
    /**
     * @param int $id
     * @param UpdateArchiveRequest $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(int $id, UpdateArchiveRequest $request)
    {
        $data = $request->validated();
        try {
            $this->service->update($id,$data);
            return response(null,204);
        } catch (\Exception $e) {
            return response(['code' => '404', 'message' => __('main.archive.notFound')], 404);
        }
    }
}
