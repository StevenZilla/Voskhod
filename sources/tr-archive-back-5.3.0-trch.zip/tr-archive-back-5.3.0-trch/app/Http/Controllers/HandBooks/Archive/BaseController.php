<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Services\HandBooks\Archive\ArchiveService;

class BaseController
{
    public $service = null;

    public function __construct(ArchiveService $service)
    {
        $this->service = $service;
    }
}
