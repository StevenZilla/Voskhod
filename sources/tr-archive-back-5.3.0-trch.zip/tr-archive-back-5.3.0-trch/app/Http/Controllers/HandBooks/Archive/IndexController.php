<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Archive\IndexArchiveRequest;
use App\Http\Resources\HandBooks\Archive\IndexResource;
use App\Models\HandBooks\Archive;

/**
 * IndexController class for get data Archive.
 */
class IndexController extends Controller
{
    /**
     * @param IndexArchiveRequest $request
     * @return IndexResource
     */
    public function __invoke(IndexArchiveRequest $request)
    {
        $archives = Archive::Filters($request)
            ->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($archives);
    }
}
