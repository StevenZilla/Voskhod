<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Http\Controllers\Controller;
use App\Http\Controllers\HandBooks\Archive\ModelNotFoundException;
use App\Http\Resources\HandBooks\Archive\ArchiveResource;
use App\Models\HandBooks\Archive;

class ShowController extends Controller
{
    /**
     * @param int $id
     * @return ArchiveResource|ModelNotFoundException
     */
    public function __invoke(int $id)
    {
        try {
            $archive = Archive::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Архива с переданным id '.$id.' не существует');
        }

        return new ArchiveResource($archive);
    }
}
