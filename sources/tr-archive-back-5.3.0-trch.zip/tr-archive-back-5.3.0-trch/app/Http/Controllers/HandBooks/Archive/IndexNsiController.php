<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Archive\IndexArchiveRequest;
use App\Http\Resources\HandBooks\Archive\IndexNsiResource;
use App\Models\HandBooks\Archive;

/**
 * IndexController class for get data Archive.
 */
class IndexNsiController extends Controller
{

    /**
     * @param IndexArchiveRequest $request
     * @return IndexNsiResource
     */
    public function __invoke(IndexArchiveRequest $request)
    {
        $archives = Archive::Filters($request)->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->Orders($request)->get(['id', 'short_name', 'code']);
        return new IndexNsiResource($archives);
    }
}
