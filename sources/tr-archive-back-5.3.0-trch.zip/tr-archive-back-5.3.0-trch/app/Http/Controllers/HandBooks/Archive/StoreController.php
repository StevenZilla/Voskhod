<?php

namespace App\Http\Controllers\HandBooks\Archive;

use App\Http\Requests\HandBooks\Archive\StoreArchiveRequest;

/**
 * StoreController class for saving the data Archive.
 */
class StoreController extends BaseController
{
    /**
     * @param StoreArchiveRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(StoreArchiveRequest $request)
    {
        $data = $request->validated();
        $archive = $this->service->store($data);

        return response(['code' => 201, 'message' => $archive->id], 201);

    }
}
