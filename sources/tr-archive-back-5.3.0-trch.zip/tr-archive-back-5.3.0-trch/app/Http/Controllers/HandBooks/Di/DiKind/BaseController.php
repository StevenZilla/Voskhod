<?php

namespace App\Http\Controllers\HandBooks\Di\DiKind;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Di\DiKind\DiKindService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(DiKindService $service)
    {
        $this->service = $service;
    }
}
