<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier\Nsi;


use Illuminate\Http\Request;
use App\Services\SQL\SqlQuery;
use App\Models\Di\DiClassifier;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Controllers\HandBooks\Di\DiClassifier\BaseController;
use App\Http\Resources\HandBooks\Di\DiClassifier\Nsi\DiKindGroupAggregateNsiResource;

class DiKindGroupAggregateNsiController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $diClassifier = DiClassifier::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response(["message" => "Классификатора с переданным идентификатором не существует", "code" => 400], 400);
        }

        $diKindGroups = $diClassifier->diKindGroups()->with('children', 'diKinds', 'diKinds.diSavePeriod')->where('parent_id', null)->get();
        $data = DiKindGroupAggregateNsiResource::collection($diKindGroups);
        return response(['di_classifier' => $data], 200);
    }
}
