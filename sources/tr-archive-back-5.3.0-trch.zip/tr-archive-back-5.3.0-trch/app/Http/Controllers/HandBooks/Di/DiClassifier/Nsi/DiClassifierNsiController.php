<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier\Nsi;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Di\DiClassifier\Nsi\DiClassifierNsiResource;
use App\Models\Di\DiClassifier;
use Illuminate\Http\Request;

class DiClassifierNsiController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $diClassifier = DiClassifier::select(['id', 'name', 'short_name', 'version'])->get();
        return response(['di_classifier' => DiClassifierNsiResource::collection($diClassifier)], 200);
    }
}
