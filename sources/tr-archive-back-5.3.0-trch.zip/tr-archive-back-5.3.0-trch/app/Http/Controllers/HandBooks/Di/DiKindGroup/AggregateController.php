<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use App\Exceptions\BaseException;
use Exception;
use App\Models\Di\DiClassifier;
use App\Http\Requests\HandBooks\Di\DiKindGroup\AggregateRequest;
use App\Http\Resources\HandBooks\Di\DiKindGroup\AggregateResource;
use App\Models\Di\DiKind;
use App\Services\SQL\SqlQuery;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class AggregateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(AggregateRequest $request, $id)
    {

        if (!$request->has('inactive_di_kind')) {
            $request->query->set('inactive_di_kind', false);
        }
        try {
            $diClassifier = DiClassifier::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response(["message" => "Классификатор с переданным id {$id} не найден", "code" => 400], 400);
        }
        $diKindGroups = DiClassifier::findOrFail($id)->diKindGroupsTree()->Filters($request)->orderDefault($request, 'path', 'asc', '')->with('diKinds')->get()->unique();
        try {
            $diKinds = DiKind::Filters($request)->leftJoin('di_kind_group', 'di_kind.group_id', '=', 'di_kind_group.id')
                ->where('di_kind_group.di_classifier_id', $id)
                ->with('diSavePeriod', 'dossier', 'diSavePeriod.temp_save_type', 'diKindInDossier', 'diSavePeriod.save_type')
                ->orderByRaw("substring(di_kind.num, '^[0-9]+')::int, substring(di_kind.num, '[^0-9]*$') asc")
                ->get(['di_kind.*']);
            $groupInDossier = SqlQuery::showAggregateDiClassifier($id);
            $diKindGroups = $this->service->extendModelIsBlockDelete($diKindGroups, $groupInDossier, $diClassifier);
            $diKindGroups = $this->service->extendModelIsLeaf($diKindGroups);
            $diKindGroups = $this->service->extendModelDiKind($diKindGroups, $diKinds, $diClassifier);
            return response(['di_groups' => AggregateResource::collection($diKindGroups)], 200);
        } catch (Exception $e) {
            if ($e instanceof BaseException) {
                return response(['message' => $e->getMessage(), 'code' => 500], 500);
            }
            return response(['message' => 'Ошибка сервера', 'code' => 500], 500);
        }
    }
}
