<?php

namespace App\Http\Controllers\HandBooks\Di\DiKind;

use Exception;
use App\Models\Di\DiKind;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DestroyController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id)
    {
        try {
            $kind = DiKind::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Статьи классификатора с переданным id ' . $id . ' не существует');
        }
        // try {
        $this->service->kindDestroy($kind);
        return response(null, 200);
        // } catch (Exception $e) {
        //     return response(["message" => "Ошибка удаления статьи", "code" => 500,], 500);
        // }
    }
}
