<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Exceptions\BaseException;
use Exception;
use App\Models\Di\DiClassifier;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\HandBooks\Di\DiClassifier\UpdateRequest;
use App\Http\Controllers\HandBooks\Di\DiClassifier\BaseController;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(UpdateRequest $request, $id)
    {
        $data = $request->validated();
        try {
            $diClassifier = DiClassifier::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Реестр с переданным id ' . $id . ' не существует');
        }
        if ($diClassifier->is_ched == true) {
            throw new BaseException('Невозможно отредактировать реестр из ЦХЭД. Создайте свой реестр или клонируйте типовой.');
        }
        if ($diClassifier->is_active == false) {
            throw new BaseException('Невозможно отредактировать неактивный реестр.');
        }

        try {
            $this->service->update($diClassifier, $data);
            return response(null, 204);
        } catch (Exception $e) {
            return response(["code" => 500], 500);
        }
    }
}
