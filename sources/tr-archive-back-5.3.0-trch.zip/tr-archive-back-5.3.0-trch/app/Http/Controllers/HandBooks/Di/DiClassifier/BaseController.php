<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Di\DiClassifier\DiClassifierService;
use App\Services\SSE\SseService;

class BaseController extends Controller
{
    public $service = null;
    public $sseService = null;

    public function __construct(DiClassifierService $service, SseService $sseService)
    {
        $this->service = $service;
        $this->sseService = $sseService;
    }
}
