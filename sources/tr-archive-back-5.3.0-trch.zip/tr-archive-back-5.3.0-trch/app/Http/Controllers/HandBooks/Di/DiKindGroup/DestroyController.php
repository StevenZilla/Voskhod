<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use Exception;
use App\Models\Di\DiKindGroupLTree;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DestroyController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id)
    {
        try {
            $kind = DiKindGroupLTree::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Группы статей классификатора с переданным id ' . $id . ' не существует');
        }
        // try {
        $this->service->kindGroupDestroy($kind, $id);
        return response(null, 204);
        // } catch (Exception $e) {
        //     Log::channel('test_log')->error("Ошибка удаления группы" . $e);
        //     return response(["message" => "Ошибка удаления группы", "code" => 500], 500);
        // }
    }
}
