<?php

namespace App\Http\Controllers\HandBooks\Di\DiKind;

use App\Services\HandBooks\Di\DiClassifier\DiClassifierService;
use Exception;
use App\Models\Di\DiKind;
use App\Exceptions\BaseException;
use App\Models\Di\DiKindInDossier;
use App\Http\Requests\HandBooks\Di\DiKind\UpdateRequest;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\HandBooks\Di\DiKindGroup\DiKindResource;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(UpdateRequest $request, $id)
    {
        $data = $request->validated();
        try {
            $kind = DiKind::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Статьи классификатора с переданным id ' . $id . ' не существует');
        }
        $dossiers = $kind->dossier()->pluck('dossier.id');
        $kindBlockEdit = DiKindInDossier::whereIn('dossier_id', $dossiers)->where('di_kind_id', '!=', $kind->id)->exists();
        if ($kindBlockEdit) {
            throw new BaseException('Редактирование статьи невозможно. Существует дело со смежными статьями.');
        }
        $isBlock = DiKindInDossier::where('di_kind_id', $id)->where('is_block', true)->exists();
        if ($isBlock) {
            throw new BaseException('Редактирование статьи невозможно. Существует блокирующее(закрытое) дело.');
        }
        $classifier = $kind->diKindGroup->diClassifier;
        if ($classifier->is_ched == true) {
            throw new BaseException("Редактирование статей классификатора полученного из ЦХЭД запрещено.");
        }
        $model = $this->service->update($kind, $data);
        $classifierId =  $kind->diKindGroup->di_classifier_id;
        DiClassifierService::refreshUpdatedAt($classifierId);
        return response(["di_kind" => new DiKindResource($model)], 200);
    }
}
