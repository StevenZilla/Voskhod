<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Models\Di\DiClassifier;
use App\Http\Requests\HandBooks\Di\DiClassifier\StoreRequest;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StoreRequest $request)
    {
        $data = $request->validated();
        if(DiClassifier::where('is_ched', false)->exists()){
            return response(["message" => "Ошибка создания. Классификатор типа ОИК уже существует", "code" => 400], 400);
        }
        $result = $this->service->store($data);
        if ($result != false) {
            return response(['message' => $result->id, 'code' => 201], 201);
        } else {
            return response(['message' => 'Ошибка. Не удалось создать справочник.', 'code' => 400], 400);
        }
    }
}
