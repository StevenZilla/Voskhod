<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Http\Resources\HandBooks\Di\DiClassifier\ShowResource;
use App\Models\Di\DiClassifier;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

class ShowController extends BaseController
{
    public function __invoke(Request $request, $id)
    {
        try {
            $diClassifier = DiClassifier::findOrFail($id);
            $queryParams  = $request->query();
            if ($request->has('is_history') && ($queryParams['is_history'] == "true")) {
                $oldOik = $this->service->getOldVersionOik();
                $oldChed = $this->service->getOldVersionChed();
                if ($diClassifier->is_ched == true) {
                    $diClassifier->old_version =  $oldChed;
                } else {
                    $diClassifier->old_version =  $oldOik;
                }
            }
            return response(new ShowResource($diClassifier), 200);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Классификатора с переданным id ' . $id . ' не существует');
        }
    }
}
