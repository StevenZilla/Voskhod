<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use Exception;
use App\Models\Di\DiClassifier;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Jobs\CloneNsiDiClassifierJob;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Http\Requests\HandBooks\Di\DiClassifier\CloneRequest;
use Illuminate\Support\Facades\Event;
use OwenIt\Auditing\Events\AuditCustom;

class CloneController extends Controller
{
    use DispatchesJobs;

    public function __invoke(CloneRequest $request)
    {
        $data = $request->validated();

        if(DiClassifier::where('is_ched', false)->count()>1){
            return response(["message" => "Ошибка клонирования. Классификатор типа ОИК уже существует", "code" => 400], 400);
        }

        // if (empty($data['from'])) {
        //     // $mainDiClassifierExists = DiClassifier::where('is_main', true)->pluck('id')->first();
        //     $mainDiClassifierExists = DiClassifier::where('is_ched', true)->orderBy('version','desc')->first();
        //     if ($mainDiClassifierExists == null) {
        //         return response(["message" => "Ошибка клонирования. Основной классификатор не выбран", "code" => 400], 400);
        //     }
        //     $data['from'] = $mainDiClassifierExists;
        // }
        try {
            $diClassifier = DiClassifier::findOrFail($data['to']);
        } catch (Exception $e) {
            return response(["message" => "Ошибка клонирования. Классификатор назначения не существует.", "code" => 400], 400);
        }
        $guidOIK = !empty($request->header()['uid']) ? $request->header()['uid'][0] : null;
        $job = new CloneNsiDiClassifierJob(Auth::user(), $guidOIK, !empty($data['from']) ? $data['from'] : null, $data['to']);
        $job->onQueue("clone_classifier_job");
        $job_id = $job->getJobStatusId();
        $diClassifier->job_id =  $job_id;
        $diClassifier->save();


        $diClassifier->auditEvent = 'diClassifierCloning';
        $diClassifier->isCustomEvent = true;
        Event::dispatch(AuditCustom::class, [$diClassifier]);
        $this->dispatch($job);
        return response(["job_id" => $job->getJobStatusId()], 202);
    }
}
