<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use App\Exceptions\BaseException;
use App\Services\HandBooks\Di\DiClassifier\DiClassifierService;
use Exception;
use App\Models\Di\DiKindGroup;
use App\Models\Di\DiKindGroupLTree;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\HandBooks\Di\DiKindGroup\UpdateRequest;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(UpdateRequest $request, $id)
    {
        $data = $request->validated();


        try {
            $group = DiKindGroupLTree::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Группы классификатора с переданным id ' . $id . ' не существует');
        }
        if ($group->diClassifier->is_ched == true) {
            throw new BaseException("Редактирование групп классификатора полученного из ЦХЭД запрещено.");
        }
        try {

            $this->service->update($group, $data);
            DiClassifierService::refreshUpdatedAt($group->di_classifier_id);

            return response(null, 204);
        } catch (Exception $e) {
            return response(["message" => "Невозможно изменить данные группы статей", "code" => 500], 500);
        }
    }
}
