<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Di\DiKindGroup\DiKindGroupService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(DiKindGroupService $service)
    {
        $this->service = $service;
    }
}
