<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Models\Di\DiClassifier;
use App\Http\Requests\HandBooks\Di\DiClassifier\IndexRequest;
use App\Http\Resources\HandBooks\Di\DiClassifier\IndexResource;

class IndexController extends BaseController
{
    public function __invoke(IndexRequest $request)
    {
        $diClassifier = DiClassifier::Filters($request)->orders($request)->get();

        $queryParams  = $request->query();
        if ($request->has('is_history') && ($queryParams['is_history'] == "true")) {
            $oldOik = $this->service->getOldVersionOik();
            $oldChed = $this->service->getOldVersionChed();
            $diClassifier->map(function ($di) use ($oldOik, $oldChed) {
                if ($di->is_ched == true) {
                    $di->old_version =  $oldChed;
                } else {
                    $di->old_version =  $oldOik;
                }
                return $di;
            });
        }
        $this->service->addMarkers($diClassifier);
        return response([
            'di_classifiers' => IndexResource::collection($diClassifier),
            // "view_buttons" => $data
        ], 200);
    }
}
