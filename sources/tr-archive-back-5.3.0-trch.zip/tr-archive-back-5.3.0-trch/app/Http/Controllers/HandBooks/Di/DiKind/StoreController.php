<?php

namespace App\Http\Controllers\HandBooks\Di\DiKind;

use App\Http\Requests\HandBooks\Di\DiKind\StoreRequest;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StoreRequest $request)
    {
        $data = $request->validated();
        $result = $this->service->store($data);
        if (is_bool($result) && $result == false) {
            return response(['message' => 'Ошибка создания статьи классификатора', 'code' => 500], 500);
        } else {
            return response(['message' => $result->id, 'code' => 201], 200);
        }
    }
}
