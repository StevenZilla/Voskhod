<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use App\Http\Requests\HandBooks\Di\DiKindGroup\StoreRequest;
use App\Services\HandBooks\Di\DiClassifier\DiClassifierService;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StoreRequest $request)
    {
        $data = $request->validated();
        $result = $this->service->store($data);
        if (is_bool($result)) {
            return response(['message' => 'Ошибка создания группы классификатора', 'code' => 500], 500);
        } else {
            DiClassifierService::refreshUpdatedAt($data['di_classifier_id']);
            return response(['message' => $result->id, 'code' => 201], 201);
        }
    }
}
