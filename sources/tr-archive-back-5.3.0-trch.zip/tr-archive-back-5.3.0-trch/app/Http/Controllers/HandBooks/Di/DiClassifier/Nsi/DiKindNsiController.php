<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier\Nsi;

use Illuminate\Http\Request;
use App\Models\Di\DiClassifier;
use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Di\DiClassifier\IndexNsiRequest;
use App\Http\Resources\HandBooks\Di\DiClassifier\Nsi\DiKindNsiResource;
use App\Models\Di\DiKind;
use App\Models\Nomenclature\Nomenclature;

class DiKindNsiController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(IndexNsiRequest $request)
    {
        if (!$request->has('inactive_di_kind')) {
            $request->query->set('inactive_di_kind', false);
        }
        $diKind = DiKind::with('diSavePeriod')
            ->join('di_kind_group', 'di_kind.group_id', '=', 'di_kind_group.id')
            ->join('di_classifier', 'di_kind_group.di_classifier_id', '=', 'di_classifier.id')
            ->where('di_classifier.is_main', true)
            ->Filters($request)
            ->orders($request)
            ->get();

        return response(DiKindNsiResource::collection($diKind), 200);
    }
}
