<?php

namespace App\Http\Controllers\HandBooks\Di\DiSavePeriod;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Di\DiSavePeriod\DiSavePeriodService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(DiSavePeriodService $service)
    {
        $this->service = $service;
    }
}
