<?php

namespace App\Http\Controllers\HandBooks\Di\DiKind;

use Exception;
use App\Models\Di\DiKind;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Di\DiKind\ActiveRequest;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;

class ActiveController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(ActiveRequest $request, $id)
    {
        $data = $request->validated();
        try {
            $kind = DiKind::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Статьи классификатора с переданным id ' . $id . ' не существует');
        }
        try {
            $this->service->setActive($kind, $data);
            return response(null, 204);
        } catch (Exception $e) {
            Log::channel('test_log')->error('Невозможно изменить статус статей' . $e->getMessage());
            return response(["code" => 500], 500);
        }
    }
}
