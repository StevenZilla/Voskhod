<?php

namespace App\Http\Controllers\HandBooks\Di\DiKindGroup;

use Exception;
use Illuminate\Http\Request;
use App\Models\Di\DiKindGroupLTree;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Requests\HandBooks\Di\DiKindGroup\ActiveRequest;
use Illuminate\Support\Facades\Log;

class ActiveController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(ActiveRequest $request, $id)
    {
        $data = $request->validated();
        try {
            $group = DiKindGroupLTree::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Группы классификатора с переданным id ' . $id . ' не существует');
        }
        try {
            $this->service->setActive($group, $data);
            return response(null, 204);
        } catch (Exception $e) {
            Log::channel('test_log')->error('Невозможно изменить статус группы статей' . $e->getMessage());
            return response(["message" => "Невозможно изменить статус группы статей", "code" => 500], 500);
        }
    }
}
