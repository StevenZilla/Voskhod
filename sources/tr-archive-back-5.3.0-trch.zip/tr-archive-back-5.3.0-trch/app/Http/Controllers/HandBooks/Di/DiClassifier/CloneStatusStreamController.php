<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Http\Controllers\Controller;
use App\Models\Di\DiClassifier;
use App\Services\HandBooks\Di\DiClassifier\DiClassifierService;
use Illuminate\Http\Request;

class CloneStatusStreamController extends BaseController
{
    public function __invoke($id)
    {
        return $this->sseService->openStream([$id], function ($id) {
            return DiClassifierService::getJobInfo($id);
        });
    }
}
