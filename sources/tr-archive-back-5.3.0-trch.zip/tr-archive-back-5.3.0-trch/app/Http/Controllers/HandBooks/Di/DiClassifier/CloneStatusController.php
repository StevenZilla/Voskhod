<?php

namespace App\Http\Controllers\HandBooks\Di\DiClassifier;

use App\Http\Controllers\Controller;
use Imtigger\LaravelJobStatus\JobStatus;

class CloneStatusController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id)
    {
        $jobStatus = JobStatus::find($id);
        return $jobStatus;
    }
}
