<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Requests\Signer\StoreRequest;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StoreRequest $request)
    {
        $data = $request->validated();
        try {
            $signer = $this->service->store($data);

            return response()->json(['code' => 201, 'message' => $signer->id], 201);
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => 'Дублируются данные'], 400);
        }

        return response(['code' => 201, 'message' => 'ok'], 201);
    }
}
