<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Signer\SignerService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(SignerService $service)
    {
        $this->service = $service;
    }
}
