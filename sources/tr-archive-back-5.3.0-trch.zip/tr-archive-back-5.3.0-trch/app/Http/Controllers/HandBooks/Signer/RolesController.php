<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Controllers\Controller;
use App\Models\Signer\SignerRole;
use Illuminate\Http\Request;

class RolesController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $roles = SignerRole::orderByRaw('participant_role.name collate "C" asc')->get();
//        return RoleResource::collection($roles);
        return $roles;
    }
}
