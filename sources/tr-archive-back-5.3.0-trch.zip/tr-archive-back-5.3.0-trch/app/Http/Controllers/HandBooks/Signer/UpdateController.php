<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Requests\Signer\UpdateRequest;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Log;

class UpdateController extends BaseController
{

    public function __invoke(int $id, UpdateRequest $request)
    {
        $data = $request->validated();
        try {
            $this->service->update($id, $data);
            return response(null, 204);
        } catch (\Exception $e) {
            if ($e instanceof QueryException) {
                if (strpos($e->getMessage(), 'signer_user_id_signer_role_id_unique') !== false) {
                    Log::error("Не смогли обновить участника согласования дублируются данные signer_user_id_signer_role_id_unique");
                    return response(['code' => '400', 'message' => __('main.signer.signer_user_id_signer_role_id_unique')], 400);
                }
            } else {
                Log::error("Не смогли обновить участника согласования - {$id}");
                return response(['code' => '404', 'message' => __('main.signer.notFound')], 404);
            }
        }
    }
}
