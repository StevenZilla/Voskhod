<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Signer\IndexNsiResource;
use App\Models\Participant\Participant;
use Illuminate\Http\Request;

/**
 * IndexController class for get data Archive.
 */
class IndexNsiController extends Controller
{

    /**
     * @param Request $request
     * @return IndexNsiResource
     */
    public function __invoke(Request $request)
    {
        $participants = Participant::filters($request)
            ->orders($request)->get(['id', 'user_id']);
        return new IndexNsiResource($participants);
    }
}
