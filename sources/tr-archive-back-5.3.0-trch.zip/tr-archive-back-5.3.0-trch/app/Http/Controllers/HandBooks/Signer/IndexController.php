<?php

namespace App\Http\Controllers\HandBooks\Signer;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Signer\IndexResource;
use App\Models\Signer\Signer;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request)
    {
        $signers = Signer::filters($request)
            ->orders($request)
            ->autopaginate($request);
            return new IndexResource($signers);
    }
}
