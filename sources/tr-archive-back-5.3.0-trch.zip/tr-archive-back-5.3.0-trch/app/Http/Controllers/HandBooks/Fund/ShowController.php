<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Fund\FundResource;
use App\Models\HandBooks\Fund;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowController extends Controller
{
    /**
     * @param int $id
     * @return FundResource
     */
    public function __invoke(int $id)
    {
        try {
            $fund = Fund::with('archive')
                ->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Фонда с переданным id '.$id.' не существует');
        }

        return new FundResource($fund);
    }
}
