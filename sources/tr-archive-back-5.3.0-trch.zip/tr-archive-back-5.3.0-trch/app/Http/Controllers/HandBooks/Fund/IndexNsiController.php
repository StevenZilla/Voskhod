<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Fund\IndexNsiResource;
use App\Models\HandBooks\Fund;
use Illuminate\Http\Request;

/**
 * IndexController class for get data Archive.
 */
class IndexNsiController extends Controller
{

    /**
     * @param Request $request
     * @return IndexNsiResource
     */
    public function __invoke(Request $request)
    {
        $funds = Fund::Filters($request)->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->Orders($request)->get(['id', 'name', 'code']);
        return new IndexNsiResource($funds);
    }
}
