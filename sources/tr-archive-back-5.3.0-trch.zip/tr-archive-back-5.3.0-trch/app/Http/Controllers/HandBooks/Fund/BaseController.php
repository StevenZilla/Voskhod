<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Fund\FundServcie;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(FundServcie $service)
    {
        $this->service = $service;
    }
}
