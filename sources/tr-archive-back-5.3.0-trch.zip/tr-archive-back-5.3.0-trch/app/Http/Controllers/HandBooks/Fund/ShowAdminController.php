<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Fund\FundAdminResource;
use App\Models\HandBooks\Fund;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowAdminController extends Controller
{
    /**
     * @param int $id
     * @return FundAdminResource
     */
    public function __invoke(int $id)
    {
        try {
            $fund = Fund::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Фонда с переданным id '.$id.' не существует');
        }

        return new FundAdminResource($fund);
    }
}
