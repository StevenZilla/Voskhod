<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Fund\IndexResource;
use App\Models\HandBooks\Fund;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request)
    {
        $funds = Fund::with('archive')
            ->Filters($request)
            ->orderDefault($request, 'name', 'asc', 'collate "C"')
            ->Orders($request)
            ->autoPaginate($request);

        return new IndexResource($funds);
    }
}
