<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Requests\HandBooks\Fund\StoreFundRequest;

class StoreController extends BaseController
{
    /**
     * @param StoreFundRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(StoreFundRequest $request)
    {
        $data = $request->validated();
        try {
            $fund = $this->service->store($data);

            return response()->json(['code' => 201, 'message' => $fund->id], 201);
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => 'Дублируются данные фондов'], 400);
        }

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }
}
