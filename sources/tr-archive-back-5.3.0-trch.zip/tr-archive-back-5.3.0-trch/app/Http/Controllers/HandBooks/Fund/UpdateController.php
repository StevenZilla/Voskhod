<?php

namespace App\Http\Controllers\HandBooks\Fund;

use App\Http\Requests\HandBooks\Fund\UpdateFundRequest;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  UpdateFundRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(int $id, UpdateFundRequest $request)
    {
        $data = $request->validated();

        try {
            $this->service->update($id, $data);

            return response(null, 204);
        } catch (\Exception $e) {
            return response(['code' => '404', 'message' => __('main.archive.notFound')], 404);
        }
    }
}
