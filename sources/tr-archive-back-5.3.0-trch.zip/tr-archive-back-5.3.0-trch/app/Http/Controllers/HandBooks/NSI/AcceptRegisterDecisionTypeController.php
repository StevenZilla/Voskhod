<?php

namespace App\Http\Controllers\HandBooks\NSI;

use App\Http\Controllers\Controller;
use App\Http\Resources\AcceptRegisterDecisionType\ShowResources;
use App\Models\AcceptRegister\Agreement\AcceptRegisterDecisionType;
use Illuminate\Http\Request;

class AcceptRegisterDecisionTypeController extends Controller
{
    public function __invoke(Request $request)
    {
        $decision_type = AcceptRegisterDecisionType::withOrder($request)->get();

        return new ShowResources($decision_type);
    }
}