<?php

namespace App\Http\Controllers\HandBooks\NSI;

use App\Http\Controllers\Controller;
use App\Http\Resources\AcceptRegisterStatus\ShowResource;
use App\Models\AcceptRegister\AcceptRegisterStatus;
use Illuminate\Http\Request;

class AcceptRegisterStatusController extends Controller
{
    public function __invoke(Request $request){
        $status = AcceptRegisterStatus::withFilter($request)->withOrderDefault($request)->get();

        return new ShowResource($status);
    }
}