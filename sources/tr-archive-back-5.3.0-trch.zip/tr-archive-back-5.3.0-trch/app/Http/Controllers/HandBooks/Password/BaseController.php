<?php

namespace App\Http\Controllers\HandBooks\Password;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Password\PasswordService;

class BaseController extends Controller
{
    //
    public $service = null;
    public function __construct(PasswordService $service)
    {
        $this->service = $service;
    }
}
