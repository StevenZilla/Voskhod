<?php

namespace App\Http\Controllers\HandBooks\Password;

use App\Http\Requests\Password\StorePasswordRequest;
use App\Models\User\CompromPassword;

class StoreController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(StorePasswordRequest $request)
    {
        $data = $request->validated();
        try {
           $password = $this->service->store($data);
            return response()->json(['code' => 201, 'message' => $password->id], 201);
        } catch (\Exception $e) {
            return response(['code'=>400, 'message'=>'store.password.error'],400);
        }
    }
}
