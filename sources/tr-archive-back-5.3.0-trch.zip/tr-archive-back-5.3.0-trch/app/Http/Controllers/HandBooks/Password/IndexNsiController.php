<?php

namespace App\Http\Controllers\HandBooks\Password;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Password\IndexNsiResource;
use App\Http\Resources\HandBooks\Password\PasswordNsiResource;
use App\Models\User\CompromPassword;
use Illuminate\Http\Request;

class IndexNsiController extends Controller
{
    /**
     * @param Request $request
     * @return IndexNsiResource
     */
    public function __invoke(Request $request)
    {
            $passwords = CompromPassword::Filters($request)->get(['id','password']);
            return new IndexNsiResource($passwords);

    }
}
