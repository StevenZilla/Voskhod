<?php

namespace App\Http\Controllers\HandBooks\Password;

use App\Http\Requests\Password\UpdatePasswordRequest;
use Illuminate\Http\Request;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(int $id, UpdatePasswordRequest $request)
    {
        $data = $request->validated();
        try {
            $this->service->update($id, $data);
            return response(null, 204);
        } catch (\Exception $e) {
            return response(['code' => '404', 'message' => __('main.password.notFound')], 404);
        }

    }
}
