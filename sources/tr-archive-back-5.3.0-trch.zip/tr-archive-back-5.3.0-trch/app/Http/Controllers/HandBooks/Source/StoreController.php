<?php

namespace App\Http\Controllers\HandBooks\Source;

use App\Http\Requests\Source\StoreSourceRequest;

class StoreController extends BaseController
{
    /**
     * @param StoreSourceRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function __invoke(StoreSourceRequest $request)
    {
        $data = $request->validated();
        try {
            $fund = $this->service->store($data);

            return response()->json(['code' => 201, 'message' => $fund->id], 201);
        } catch (\Exception $exception) {
            return response()->json(['code' => 400, 'message' => __('main.source.duplicate')], 400);
        }

        return response()->json(['code' => 201, 'message' => 'ok'], 201);
    }
}
