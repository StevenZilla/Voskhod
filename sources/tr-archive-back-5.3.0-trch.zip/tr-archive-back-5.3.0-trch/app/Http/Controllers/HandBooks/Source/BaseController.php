<?php

namespace App\Http\Controllers\HandBooks\Source;

use App\Http\Controllers\Controller;
use App\Services\HandBooks\Source\SourceService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(SourceService $service)
    {
        $this->service = $service;
    }
}
