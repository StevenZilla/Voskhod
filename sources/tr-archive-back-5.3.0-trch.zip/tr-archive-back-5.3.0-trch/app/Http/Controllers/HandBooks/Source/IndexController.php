<?php

namespace App\Http\Controllers\HandBooks\Source;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Source\IndexResource;
use App\Models\HandBooks\Source;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * @param Request $request
     * @return IndexResource
     */
    public function __invoke(Request $request)
    {
        $sources = Source::Filters($request)
            ->orderDefault($request, 'actual_date', 'asc', '')
            ->Orders($request)
            ->autoPaginate($request);

        return new IndexResource($sources);
    }
}
