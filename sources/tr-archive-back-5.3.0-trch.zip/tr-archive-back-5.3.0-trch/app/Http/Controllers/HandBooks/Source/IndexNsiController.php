<?php

namespace App\Http\Controllers\HandBooks\Source;

use App\Http\Controllers\Controller;
use App\Http\Resources\HandBooks\Source\IndexNsiResource;
use App\Models\HandBooks\Source;
use Illuminate\Http\Request;

/**
 * IndexController class for get data Archive.
 */
class IndexNsiController extends Controller
{

    /**
     * @param Request $request
     * @return IndexNsiResource
     */
    public function __invoke(Request $request)
    {
        $sources = Source::Filters($request)
            ->orderDefault($request, 'actual_date', 'asc', '')
            ->Orders($request)->get(['id', 'name', 'code']);

        return new IndexNsiResource($sources);
    }
}
