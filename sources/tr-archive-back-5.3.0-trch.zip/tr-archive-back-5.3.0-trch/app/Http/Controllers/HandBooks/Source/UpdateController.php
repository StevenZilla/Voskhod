<?php

namespace App\Http\Controllers\HandBooks\Source;

use App\Http\Requests\Source\UpdateSourceRequest;

class UpdateController extends BaseController
{
    /**
     * Handle the incoming request.
     *
     * @param  UpdateSourceRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(int $id, UpdateSourceRequest $request)
    {
        $data = $request->validated();
        try {
            $this->service->update($id, $data);

            return response(null, 204);
        } catch (\Exception $e) {
            return response(['code' => '404', 'message' => __('main.source.notFound')], 404);
        }
    }
}
