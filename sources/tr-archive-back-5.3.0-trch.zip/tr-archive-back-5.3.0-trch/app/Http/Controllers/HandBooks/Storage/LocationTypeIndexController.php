<?php

namespace App\Http\Controllers\HandBooks\Storage;

use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Storage\IndexLocationTypeRequest;
use App\Http\Resources\HandBooks\Storage\LocationTypeIndexResource;
use App\Models\HandBooks\LocationType;

class LocationTypeIndexController extends Controller
{
    public function __invoke(IndexLocationTypeRequest $request)
    {
        $locationTypes = LocationType::where('parent_id', null)
            ->orderBy('id', 'asc')
            ->with('locationTypes')
            ->get();

        return ['storage_type' => LocationTypeIndexResource::collection($locationTypes)];
    }
}
