<?php

namespace App\Http\Controllers\HandBooks\Storage;

use App\Http\Controllers\Controller;
use App\Http\Requests\HandBooks\Storage\IndexLocationTypeRequest;
use App\Http\Resources\HandBooks\Storage\LocationTypeIndexResource;
use App\Models\HandBooks\LocationType;

class LocationTypeShowController extends Controller
{
    public function __invoke(IndexLocationTypeRequest $request, string $id)
    {
        $locationTypes = LocationType::with('locationTypes')
            ->where('parent_id', $id)
            ->get();

        return ['storage_type' => LocationTypeIndexResource::collection($locationTypes)];
    }
}