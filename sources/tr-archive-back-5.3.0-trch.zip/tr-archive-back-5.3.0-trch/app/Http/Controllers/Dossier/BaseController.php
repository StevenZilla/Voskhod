<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Controllers\Controller;
use App\Services\Dossier\DossierService;

class BaseController extends Controller
{
    public $service = null;

    public function __construct(DossierService $service)
    {
        $this->service = $service;
    }
}
