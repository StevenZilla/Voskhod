<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Requests\Dossier\ChangeStatusDossierEdit;

class SetCloseStatusController extends BaseController
{
    public function __invoke(int $id)
    {
        return $this->service->changeStatus($id, 'closed');
    }
}
