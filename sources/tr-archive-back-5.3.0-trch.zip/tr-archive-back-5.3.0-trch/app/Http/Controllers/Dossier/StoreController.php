<?php

namespace App\Http\Controllers\Dossier;


use App\Http\Requests\Dossier\StoreDossierRequest;

class StoreController extends BaseController
{
    /**
     * @param StoreDossierRequest $request
     * @return mixed
     */
    public function __invoke(StoreDossierRequest $request)
    {
        $data = $request->validated();
        return $this->service->store($data);
    }
}
