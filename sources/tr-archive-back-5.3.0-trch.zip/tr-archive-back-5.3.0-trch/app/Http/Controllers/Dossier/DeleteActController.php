<?php

namespace App\Http\Controllers\Dossier;

use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DeleteActController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id,Request $request)
    {
        //TODO реализовано в виде фильтра
        // try {
        //     $dossier = Dossier::with('eds','eds.deleteAct','eds.deleteAct.deleteActStatus')->withTrashed()->findOrFail($id);
        // } catch (ModelNotFoundException $e) {
        //     throw new ModelNotFoundException('Дело с переданным id ' . $id . ' не существует');
        // }
        // $deleteActs = collect();
        // foreach ($dossier->eds as $ed) {
        //     $deleteActs->push($ed->deleteAct);
        // }
        // $deleteActs = $deleteActs->unique("id");
        // return $deleteActs;
        // $deleteAct = 
        // return $deleteAct;
    }
}
