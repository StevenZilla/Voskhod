<?php

namespace App\Http\Controllers\Dossier;


class ShowController extends BaseController
{
    /**
     * @param $id
     * @return mixed
     */
    public function __invoke($id)
    {
        return $this->service->show($id);
    }
}
