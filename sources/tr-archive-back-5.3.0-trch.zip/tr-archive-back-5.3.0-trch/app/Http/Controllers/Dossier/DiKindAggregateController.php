<?php

namespace App\Http\Controllers\Dossier;

use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
use App\Models\Di\DiKindGroupLTree;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Resources\Dossier\DiKindGroupAggregateResource;

class DiKindAggregateController extends Controller
{
    public function __invoke($id, Request $request)
    {
        try {
            $dossier = Dossier::with('diKind', 'diKind.diSavePeriod', 'diKind.diKindGroup', 'diKind.diKindGroup.diClassifier')
            ->withTrashed()
                ->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return response(["Message" => "Дело с идентификатором {$id} не найдено.", "code" => 400], 400);
        }
        $diKinds = $dossier->diKind;
        $groups = [];
        foreach ($diKinds as $diKind) {
            $groups[] = $diKind->diKindGroup;
        }
        $groups = array_unique($groups);
        $paths = [];
        foreach ($groups as $group) {
            $paths[] = $group->path;
        }
        $uTree = collect();
        $tree = DiKindGroupLTree::ParentsOf($paths)->get();
        foreach ($tree as $key => $tr) {
            $tree[$key]->childrenKind = $diKinds->where('group_id', $tr->id);
            if ($tree->where('parent_id', $tr->id)->isNotEmpty()) {
                $tr->childrenTr = $tree->where('parent_id', $tr->id);
                if ($tr->parent_id == null) {
                    $uTree = $uTree->push($tr);
                }
            } else {
                if (empty($tr->parent_id)) {
                    $uTree = $uTree->push($tr);
                }
            }
        }
        return response(['di_classifier' => DiKindGroupAggregateResource::collection($uTree)], 200);
    }
}
