<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Controllers\Controller;
use App\Http\Requests\Dossier\DossierRequest;
use App\Http\Resources\Dossier\IndexActiveBySubdivisionResource;
use App\Models\Dossier\Dossier;

class IndexActiveBySubdivisionController extends Controller
{
    /**
     * @param DossierRequest $request
     * @return mixed
     */
    public function __invoke(DossierRequest $request)
    {
        $dossiers = Dossier::with(
                'source',
                'lastDossierInNom',
                'dossierInNom',
                'firstRegister',
                'status',
                'cipherIsActive',
                'mediaType',
                'saveType',
                'eds',
                'eds.source',
                'eds.cipherIsActive',
                'eds.edChipher',
                'eds.lastTk',
                'eds.lastTk.archive',
                'eds.lastTk.fund',
                'eds.lastTk.type',
                'diKind',
                'diKind.diSavePeriod'
            )
            ->permissions()
            ->filters($request)
            ->orders($request)
            ->get($request);

        return new IndexActiveBySubdivisionResource($dossiers);
    }
}
