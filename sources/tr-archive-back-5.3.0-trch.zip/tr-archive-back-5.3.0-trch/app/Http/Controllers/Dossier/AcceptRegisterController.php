<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Resources\Dossier\AcceptRegisterDataResource;
use Illuminate\Http\Request;
use App\Models\Dossier\Dossier;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class AcceptRegisterController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke($id, Request $request)
    {
        try {
            $dossier = Dossier::with('acceptRegister:id,name,num,year,accept_register_status_id','acceptRegisterPart:id,name','acceptRegister.registerStatus')->withTrashed()->findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Дело с переданным id ' . $id . ' не существует');
        }

        $acceptRegister = $dossier->acceptRegister->first();
        $acceptRegisterPart = $dossier->acceptRegisterPart->first();
        $dossier->acceptRegister_data = $acceptRegister;
        $dossier->acceptRegisterPart_data = $acceptRegisterPart;
        return response (new AcceptRegisterDataResource($dossier),200);
    }
}
