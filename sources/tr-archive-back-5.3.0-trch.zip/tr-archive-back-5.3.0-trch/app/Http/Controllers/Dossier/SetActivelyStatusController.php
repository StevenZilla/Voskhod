<?php

namespace App\Http\Controllers\Dossier;

class SetActivelyStatusController extends BaseController
{
    public function __invoke(int $id)
    {
        return $this->service->changeStatus($id, 'actively');
    }
}
