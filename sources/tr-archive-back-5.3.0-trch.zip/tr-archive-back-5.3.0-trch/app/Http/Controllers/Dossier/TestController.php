<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Controllers\Controller;
use App\Models\Di\DiKind;
use App\Models\Dossier\Dossier;
use App\Services\HandBooks\Di\DiService;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public static function test($id)
    {

        $dossier = Dossier::find($id);

        $dossier->diKind()->syncWithoutDetaching(20);
        // DiService::setDossierSavePeriod($dossier);

        // $diKind = DiKind::find(76);
        // var_dump(DiService::updateKindCheck($diKind));
    }
}
