<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Controllers\Controller;
use App\Http\Requests\Dossier\DossierRequest;
use App\Http\Resources\Dossier\IndexResource;
use App\Models\Dossier\Dossier;

class IndexController extends Controller
{
    /**
     * @param DossierRequest $request
     * @return mixed
     */
    public function __invoke(DossierRequest $request)
    {
        $dossiers = Dossier::with('source', 'lastDossierInNom', 'dossierInNom', 'firstRegister', 'status', 'cipherIsActive', 'mediaType', 'saveType', 'eds', 'eds.source', 'eds.cipherIsActive', 'eds.edChipher', 'eds.lastTk', 'eds.lastTk.archive', 'eds.lastTk.fund', 'eds.lastTk.type', 'diKind', 'diKind.diSavePeriod', 'acceptRegister', 'acceptRegister.registerStatus')
            ->permissions()
            ->filters($request)
            //     ->toSql();
            // $bindings = Dossier::with('source', 'lastDossierInNom', 'dossierInNom', 'firstRegister', 'status', 'cipherIsActive', 'mediaType', 'saveType', 'eds', 'eds.source', 'eds.cipherIsActive', 'eds.edChipher', 'eds.lastTk', 'eds.lastTk.archive', 'eds.lastTk.fund', 'eds.lastTk.type', 'diKind', 'diKind.diSavePeriod', 'acceptRegister', 'acceptRegister.registerStatus')
            //     ->permissions()
            //     ->filters($request)
            //     ->getBindings();
            // dump($bindings);
            // dd($dossiers);
            ->orders($request)
            ->autoPaginate($request);

        return new IndexResource($dossiers);
    }
}
