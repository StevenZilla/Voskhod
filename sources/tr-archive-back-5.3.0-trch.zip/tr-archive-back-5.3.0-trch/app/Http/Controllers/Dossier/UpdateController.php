<?php

namespace App\Http\Controllers\Dossier;

use App\Http\Requests\Dossier\EditDossierRequest;

class UpdateController extends BaseController
{
    public function __invoke(EditDossierRequest $request, int $id)
    {
        $data = $request->validated();
        $data = $this->service->update($data, $id);
        $data['code'] = 200;

        return response()->json($data, $data['code']);
    }
}
