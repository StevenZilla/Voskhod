<?php

namespace App\Http\Controllers;

use App\Models\Register\RegisterStatus;

class RegisterStatusController extends Controller
{
    /**
     * @return null[]
     */
    public function index()
    {
        return ['register_status' => RegisterStatus::get() ?: null];
    }
}
