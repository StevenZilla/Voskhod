<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ForgotAuthPassword;
use App\Http\Requests\Auth\ForgotPassword;
use App\Http\Requests\ForgotController\RestorePasswordRequest;
use App\Models\User\User;
use App\Services\Users\ResetPassword;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    /**
     * Validate the email for the given request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validateEmail(Request $request)
    {
        $this->validate($request, ['login' => 'required|string|exists:user,login']);
    }

    /**
     * Display the form to request a password reset link.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLinkRequestForm()
    {
        return false;
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * @param ForgotPassword $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function resetPassword(ForgotPassword $request, $id = null)
    {
        $user = User::findOrFail($id);

        if (ResetPassword::resetPassword($user, $request)) {
            return response()->json(['code' => 201, 'message' => 'true'], 201);
        } else {
            return response()->json(['code' => 400, 'message' => 'Пользователь не активен!'], 400);
        }
    }

    /**
     * @param ForgotAuthPassword $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function resetAuthPassword(ForgotAuthPassword $request)
    {
        if (ResetPassword::resetPassword(Auth::user(), $request, true)) {
            return response()->json(['code' => 201, 'message' => 'true'], 201);
        } else {
            return response()->json(['code' => 404, 'message' => 'Пользователь не активен!'], 404);
        }
    }

    /**
     * @param $response
     * @return bool
     */
    protected function sendResetLinkResponse($response)
    {
        return true;
    }

    public function restorePassword(RestorePasswordRequest $request)
    {
        if (! empty(preg_replace('/(.+)@(.+)\.(.+)/i', '', $request->contact))) {
            $user = User::where('login', $request->contact)->first();
        } else {
            $user = User::where('email', $request->contact)->first();
        }

        if (ResetPassword::restorePassword($user)) {
            return response()->json(['code' => 201, 'message' => 'true'], 201);
        } else {
            return response()->json(['code' => 400, 'message' => 'Не смогли отправить письмо на почту'], 400);
        }
    }
}
