<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\Auth\PasswordSettingsResource;
use App\Models\System\SystemParam;
use Illuminate\Http\Request;

class PasswordSettingsController extends Controller
{
    private $codes = [
        'character_count',
        'lower_case',
        'upper_case',
        'numbers',
        'special_symbols',
    ];

    public function getSettings(Request $request) {

        $systemParams = SystemParam::whereIn('code', $this->codes)->get();
        return [
            'password_requirements' => PasswordSettingsResource::collection($systemParams),
        ];
    }
}