<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\Permissions\SetPermissionOnUser;
use App\Http\Requests\Permissions\UpdatePermissionOnUser;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\Permission\ActionPermission;
use App\Models\Permission\Permission;
use App\Models\Permission\Permission as PermissionModel;
use App\Models\Permission\RoutePermission;
use App\Models\Sert\Sert;
use App\Models\Sert\SertOneUse;
use App\Models\User\User;
use App\Models\User\UserRole;
use App\Services\CheckDate\CheckDate;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $users = User::filters($request)
            ->orderDefault($request, 'fio', 'asc', 'collate "C"')
            ->orders($request);

        if ($request->has('all') && $request->get('all') != 'false') {
            return ['users' => $users->get()];
        } else {
            return $users->withPaginate($request);
        }
    }

    /**
     * @param $id
     * @return mixed
     */
    public function show($id)
    {
        try {
            $user = User::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new ModelNotFoundException('Пользователя с переданным id '.$id.' не существует');
        }

        return $user->formatUser();
    }

    /**
     * @param UpdateUserRequest $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UpdateUserRequest $request, $id)
    {
        try {
            DB::transaction(function () use ($id, $request) {
                if ($request->exists('end_date') && $request->exists('start_date')) {
                    $messageCheckDate = CheckDate::checkStartEndDate($request->get('start_date'), $request->get('end_date'));

                    if ($messageCheckDate !== 'true') {
                        $msg = 'При редактировании пользователя проверка даты начала/окончания действия пользователя не прошла. ';
                        throw new BaseException($msg.$messageCheckDate);
                    }
                }

                $user = User::findOrFail($id);
                $user->updatePatch($request, $user);

                if ($request->has('system_roles')) {
                    foreach ($request->get('system_roles') as $key => $system_role) {
                        if (! empty($system_role['start_date']) && ! empty($system_role['end_date'])) {
                            $messageCheckDate = CheckDate::checkStartEndDate($system_role['start_date'], $system_role['end_date']);

                            if ($messageCheckDate !== 'true') {
                                $msg = 'При редактировании пользователя проверка даты начала/окончания действия роли пользователя не прошла. ';
                                throw new BaseException($msg.$messageCheckDate);
                            }
                        }

                        if (empty($system_role['end_date'])) {
                            $system_role['end_date'] = Carbon::now()->addYears(100)->toDateTimeString();
                        }

                        if (empty($system_role['start_date'])) {
                            $system_role['start_date'] = Carbon::now()->toDateTimeString();
                        }

                        if (! empty($system_role['id'])) {
                            $user_role = UserRole::findOrFail($system_role['id']);

                            if (! ($user_role->checkChangesSystemRole($system_role['role_id']))) {
                                throw new BaseException('Нельзя изменить идентификатор системной роли у системной роли пользователя. Ошибка в \'system_roles.'.$key.'\'');
                            }

                            if (! ($user_role->checkUserID($user->id))) {
                                throw new BaseException('Системной роли пользователя отличается пользователь, которого мы редактируем');
                            }

                            if (! ($user_role->updateUserRole($system_role))) {
                                throw new BaseException('Системная роль пользователя(id = '.$system_role['id'].') не обновилась.');
                            }
                        } else {
                            $user_role = new UserRole();

                            if (! ($user_role->storeUserRole($user->id, $system_role))) {
                                throw new BaseException('Системная роль пользователя не создалась. Ошибка в \'system_roles.'.$key.'\'');
                            }
                        }

                        $not_delete_user_role[] = $user_role->id;
                    }
                }

                if ($request->has('serts')) {
                    foreach ($request->get('serts') as $key => $sert_val) {
                        SertOneUse::where('sert_id', '=', $sert_val['id'])->delete();

                        try {
                            $sert = Sert::findOrFail($sert_val['id']);
                        } catch (ModelNotFoundException $e) {
                            throw new ModelNotFoundException('Сертификата с переданным id '.$sert_val['id'].' не существует');
                        }

                        if (! ($sert->sertChangesThumbprint($sert_val, $user->id))) {
                            throw new BaseException('Системная роль пользователя(id = '.$sert_val['id'].') не обновилась.');
                        }

                        $not_delete_sert[] = $sert->id;

                        if (! empty($sert_val['use'])) {
                            foreach ($sert_val['use'] as $key_use => $use) {
                                $sert_one_use = SertOneUse::where('sert_id', $sert->id)->where('sert_use_id', $use['use_id'])->first();
                                if (empty($sert_one_use)) {
                                    $sert_one_use = new SertOneUse();
                                    if (! ($sert_one_use->storeSertOneUse($sert->id, $use))) {
                                        throw new BaseException('Идентификатор одного назначения сертификата не создался. Ошибка в \'serts.'.$key.'.use'.$key_use.'\'');
                                    }
                                }

                                $not_delete_sert_use[] = $sert_one_use->id;
                            }
                        }

                        SertOneUse::where('sert_id', $sert->id)->whereNotIn('sert_one_use.id', $not_delete_sert_use ?? [])
                            ->delete();
                    }
                }
            });
        } catch (BaseException $e) {
            if (str_contains($e->getMessage(), 'No query results for model [App\Models\User]')) {
                $msg = 'Такого пользователя не существует';
                $status = 400;

                Log::alert('Ошибка при редактировании пользователя, такого пользователя не существует');
            } else {
                $msg = 'Произошла ошибка при редактировании пользователя: '.$e->getMessage();
                $status = 500;

                Log::warning('Ошибка при редактировании пользователя');
            }

            return response()->json(['code' => $status, 'message' => $msg], $status);
        }

        return response()->json(['code' => 201, 'message' => $id], 201);
    }

    /**
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function getInfoCurrentUser()
    {
        try {
            $authUser = Auth::user();
            $currentUser = [
                'id' => $authUser->id,
                'fio' => $authUser->fio,
                'login' => $authUser->login,
                'reg_date' => $authUser->start_date,
                'log_date' => $authUser->log_date,
                'update_password_date' => $authUser->update_password_date,
                'is_2fa' => $authUser->is_2fa,
                'is_block' => $authUser->is_block,
            ];

            return $currentUser;
        } catch (BaseException $e) {
            Log::warning('Не получилось получить информацию текущего пользователя');

            return response()->json(['code' => 400, 'message' => 'Произошла ошибка. Не получилось получить информацию текущего пользователя '.$e->getMessage()], 400);
        }
    }

    public function getPermissions($id)
    {
        return Permission::getPermissionForUser($id);
    }

    public function setPermissions(SetPermissionOnUser $request, $id)
    {
        if (! empty($request->permissions) && count($request->permissions) > 0) {
            if (User::where('id', $id)->where('is_superuser', true)->exists()) {
                return response()->json([
                    'code' => 400,
                    'message' => 'Нельзя пользователю установить права, потому что пользователь является супер-юзером.',
                ], 400);
            }

            $userLogin = User::where('id', $id)->pluck('login')->first();
            foreach ($request->permissions as $permission) {
                $route = RoutePermission::where('name', $permission)->pluck('route')->first();
                PermissionModel::addPolicy($userLogin, $route, $permission, 'true');
            }
        }

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }

    public function updatePermission(UpdatePermissionOnUser $request, $id, $techName)
    {
        if (! ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        if (! User::where('id', $id)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Пользователь отсутствует в системе.',
            ], 400);
        }

        if (User::where('id', $id)->where('is_superuser', true)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Нельзя пользователю обновить права, потому что пользователь является супер-юзером.',
            ], 400);
        }

        $userLogin = User::where('id', $id)->pluck('login')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::addPolicy($userLogin, $route, $techName, $request->rule, 'user');

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }

    public function deletePermission($id, $techName)
    {
        if (! ActionPermission::where('tech_name', $techName)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => "Отсутствует техническое наименование - {$techName} прав доступа в система",
            ], 400);
        }

        if (! User::where('id', $id)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Пользователь отсутствует в системе.',
            ], 400);
        }

        if (User::where('id', $id)->where('is_superuser', true)->exists()) {
            return response()->json([
                'code' => 400,
                'message' => 'Нельзя пользователю удалить права доступа, потому что пользователь является супер-юзером.',
            ], 400);
        }

        $userLogin = User::where('id', $id)->pluck('login')->first();
        $route = RoutePermission::where('name', $techName)->pluck('route')->first();
        PermissionModel::deletePolicy($userLogin, $route, $techName);

        return response()->json([
            'code' => 200,
            'message' => 'ok',
        ], 200);
    }

    public function timePassword()
    {
        return ['password' => Auth()->user()->generatePassword()];
    }
}
