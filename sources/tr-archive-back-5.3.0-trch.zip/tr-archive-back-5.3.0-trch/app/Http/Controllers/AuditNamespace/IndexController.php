<?php

namespace App\Http\Controllers\AuditNamespace;

use App\Http\Controllers\Controller;
use App\Http\Resources\Audit\AuditNamespaceResource;
use App\Models\Audit\AuditNamespace;

class IndexController extends Controller
{
    public function __invoke()
    {
        return new AuditNamespaceResource(AuditNamespace::all());
    }
}
