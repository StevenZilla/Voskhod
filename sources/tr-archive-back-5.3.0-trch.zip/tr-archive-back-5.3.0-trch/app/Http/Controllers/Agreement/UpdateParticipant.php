<?php

namespace App\Http\Controllers\Agreement;

use App\Exceptions\BaseException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Agreement\UpdateParticipantInAgreement;
use App\Models\Agreement;
use App\Models\AgreementType;
use App\Models\ParticipantInAgreement;
use App\Models\Signer\Signer;
use App\Models\Signer\SignerRole;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;

class UpdateParticipant extends Controller
{
    public function __invoke(UpdateParticipantInAgreement $request, $id)
    {
        $agreementId = Agreement::where('register_id', $id)
            ->where('type_id', AgreementType::getIdEc())
            ->where('is_actual', true)
            ->pluck('id')->first();

        if (empty($agreementId)) {
            return response()->json(['code' => 400, 'message' => "Отсутствует согласование, которое является актуальным и имеет тип ЭК у описи с идентификатором {$id}"], 400);
        }

        $data = $request->validated();
        DB::transaction(function () use($agreementId, $data) {
            $checkParticipant = ParticipantInAgreement::where('agreement_id', $agreementId)
                ->whereNotIn('participant_id', $data['ids'])
                ->whereNotNull('decision_type_id')->exists();

            if ($checkParticipant) {
                throw new BaseException("Не можем обновить список участников у согласования с идентификатором {$agreementId}, потому что удаленные участники вынесли решения.");
            }

            ParticipantInAgreement::where('agreement_id', $agreementId)
                ->whereNotIn('participant_id', $data['ids'])
                ->delete();

            $idApprover = SignerRole::getIdApprover();
            foreach ($data['ids'] as $participantId) {
                $existsParticipant = ParticipantInAgreement::where('agreement_id', $agreementId)
                    ->where('participant_id', $participantId)
                    ->exists();

                if (! $existsParticipant) {
                    $participant = Signer::findOrFail($participantId);
                    $participantInAgreement = new ParticipantInAgreement();
                    $participantInAgreement->agreement_id = $agreementId;
                    $participantInAgreement->is_approving = $participant->signer_role_id === $idApprover;
                    $participantInAgreement->participant_id = $participant->id;
                    $participantInAgreement->save();
                }
            }

            $checkApproving = ParticipantInAgreement::where('agreement_id', $agreementId)
                ->where('is_approving', true)
                ->exists();
            if (! $checkApproving) {
                throw new BaseException("Мы не можем обновить участников согласования с идентификатором {$agreementId}, потому что необходим 1 утверждающий");
            }

            $checkCoordinating = ParticipantInAgreement::where('agreement_id', $agreementId)
                ->where('is_approving', false)
                ->exists();
            if (! $checkCoordinating) {
                throw new BaseException("Мы не можем обновить участников согласования с идентификатором {$agreementId}, потому что необходим хотя бы 1 согласующий");
            }
        });

        return response()->json(['code' => 200, 'message' => 'ok'], 200);
    }
}