<?php

namespace App\Http\Controllers;

use App\Exceptions\BaseException;
use App\Http\Requests\DirectoryRequest;
use App\Models\Event\EventStream;
use App\Models\System\SystemParam;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Support\Facades\Auth;

class EventStreamController extends Controller
{
    /**
     * @param EventStream $event
     * @return array|null
     * @throws AuthenticationException
     */
    public function stream(EventStream $event, DirectoryRequest $request)
    {
        if (! Auth::check()) {
            throw new AuthenticationException('Необходимо авторизоваться.');
        }

        $countEvents = SystemParam::where('code', 'count_notifications_received')->pluck('value')->first();

        return $event->where('delivered', $request->has('is_read') ? 1 : 0)->where('user_id', Auth::id())->withFilter($request)->orderBy('id')->limit($countEvents)->paginate();
    }

    public function readAll(EventStream $event)
    {
        try {
            if (! Auth::check()) {
                throw new AuthenticationException('Необходимо авторизоваться.');
            }

            $event->where('delivered', 0)->where('user_id', Auth::id())->update(['delivered' => 1]);

            return response()->json(['code' => 201, 'message' => 'true'], 201);
        } catch (\Exception $e) {
            return response()->json(['code' => 400, 'message' => $e->getMessage()], 400);
        }
    }

    public function statusChanges(EventStream $event, int $eventID)
    {
        if (! Auth::check()) {
            throw new AuthenticationException('Необходимо авторизоваться.');
        }

        $eventModel = $event->where('id', $eventID)->where('user_id', Auth::id())->first();

        if (! empty($eventModel)) {
            $eventModel->delivered = 1;
            $eventModel->save();

            return response()->json(['code' => 201, 'message' => $eventModel->id], 201);
        } else {
            $userID = Auth::id();
            throw new BaseException("Не смогли определить событие {$eventID} для пользователя {$userID}");
        }
    }
}
