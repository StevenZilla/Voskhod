<?php

namespace App\Http\Requests\Fund;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreFundsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'funds' => ['required', 'array'],
            'funds.*.value' => ['required', 'string'],
            'funds.*.num' => ['required', 'string'],
            'funds.*.descr' => ['required', 'string'],
            'funds.*.code' => ['required', 'string'],
            'funds.*.archive_id' => ['required', 'exists:archive,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'funds.required' => 'Данные о фондах необходимо передавать в именнованном массиве funds',
            'funds.array' => 'Параметр funds должен быть представлен в виде массива объектов',
            'funds.*.value.required' => 'Необходимо указать наименование фонда',
            'funds.*.value.string' => 'Наименование фонда должно быть в виде текста',
            'funds.*.num.required' => 'Необходимо указать номер фонда',
            'funds.*.num.string' => 'Номер фонда должен быть в виде текста',
            'funds.*.descr.required' => 'Необходимо указать описание фонда',
            'funds.*.descr.string' => 'Описание фонда должно быть в виде текста',
            'funds.*.code.required' => 'Необходимо указать код фонда',
            'funds.*.code.string' => 'Код фонда должно быть в виде текста',
            'funds.*.archive_id.required' => 'Необходимо указать архив',
            'funds.*.archive_id.exists' => 'Указанного архива не существует',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'FUND',
            'error' => $validator->errors(),
        ], 400));
    }
}
