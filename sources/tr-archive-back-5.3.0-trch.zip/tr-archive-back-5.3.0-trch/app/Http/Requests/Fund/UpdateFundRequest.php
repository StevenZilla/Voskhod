<?php

namespace App\Http\Requests\Fund;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateFundRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'value' => ['string'],
            'num' => ['string'],
            'descr' => ['string'],
            'code' => ['string'],
            'archive_id' => ['integer', 'exists:archive,id'],
            'is_default' => ['bool'],
        ];
    }

    public function messages(): array
    {
        return [
            'value.required' => 'Необходимо указать наименование фонда',
            'value.string' => 'Наименование фонда должно быть в виде текста',
            'num.required' => 'Необходимо указать номер фонда',
            'num.string' => 'Номер фонда должен быть в виде текста',
            'descr.required' => 'Необходимо указать описание фонда',
            'descr.string' => 'Описание фонда должно быть в виде текста',
            'code.required' => 'Необходимо указать код фонда',
            'code.string' => 'Код фонда должно быть в виде текста',
            'archive_id.required' => 'Необходимо указать архив',
            'archive_id.exists' => 'Указанного архива не существует',
            'is_default.bool' => 'Дефолтное значение должно быть булевым типом',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'FUND',
            'error' => $validator->errors(),
        ], 400));
    }
}
