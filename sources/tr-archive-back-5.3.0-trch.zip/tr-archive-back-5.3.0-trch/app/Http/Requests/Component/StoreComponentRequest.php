<?php

namespace App\Http\Requests\Component;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreComponentRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => 'required|string',
            'tech_name' => 'required|string',
            'descr' => 'required|string',
            'start_date' => 'required|date_format:"Y-m-d H:i:s"',
            'end_date' => 'required|date_format:"Y-m-d H:i:s"',
            'parent_id' => 'integer|exists:component,id',
            'children' => 'array',
            'component_params' => 'array',
            'component_params.*.code' => 'required|string',
            'component_params.*.name' => 'required|string',
            'component_params.*.descr' => 'required|string',
            'component_params.*.value_type' => 'required|int',
            'component_params.*.default_value' => 'required',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Не передано имя компонента',
            'name.string' => 'Имя компонента должно быть строкой',
            'tech_name.required' => 'Не передано программное имя компонента',
            'tech_name.string' => 'Программное имя компонента должно быть в виде текста',
            'descr.required' => 'Не передано описание компонента',
            'descr.string' => 'Описание компонента должно быть строкой',
            'start_date.required' => 'Не передана дата начала работы компонента',
            'start_date.date' => 'Дата начала работы компонента должна быть в формате даты',
            'start_date.date_format' => 'Неверный формат даты, ожидается: Y-m-d H:m:s',
            'end_date.required' => 'Не передана дата завершения работы компонента',
            'end_date.date' => 'Дата завершения работы компонента должна быть в формате даты',
            'end_date.date_format' => 'Неверный формат даты, ожидается: Y-m-d H:m:s',
            'parent_id.integer' => 'Значение должно быть числом',
            'parent_id.exists' => 'Такого родительского компонента не существует',
            'children.array' => 'Элемент должен быть массивом',
            'component_params.array' => 'Элемент должен быть массивом',
            'component_params.*.code.required' => 'Поле обязательно для заполнения',
            'component_params.*.code.string' => 'Значение должно быть представлено в виде текста',
            'component_params.*.name.required' => 'Поле обязательно для заполнения',
            'component_params.*.name.string' => 'Значение должно быть представлено в виде текста',
            'component_params.*.descr.required' => 'Поле обязательно для заполнения',
            'component_params.*.descr.string' => 'Значение должно быть представлено в виде текста',
            'component_params.*.value_type.required' => 'Поле обязательно для заполнения',
            'component_params.*.default_value.required' => 'Поле обязательно для заполнения',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'COMPONENT',
            'error' => $validator->errors(),
        ], 400));
    }
}
