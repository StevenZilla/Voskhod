<?php

namespace App\Http\Requests\Antivirus;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class CheckRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'files' => 'array|required',
            'files.*' => 'file|required|max:5120' // лимит в 5 Мегабайт
        ];
    }

    public function messages(): array
    {
        return [
            'files.required' => 'Список файлов обязателен',
            'files.array' => 'Список файлов должен быть массивом',
            'files.*.file' => 'Элемент списка должен быть файлом',
            'files.*.required' => 'Элемент списка должен быть файлом',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'ANTIVIRUS',
            'error' => $validator->errors(),
        ], 400));
    }
}
