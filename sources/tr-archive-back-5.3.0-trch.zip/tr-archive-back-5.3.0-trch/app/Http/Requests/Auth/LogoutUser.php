<?php

namespace App\Http\Requests\Auth;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class LogoutUser extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
//            'sessionID' => 'required|integer|exists:session,id',
        ];
    }

    public function messages(): array
    {
        return [
//            'sessionID.required' => 'sessionID должен быть обязательным параметром',
//            'sessionID.integer' => 'sessionID должен быть обязательным параметром',
//            'sessionID.exists' => 'Такой sessionID не существует',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AUTH',
            'error' => $validator->errors(),
        ], 400));
    }
}
