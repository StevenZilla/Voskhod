<?php

namespace App\Http\Requests\Auth;

use App\Http\Requests\BaseRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class LoginUser extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'login' => 'required|string|exists:user,login',
            'password' => ['required', 'string'],
            'uid' => 'uuid|min:36|max:36|exists:master.instance_system,guid',
        ];
    }

    public function messages(): array
    {
        return [
            'login.required' => 'Логин должен быть обязательным параметром',
            'login.string' => 'Логин должен быть обязательным параметром',
            'login.exists' => 'Указанного пользователя не существует',

            'password.required' => 'Пароль должен быть обязательным значением',
            'password.string' => 'Пароль должен быть строкой',

        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 401,
            'message' => 'Валидация не пройдена',
            'target' => 'AUTH',
            'error' => $validator->errors(),
        ], 401));
    }
}
