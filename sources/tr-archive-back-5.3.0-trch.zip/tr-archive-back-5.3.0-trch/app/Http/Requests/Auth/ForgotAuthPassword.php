<?php

namespace App\Http\Requests\Auth;

use App\Rules\Auth\CheckUserOldPassword;
use App\Rules\Auth\CheckUserPassword;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Auth;

class ForgotAuthPassword extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = Auth::user();

        return [
            'old_password' => [
                'nullable',
                new CheckUserOldPassword($user),
            ],
            'new_password' => [
                'required',
                'string',
                new CheckUserPassword(),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'new_password.required' => 'поле new_password обязательно для заполнения',
            'new_password.min' => 'Пароль должен быть не меньше 6 символов',
            'new_password.regex' => 'Пароль должен содержать цифры и прописные и заглавные латинские буквы',
            'new_password.alpha_dash' => 'Пароль не может содержать ничего кроме букв, цифр, дефиса и нижнего подчеркивания',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AUTH',
            'error' => $validator->errors(),
        ], 400));
    }
}
