<?php

namespace App\Http\Requests\Auth;

use App\Rules\Auth\CheckUserPassword;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class RegisterNewUser extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'fio' => 'required|string|max:255',
            'login' => ['required', 'string', 'max:255', 'unique:user,login', 'regex:/^[a-zA-Z0-9-_]+$/', 'min:5'],
            'email' => ['required', 'string', 'max:255', 'email', 'unique:user,email', 'min:5'],
            'password' => ['required', 'string', new CheckUserPassword()],
            'start_date' => ['nullable', 'date', 'date_format:"Y-m-d"'],
            'end_date' => ['nullable', 'date', 'date_format:"Y-m-d"'],
            'is_2fa' => ['nullable', 'boolean'],
            'is_block' => ['nullable', 'boolean'],
            'activated' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'fio.required' => 'ФИО обязательное поле',
            'fio.string' => 'ФИО должна быть строкой',
            'fio.max' => 'Максимальная длина фио 255 символов',

            'login.required' => 'Логин должен быть обязательным параметром',
            'login.string' => 'Логин должен быть обязательным параметром',
            'login.regex' => 'Логин может состоять только из латинских букв и цифр',
            'login.min' => 'Логин не может быть меньше 5 символов',
            'login.max' => 'Максимальная длина логина 255 символов',
            'login.unique' => 'Пользователь с таким логином уже существует',

            'email.required' => 'Эл. почта является обязательным параметром',
            'email.string' => 'Эл. почта должна быть передана в строке',
            'email.max' => 'Максимальная длина эл.почты 255 символов',
            'email.min' => 'Минимальная длина эл.почты 5 символов',
            'email.email' => 'Эл. почта должна быть в формате email@email.email',
            'email.unique' => 'Пользователь с такой эл. почтой уже существует',

            'password.required' => 'Пароль должен быть обязательным значением',
            'password.string' => 'Пароль должен быть стракой',
            'password.min' => 'Пароль должен быть минимум 6 символов',
            'password.regex' => 'Пароль должен содержать цифры и прописные и заглавные латинские буквы',
            'password.alpha_dash' => 'Пароль не может содержать ничего кроме букв, цифр, дефиса и нижнего подчеркивания',

            'start_date.date' => 'Начало регистрации должен быть датой',
            'start_date.date_format' => 'Формат даты \'YYYY-MM-DD\'',

            'end_date.date' => 'Конец регистрации должен быть датой',
            'end_date.date_format' => 'Формат даты \'YYYY-MM-DD\'',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AUTH',
            'error' => $validator->errors(),
        ], 400));
    }
}
