<?php

namespace App\Http\Requests;

use App\Models\User\CompromPassword;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class EditCompromRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $errors = [];
        foreach ($this->all() as $key => $item) {
            if (CompromPassword::where('id', '!=', $item['id'] ?? null)->where('password', $item['value'])->exists()) {
                $errors["{$key}.value"] = 'Не уникальный пароль';
            }
        }

        if (! empty($errors)) {
            throw new HttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Валидация не пройдена',
                'target' => 'COMPROM_PASSWORD',
                'error' => $errors,
            ], 400));
        }

        return [
            '.*.id' => 'nullable|integer|exists:comprom_password,id',
            '.*.value' => 'string',
        ];
    }

    public function messages()
    {
        return [
            '*.id.required' => 'Поле ID обязательное',
            '*.value.string' => 'Поле value должно быть строкой',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'COMPROM_PASSWORD',
            'error' => $validator->errors(),
        ], 400));
    }
}
