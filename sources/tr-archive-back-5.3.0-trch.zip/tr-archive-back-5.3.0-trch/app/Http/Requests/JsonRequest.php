<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\UploadedFile;

class JsonRequest extends FormRequest
{
    public function validator($factory)
    {
        return $factory->make(
            $this->sanitize(), $this->container->call([$this, 'rules']), $this->messages()
        );
    }

    public function sanitize()
    {
        if (! is_array($this->input('data'))) {
            $this->merge([
                'data_to_array' => json_decode($this->input('data'), true),
            ]);
        }

        if (empty($this->all()['data_to_array'])) {
            $encodeString = mb_convert_encoding($this->all()['data'], 'utf-8', 'windows-1251');
            $array = $encodeString;
            $encodeString = json_encode($encodeString, JSON_UNESCAPED_UNICODE);
            if (! is_array($encodeString)) {
                $array = json_decode($encodeString, true);
            }

            $this->merge([
                'data' => $encodeString,
                'data_to_array' => $array,
            ]);
        }

        if (! empty($this->allFiles()['files'])) {
            $array_files = [];
            foreach ($this->allFiles()['files'] as $key_file => $file) {
                if (! mb_check_encoding($file->getClientOriginalName(), 'utf-8')) {
                    $file_name = mb_convert_encoding($file->getClientOriginalName(), 'utf-8', 'windows-1251');
                    $uploadFile = new UploadedFile($file->getPathname(), $file_name, $file->getClientMimeType(), $file->getSize(), $file->getError());

                    $array_files[$key_file] = $uploadFile;
                }
            }

            if (! empty($array_files)) {
                $this->merge([
                    'files_new' => $array_files,
                ]);
            }
        }

        return $this->all();
    }
}
