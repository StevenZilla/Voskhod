<?php

namespace App\Http\Requests\Dossier;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class EditDossierRequest extends FormRequest
{
    private $paperInfoRules = [
        'sheet_num' => 'integer|nullable',
        'location' => 'string|nullable',
        'paper_register_num' => 'string|nullable',
    ];

    private $paperInfoMessages = [
        'sheet_num.integer' => 'Кол-во листов в деле должно быть целым числом',
        'location.string' => 'Местоположение должно быть строковым значением',
        'paper_register_num.string' => 'Номер бумажной описи должен быть строковым значением',
    ];

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $paper_info = $this->paper_info;
        if ($paper_info != null) {
            $validator = \Illuminate\Support\Facades\Validator::make($paper_info, $this->paperInfoRules, $this->paperInfoMessages);
            if ($validator->fails()) {
                throw new HttpResponseException(response()->json([
                    'code' => 400,
                    'message' => 'Валидация не пройдена',
                    'target' => 'paper_info',
                    'error' => $validator->errors(),
                ], 400));
            }
        }

        return [
            'index' => 'string|required',
            'name' => 'string|required',
            'is_transit' => 'required|boolean',
            'id_eds' => 'array',
            'id_eds.*' => 'integer|exists:ed,id',
            'paper_info' => 'nullable|array',
        ];
    }

    public function messages(): array
    {
        return [
            'index.string' => 'Индекс должен быть строковым значением',
            'index.required' => 'Индекс обязательное поле',
            'name.string' => 'Название должно быть строкой',
            'name.required' => 'Название обязательное поле',
            'is_transit.required' => 'Поле is_transit обязательно.',
            'is_transit.boolean' => 'Поле is_transit должно иметь булевый тип данных',
            'id_eds.array' => 'Идентификатор электронного документа должен быть списком',
            'id_eds.*.integer' => 'Идентификатор электронного документа должен быть целым числом',
            'id_eds.*.exists' => 'Идентификатор электронного документа не найден',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'DOSSIER',
            'error' => $validator->errors(),
        ], 400));
    }
}
