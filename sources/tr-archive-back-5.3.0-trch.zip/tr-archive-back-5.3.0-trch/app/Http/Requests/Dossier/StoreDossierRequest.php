<?php

namespace App\Http\Requests\Dossier;

use App\Rules\CheckUniqueColumns\CheckUniqueColumns;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreDossierRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'source_id' => ['required', 'integer', 'min:1', 'exists:source,id', new CheckUniqueColumns(['index' => $this->request->get('index'), 'source_id' => $this->request->get('source_id')], 'Dossier\Dossier')],
            'name' => 'required|string',
            'index' => ['required', 'string', new CheckUniqueColumns(['index' => $this->request->get('index'), 'source_id' => $this->request->get('source_id')], 'Dossier\Dossier')],
            'media_type_id' => 'required:integer',
            'id_eds' => 'array',
            'id_eds.*' => 'integer|min:1|exists:ed,id',
            'temp_save_period' => 'integer|min:1|nullable',
        ];
    }

    public function messages(): array
    {
        return [
            'source_id.required' => 'Источник должен быть обязательным полем',
            'source_id.integer' => 'Источник должен быть целым числом',
            'source_id.min' => 'Источник должен начинаться с 1',
            'source_id.exists' => 'Не найден такой идентификатор источника',

            'media_type_id.required' => 'media_type_id - обязательное поле',

            'name.required' => 'Название должно быть обязательным полем',
            'name.string' => 'Название должно быть строкой',

            'index.required' => 'Индекс должен быть обязательным полем',
            'index.string' => 'Индекс должен быть строковым значением',

            'id_eds.array' => 'Идентификатор электронного документа должен быть списком',
            'id_eds.*.integer' => 'Идентификатор электронного документа должен быть целым числом',
            'id_eds.*.min' => 'Идентификатор электронного документа минимум должен начинаться от 1',
            'id_eds.*.exists' => 'Идентификатор электронного документа не найден',

            'temp_save_period.integer' => 'Temp Save Period должен быть числом',
            'temp_save_period.min' => 'Temp Save Period должен начинаться от 1',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'DOSSIER',
            'error' => $validator->errors(),
        ], 400));
    }
}
