<?php

namespace App\Http\Requests\Dossier;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class ChangeStatusDossierEdit extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'status_code' => 'required|string|exists:dossier_status,code',
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'status_code.required' => 'Код статуса является обязательным параметром',
            'status_code.string' => 'Код статуса должен быть строкой',
            'status_code.exists' => 'Код статуса не существует в системе',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Неправильный параметр фильтрации',
            'target' => 'DOSSIER',
            'error' => $validator->errors(),
        ], 400));
    }
}
