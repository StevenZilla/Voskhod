<?php

namespace App\Http\Requests\Dossier;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class DossierRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'source_id' => 'integer|min:1|exists:source,id',
            'name' => 'string',
            'index' => 'string',
            'temp_save_period' => 'integer',
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'name.string' => 'Наименование дела должно быть строкой',
            'name.index' => 'Индекс дела должен быть строкой',
            'source_id.integer' => 'Источник дела должен быть числом',
            'source_id.min' => 'Источник дела должен быть больше 1',
            'source_id.exists' => 'Такой источник дела не существует',
            'temp_save_period.integer' => 'Temp save period должен быть числом',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Неправильный параметр фильтрации',
            'target' => 'DOSSIER',
            'error' => $validator->errors(),
        ], 400));
    }
}
