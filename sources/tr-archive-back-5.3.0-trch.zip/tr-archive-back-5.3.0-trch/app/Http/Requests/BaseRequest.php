<?php

namespace App\Http\Requests;

use App\Exceptions\BadRequestException;
use Illuminate\Foundation\Http\FormRequest;

class BaseRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function validator($factory)
    {
        $requestToArray = $this->request->all();
        if (empty($requestToArray)) {
            throw new BadRequestException(json_encode([
                'code' => 400,
                'message' => 'Отсутствует тело запроса. Добавьте тело запроса.',
            ]));
        }

        return $factory->make(
            $this->request->all(), $this->container->call([$this, 'rules']), $this->messages()
        );
    }
}
