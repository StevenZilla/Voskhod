<?php

namespace App\Http\Requests\Nomenclature;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class GetNomPartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'nom_part_id' => 'integer|exists:nom_part,id',
        ];
    }

    public function messages()
    {
        return [
            'nom_part_id.integer' => 'Параметр должен быть числовым',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'NOMENCLATURE',
            'error' => $validator->errors(),
        ], 400));
    }
}
