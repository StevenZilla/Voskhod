<?php

namespace App\Http\Requests\Nomenclature;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class NomenclatureGetRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'num' => 'string',
            'year' => 'integer',
        ];
    }

    public function messages()
    {
        return [
            'num.string' => 'Номер номенклатуры должен быть в текстовом формате',
            'year.integer' => 'Год номенклатуры должен быть числом',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'NOMENCLATURE',
            'error' => $validator->errors(),
        ], 400));
    }
}
