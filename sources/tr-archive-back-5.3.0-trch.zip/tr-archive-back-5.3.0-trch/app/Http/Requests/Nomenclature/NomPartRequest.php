<?php

namespace App\Http\Requests\Nomenclature;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class NomPartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'integer|min:1|exists:nom_part,id',
        ];
    }

    public function messages(): array
    {
        return [
            'id.integer' => 'Идентификатор номенклатуры должен быть положительным числом',
            'id.min' => 'Минимальное значение идентификатора - 1',
            'id.exists' => 'Раздел номенлкатуры с переданным идентификатором не существует',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'NOMENCLATURE',
            'error' => $validator->errors(),
        ], 400));
    }
}
