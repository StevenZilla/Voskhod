<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class ChangeGuidTKRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'message_guid' => 'required|uuid',
        ];
    }

    public function messages(): array
    {
        return [
            'message_guid.required' => 'Поле обязательно для заполнения',
            'message_guid.uuid' => 'Значение поля должно быть представлено в виде текста',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'TK',
            'error' => $validator->errors(),
        ], 400));
    }
}
