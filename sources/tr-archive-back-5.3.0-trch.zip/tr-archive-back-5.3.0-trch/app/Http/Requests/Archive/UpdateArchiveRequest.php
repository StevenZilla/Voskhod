<?php

namespace App\Http\Requests\Archive;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateArchiveRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'value' => ['required', 'string'],
            'full_name' => ['required', 'string'],
            'email' => ['nullable', 'string', 'email'],
            'descr' => ['nullable', 'string'],
            'code' => ['required', 'string'],
            'address' => ['nullable', 'string'],
            'head' => ['nullable', 'string'],
            'head_phone' => ['nullable', 'string'],
        ];
    }

    public function messages(): array
    {
        return [
            'value.required' => 'Необходимо указать наименование архива',
            'value.string' => 'Наименование архива должно быть в виде текста',
            'address.required' => 'Необходимо указать адрес архива',
            'address.string' => 'Адрес архива должен быть в виде текста',
            'full_name.required' => 'Необходимо указать полное наименование архива',
            'full_name.string' => 'Полное наименование архива должно быть в виде текста',
            'email.required' => 'Необходимо указать электронную почту архива',
            'email.string' => 'Электронная почта архива должна быть в виде @email.ru',
            'email.email' => 'Электронная почта архива должна быть в виде @email.ru',
            'descr.required' => 'Необходимо указать описание архива',
            'descr.string' => 'Описание архива должно быть в виде текста',
            'code.required' => 'Необходимо указать код архива',
            'code.string' => 'Код архива должно быть в виде текста',
            'head.required' => 'Необходимо указать руководителя архива',
            'head.string' => 'Руководитель архива должен быть в виде текста ФИО',
            'head_phone.required' => 'Необходимо указать номер руководителя архива',
            'head_phone.string' => 'Номер руководителя архива архива должен быть в виде +70000000000',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'ARCHIVE',
            'error' => $validator->errors(),
        ], 400));
    }
}
