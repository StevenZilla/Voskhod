<?php

namespace App\Http\Requests\Archive;

use App\Http\Requests\BaseRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreArchivesRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'archives' => ['required', 'array'],
            'archives.*.value' => ['required', 'string'],
            'archives.*.full_name' => ['required', 'string'],
            'archives.*.email' => ['nullable', 'string', 'email'],
            'archives.*.descr' => ['nullable', 'string'],
            'archives.*.code' => ['required', 'string'],
            'archives.*.address' => ['nullable', 'string'],
            'archives.*.head' => ['nullable', 'string'],
            'archives.*.head_phone' => ['nullable', 'string'],
        ];
    }

    public function messages(): array
    {
        return [
            'archives.required' => 'Данные об архивах необходимо передавать в именнованном массифе archives',
            'archives.array' => 'Параметр archives должен быть представлен в виде массива объектов',
            'archives.*.value.required' => 'Необходимо указать наименование архива',
            'archives.*.value.string' => 'Наименование архива должно быть в виде текста',
            'archives.*.address.required' => 'Необходимо указать адрес архива',
            'archives.*.address.string' => 'Адрес архива должен быть в виде текста',
            'archives.*.full_name.required' => 'Необходимо указать полное наименование архива',
            'archives.*.full_name.string' => 'Полное наименование архива должно быть в виде текста',
            'archives.*.email.required' => 'Необходимо указать электронную почту архива',
            'archives.*.email.string' => 'Электронная почта архива должна быть в виде @email.ru',
            'archives.*.email.email' => 'Электронная почта архива должна быть в виде @email.ru',
            'archives.*.descr.required' => 'Необходимо указать описание архива',
            'archives.*.descr.string' => 'Описание архива должно быть в виде текста',
            'archives.*.code.required' => 'Необходимо указать код архива',
            'archives.*.code.string' => 'Код архива должно быть в виде текста',
            'archives.*.head.required' => 'Необходимо указать руководителя архива',
            'archives.*.head.string' => 'Руководитель архива должен быть в виде текста ФИО',
            'archives.*.head_phone.required' => 'Необходимо указать номер руководителя архива',
            'archives.*.head_phone.string' => 'Номер руководителя архива архива должен быть в виде +70000000000',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'ARCHIVE',
            'error' => $validator->errors(),
        ], 400));
    }
}
