<?php

namespace App\Http\Requests\AcceptRegister\ProjectRegister;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // 'id' => 'required|integer|min:1|exists:accept_register,id',
            'name' => 'required|string',
            'num' => 'required|string',
            'year' => 'required|date_format:Y',
            'subdivision_id' => 'required|integer|min:1|exists:subdivision,id',
            'accept_register_parts' => 'array',
        ];
    }


    public function messages(): array
    {
        return [
            'name.required' => 'Заголовок описи обязателен',
            'name.string' => 'Заголовок описи должен быть строкой',
            'num.required' => 'Номер описи обязателен',
            'num.required' => 'Номер описи должен быть строкой',
            'year.required' => 'Год описи обязателен',
            'year.date_format' => 'Год описи имеет неверный формат',
            'subdivision_id.required' => 'Подразделение обязательно',
            'subdivision_id.integer' => 'Подразделение должно быть числом',
            'subdivision_id.exists' => 'Подразделения не существует',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'ACCEPT_REGISTER',
            'error' => $validator->errors(),
        ], 400));
    }
}
