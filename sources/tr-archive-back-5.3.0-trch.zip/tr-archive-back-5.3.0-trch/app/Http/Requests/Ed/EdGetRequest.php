<?php

namespace App\Http\Requests\Ed;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class EdGetRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
//            'name' => 'string',
//            'num' => 'string',
//            'source' => 'integer|min:1|exists:source,id',
//            'start_reg_date' => 'date|date_format:Y-m-d',
//            'end_reg_date' => 'date|date_format:Y-m-d',
//            'sort' => 'string',
//            'page' => 'array',
//            'page[number]' => 'integer|min:1',
//            'page.size' => 'integer|min:1',
//            'tk_status' => 'integer|min:1|exists:tk_status,id',
//            'ed_status' => 'integer|min:1|exists:ed_status,id',
//            'update_date' => 'date|date_format:Y-m-d',
//            'resend_ak' => 'in:true,false',
//            'dossier_id' => 'integer|min:1|exists:dossier,id',
//            'ed_status_id' => 'integer|min:1|exists:ed_status,id'
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'name.string' => 'Наименование документа должно быть строкой',
            'num.string' => 'Номер документа должен быть строкой',
            'source.integer' => 'Источник документа должен быть числом',
            'source.min' => 'Источник документа должен быть больше нуля',
            'source.exists' => 'Источник документа не существует',
            'start_reg_date.date' => 'Дата регистрации документа должна быть датой в формате ГГГГ-ММ-ДД',
            'start_reg_date.date_format' => 'Дата регистрации документа должна быть датой в формате ГГГГ-ММ-ДД',
            'end_reg_date.date' => 'Дата регистрации документа должна быть датой в формате ГГГГ-ММ-ДД',
            'end_reg_date.date_format' => 'Дата регистрации документа должна быть датой в формате ГГГГ-ММ-ДД',
            'tk_status.integer' => 'Статус транспортного контейнера документа должен быть числом',
            'tk_status.min' => 'Статус транспортного контейнера документа должен быть больше 1',
            'tk_status.exists' => 'Статус транспортного контейнера документа не существует',
            'ed_status.integer' => 'Статус документа должен быть числом',
            'ed_status.min' => 'Статус документа должен быть больше 1',
            'ed_status.exists' => 'Статус документа не существует',
            'ed_status_id.integer' => 'Статус документа должен быть числом',
            'ed_status_id.min' => 'Статус документа должен быть больше 1',
            'ed_status_id.exists' => 'Статус документа не существует',
            'update_date.date' => 'Дата обновления документа должна быть датой в формате ГГГГ-ММ-ДД',
            'update_date.date_format' => 'Дата обновления документа должна быть датой в формате ГГГГ-ММ-ДД',
            'dossier_id.integer' => 'Дело документа должно быть числом',
            'dossier_id.min' => 'Дело документа должно быть больше 1',
            'dossier_id.exists' => 'Дело документа не существует',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Неправильный параметр фильтрации',
            'target' => 'EAD',
            'error' => $validator->errors(),
        ], 400));
    }
}
