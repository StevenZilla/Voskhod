<?php

namespace App\Http\Requests\Ed;

use App\Http\Requests\JsonRequest;
use App\Rules\CheckUniqueColumns\CheckUniqueColumns;
use App\Rules\Ed\CheckExitFile;
use App\Rules\Ed\CheckExtensionFile;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class EdEditRequest extends JsonRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $requestFiles = [];
        if (! empty($this->files->all()['files'])) {
            $requestFiles = $this->files->all()['files'];
        }
        if (! empty($this->data_to_array['files'])) {
            $dataFiles = $this->data_to_array['files'];
        }

        return [
            'data' => 'required|json',
            'files' => 'array',
            'files.*' => 'file|max:51200', // лимит в 50 Мегабайт

            'data_to_array.name' => 'required|string',
            'data_to_array.num' => ['required', 'string', new CheckUniqueColumns(['num' => $this->data_to_array['num'], 'reg_date' => $this->data_to_array['reg_date']], 'Ed\Ed', $this->route()->parameter('id'))],
            'data_to_array.reg_date' => ['required', 'date', 'date_format:Y-m-d', new CheckUniqueColumns(['num' => $this->data_to_array['num'], 'reg_date' => $this->data_to_array['reg_date']], 'Ed\Ed', $this->route()->parameter('id'))],
            'data_to_array.ed_type_id' => 'integer|min:1',
            'data_to_array.ed.status_id' => 'nullable|integer|min:1|exists:ed_status,id',
            'data_to_array.is_dsp' => 'bool',
            'data_to_array.source_id' => 'required|integer|min:1|exists:source,id',
            'data_to_array.source_ed_id' => 'string|nullable',
            'data_to_array.dossier_id' => 'nullable|integer|min:1|exists:dossier,id',
            'data_to_array.attr' => 'array',
            'data_to_array.attr.*.attr_id' => 'required|integer|min:1|exists:attribute,id',
            'data_to_array.files' => 'required|array',
            'data_to_array.files.*.fr_id' => 'required|integer|min:1|exists:file_role,id',
            'data_to_array.files.*.file' => ['required', new CheckExitFile($requestFiles, $dataFiles)],
            //'files.*.parent_file' => 'string',
            'data_to_array.update_date' => 'date|date_format:Y-m-d',
            'data_to_array.temp_save_period' => 'nullable|integer',
            'data_to_array.resend_ak' => 'boolean',
            'data_to_array.media_type_id' => 'nullable|integer|min:1|exists:media_type_ed,id',
        ];
    }

    public function messages(): array
    {
        return [
            'data.required' => 'Данные являются обязательным значением',
            'data.json' => 'Данные должны быть в формате json',
            'files.array' => 'Файлы должны передаваться в массиве',
            'files.*.max' => 'Максимальный размер файла не должен превышать ~500mb',

            'data_to_array.name.required' => 'Данные поля name является обязательным значением',
            'data_to_array.name.string' => 'Данные поля name должны быть строкой',

            'data_to_array.num.required' => 'Данные поля num является обязательным значением',
            'data_to_array.num.string' => 'Данные поля num должны быть строкой',

            'data_to_array.reg_date.required' => 'Данные поля reg_date является обязательным значением',
            'data_to_array.reg_date.date' => 'Данные поля reg_date должны быть датой',
            'data_to_array.reg_date.date_format' => 'Данные поля reg_date должны быть в формате YYYY-MM-DD',

            'data_to_array.ed_type_id.integer' => 'Значение должно быть целым числом',
            'data_to_array.ed_type_id.min' => 'Значение должно быть больше единицы',

            'data_to_array.source_id.required' => 'Необходимо заполнить источник',
            'data_to_array.source_id.integer' => 'Значение должно быть целым числом',
            'data_to_array.source_id.min' => 'Значение должно быть больше единицы',
            'data_to_array.source_id.exists' => 'Такого источника не сущесвует',

            'data_to_array.source_ed_id.string' => 'Значение должно быть строкой',
            'data_to_array.num.nullable' => 'Поле может быть пустым',
            'data_to_array.is_dsp.bool' => 'Штамп ДСП должен быть булевым',

            'data_to_array.dossier_id.nullable' => 'Значение может быть не передано',
            'data_to_array.dossier_id.integer' => 'Значение должно быть числом',
            'data_to_array.dossier_id.min' => 'Значение должно начинаться от единицы',
            'data_to_array.dossier_id.exists' => 'Такого дела не существует',

            'data_to_array.attr.array' => 'Аттрибуты должны быть переданы массивом',

            'data_to_array.attr.*.attr_id.required' => 'Необходимо указать атрибут',
            'data_to_array.attr.*.attr_id.integer' => 'Значение должно быть числом',
            'data_to_array.attr.*.attr_id.min' => 'Значение должно начинаться от единицы',
            'data_to_array.attr.*.attr_id.exists' => 'Такого атрибута не существует',

            'data_to_array.files.required' => 'Файлы должны быть обязательные',
            'data_to_array.files.array' => 'Файлы должны быть переданы массивом',

            'data_to_array.files.*.fr_id.required' => 'Необходимо указать роль файла',
            'data_to_array.files.*.fr_id.integer' => 'Значение должно быть числом',
            'data_to_array.files.*.fr_id.min' => 'Значение должно начинаться от единицы',
            'data_to_array.files.*.fr_id.exists' => 'Такой роли для файла не существует',

            'data_to_array.update_date.date' => 'Данные поля update_date должны быть датой',
            'data_to_array.update_date.date_format' => 'Данные поля update_date должны быть в формате Год/месяц/день',

            'data_to_array.temp_save_period.integer' => 'Значение должно быть числом',
            'data_to_array.temp_save_period.min' => 'Значение поля должно начинаться от единицы',

            'data_to_array.resend_ak.boolean' => 'Должен имееть булевый тип данных',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $bugs = $this->changeKeyData($validator->getMessageBag());
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'EAD',
            'error' => $bugs,
        ], 400));
    }

    private function changeKeyData($bugs)
    {
        $result = [];
        if (! empty($bugs->messages())) {
            foreach ($bugs->messages() as $key=>$bug) {
                $result[str_replace('data_to_array.', '', $key)] = $bug;
            }
        }

        return $result;
    }
}
