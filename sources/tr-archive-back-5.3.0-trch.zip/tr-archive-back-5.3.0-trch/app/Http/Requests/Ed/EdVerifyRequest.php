<?php

namespace App\Http\Requests\Ed;

use App\Http\Requests\JsonRequest;
use App\Models\System\SystemParam;
use App\Rules\Ed\CheckExitFile;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class EdVerifyRequest extends JsonRequest
{
    protected $countUploadedFiles;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->countUploadedFiles = ini_get('max_file_uploads') - 1;
        $fileSize = config('app.file_size') ? config('app.file_size') : 500000;

        $requestFiles = [];
        if (! empty($this->files->all()['files'])) {
            $requestFiles = $this->files->all()['files'];
        }
        if (! empty($this->data_to_array['files'])) {
            $dataFiles = $this->data_to_array['files'];
        }

        return [
            'data' => 'required|json', //
            'files' => 'array|max:'.$this->countUploadedFiles,
            'files.*' => 'file|max:'.$fileSize, //~500mb
            'data_to_array.files' => 'required|array',
            'data_to_array.files.*.file' => ['required', new CheckExitFile($requestFiles, $dataFiles)],
            'data_to_array.files.*.fr_id' => 'required|integer|min:1|exists:file_role,id',
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'data.required' => 'Данные являются обязательным значением',
            'data.json' => 'Данные должны быть в формате json',
//            "files.required" => 'Файлы являются обязательным значением',
            'files.array' => 'Файлы должны передаваться в массиве',
            'files.max' => 'Превышен лимит загружаемых файлов. Количество файлов должно быть меньше '.ini_get('max_file_uploads'),
            'files.*.max' => 'Максимальный размер файла не должен превышать ~500mb',

            'data_to_array.files.required' => 'Файлы должны быть обязательные',
            'data_to_array.files.array' => 'Файлы должны быть переданы массивом',

            'data_to_array.files.*.fr_id.required' => 'Данные поля fr_id является обязательным значением',
            'data_to_array.files.*.fr_id.integer' => 'Данные поля fr_id должны быть целым числом',
            'data_to_array.files.*.fr_id.min' => 'Данные поля fr_id должны быть от 1',
            'data_to_array.files.*.fr_id.exists' => 'Идентификатор роли файла неправильный',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $systemForbidInvalidEp = SystemParam::getForbidInvalidEp();

        throw new HttpResponseException(response()->json([
            'is_forbid_invalid_ep' => $systemForbidInvalidEp,
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'EAD',
            'error' => $validator->errors(),
        ], 400));
    }
}
