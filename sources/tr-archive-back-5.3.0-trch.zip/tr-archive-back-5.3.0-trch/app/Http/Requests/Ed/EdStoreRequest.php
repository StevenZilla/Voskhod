<?php

namespace App\Http\Requests\Ed;

use App\Exceptions\EdException\EdException;
use App\Http\Requests\JsonRequest;
use App\Rules\CheckUniqueColumns\CheckUniqueColumns;
use App\Rules\Ed\CheckExitFile;
use App\Rules\Ed\CheckExtensionFile;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class EdStoreRequest extends JsonRequest
{
    protected $countUploadedFiles;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->countUploadedFiles = ini_get('max_file_uploads') - 1;
        $fileSize = config('app.file_size') ? config('app.file_size') : 500000;

        if (empty($this->data_to_array) || !is_array($this->data_to_array)) {
            throw new EdException('Ошибка при парсинге тела запроса.');
        }

        $requestFiles = [];
        if (!empty($this->files->all()['files'])) {
            $requestFiles = $this->files->all()['files'];
        }
        $dataFiles = [];
        if (!empty($this->data_to_array['files'])) {
            $dataFiles = $this->data_to_array['files'];
        }

        if (!empty($this->data_to_array['num']) && !empty($this->data_to_array['reg_date'])) {
            $resultCheckUniqueColumns = (new CheckUniqueColumns(['num' => $this->data_to_array['num'], 'reg_date' => $this->data_to_array['reg_date']], 'Ed\Ed'))->passes(1, 1);

            if (!$resultCheckUniqueColumns) {
                throw new HttpResponseException(response()->json([
                    'code' => 400,
                    'message' => 'Валидация не пройдена',
                    'target' => 'EAD',
                    'error' => [
                        'data_to_array.reg_date' => ['Неуникальное значение у ЭД ' . $this->data_to_array['reg_date']],
                        'data_to_array.num' => ['Неуникальное значение у ЭД ' . $this->data_to_array['num']],
                    ],
                ], 400));
            }
        }

        return [
            'data' => 'required|json', //
            'files' => 'required|array|max:' . $this->countUploadedFiles,
            //            'files.*' => 'file|max:500000', //~500mb
            'files.*' => 'file|max:' . $fileSize, //~500mb

            'data_to_array.name' => 'required|string',
            'data_to_array.num' => 'required|string',
            'data_to_array.reg_date' => ['required', 'regex:/([1-9][0-9][0-9]{2}\-([0][1-9]|[1][0-2])\-([1-2][0-9]|[0][1-9]|[3][0-1]))|(([1-9][0-9][0-9]{2}\.([0][1-9]|[1][0-2])\.([1-2][0-9]|[0][1-9]|[3][0-1])))|((([1-2][0-9]|[0][1-9]|[3][0-1])\.([0][1-9]|[1][0-2])\.[1-9][0-9][0-9]{2}))/',],
            'data_to_array.is_dsp' => 'bool',
            'data_to_array.ed_type_id' => 'integer|min:1',
            'data_to_array.ed.status_id' => 'nullable|integer|min:1|exists:ed_status,id',
            'data_to_array.source_id' => 'required|integer|min:1|exists:source,id',
            'data_to_array.source_ed_id' => 'string|nullable',
            'data_to_array.dossier_id' => 'nullable|integer|min:1|exists:dossier,id',
            'data_to_array.media_type_id' => 'nullable|integer|min:1|exists:media_type_ed,id',
            'data_to_array.attr' => 'array',
            'data_to_array.attr.*.attr_id' => 'required|integer|min:1|exists:attribute,id',
            'data_to_array.files' => 'required|array',
            'data_to_array.files.*.fr_id' => 'required|integer|min:1|exists:file_role,id',
            //            'data_to_array.files.*.file' => ['required', new CheckExtensionFile($this->data_to_array['files']), new CheckExitFile($requestFiles, $dataFiles)],
            'data_to_array.files.*.file' => ['required', new CheckExitFile($requestFiles, $dataFiles)],
            //'files.*.parent_file' => 'string',
            'data_to_array.update_date' => 'date|date_format:Y-m-d',
            'data_to_array.temp_save_period' => 'integer|min:0',
            'data_to_array.resend_ak' => 'boolean',
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'data.required' => 'Данные являются обязательным значением',
            'data.json' => 'Данные должны быть в формате json',
            'files.required' => 'Файлы являются обязательным значением',
            'files.array' => 'Файлы должны передаваться в массиве',
            'files.max' => 'Превышен лимит загружаемых файлов. Количество файлов должно быть меньше ' . ini_get('max_file_uploads'),
            'files.*.max' => 'Максимальный размер файла не должен превышать ~500mb',

            'data_to_array.name.required' => 'Данные поля name является обязательным значением',
            'data_to_array.name.string' => 'Данные поля name должны быть строкой',

            'data_to_array.num.required' => 'Данные поля num является обязательным значением',
            'data_to_array.num.string' => 'Данные поля num должны быть строкой',
            'data_to_array.is_dsp.bool' => 'Штамп ДСП должен быть булевым',

            'data_to_array.reg_date.required' => 'Данные поля reg_date является обязательным значением',
            'data_to_array.reg_date.date' => 'Данные поля reg_date должны быть датой',
            'data_to_array.reg_date.date_format' => 'Данные поля reg_date должны быть в формате YYYY-MM-DD',

            'data_to_array.ed_type_id.integer' => 'Данные поля ed_type_id должны быть целым числом',
            'data_to_array.ed_type_id.min' => 'Данные поля ed_type_id должны быть от 1',

            'data_to_array.source_id.required' => 'Данные поля source_id является обязательным значением',
            'data_to_array.source_id.integer' => 'Данные поля source_id должны быть целым числом',
            'data_to_array.source_id.min' => 'Данные поля source_id должны быть от 1',
            'data_to_array.source_id.exists' => 'Идентификатор источника неправильный',

            'data_to_array.source_ed_id.string' => 'Данные поля source_ed_id должны быть строкой',
            'data_to_array.num.nullable' => 'Данные поля source_ed_id могут быть пустыми',

            'data_to_array.dossier_id.nullable' => 'Данные поля dossier_id могут быть пустыми',
            'data_to_array.dossier_id.integer' => 'Данные поля dossier_id должны быть целым числом',
            'data_to_array.dossier_id.min' => 'Данные поля dossier_id должны быть от 1',
            'data_to_array.dossier_id.exists' => 'Идентификатор дела неправильный',

            'data_to_array.attr.array' => 'Аттрибуты должны быть переданы массивом',

            'data_to_array.attr.*.attr_id.required' => 'Данные поля attr_id является обязательным значением',
            'data_to_array.attr.*.attr_id.integer' => 'Данные поля attr_id должны быть целым числом',
            'data_to_array.attr.*.attr_id.min' => 'Данные поля attr_id должны быть от 1',
            'data_to_array.attr.*.attr_id.exists' => 'Идентификатор аттрибута неправильный',

            'data_to_array.files.required' => 'Файлы должны быть обязательные',
            'data_to_array.files.array' => 'Файлы должны быть переданы массивом',

            'data_to_array.files.*.fr_id.required' => 'Данные поля fr_id является обязательным значением',
            'data_to_array.files.*.fr_id.integer' => 'Данные поля fr_id должны быть целым числом',
            'data_to_array.files.*.fr_id.min' => 'Данные поля fr_id должны быть от 1',
            'data_to_array.files.*.fr_id.exists' => 'Идентификатор роли файла неправильный',

            'data_to_array.update_date.date' => 'Данные поля update_date должны быть датой',
            'data_to_array.update_date.date_format' => 'Данные поля update_date должны быть в формате YYYY-MM-DD',

            'data_to_array.temp_save_period.integer' => 'Данные поля temp_save_period должны быть целым числом',
            'data_to_array.temp_save_period.min' => 'Данные поля temp_save_period должны быть от 0',

            'data_to_array.resend_ak.boolean' => 'Должен имееть булевый тип данных',

            'data_to_array.media_type_id.integer' => 'Данное поле должно быть числом',
            'data_to_array.media_type_id.min' => 'Данное поле должно начинаится с 1',
            'data_to_array.media_type_id.exists' => 'Идентификатор медиа типа неправильный',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'EAD',
            'error' => $validator->errors(),
        ], 400));
    }

    private function changeKeyData($bugs)
    {
        $result = [];
        if (!empty($bugs->messages())) {
            foreach ($bugs->messages() as $key => $bug) {
                $result[str_replace('data_to_array.', '', $key)] = $bug;
            }
        }

        return $result;
    }
}
