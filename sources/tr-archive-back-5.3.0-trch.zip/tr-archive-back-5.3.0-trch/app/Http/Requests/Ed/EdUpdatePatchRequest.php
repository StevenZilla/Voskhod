<?php

namespace App\Http\Requests\Ed;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;

class EdUpdatePatchRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'string',
            'num' => 'string',
            'reg_date' => 'date|regex:/([1-9][0-9][0-9]{2}\-([0][1-9]|[1][0-2])\-([1-2][0-9]|[0][1-9]|[3][0-1]))|(([1-9][0-9][0-9]{2}\.([0][1-9]|[1][0-2])\.([1-2][0-9]|[0][1-9]|[3][0-1])))|((([1-2][0-9]|[0][1-9]|[3][0-1])\.([0][1-9]|[1][0-2])\.[1-9][0-9][0-9]{2}))/',
            'ed_type_id' => 'integer|min:1',
            'source_id' => 'integer|min:1|exists:source,id',
            'source_ed_id' => 'string|nullable',
            'dossier_id' => 'nullable|integer|min:1|exists:dossier,id',
            'update_date' => 'date|date_format:Y-m-d',
            'temp_save_period' => 'integer|min:0',
            'ed_status_id' => 'integer|min:1|exists:ed_status,id',
            'resend_ak' => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'name.string' => 'Наименование документа должно быть строкой',
            'num.string' => 'Регистрационный номер документа должен быть строкой',
            'reg_date.date' => 'Дата регистрации документа должна быть датой в формате YYYY-MM-DD',
            'reg_date.date_format' => 'Дата регистрации документа должна быть датой в формате YYYY-MM-DD',

            'ed_type_id.integer' => 'Данные поля ed_type_id должны быть целым числом',
            'ed_type_id.min' => 'Данные поля ed_type_id должны быть от 1',

            'source_id.required' => 'Данные поля source_id является обязательным значением',
            'source_id.integer' => 'Данные поля source_id должны быть целым числом',
            'source_id.min' => 'Данные поля source_id должны быть от 1',
            'source_id.exists' => 'Идентификатор источника неправильный',

            'source_ed_id.string' => 'Данные поля source_ed_id должны быть строкой',
            'num.nullable' => 'Данные поля source_ed_id могут быть пустыми',

            'dossier_id.nullable' => 'Данные поля dossier_id могут быть пустыми',
            'dossier_id.integer' => 'Данные поля dossier_id должны быть целым числом',
            'dossier_id.min' => 'Данные поля dossier_id должны быть от 1',
            'dossier_id.exists' => 'Идентификатор дела неправильный',

            'attr.array' => 'Аттрибуты должны быть переданы массивом',

            'attr.*.attr_id.required' => 'Данные поля attr_id является обязательным значением',
            'attr.*.attr_id.integer' => 'Данные поля attr_id должны быть целым числом',
            'attr.*.attr_id.min' => 'Данные поля attr_id должны быть от 1',
            'attr.*.attr_id.exists' => 'Идентификатор аттрибута неправильный',

            'files.required' => 'Файлы должны быть обязательные',
            'files.array' => 'Файлы должны быть переданы массивом',

            'files.*.fr_id.required' => 'Данные поля fr_id является обязательным значением',
            'files.*.fr_id.integer' => 'Данные поля fr_id должны быть целым числом',
            'files.*.fr_id.min' => 'Данные поля fr_id должны быть от 1',
            'files.*.fr_id.exists' => 'Идентификатор роли файла неправильный',

            'update_date.date' => 'Данные поля update_date должны быть датой',
            'update_date.date_format' => 'Данные поля update_date должны быть в формате YYYY-MM-DD',

            'temp_save_period.integer' => 'Данные поля temp_save_period должны быть целым числом',
            'temp_save_period.min' => 'Данные поля temp_save_period должны быть от 0',

            'resend_ak.boolean' => 'Должен имееть булевый тип данных',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'EAD',
            'error' => $validator->errors(),
        ], 400));
    }
}
