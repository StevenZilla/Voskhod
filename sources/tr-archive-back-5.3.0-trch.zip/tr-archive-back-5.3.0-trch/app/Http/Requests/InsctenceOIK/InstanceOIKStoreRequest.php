<?php

namespace App\Http\Requests\InsctenceOIK;

use App\Http\Requests\JsonRequest;

class InstanceOIKStoreRequest extends JsonRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'type_is_id' => ['request', 'integer'],
            'name' => ['request', 'string'],
            'guid' => ['request', 'string'],
            'descr' => ['request', 'string'],
            'codebase_vm_id' => ['request', 'integer'],
            'claster' => ['request', 'array'],
            'claster.vm_id' => ['request', 'integer'],
            'claster.dbms_id' => ['request', 'integer'],
            'claster.dbms_port_id' => ['integer'],
            'claster.dbms_port' => ['request', 'string'],
            'claster.db_params' => ['request'],
            'claster.name' => ['request', 'string'],
            'claster.db_scheme' => ['request', 'string'],
            'claster.db_role' => ['request', 'string'],
            'claster.db_login' => ['request', 'string'],
            'claster.replicas' => ['request', 'array'],
            'storage' => ['request', 'array'],
            'storage.vm_id' => ['request', 'integer'],
            'storage.storage_id' => ['request', 'integer'],
            'storage.root' => ['request', 'string'],
            'user' => ['request', 'array'],
            'user.fio' => ['request', 'string'],
            'user.contact' => ['request', 'string'],
        ];
    }

    public function messages(): array
    {
        return [
            'type_is_id' => [],
            'name' => [],
            'guid' => [],
            'descr' => [],
            'claster' => [],
            'claster.vm_id' => [],
            'claster.dbms_id' => [],
            'claster.dbms_port' => [],
            'claster.db_params' => [],
            'claster.db_scheme' => [],
            'claster.db_role' => [],
            'claster.db_login' => [],
            'claster.replicas' => [],
            'storage' => [],
            'storage.vm_id' => [],
            'storage.storage_id' => [],
            'storage.root' => [],
            'user' => [],
            'user.fio' => [],
            'user.contact' => [],
        ];
    }
}
