<?php

namespace App\Http\Requests\Agreement;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AgreementReviewEpkPatchRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'thumbprint' => ['nullable', 'array'],
            'thumbprint.*' => ['required', 'exists:sert,thumbprint'],
        ];
    }

    public function messages(): array
    {
        return [
            'thumbprint.array' => 'Сертификаты должны быть в формате массива',
            'thumbprint.*.required' => 'Сертификаты являются обязательным полем',
            'thumbprint.*.exists' => 'Сертификат отсутствует в системе',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT.REVIEW.EPK',
            'error' => $validator->errors(),
        ], 400));
    }
}
