<?php

namespace App\Http\Requests\Agreement;

use Illuminate\Foundation\Http\FormRequest;

class IndexGetRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'register_id' => 'integer',
            'is_actual' => 'in:true,false',
        ];
    }

    public function messages()
    {
        return [
            'register_id.integer' => 'Поле register_id должно быть числом',
        ];
    }
}
