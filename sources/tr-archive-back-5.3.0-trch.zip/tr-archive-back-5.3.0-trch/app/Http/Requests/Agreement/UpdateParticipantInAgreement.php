<?php

namespace App\Http\Requests\Agreement;

use App\Models\System\SystemParam;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateParticipantInAgreement extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ids' => 'required|array',
            'ids.*' => 'required|integer|min:1|exists:participant,id',
        ];
    }

    /**
     * Вывод сообщений об ошибках.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'ids.required' => 'Участники согласования являются обязательными параметрами.',
            'ids.array' => 'Участники согласования должны быть в формате массива.',

            'ids.*.required' => 'Идентификатор участника является обязательным параметром.',
            'ids.*.integer' => 'Идентификатор участника согласования должен быть в формате целого числа.',
            'ids.*.min' => 'Идентификатор участника согласования должен быть больше или равен 1.',
            'ids.*.exists' => 'Идентификатор участника согласования не существует в системе.',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT.PARTICIPANT',
            'error' => $validator->errors(),
        ], 400));
    }
}
