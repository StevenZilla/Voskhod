<?php

namespace App\Http\Requests\DeleteAct\Agreements;


use Illuminate\Http\UploadedFile;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class SetAffirmativeDecisionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'decision_type_id' => 'required|exists:delete_act_decision_type,id',
            'comment' => ['nullable', 'string'],
            'files_comment' => [
                'nullable',
                function ($attribute, $value, $fail) {
                    $sizeFile = getUploadMaxFileSize();
                    foreach ($value as $item) {
                        if ($item instanceof UploadedFile) {
                            if (empty($item->getSize())) {
                                $fail("Файл не должен быть пуст");
                            }
                            if ($item->getSize() > $sizeFile) {
                                $tmpSize = $sizeFile/1000/1000;
                                $fail("Размер файла не должен превышать - {$tmpSize} Мб");
                            }

                            $extension = pathinfo($item->getClientOriginalName(), PATHINFO_EXTENSION);
                            if (!in_array(mb_strtolower($extension), ['pdf', 'doc', 'docx', 'rtf'])) {
                                $fail('Формат файла должен быть: pdf, doc, docx, rtf');
                            }
                        } else {
                            $fail('Файл замечаний должен быть файлом');
                        }
                    }
                },
            ],


            'thumbprint' => 'string|nullable'
        ];
    }
    public function messages(): array
    {
        return [
            'thumbprint.present' => 'Отпечаток сертификата обязателен',
            'thumbprint.string' => 'Сертификаты должны быть строкой',
            'thumbprint.exists' => 'Сертификат отсутствует в системе',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'DELETE_ACT_AGREEMENT.AFFIRMATIVE',
            'error' => $validator->errors(),
        ], 400));
    }
}
