<?php

namespace App\Http\Requests\DeleteAct\Agreements;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "agreeing" => "required|array",
            "affirmative" => "required|exists:participant,id",
        ];
    }

    public function messages(): array
    {
        return [
            'agreeing.required' => "Список согласующих обязателен",
            'agreeing.array' => "Список согласующих должен быть массивом",
            'affirmative.present' => "Поле с идентификатором утверждающего обязательно, но может быть пустым",
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'DELETE_ACT_AGREEMENT',
            'error' => $validator->errors(),
        ], 400));
    }
}
