<?php

namespace App\Http\Requests\DeleteAct\Project;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'number' => [
                'string', 'required', 'unique:delete_act,num,' . $this->id
            ],
            // 'year' => [
            //     'required', 'date_format:Y'
            // ],
            "eds" => "array|present",
            "eds.*" => "int|exists:ed,id",
        ];
    }

    public function messages(): array
    {
        return [
            'number.required' => 'Номер акта обязателен',
            'number.unique' => 'Номер акта должен быть уникальным',
            'eds.array' => 'Список ЭД должен быть массивом',
            'eds.present' => 'Список ЭД обязателен',
            'eds.*.int' => 'Идентификатор ЭД должен быть числом',
            'eds.*.exists' => 'ЭД должен существовать в системе',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'DELETE_ACT',
            'error' => $validator->errors(),
        ], 400));
    }
}
/*

             function ($attribute, $value, $fail) {
                    $deleteActId = $this->route()->originalParameter('id');
                    if (DeleteAct::where($attribute, $value)->where('id', '!=', $deleteActId)->exists()) {
                        $fail("Номер акта {$value} не уникальный.");
                    }
                }
                */