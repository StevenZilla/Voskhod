<?php

namespace App\Http\Requests\ForgotController;

use App\Models\User\User;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class RestorePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'contact' => ['required', function ($attribute, $value, $fail) {
                if (! empty(preg_replace('/(.+)@(.+)\.(.+)/i', '', $value))) {
                    $user = User::where('login', $value)->first();
                } else {
                    $user = User::where('email', $value)->first();
                }

                if (empty($user)) {
                    throw new HttpResponseException(response()->json([
                        'code' => 400,
                        'message' => 'Валидация не пройдена',
                        'target' => 'AUTH',
                        'error' => [$attribute => 'Пользователя не существует с таким логином/эл.почтой'],
                    ], 400));
                }
            }],
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AUTH',
            'error' => $validator->errors(),
        ], 400));
    }
}
