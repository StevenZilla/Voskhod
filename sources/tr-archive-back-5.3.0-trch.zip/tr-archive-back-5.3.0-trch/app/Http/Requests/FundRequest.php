<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class FundRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'archive_id' => 'integer|min:1|exists:archive,id',
            'q' => 'string',
        ];
    }

    public function getMessages(): array
    {
        return [
            'archive_id'                 => 'archive_id должен быть положительным числом',
            'q'                          => 'q-параметр должен быть строкой',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'FUND',
            'error' => $validator->errors(),
        ], 400));
    }
}
