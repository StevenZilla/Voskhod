<?php

namespace App\Http\Requests\AgreementRequest;

use App\Models\User\User;
use Carbon\Carbon;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AgreementStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'type_id' => ['required', 'integer', 'min:1', 'exists:agreement_type,id'],
            'register_id' => ['required', 'integer', 'min:1', 'exists:register,id'],
            'participants' => ['nullable', 'array'],
            'participants.*' => ['required', 'integer', 'min:1', 'exists:participant,id'],
            'approval_period_till' => [
                'required',
                'regex:/([1-9][0-9][0-9]{2}\-([0][1-9]|[1][0-2])\-([1-2][0-9]|[0][1-9]|[3][0-1]))|(([1-9][0-9][0-9]{2}\.([0][1-9]|[1][0-2])\.([1-2][0-9]|[0][1-9]|[3][0-1])))|((([1-2][0-9]|[0][1-9]|[3][0-1])\.([0][1-9]|[1][0-2])\.[1-9][0-9][0-9]{2}))/',
                function ($attribute, $value, $fail) {
                    $carbonNow = Carbon::now();
                    $carbonValue = Carbon::parse($value);

                    if ($carbonNow->diffInDays($carbonValue, false) < 0) {
                        $fail("Срок согласования должен быть не меньше текущего дня");
                    }
                },
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'type_id.required' => 'Тип согласования является обязательным значением',
            'type_id.integer' => 'Тип согласования должен быть передан в формате целого числа',
            'type_id.min' => 'Тип согласования должен быть больше 1',
            'type_id.exists' => 'Тип согласования отсутствует в системе',

            'register_id.required' => 'Опись является обязательным значением',
            'register_id.integer' => 'Опись должна быть передана в формате целого числа',
            'register_id.min' => 'Опись должна быть больше 1',
            'register_id.exists' => 'Опись отсутствует в системе',

            'participants.array' => 'Участники согласования должны быть переданы в массиве данных',

            'participants.*.required' => 'Участник согласования является обязательным значением',
            'participants.*.integer' => 'Участник согласования должен быть передан в формате целого числа',
            'participants.*.min' => 'Участник согласования должен быть больше 1',
            'participants.*.exists' => 'Участник согласования отсутствует в системе',

            'approval_period_till.required' => 'Срок согласования является обязательным',
            'approval_period_till.date' => 'Срок согласования должен содержать дату',
            'approval_period_till.date_format' => 'Формат срока согласования должен быть: ГГГГ-ММ-ДД',
            'approval_period_till.after_or_equal' => 'Срок согласования не меньше текущего дня',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT',
            'error' => $validator->errors(),
        ], 400));
    }
}
