<?php

namespace App\Http\Requests\AgreementRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AgreementUpdateActionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'is_send_ek' => ['nullable', 'in:true,1'],
        ];
    }

    public function messages(): array
    {
        return [
            'is_send_ek.in' => 'Отправить на согласование ожидает параметр true/1',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT.ACTION',
            'error' => $validator->errors(),
        ], 400));
    }
}
