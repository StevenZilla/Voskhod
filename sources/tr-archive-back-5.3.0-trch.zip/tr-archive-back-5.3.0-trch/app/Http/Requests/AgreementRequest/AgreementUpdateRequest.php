<?php

namespace App\Http\Requests\AgreementRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AgreementUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'participants' => ['required', 'array'],
            'participants.deleted_participants' => ['nullable', 'array'],
            'participants.deleted_participants.*' => ['required', 'integer', 'min:1', 'exists:participant,id'],
            'participants.new_participants' => ['nullable', 'array'],
            'participants.new_participants.*' => ['required', 'integer', 'min:1', 'exists:participant,id'],
            'approval_period_till' => ['date', 'date_format:d.m.Y', 'after_or_equal:'.date('d.m.Y')],
        ];
    }

    public function messages(): array
    {
        return [
            'participants.required' => 'Массив с участниками согласования должен быть обязательным',
            'participants.array' => 'Участники согласования должны быть переданы в массиве данных',

            'participants.deleted_participants.array' => 'даленные участники согласования должны быть переданы в массиве данных',

            'participants.deleted_participants.*.required' => 'Удаленные участники согласования являются обязательным значением',
            'participants.deleted_participants.*.integer' => 'Удаленные участники согласования должны быть переданы в формате целого числа',
            'participants.deleted_participants.*.min' => 'Удаленные участники согласования должны быть больше 1',
            'participants.deleted_participants.*.exists' => 'Удаленный участник согласования отсутствует в системе',

            'participants.new_participants.array' => 'Новые участники согласования должны быть переданы в массиве данных',

            'participants.new_participants.*.required' => 'Новые участники согласования являются обязательным значением',
            'participants.new_participants.*.integer' => 'Новые участники согласования должны быть переданы в формате целого числа',
            'participants.new_participants.*.min' => 'Новые участники согласования должны быть больше 1',
            'participants.new_participants.*.exists' => 'Новый участник согласования отсу тствует в системе',

            'approval_period_till.date' => 'Срок согласования должен содержать дату',
            'approval_period_till.date_format' => 'Формат срока согласования должен быть: ГГГГ-ММ-ДД',
            'approval_period_till.after_or_equal' => 'Срок согласования не меньше текущего дня',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT',
            'error' => $validator->errors(),
        ], 400));
    }
}
