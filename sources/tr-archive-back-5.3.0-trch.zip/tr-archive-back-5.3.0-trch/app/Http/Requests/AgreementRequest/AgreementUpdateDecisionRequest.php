<?php

namespace App\Http\Requests\AgreementRequest;

use App\Models\User\User;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\UploadedFile;

class AgreementUpdateDecisionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'decision_type_id' => ['required', 'integer', 'min:1', 'exists:decision_type,id'],
            'comment' => ['nullable', 'string'],
            'files_comment' => [
                'nullable',
                function ($attribute, $value, $fail) {
                    $sizeFile = getUploadMaxFileSize();
                    foreach ($value as $item) {
                        if ($item instanceof UploadedFile) {
                            if (empty($item->getSize())) {
                                $fail("Файл не должен быть пуст");
                            }
                            if ($item->getSize() > $sizeFile) {
                                $tmpSize = $sizeFile/1000/1000;
                                $fail("Размер файла не должен превышать - {$tmpSize} Мб");
                            }

                            $extension = pathinfo($item->getClientOriginalName(), PATHINFO_EXTENSION);
                            if (!in_array(mb_strtolower($extension), ['pdf', 'doc', 'docx', 'rtf'])) {
                                $fail('Формат файла должен быть: pdf, doc, docx, rtf');
                            }
                        } else {
                            $fail('Файл замечаний к проекту описи должен быть файлом');
                        }
                    }
                },
            ],
            'thumbprint' => ['nullable', 'array'],
            'thumbprint.*' => ['nullable', 'exists:sert,thumbprint'],

        ];
    }

    public function messages(): array
    {
        return [
            'decision_type_id.required' => 'Решение проекта описи является обязательным параметром',
            'decision_type_id.integer' => 'Решение проекта описи должно быть целым числом',
            'decision_type_id.min' => 'Решение проекта описи должно быть больше либо равно 1',
            'decision_type_id.exists' => 'Решение проекта описи отсутствует в системе',

            'comment.string' => 'Комментарий к проекту описи должен быть строкой',

            'thumbprint.array' => 'Сертификаты должны быть в формате массива',
            'thumbprint.*.exists' => 'Сертификат отсутствует в системе',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => 'Валидация не пройдена',
            'target' => 'AGREEMENT.DECISION',
            'error' => $validator->errors(),
        ], 400));
    }
}
