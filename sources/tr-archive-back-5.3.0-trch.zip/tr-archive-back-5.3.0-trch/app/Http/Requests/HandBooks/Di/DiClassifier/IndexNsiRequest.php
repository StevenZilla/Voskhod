<?php

namespace App\Http\Requests\HandBooks\Di\DiClassifier;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class IndexNsiRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'save_info' => "string|nullable",
            'is_main' => "nullable|in:true,false,1,0",
            'like_save_info_id' => "integer|exists:di_kind,id",
            'like_name' => "string"
        ];
    }
    public function messages(): array
    {
        return [
            'save_info.string' => __('main.diKind.save_info.string'),
            'save_info.nullable' => __('main.diKind.save_info.nullable'),

            'is_main.boolean' => __('main.diKind.is_main.boolean'),
            'is_main.nullable' => __('main.diKind.is_main.nullable'),

            'like_save_info_id.integer' => __('main.diKind.like_save_info_id.integer'),
            'like_save_info_id.exists' => __('main.diKind.like_save_info_id.exists'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'DiKind',
            'error' => $validator->errors(),
        ], 400));
    }
}
