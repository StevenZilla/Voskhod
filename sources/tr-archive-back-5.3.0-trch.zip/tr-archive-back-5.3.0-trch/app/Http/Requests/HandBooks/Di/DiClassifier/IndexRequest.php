<?php

namespace App\Http\Requests\HandBooks\Di\DiClassifier;

use App\Models\Di\DiClassifier;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class IndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'is_actual' => "nullable|in:true,false,1,0",
            'is_history' => "nullable|in:true,false,1,0",
            'sort' => [function ($attribute, $value, $fail) {
                $sort = DiClassifier::hasOrder($value);
                foreach ($sort as $key => $error) {
                    $errorString[$key] = "Сортировки по полю {$error} не существует";
                }
                if (!empty($errorString)) $fail($errorString);
            }],
        ];
    }
    public function messages(): array
    {
        return [
            'is_actual.in' => __('main.diClassifier.is_actual.in'),
            'is_actual.nullable' => __('main.diClassifier.is_actual.nullable'),
            'is_history.in' => __('main.diClassifier.is_history.in'),
            'is_history.nullable' => __('main.diClassifier.is_history.nullable'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'DiClassifier',
            'error' => $validator->errors(),
        ], 400));
    }
}
