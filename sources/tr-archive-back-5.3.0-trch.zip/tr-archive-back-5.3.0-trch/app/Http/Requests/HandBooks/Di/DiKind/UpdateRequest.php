<?php

namespace App\Http\Requests\HandBooks\Di\DiKind;

use Exception;
use Faker\Provider\Base;
use App\Models\Di\DiKind;
use App\Models\Di\DiKindGroup;
use Illuminate\Validation\Rule;
use App\Exceptions\BaseException;
use App\Models\Di\DiClassifier;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // dd($this->request);
        try {
            $diKindId = $this->route('id');
            $diKind = DiKind::findOrFail($diKindId);
            $diKindGroupId = $diKind->group_id;
            $diKindGroup = DiKindGroup::findOrFail($diKindGroupId);
            $diClassifierId = $diKindGroup->di_classifier_id;
        } catch (Exception $e) {
            throw new BaseException("Статьи с переданным id не существует");
        }
        return [
            "name" => "required|string",
            "num" => [
                'required', 'string',
                function ($attribute, $value, $fail) use ($diClassifierId, $diKindId) {
                    $valid =  DiKind::leftJoin('di_kind_group', 'di_kind.group_id', '=', 'di_kind_group.id')
                        ->where('di_kind_group.di_classifier_id', $diClassifierId)->where('di_kind.id', '<>', $diKindId)->where('di_kind.num', $value)->exists();
                    if ($valid) {
                        $fail(__('main.diKind.num.unique'));
                    }
                }
            ],
            "code" => "nullable|string|unique:di_kind,code," . $this->id,
            "description" => "required|string",
            "save_type_id" => "required|integer|exists:save_type,id",
            "temp_save_period" => "nullable|integer|required_if:save_type_id,2",
            "is_need_epk" => "required|nullable|boolean", //in:true,false,1,0
            "is_need_ek" => "required|nullable|boolean", //in:true,false,1,0
            // "is_active" => "nullable|boolean" //in:true,false,1,0
        ];
    }
    public function messages(): array
    {
        return [
            'name.required' => __('main.diKind.name.required'),
            'name.string' => __('main.diKind.name.string'),
            'num.required' => __('main.diKind.num.required'),
            'num.string' => __('main.diKind.num.string'),
            'num.unique' => __('main.diKind.num.unique'),
            'code.string' => __('main.diKind.code.string'),
            'code.unique' => __('main.diKind.code.unique'),
            'description.required' => __('main.diKind.description.required'),
            'description.string' => __('main.diKind.description.string'),
            'save_type_id.exists' => __('main.diKind.save_type_id.exists'),
            'save_type_id.integer' => __('main.diKind.save_type_id.integer'),
            'save_type_id.required' => __('main.diKind.save_type_id.required'),
            'temp_save_period.required_if' => __('main.diKind.temp_save_period.required_if'),
            'temp_save_period.integer' => __('main.diKind.temp_save_period.integer'),


            'is_need_epk.required' => __('main.diKind.is_need_epk.required'),
            'is_need_epk.boolean' => __('main.diKind.is_need_epk.boolean'),
            'is_need_ek.required' => __('main.diKind.is_need_ek.required'),
            'is_need_ek.boolean' => __('main.diKind.is_need_ek.boolean'),
            // 'is_active.in' => __('main.diKind.is_active.in'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'di_kind',
            'error' => $validator->errors(),
        ], 400));
    }
}
