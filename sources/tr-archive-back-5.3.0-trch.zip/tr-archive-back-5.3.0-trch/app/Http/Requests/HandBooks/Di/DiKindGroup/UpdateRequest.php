<?php

namespace App\Http\Requests\HandBooks\Di\DiKindGroup;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // $exceptId = $this->request()->route('id');
        return [
            "name" => "required|string",
            "code" => "nullable|string|unique:di_kind_group,code," . $this->id,
            // "code" => "nullable|string|unique:di_kind_group,code," . $this->request->get('code') . "",
            "parent_id" => "nullable|integer|exists:di_kind_group,id,",
//            "is_active" => "nullable|boolean" //in:true,false,1,0
        ];
    }
    public function messages(): array
    {
        return [
            'name.required' => __('main.diKindGroup.name.required'),
            'name.string' => __('main.diKindGroup.name.string'),
            'code.string' => __('main.diKindGroup.code.string'),
            'code.unique' => __('main.diKindGroup.code.unique'),
            'parent_id.exists' => __('main.diKindGroup.parent_id.exists'),
            'parent_id.integer' => __('main.diKindGroup.parent_id.integer'),

        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'di_kind_group',
            'error' => $validator->errors(),
        ], 400));
    }
}
