<?php

namespace App\Http\Requests\HandBooks\Di\DiClassifier;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'short_name' => 'required|string',
            'description' => 'string|nullable',
            'is_main' => "nullable|boolean", //in:true,false,1,0
        ];
    }
    public function messages(): array
    {
        return [
            'name.required' => __('main.diClassifier.name.required'),
            'name.string' => __('main.diClassifier.name.string'),
            'short_name.required' => __('main.diClassifier.short_name.required'),
            'short_name.string' => __('main.diClassifier.short_name.string'),
            'description.string' => __('main.diClassifier.description.string'),
            'description.nullable' => __('main.diClassifier.description.nullable'),
            'is_main.in' => __('main.diClassifier.is_main.in'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'DiClassifier',
            'error' => $validator->errors(),
        ], 400));
    }
}
