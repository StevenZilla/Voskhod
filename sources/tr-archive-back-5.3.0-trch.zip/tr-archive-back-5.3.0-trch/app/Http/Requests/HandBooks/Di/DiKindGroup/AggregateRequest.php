<?php

namespace App\Http\Requests\HandBooks\Di\DiKindGroup;

use App\Models\Di\DiKindGroup;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class AggregateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'inactive_di_kind' => "nullable|string|in:true,false,1,0", //
            'sort' => [function ($attribute, $value, $fail) {
                $sort = DiKindGroup::hasOrder($value);
                foreach ($sort as $key => $error) {
                    $errorString[$key] = "Сортировки по полю {$error} не существует";
                }
                if (!empty($errorString)) $fail($errorString);
            }],

        ];
    }
    public function messages(): array
    {
        return [
            'inactive_di_kind.in' => __('main.diKindGroup.inactive_di_kind.in'),

        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'di_kind_group',
            'error' => $validator->errors(),
        ], 400));
    }
}
