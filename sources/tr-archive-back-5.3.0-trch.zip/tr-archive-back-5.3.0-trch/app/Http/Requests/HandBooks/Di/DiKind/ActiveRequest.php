<?php

namespace App\Http\Requests\HandBooks\Di\DiKind;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class ActiveRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'is_active' => 'required|boolean'
        ];
    }
    public function messages(): array
    {
        return [
            'is_active.required' => __('main.diKind.is_active.required'),
            'is_active.boolean' => __('main.diKind.is_active.boolean'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'DiKind',
            'error' => $validator->errors(),
        ], 400));
    }
}
