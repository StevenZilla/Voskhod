<?php

namespace App\Http\Requests\HandBooks\Fund;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateFundRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'value' => ['required', 'string'],
            'num' => ['required', 'string'],
            'descr' => ['required', 'string'],
            'code' => ['required', 'string'],
            'archive_id' => ['required', 'exists:archive,id'],
            'is_actual' => ['required'],
            'is_default' => ['required'],
        ];
    }

    public function messages(): array
    {
        return [
            'value.required' => __('main.funds.value.required'),
            'value.string' => __('main.funds.value.string'),
            'num.required' => __('main.funds.num.required'),
            'num.string' => __('main.funds.num.string'),
            'descr.required' => __('main.funds.descr.required'),
            'descr.string' => __('main.funds.descr.string'),
            'code.required' => __('main.funds.code.required'),
            'code.string' => __('main.funds.code.string'),
            'archive_id.required' => __('main.funds.archive_id.required'),
            'archive_id.exists' => __('main.funds.archive_id.exists'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'FUND',
            'error' => $validator->errors(),
        ], 400));
    }
}
