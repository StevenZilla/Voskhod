<?php

namespace App\Http\Requests\HandBooks\Source;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSourceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //            "name"
//            "description"
//            "actual_date"
//            "created_at"
//            "updated_at"
//            "code"
//            "is_actual"
//            "guid"
//            "is_send_ack"
//            "code_xml"
        ];
    }
}
