<?php

namespace App\Http\Requests\HandBooks\Archive;

use App\Models\HandBooks\Archive;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateArchiveRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        //        return [
        //            'value' => ['required', 'string','unique:Archive,name'],
        //            'full_name' => ['required', 'string'],
        //            'email' => ['nullable', 'string', 'email'],
        //            'descr' => ['nullable', 'string'],
        //            'code' => ['required', 'string'],
        //            'address' => ['nullable', 'string'],
        //            'head' => ['nullable', 'string'],
        //            'head_phone' => ['nullable', 'string'],
        //        ];

        return [
            'value' => ['required', 'string', "unique:archive,short_name," . $this->id,],
            'full_name' => ['required', 'string'],
            'email' => ['nullable', 'string', 'email'],
            'descr' => ['nullable', 'string'],
            'code' => ['required', 'string'],
            'address' => ['nullable', 'string'],
            'head' => ['nullable', 'string'],
            'head_phone' => ['nullable', 'string'],
            'is_actual' => ['required'],
        ];
    }

    public function messages(): array
    {
        return [
            'value.required' => __('main.archives.value.required'),
            'value.unique' => __('main.archives.duplicate'),
            'value.string' => __('main.archives.value.string'),
            'address.required' => __('main.archives.address.required'),
            'address.string' => __('main.archives.address.string'),
            'full_name.required' => __('main.archives.full_name.required'),
            'full_name.string' => __('main.archives.full_name.string'),
            'email.required' => __('main.archives.email.required'),
            'email.string' => __('main.archives.email.string'),
            'email.email' => __('main.archives.email.email'),
            'descr.required' => __('main.archives.descr.required'),
            'descr.string' => __('main.archives.descr.string'),
            'code.required' => __('main.archives.code.required'),
            'code.string' => __('main.archives.code.string'),
            'head.required' => __('main.archives.head.required'),
            'head.string' => __('main.archives.head.string'),
            'head_phone.required' => __('main.archives.head_phone.required'),
            'head_phone.string' => __('main.archives.head_phone.string'),
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'code' => 400,
            'message' => __('main.validation.failed'),
            'target' => 'ARCHIVE',
            'error' => $validator->errors(),
        ], 400));
    }
}
