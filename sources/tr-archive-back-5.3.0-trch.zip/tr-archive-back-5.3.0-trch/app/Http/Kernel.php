<?php

namespace App\Http;

use App\Http\Middleware\AddHeaders;
use App\Http\Middleware\AuditMiddleware;
use App\Http\Middleware\AuthenticateWithBasicAuthMiddleware;
use App\Http\Middleware\Check2FAMiddleware;
use App\Http\Middleware\CheckIpMiddleware;
use App\Http\Middleware\CorsMiddleware;
use App\Http\Middleware\HasValidSignatureRequestMiddleware;
use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     *
     * These middleware are run during every request to your application.
     *
     * @var array
     */
    protected $middleware = [
        \Fruitcake\Cors\HandleCors::class,
        \Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \App\Http\Middleware\TrimStrings::class,
        \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
        \App\Http\Middleware\TrustProxies::class,
    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            // \Illuminate\Session\Middleware\AuthenticateSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
        ],

        'api' => [
            \App\Http\Middleware\EncryptCookies::class, // TODO https://stackoverflow.com/questions/33130748/laravel-session-id-changes-with-each-request
            \Illuminate\Session\Middleware\AuthenticateSession::class, // TODO https://kfirba.me/blog/the-undocumented-authenticatesession-middleware-decoded
            \Illuminate\Session\Middleware\StartSession::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            'bindings',
        ],
    ];

    /**
     * The application's route middleware.
     *
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth' => \Illuminate\Auth\Middleware\Authenticate::class,
        'auth.basic' => AuthenticateWithBasicAuthMiddleware::class,
        'bindings' => \Illuminate\Routing\Middleware\SubstituteBindings::class,
        'can' => \Illuminate\Auth\Middleware\Authorize::class,
        'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
        'check.ip' => CheckIpMiddleware::class,
        'event_journal' => AuditMiddleware::class,
        'check_2fa' => Check2FAMiddleware::class,
        'has_valid_signature' => HasValidSignatureRequestMiddleware::class,

        // a basic Enforcer Middleware
        'enforcer' => \Lauthz\Middlewares\EnforcerMiddleware::class,
        // an HTTP Request Middleware
        'http_request' => \Lauthz\Middlewares\RequestMiddleware::class,
        'add_header' => AddHeaders::class,
    ];

    /**
     * Список посредников, отсортированный по приоритетности.
     *
     * Заставит неглобальных посредников всегда быть в заданном порядке.
     *
     * @var string[]
     */
    protected $middlewarePriority = [
        AuditMiddleware::class,
    ];
}
