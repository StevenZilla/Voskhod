<?php

namespace App;

use App\Models\BaseModel;

/**
 * App\EDAttributeType
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType query()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
class EDAttributeType extends BaseModel
{
    //
}
