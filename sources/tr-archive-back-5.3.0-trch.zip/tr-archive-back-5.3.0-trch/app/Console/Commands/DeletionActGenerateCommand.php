<?php

namespace App\Console\Commands;

use App\Facades\DatabaseConnectionFacade;
use App\Services\ConnectionDB\ConnectionDB;
use App\Jobs\DeleteAct\DeleteActGenerateJob;
use Illuminate\Support\Facades\Log;

class DeletionActGenerateCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deletionAct:generate {--U|uid_org=} {--I|id_app=}';

    protected $description = 'Создание задачи для генерации акта на уничтожение ЭД';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        try {
            Log::channel("single_jobs")->info("Запуск задачи на генерацию акта об уничтожении ЭД\n");
            $guid = null;
            if (!ConnectionDB::isLocalConnectDB()) {
                if ($this->hasOption('uid_org') && $this->option('uid_org') != null) {
                    $guid = $this->option('uid_org');
                } else {
                    $guid = DatabaseConnectionFacade::getGuidMedo($this->id_app);
                }
                $this->setConnection($guid);
            }
            echo "GUID организации для которой будем генерировать отчёт {$guid}\n";
            DeleteActGenerateJob::dispatch($guid)->onQueue("delete_act_generate_job");
        } catch (\Exception $exception) {
            $msg = "Произошла ошибка при запуске задачи на генерацию акта об уничтожении ЭД";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
