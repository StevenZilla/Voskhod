<?php

namespace App\Console\Commands;

use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class SetVersionProduct extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'version_product:set {--A|all=false} {--U|uid_org=} {--p|path=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Команда позволяющая обновить версию продукта в таблице system_params, считав значение из файла version.txt';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Устанавливаем версию продукта у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->setVersion();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->setVersion();
            }
        } else {
            $this->info('Устанавливаем версию продукта у локального тр-архива');
            $this->setVersion();
        }
    }

    protected function setVersion()
    {
        try {
            if (! empty($this->option('path'))) {
                $pathToVersionFile = $this->option('path');
            } else {
                $files = array_diff(scandir($this->getLaravel()->basePath()), ['..', '.']);
                if (count($files) > 0) {
                    foreach ($files as $file) {
                        if (stripos($file, 'version') !== false) {
                            $pathToVersionFile = $this->getLaravel()->basePath().'/'.$file;
                            break;
                        }
                    }
                }
            }

            if (! empty($pathToVersionFile) && file_exists($pathToVersionFile)) {
                $version = trim(file_get_contents($pathToVersionFile));

                $systemParam = SystemParam::where('name', 'Версия ПО')->where('code', 'version_po')->first();
                if ($version !== $systemParam->value) {
                    $systemParam->value = $version;
                    $systemParam->save();
                }

                $this->info("Версию успешно обновили. Текущая версия: {$version}");
            } else {
                $messageError = ! empty($pathToVersionFile) ? $pathToVersionFile : 'корне проекта';
                $this->error('Файл с версией продукта отсутствует в '.$messageError);
            }
        } catch (\Exception $exception) {
            $msg = "Команда по установки версии продукта завершилась с ошибкой.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
