<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class SetVersionTK extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'version.tk:set {--U|uid_org=} {--S|show_versions=false}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Устанавливает версию транспортных контейнеров';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Версию ТК больше не устанавливаем');
    }
}
