<?php

namespace App\Console\Commands\OpenSearch;

use App\Console\Commands\BaseCommand;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;
use OpenSearch\ClientBuilder;

class CreateIndexPopularQuery extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'opensearch:create.popular_query {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Будем создавать индекс для OpenSearch у облачного архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    if ($this->option('all') === 'true') {
                        $this->setMessageGuid($guid);
                    }

                    Log::channel('command_single')->debug("Создаем индекс популярных запросов у OpenSearch для инстанции -{$this->messageGuid}");
                    $this->info("Создаем индекс популярных запросов у OpenSearch для инстанции -{$this->messageGuid}");
                    $this->setConnection($guid);

                    $this->createIndexPopularQuery();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->createIndexPopularQuery();
            }

            $this->info('Успешно создали индекс для OpenSearch у облачного архива');
        } else {
            $this->info('Будем создавать индекс для OpenSearch у локального архива');
            $this->createIndexPopularQuery();
            $this->info('Успешно создали индекс для OpenSearch у локального архива');
        }
    }

    private function createIndexPopularQuery()
    {
        try {
            $guidInstance = SystemParam::where('code', 'identificator_app')->pluck('value')->first();
            $config = config('opensearch');
            $client = new ClientBuilder();
            $client->setHosts([$config['host']]);
            $client->setBasicAuthentication($config['login'], $config['password']);

            if (!$config['ssl_verification']) {
                $client->setSSLVerification($config['ssl_verification']);
            }

            $client = $client->build();
            $index = "oik_{$guidInstance}_popular_query";
            $checkExistsIndex = $client->indices()->exists(['index' => $index]);
            if (!$checkExistsIndex) {
                $this->info("Индекс {$index} не создан для OpenSearch.");

                $data = [
                    'index' => $index, // Наименование индекс
                    'body' => [ // Тело
                        'mappings' => [ // Информация о полях
                            'properties' => [ // Описание полей
                                'title' => [ // Заголовок поиска
                                    'type' => 'text', // Тип строка
                                    'analyzer' => 'custom_analyzer', // Какой используется анализатор при сохранении данных
//                                'search_analyzer' => 'custom_search_analyzer', // Какой используется анализатор при поиске
                                ],
                                'title_without_changes' => [ // Количество использования
                                    'type' => 'keyword' // Целая строка
                                ],
                                'last_use_date' => [ // Дата последнего использования
                                    'type' => 'date' // Дата
                                ]
                            ]
                        ],
                        'settings' => [
                            'index' => [
                                'max_ngram_diff' => 10
                            ],
                            'analysis' => [
                                'analyzer' => [
                                    'custom_analyzer' => [ // анализатор разбивает строку на отдельные термины, вводит термины в нижний регистр, а затем выдает граничные n-граммы для каждого термина, используя custom_filter.
                                        'type' => 'custom',
                                        'tokenizer' => 'tokenizer',
                                        'filter' => ['lowercase', 'custom_filter'],
                                    ],
                                ],
                                'tokenizer' => [
                                    'tokenizer' => [
                                        'token_chars' => ['letter', 'digit', 'punctuation', 'symbol'],
                                        'type' => 'ngram',
                                        'min_gram' => 2,
                                        'max_gram' => 5,
                                    ]
                                ],
                                'filter' => [
                                    'custom_filter' => [ // создает граничные n-граммы с минимальной длиной n-грамма 2 (две буквы) и максимальной длиной 10 букв
                                        'type' => 'ngram',
                                        'min_gram' => 2,
                                        'max_gram' => 5,
                                    ]
                                ]
                            ]
                        ],
                    ]
                ];

                $indexCreationResult = $client->indices()->create($data);

                if (!empty($indexCreationResult) && !empty($indexCreationResult['acknowledged'])) {
                    $this->info("Индекс {$index} для OpenSearch успешно создан.");
                } else {
                    $json = json_encode($indexCreationResult ?? ['Нет тела ответа.']);
                    $this->warn("Непонятный ответ от создания индекса. Ответ, который отправил на OpenSearch: {$json}");
                    Log::channel('command_single')->debug("Непонятный ответ от создания индекса. Ответ, который отправил на OpenSearch: {$json}");
                }
            } else {
                $this->info("Индекс {$index} для OpenSearch уже создан.");
            }
        } catch (\Exception $exception) {
            $msg = "Не смогли создать индекс для популярных запросов в OpenSearch.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
