<?php

namespace App\Console\Commands;

use App\Facades\DatabaseConnectionFacade;
use App\Jobs\UpdateCertificateNotificationJob;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class UpdateCertificateNotification extends BaseCommand
{
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'sert:update-notification {--A|all=false} {--U|uid_org=} {--I|id_app=}';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Отравляет уведомления администраторам об истечении срока действия сертификатов';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 */
	public function handle()
	{
		if (!ConnectionDB::isLocalConnectDB()) {
			$this->info('Отравляет уведомления администраторам об истечении срока действия сертификатов у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

			if (!empty($this->guidOiks)) {
				foreach ($this->guidOiks as $guid) {
					$this->notify($guid);
				}
            } elseif (!empty($this->id_app)) {
                $guid = DatabaseConnectionFacade::getGuidMedo($this->id_app);
                $this->notify($guid);
            }
		} else {
			$this->info('Отравляет уведомления администраторам об истечении срока действия сертификатов у локального тр-архива');
			$this->notify();
		}
	}

	protected function notify(string $guidInstance = null)
	{
        try {
            UpdateCertificateNotificationJob::dispatch($guidInstance)->onQueue('update_cert_notification_job');
        } catch (\Exception $exception) {
            $msg = "Команда по отправки уведомлений администраторам об истечении срока действия сертификатов завершилась с ошибкой.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
	}
}
