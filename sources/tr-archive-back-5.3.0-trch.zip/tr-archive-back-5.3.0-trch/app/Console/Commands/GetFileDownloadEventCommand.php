<?php

namespace App\Console\Commands;

use App\Jobs\GetFileDownloadEvent;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class GetFileDownloadEventCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'file_download_event:get';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Получаем все записи из редиса о скаченных файлах';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        try {
            $redis = Redis::connection('event_download');
            $keys = $redis->keys('*');

            foreach ($keys as $key) {
                $value = json_decode($redis->get($key), true);

                $redis->del($key);

                if (! ConnectionDB::isLocalConnectDB()) {
                    $this->setConnection($value['uid']);
                }

                $value['is_success'] = $value['was_download'];
                $uidInstance = $value['uid'];
                unset($value['was_download']);
                unset($value['namespace']);
                unset($value['uid']);
                unset($value['path']);

                if (! empty($value['error_message'])) {
                    $value['new_values']['error_message'] = $value['error_message'];
                    unset($value['error_message']);
                }

                GetFileDownloadEvent::dispatch($key, $value, $uidInstance)->onQueue('file_download_event');
            }
        } catch (\Exception $exception) {
            $msg = "Не получилось зафиксировать событие по скачиванию файла.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
