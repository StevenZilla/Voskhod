<?php

namespace App\Console\Commands;

use App\Models\AcceptRegister\AcceptRegister;
use App\Models\DeleteAct\DeleteAct;
use App\Models\Di\DiClassifier;
use App\Models\Dossier\Dossier;
use App\Models\Ed\Ed;
use App\Models\HandBooks\Archive;
use App\Models\HandBooks\Fund;
use App\Models\Nomenclature\Nomenclature;
use App\Models\Register\Register;
use App\Models\Tk\Tk;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File as FileManager;
use Illuminate\Support\Facades\Log;

class EntitiesClear extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'entities:clear {--H|handbook=false} {--S|clear_storage=true} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Очистка основных сущностей бд. 1) номенклатура 2) дела 3) описи 4) еад 5) тк';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Очищаем основные сущности у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->entitiesClear();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->entitiesClear();
            }
        } else {
            $this->info('Очищаем основные сущности у локального тр-архива');

            $this->entitiesClear();
        }
    }

    protected function entitiesClear()
    {
        try {
            DB::transaction(function () {
                $tableTk = Tk::getTableName();
                DB::statement("TRUNCATE table {$tableTk} CASCADE;");

                $tableDiClassifier = DiClassifier::getTableName();
                DB::statement("TRUNCATE table {$tableDiClassifier} CASCADE;");

                $tableEd = Ed::getTableName();
                DB::statement("TRUNCATE table {$tableEd} CASCADE;");

                $tableAcceptRegister = AcceptRegister::getTableName();
                DB::statement("TRUNCATE table {$tableAcceptRegister} CASCADE;");

                $tableRegister = Register::getTableName();
                DB::statement("TRUNCATE table {$tableRegister} CASCADE;");

                $tableDossier = Dossier::getTableName();
                DB::statement("TRUNCATE table {$tableDossier} CASCADE;");

                $tableNomenclature = Nomenclature::getTableName();
                DB::statement("TRUNCATE table {$tableNomenclature} CASCADE;");

                $tableDeleteAct = DeleteAct::getTableName();
                DB::statement("TRUNCATE table {$tableDeleteAct} CASCADE;");

                if (mb_strtolower($this->option('handbook')) == 'true') {
                    Log::channel('command_single')->debug('Очищаем справочники');
                    $this->info('Очищаем справочники');

                    $tableFund = Fund::getTableName();
                    DB::statement("TRUNCATE table {$tableFund} CASCADE;");

                    $tableArchive = Archive::getTableName();
                    DB::statement("TRUNCATE table {$tableArchive} CASCADE;");
                }

                if (mb_strtolower($this->option('clear_storage')) == 'true') {
                    Log::channel('command_single')->debug('Очищаем файловое хранилище');
                    $this->info('Очищаем файловое хранилище');

                    $absolutePath = MediaStorage::getAdapter()->getPathPrefix();

                    if (FileManager::exists($absolutePath)) {
                        $directories = FileManager::directories($absolutePath);

                        if (!empty($directories) && count($directories) > 0) {
                            foreach ($directories as $directory) {
                                $nameDirectory = basename($directory);
                                if ($nameDirectory !== 'docs') {
                                    FileManager::deleteDirectory($directory);
                                }
                            }
                        }

                        $this->info("Обновили директорию {$absolutePath}");
                    }
                } elseif (mb_strtolower($this->option('clear_storage')) != 'false') {
                    $this->error('Не смогли обновить файловое хранилище. Флаг ожидает значение --S|clear_storage true');
                }

                $this->info('Успешно очистили основные сущности БД');
            });
        } catch (\Exception $e) {
            $msg = "Не смогли очистить систему от основных сущностей БД.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$e);

            $this->error($msg.PHP_EOL.$e->getMessage());
            $this->error($e->getMessage());
        }
    }
}
