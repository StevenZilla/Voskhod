<?php

namespace App\Console\Commands\Event;

use App\Console\Commands\BaseCommand;
use App\Jobs\AgreementEcJob;
use App\Jobs\Audit\SendMailAuditJob;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class AuditSendMail extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'event:send.mail {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Проверяем существование сообщений аудита и отправляем их в очередь.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Отправляем уведомление администраторам облачного архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->sendMailAudit($guid);
                    $this->info('Успешно отправили уведомление администраторам облачного архива с уидом - ' . $guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->sendMailAudit();

                $this->info('Успешно отправили уведомление администраторам облачного архива с идентификатором приложения - ' . $this->id_app);
            }
        } else {
            $this->info('Отправляем уведомление администраторам локального архива');

            $this->sendMailAudit();
            $this->info('Успешно отправили уведомление администраторам локального архива');
        }
    }

    public function sendMailAudit(string $guid = null)
    {
        try {
            if (empty($guid)) {
                $guid = DB::table('system_param')
                    ->where('code', 'guid_oik_in_medo')
                    ->pluck('value')->first();
            }

            $redis = Redis::connection('audit');
            $keys = $redis->keys("{$guid}_*");

            foreach ($keys as $key) {
                $value = json_decode($redis->get($key), true);
                $redis->del($key);
                SendMailAuditJob::dispatch($value['id'], $guid)->onQueue('send_mail_audit');
            }
        } catch (\Exception $exception) {
            $msg = "Произошла ошибка при проверке существования сообщений аудита и отправки их в очередь";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
