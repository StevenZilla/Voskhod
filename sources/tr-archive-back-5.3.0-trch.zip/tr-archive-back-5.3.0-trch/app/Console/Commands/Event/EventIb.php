<?php

namespace App\Console\Commands\Event;

use App\Models\Event\EventType;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class EventIb extends EventBaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'event_clear:ib {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Команда, которая очищает журнал событий по ИБ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Очищаем журнал событий для ИБ у облачного Тр-Архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    if ($this->setData()) {
                        $this->clearingEventJournal();
                        $this->info("Успешно очистили журнал событий для ИБ у облачного Тр-Архива для ОИКа {$guid}");
                    }
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->clearingEventJournal();
                $this->info("Успешно очистили журнал событий для ИБ у облачного Тр-Архива для ОИКа с идентификатором приложения {$this->id_app}");
            }
        } else {
            $this->info('Очищаем журнал событий для ИБ у локального Тр-Архива');

            if ($this->setData()) {
                $this->clearingEventJournal();
                $this->info('Успешно очистили журнал событий для ИБ у локального Тр-Архива');
            }
        }
    }

    protected function setData()
    {
        try {
            $this->types = EventType::whereIn('code', ['authorization'])->pluck('id')->all();
            $period_info = SystemParam::where('code', 'security_event_retention_period')->first();
            $this->date = Carbon::now()->addMonths(-$period_info->value);
            if ($period_info->value == 0) {
                return false;
            }

            return true;
        } catch (\Exception $exception) {
            $msg = "Не смогли получить тип событий для очистки аудита по ИБ";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
