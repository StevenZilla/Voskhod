<?php

namespace App\Console\Commands\Event;

use App\Console\Commands\BaseCommand;
use App\Models\Audit\Audit;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class EventBaseCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'event_clear:base';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Базовый класс для очищения журнала событий';

    /**
     * @var array
     */
    protected $types;

    /**
     * @var Carbon
     */
    protected $date;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Базовый класс для очищения журнала событий. Эта команда ничего не делает, а просто хранит общие методы.');
    }

    protected function clearingEventJournal()
    {
        try {
            Audit::whereIn('event_type_id', $this->types)->where('created_at', '<', $this->date->toDateTimeString())->delete();
        } catch (\Exception $exception) {
            $msg = "Не смогли очистить аудит";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
