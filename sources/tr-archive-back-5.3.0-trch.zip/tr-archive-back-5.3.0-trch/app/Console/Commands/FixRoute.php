<?php

namespace App\Console\Commands;

use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Routing\Route;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use App\Models\Permission\Permission;
use App\Models\Permission\RoutePermission;
use App\Services\MasterDB\Connection;

class FixRoute extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fix:route {--U|uid_org=} {--I|id_app=} {--A|all=false}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Синхронизация routes с ib_permission_route.route';

    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Исправляем маршруты облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->fixRoute($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->fixRoute($this->id_app);
            }
        } else {
            $this->info('Исправляем маршруты локального тр-архива');
            $this->fixRoute();
        }
    }

    private function fixRoute($guid = null)
    {
        try {
            if ($guid != null) {
                Log::channel('command_single')->info("Запуск команды синхронизации routes с ib_permission_route.route для {$guid}");
            } else {
                Log::channel('command_single')->info("Запуск команды синхронизации routes с ib_permission_route.route");
            }
            $app = app();
            $routes = $app->routes->getRoutes();
            $allPErmissions = [];
            foreach ($routes as $route) {
                $routePermission = $route->getAction('permissions');
                if (is_array($routePermission)) {
                    foreach ($routePermission as $permission) {
                        if (in_array($permission, array_keys($allPErmissions))) {
                            $allPErmissions[$permission] = '*';
                        } else {
                            $allPErmissions[$permission] = $route->uri;
                        }
                    }
                }
            }
            foreach ($allPErmissions as $name => $route) {
                if (RoutePermission::where('name', $name)->exists()) {
                    $count =  RoutePermission::where('name', $name)->update(['route' => $route]);
                } else {
                    $count =  RoutePermission::insert(['name' => $name, 'route' => $route]);
                }

                Log::channel('command_single')->info("Таблица ib_permission_route. Обновлены маршруты группы {$name}, установлено {$route}, затронуто {$count} записей");
            }
            $ibRoutes = RoutePermission::pluck('route', 'name');
            foreach ($ibRoutes as $name => $route) {
                $count = Permission::where('v2', $name)->update(['v1' => $route]);
                Log::channel('command_single')->info("Таблица ib_permission. Обновлены маршруты группы {$name}, установлено {$route}, затронуто {$count} записей");
            }
            if ($guid != null) {
                Log::channel('command_single')->info("Команда синхронизации routes с ib_permission_route.route завершилась для {$guid}");
            } else {
                Log::channel('command_single')->info("Команда синхронизации routes с ib_permission_route.route завершилась");
            }
        } catch (\Exception $exception) {
            $msg = "Команда по синхронизации роутов с правами доступа завершилась с ошибкой.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
