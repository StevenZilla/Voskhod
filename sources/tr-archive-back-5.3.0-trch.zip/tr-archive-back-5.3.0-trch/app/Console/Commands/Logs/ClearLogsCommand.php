<?php

namespace App\Console\Commands\Logs;

use App\Console\Commands\BaseCommand;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\MasterDB\Connection;

class ClearLogsCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'log:clear {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Удаление старых логов';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }


    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Очистка логов будет выполнятся у облачного архива.');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            $countDays = config('logging.count_days_until_logs_deleted');
            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->info("Для очистки логов будет выполняться для инстанции с uuid - {$guid}");
                    $this->clearLogs($guid, $countDays);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->clearLogs($this->id_app, $countDays);
                $this->info("Успешно очистили журнал событий для ИБ у облачного Тр-Архива для ОИКа с идентификатором приложения {$this->id_app}");
            }

            $this->info('Очистка логов успешно выполнилась у облачного архива.');
        } else {
            $this->info('Очистка логов будет выполнятся у локального архива.');

            $countDays = config('logging.count_days_until_logs_deleted');
            $guid = SystemParam::where('code', 'guid_oik_in_medo')->pluck('value')->first();
            $this->clearLogs($guid, $countDays);

            $this->info('Очистка логов успешно выполнилась у локального архива.');
        }
    }

    private function clearLogs(string $uuidInstance, int $countDays)
    {
        $files = MediaStorage::disk('storage')->files('logs');
        foreach ($files as $file) {
//            if (!str_contains('.gitignore', $file)) {
//
//            }
        }
    }
}
