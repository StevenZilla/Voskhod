<?php

namespace App\Console\Commands\CustomMigration;

use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use mysql_xdevapi\Exception;

class CustomMigration extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration {--S|seed} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Накатывает миграции для облачного тр-архива';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Применяем миграции к облачному тр-архиву');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            $result = true;
            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    if ($this->option('all') === 'true') {
                        $this->setMessageGuid($guid);
                    }

                    Log::channel('command_single')->debug("Накатываем миграции {$this->messageGuid}");

                    $this->info("Накатываем миграции {$this->messageGuid}");

                    $this->setConnection($guid);
                    if(!$this->migration()) {
                        $result = false;
                    }
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $result = $this->migration();
            } else {
                $this->info('Не можем накатить миграции, потому что не переданы флаги {--A|all=false} {--U|uid_org=}');
                $result = false;
            }
            // в случае неудачи, требуется возвращать ненулевой код для перехвата Менеджером Архива
            if (!$result){
                return 1;
            }
        } else {
            $this->info('Обновляем миграции к локальному тр-архиву');
            if (!$this->migration()){
                return 1;
            }
        }
    }

    protected function migration()
    {
        try {
            DB::beginTransaction();

            $this->call('migrate');
            $this->info("Миграции успешно применены {$this->messageGuid}");

            if ($this->hasOption('seed') && $this->option('seed') != null) {
                $this->call('db:seed');
                $this->info("Фикстуры успешно добавлены {$this->messageGuid}");
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            $msg = "Произошла ошибка при накатывании миграций {$this->messageGuid}. {$e->getMessage()}. Миграции откатили.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$e);

            $this->error($msg.PHP_EOL.$e->getMessage());{
                return false;
            }
        }
        return true;
    }

    protected function dropMigration($db, string $connection)
    {
        DB::connection($connection)->beginTransaction();
        $db->connection($connection)
            ->getSchemaBuilder()
            ->dropAllTables();
        $this->info("База данных с соединением[{$connection}] очищена {$this->messageGuid}");
        DB::connection($connection)->commit();
    }
}
