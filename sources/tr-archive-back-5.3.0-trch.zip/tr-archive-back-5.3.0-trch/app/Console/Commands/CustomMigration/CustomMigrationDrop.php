<?php

namespace App\Console\Commands\CustomMigration;

use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CustomMigrationDrop extends CustomMigration
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:drop {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Полностью очищает базу данных';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Очищаем миграции у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    if ($this->option('all') === 'true') {
                        $this->setMessageGuid($guid);
                    }

                    Log::channel('command_single')->debug("Очищаем миграции {$this->messageGuid}");

                    $this->info("Накатываем миграции {$this->messageGuid}");

                    $this->setConnection($guid);
                    $this->migration();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->migration();
            } else {
                $this->info('Не можем очистить миграции, потому что не переданы флаги {--A|all=false} {--U|uid_org=}');
            }
        } else {
            $this->info('Очищаем миграции к локальному тр-архиву');

            $this->migration();
        }
    }

    protected function migration()
    {
        try {
            $db = $this->laravel['db'];
            $this->dropMigration($db, 'pgsql');

            $this->info("База данных очищена {$this->messageGuid}");
        } catch (\Exception $e) {
            DB::rollBack();

            $msg = "Произошла ошибка при очищении миграций {$this->messageGuid}. Миграции откатили.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$e);

            $this->error($msg.PHP_EOL.$e->getMessage());
        }
    }
}
