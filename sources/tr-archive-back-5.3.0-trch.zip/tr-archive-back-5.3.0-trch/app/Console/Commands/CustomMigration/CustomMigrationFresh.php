<?php

namespace App\Console\Commands\CustomMigration;

use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CustomMigrationFresh extends CustomMigration
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:fresh {--seed} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Полностью обновляет базу данных';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Обновляем миграции к облачному тр-архиву');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    Log::channel('command_single')->debug("Накатываем миграции {$this->messageGuid}");
                    $this->info("Накатываем миграции {$this->messageGuid}");

                    $this->setConnection($guid);
                    $this->migration();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->migration();
            } else {
                $this->info('Не можем обновляем миграции, потому что не переданы флаги {--A|all=false} {--U|uid_org=}');
            }
        } else {
            $this->info('Обновляем миграции к локальному тр-архиву');

            $this->migration();
        }
    }

    protected function migration()
    {
        try {
            $db = $this->laravel['db'];
            $this->dropMigration($db, 'pgsql');

            DB::beginTransaction();

            $this->call('migrate');
            $this->info("Миграции успешно применены {$this->messageGuid}");

            if ($this->hasOption('seed') && $this->option('seed') != null) {
                $this->call('db:seed');
                $this->info("Фикстуры успешно добавлены {$this->messageGuid}");
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            $msg = "Произошла ошибка при накатывании миграций {$this->messageGuid}. Миграции откатили.}";
            Log::channel('command_single')->critical($msg.PHP_EOL.$e);

            $this->error($msg.PHP_EOL.$e->getMessage());
        }
    }
}
