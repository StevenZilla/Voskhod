<?php

namespace App\Console\Commands;

use App\Services\Mail\CurlMail;
use Illuminate\Console\Command;
use App\Models\System\SystemParam;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use App\Facades\SendMailServiceFacade;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Support\Carbon;

class TestSendEmailCommand extends BaseCommand
{
    protected $login;
    protected $password;
    protected $fromEmail;
    protected $host;
    protected $port;
    protected $customParameters;

    protected $isHeader;
    protected $pathTmpDir;

    public function __construct()
    {
        parent::__construct();
    }
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:email {--e|email=} {--U|uid_org=} {--I|id_app=}';

    protected $description = 'Отправка письма для проверки работы SMTP сервера';



    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Тестирование отправки email облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Тестирование отправки email инстанции: [$guid]");
                    $this->setConnection($guid);
                    $this->sendEmail($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->sendEmail();
            } else {
                $this->info('Ошибка. Тестирование отправки email отменено. Организации не обнаружены');
            }
        } else {
            $this->info('Тестирование отправки email локального тр-архива');
            $this->sendEmail();
        }
    }

    public function sendEmail($guid = null)
    {
        $params = SystemParam::whereIn('code',['name_oik','guid_oik_in_medo','identificator_app'])->pluck('value','code')->toArray();
        $msg = "";
        $msg .= Carbon::now()->format("Y-m-d h:i:s")."\r\n";
        $msg .= "GUID ОИК в МЭДО:".$params['guid_oik_in_medo']."\r\n";
        $msg .= "Идентификатор приложения:".$params['identificator_app']."\r\n";
        SendMailServiceFacade::mail($this->option('email'), 'Тест отправки email', $msg,'emails.test_send_email',$guid)->send();
    }
}
