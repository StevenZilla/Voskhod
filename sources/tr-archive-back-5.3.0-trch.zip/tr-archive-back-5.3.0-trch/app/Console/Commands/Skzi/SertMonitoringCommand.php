<?php
namespace App\Console\Commands\Skzi;



use App\Jobs\Skzi\SertMonitoringJob;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Foundation\Bus\DispatchesJobs;

class SertMonitoringCommand extends BaseCommand
{
    use DispatchesJobs;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sert:monitoring {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Мониторинг состояния сертификатов';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Мониторинг сертификатов облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Мониторинг сертификатов инстанции: [$guid]");
                    $this->setConnection($guid);
                    $this->monitoringSert($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->monitoringSert();
            } else {
                $this->info('Ошибка. Мониторинг сертификатов отменен. Организации не обнаружены');
            }
        } else {
            $this->info('Мониторинг сертификатов локального тр-архива');
            $this->monitoringSert();
        }
    }

    public function monitoringSert($guid= null)
    {
        $job = new SertMonitoringJob($guid);
        $job->onQueue('sert_monitoring_job');
        $this->dispatchSync($job);
    }
}
