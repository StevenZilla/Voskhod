<?php
namespace App\Console\Commands\Skzi;

use App\Jobs\Skzi\SertSyncJob;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Foundation\Bus\DispatchesJobs;

class SertSyncCommand extends BaseCommand
{

    use DispatchesJobs;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sert:sync {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Синхронизация и актуализация сертификатов с СКЗИ';

    private $currentGuid;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Синхронизируем сертификаты облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Синхронизируем сертификаты инстанции: [$guid]");
                    $this->setConnection($guid);
                    $this->syncSert($guid,null);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->syncSert(null, $this->id_app);
            } else {
                $this->info('Ошибка. Синхронизация сертификатов отменена. Организации не обнаружены');
            }
        } else {
            $this->info('Синхронизируем сертификаты локального тр-архива');
            $this->syncSert();
        }
    }


    public function syncSert($guid = null, $idApp = null)
    {
        $job = new SertSyncJob($guid, $idApp);
        $job->onQueue('insert_sert_job');
        $this->dispatch($job);
    }
}
