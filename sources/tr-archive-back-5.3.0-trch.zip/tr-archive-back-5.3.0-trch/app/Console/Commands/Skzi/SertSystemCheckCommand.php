<?php
namespace App\Console\Commands\Skzi;

use App\Console\Commands\BaseCommand;
use App\Jobs\Skzi\SertSystemCheckJob;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Foundation\Bus\DispatchesJobs;

class SertSystemCheckCommand extends BaseCommand
{
    use DispatchesJobs;
    private $notificationService;

    protected $signature = 'sert:system_check {--A|all=false} {--U|uid_org=}';

    private $users;
    private $systemSert;
    private $systemSertModel;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'проверка сертификатов';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    // public function handle()
    // {
    //     if (Connection::checkConnectionDB()) {
    //         $this->info('Проверяем сертификаты облачного тр-архива');
    //         $this->getGuidOik();
    //         if (!empty($this->guidOiks)) {
    //             foreach ($this->guidOiks as $guid) {
    //                 $this->info("Выполняем проверку сертификатов [$guid]");
    //                 $this->setConnection($guid);
    //                 $this->sertCheck();
    //             }
    //         } else {
    //             $this->info('Не можем выполнить проверку сертификатов. Организации не обнаружены');
    //         }
    //     } else {
    //         $this->info('Проверяем сертификаты локального тр-архива');
    //         $this->sertCheck();
    //     }
    // }

    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Мониторинг системной подписи облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Мониторинг системной подписи инстанции: [$guid]");
                    $this->setConnection($guid);
                    $this->sertCheck($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->sertCheck();
            } else {
                $this->info('Ошибка. Мониторинг системной подписи отменен. Организации не обнаружены');
            }
        } else {
            $this->info('Мониторинг системной подписи локального тр-архива');
            $this->sertCheck();
        }
    }




    public function sertCheck()
    {
        $job = new SertSystemCheckJob();
        $job->onQueue('insert_sert_job');
        $this->dispatch($job);
        // try {
        //     $this->checkSystemSert();
            
        // } catch (Exception $e) {
        //     Log::channel('skzi_log')->error("Ошибка проверки сертификатов. " . $e);
        // }
    }

    // public function checkSystemSert()
    // {
    //     $this->systemSert = SystemParam::where('code', 'system_signature')->pluck('value')->first();
    //     $this->systemSertModel = Sert::where('thumbprint', $this->systemSert)->first();

    // }

    // public function checkActiveSert()
    // {
    //     if (!empty($this->systemSertModel) && $this->systemSertModel->is_active == false) {
    //         $activeSKZI =  SystemParam::where('code', "type_skzi")->pluck('value')->first();
    //         $this->getAdminUser();
    //         if ($this->systemSertModel->skzi_id !=  $activeSKZI) {
    //             $usedSKZI = Skzi::where('id', $this->systemSertModel->skzi_id)->pluck('name')->first();
    //             $msg = "Ошибка! Системная подпись не активна т.к. принадлежит СКЗИ {$usedSKZI}. Активная СКЗИ в системных парамерах {$activeSKZI}";
    //             Log::channel('skzi_log')->error($msg);
    //             foreach ($this->users as $user) {
    //                 $this->notificationService = new NotificationService(null, 'sert', null, "", $user);
    //                 $this->notificationService->prepareMessage(MessagesService::messageSystemSignatureIsNotActiveSKZI());
    //                 $this->notificationService->insertRedis();
    //             }
    //             SendMailServiceFacade::mail($this->users, 'ТР Архив ошибка системной подписи', $msg)->send();
    //         } else {
    //             $msg = "Ошибка! Системная подпись не активна";
    //             Log::channel('skzi_log')->error($msg);
    //             foreach ($this->users as $user) {
    //                 $this->notificationService = new NotificationService(null, 'sert', null, "", $user);
    //                 $this->notificationService->prepareMessage(MessagesService::messageSystemSignatureIsNotActive());
    //                 $this->notificationService->insertRedis();
    //             }
    //             SendMailServiceFacade::mail($this->users, 'ТР Архив ошибка системной подписи', $msg)->send();
                
    //         }
    //     }
    // }

    // public function checkSetSystemSert()
    // {
    //     if (empty($this->systemSertModel)) {
    //         $msg = "Ошибка! Системная подпись не задана в настройках системы";
    //         Log::channel('skzi_log')->error($msg); //
    //         $this->getAdminUser();
    //         foreach ($this->users as $user) {
    //             $this->notificationService = new NotificationService(null, 'sert', null, "", $user);
    //             $this->notificationService->prepareMessage(MessagesService::messageSystemSignatureNotSet());
    //             $this->notificationService->insertRedis();
    //         }
    //         SendMailServiceFacade::mail($this->users, 'ТР Архив ошибка системной подписи', $msg)->send();
    //     }
    // }

    // public function checkPeriodSert()
    // {
    //     if (!empty($this->systemSertModel) && !($this->systemSertModel->start_date <= Carbon::now() && $this->systemSertModel->end_date >= Carbon::now())) {
    //         $msg = "Ошибка! Срок действия системной подписи истёк";
    //         Log::channel('skzi_log')->error($msg);
    //         $this->getAdminUser();
    //         foreach ($this->users as $user) {
    //             $this->notificationService = new NotificationService(null, 'sert', null, "", $user);
    //             $this->notificationService->prepareMessage(MessagesService::messageSystemSignatureExpired());
    //             $this->notificationService->insertRedis();
    //         }
    //         SendMailServiceFacade::mail($this->users, 'ТР Архив ошибка системной подписи', $msg)->send();
    //     }
    // }

    // private function getAdminUser()
    // {
    //     if (empty($this->users)) {
    //         $this->users = User::leftJoin('user_role', 'user_role.user_id', '=', 'user.id')
    //             ->leftJoin('system_role', 'system_role.id', '=', 'user_role.system_role_id')
    //             ->where('system_role.code', 'administrator')->orWhere('user.is_superuser', true)->get();
    //     }
    // }
}
