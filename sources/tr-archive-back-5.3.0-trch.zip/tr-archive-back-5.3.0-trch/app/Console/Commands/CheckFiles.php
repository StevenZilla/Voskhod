<?php

namespace App\Console\Commands;

use App\Facades\SendMailServiceFacade;
use App\Jobs\SendMail;
use App\Models\Ed\Ed;
use App\Models\System\SystemParam;
use App\Models\System\SystemRole;
use App\Models\User\User;
use App\Models\User\UserRole;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\FilesystemManager\MediaStorage;
use App\Services\Mail\SendMailService;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class CheckFiles extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:files {--A|all=false} {--U|uid_org=} {--I|id_app=}';
    protected $currentOikGuid;
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Проверка файлов ЭД на существование';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->currentOikGuid = $guid;
                    $this->notify();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->notify();
            }
        } else {
            $this->notify();
        }
    }

    private function notify()
    {

        try {
            $missingFiles = [];
            $code = SystemParam::where('code', '=', 'guid_oik_in_medo')->first()->value;
            $chunkCount = config('app.chunk_count_file_ed');

            Ed::chunk($chunkCount, function ($eds) use ($code, &$missingFiles) {
                foreach ($eds as $ed) {
                    $files = $ed->file()->get();
                    foreach ($files as $file) {
                        if (!MediaStorage::isFile($file->path))
                            $missingFiles[] = count($missingFiles) + 1 . ". Регистрационный номер: {$ed->num} ({$ed->reg_date}) | Путь файла: {$file->path} | UID ОИК в МЭДО: {$code}";
                    }
                }
            });

            if (count($missingFiles) == 0) {
                $this->info('Отсутствующих файлов нет.');
                return;
            }

            $today = Carbon::today()->format('d.m.Y');

            $adminRoleId = SystemRole::where('code', '=', 'administrator')->first()->id;
            $adminsId = UserRole::where('system_role_id', '=', $adminRoleId)->pluck('user_id')->toArray();
            $users = User::whereIn('id', $adminsId)->get();
            SendMailServiceFacade::mail(
                $users,
                "Отчет по отсутствующим файлам ЭД. $today",
                ['missingFiles' => $missingFiles],
                'emails.missingFiles',
                $this->currentOikGuid
            )->send();
            $this->info('Отчет был отправлен администраторам.');
        } catch (\Exception $e) {
            $msg = 'Не смогли проверить файлы на существование.';

            Log::channel('command_single')->critical($msg.PHP_EOL.$e);
            if (!empty($missingFiles)) {
                Log::channel('command_single')->critical(implode(PHP_EOL, $missingFiles));
            }

            $this->error($msg.PHP_EOL.$e->getMessage());
        }
    }
}
