<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\System\SystemParam;
use App\Services\FileWatch\Medo\MedoWatchService;
use App\Services\MasterDB\Connection;
use App\Services\FileWatch\Watch;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Carbon;

class FileWatchCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'medo:watch';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Наблюдение за каталогом куда копируются входящие ТК';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }


    public function handle()
    {
        $date = Carbon::now()->format('Y-m-d H:i:s');
        echo "Служба fileWatch запущена. Время запуска {$date}\n";
        $directory = config('filesystems.medo_in');
        echo "Наблюдаю за: {$directory}\n";
        $excludes = config('filesystems.excludes');
        echo "Исключения:\n";
        echo (implode(',', $excludes) . "\n");

        Log::channel('medo_watch_single')->info("Наблюдаю за: " . $directory . "\n");
        $templates = json_decode(config("file_watch.templates"));
        $templates = array_map(function ($template) {
            sort($template);
            return $template;
        }, $templates);

        $mergedTemplates = [];
        foreach ($templates as $template) {
            $mergedTemplates = array_merge($mergedTemplates, $template);
        }
        $mergedTemplates = array_unique($mergedTemplates);

        /***
         * Watcher::EVENT_TYPE_FILE_CREATED: файл создан
         * Watcher::EVENT_TYPE_FILE_UPDATED: файл был обновлен
         * Watcher::EVENT_TYPE_FILE_DELETED: файл был удален
         * Watcher::EVENT_TYPE_DIRECTORY_CREATED: каталог создан
         * Watcher::EVENT_TYPE_DIRECTORY_DELETED: каталог был удален
         */
        $watcher = new Watch;
        $watcher->setPaths($directory);
        $watcher->setExcludes($excludes);
        $watcher->onAnyChange(
            function (string $type, string $path) use ($watcher, $templates, $mergedTemplates) {
                $medoWatchService = new MedoWatchService($watcher->getPath(), $path, $templates, $mergedTemplates);
                switch ($type) {
                    case Watch::EVENT_TYPE_DIRECTORY_CREATED:
                        echo "EVENT_TYPE_DIRECTORY_CREATED {$path}\n\n";
                        $medoWatchService->directoryCreated();
                        break;
                    case Watch::EVENT_TYPE_DIRECTORY_DELETED:
                        echo "EVENT_TYPE_DIRECTORY_DELETED {$path}\n\n";
                        $medoWatchService->directoryDeleted();
                        break;
                    case Watch::EVENT_TYPE_FILE_CREATED:
                        echo "EVENT_TYPE_FILE_CREATED {$path}\n\n";
                        $medoWatchService->fileCreated();
                        break;
                    case Watch::EVENT_TYPE_FILE_UPDATED:
                        echo "EVENT_TYPE_FILE_UPDATED {$path}\n\n";
                        break;
                    case Watch::EVENT_TYPE_FILE_DELETED:
                        echo "EVENT_TYPE_FILE_DELETED {$path}\n\n";
                        break;
                    case Watch::EVENT_TYPE_FILE_COPY_STARTED:
                        echo "EVENT_TYPE_FILE_COPY_STARTED {$path}\n\n";
                        $medoWatchService->fileCopyStarted();
                        break;
                    case Watch::EVENT_TYPE_FILE_COPY_COMPLETE:
                        echo "EVENT_TYPE_FILE_COPY_COMPLETE {$path}\n\n";
                        $medoWatchService->fileCopyCompleted();
                        $medoWatchService->compareTemplate();
                        break;
                    case Watch::EVENT_TYPE_FILE_ERROR:
                        Log::channel('medo_watch_single')->error("Ошибка обработки файла {$path} \n");
                        break;
                }
            }
        )->start();
    }
}
