<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Services\ConnectionDB\ConnectionDB;

class ChangeEditFlagSystemParamCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'system_param_edit:change {--E|is_edit=false} {--U|uid_org=} {--I|id_app=} {--A|all=false}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->changeSystemParam();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->changeSystemParam();
            }
        } else {
            $this->changeSystemParam();
        }
    }

    public function changeSystemParam()
    {
        $systemCategoryId = DB::table('system_category')
            ->where('code', 'support')
            ->orWhere('code', 'mail_server')
            ->pluck('id');
        DB::table('system_param')
            ->whereIn('category_id', $systemCategoryId)
            ->update(['is_edit' => $this->option('is_edit')]);
    }
}
