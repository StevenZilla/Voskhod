<?php

namespace App\Console\Commands\RenewalsAk;

use App\Console\Commands\BaseCommand;
use App\Jobs\RenewalsAkJob;
use App\Models\Sert\Sert;
use App\Models\System\SystemParam;
use App\Models\Tk\CheckRenewalsAk;
use App\Models\Tk\Tk;
use App\Models\Tk\TkStatus;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use App\Services\ModuleSKZI\ModuleSKZI;
use App\Services\RenewalsAk\CheckAkonRenewals;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class RenewalsAkCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'parse:ak.renewals {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Обработка архивных контейнеров на продление подписи, и отправка их в очередь';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Выполняем продление юр.зн у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->renewalsAk();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->renewalsAk();
            }
        } else {
            $this->info('Выполняем продление юр.зн у локального тр-архива');

            $this->renewalsAk();
        }
    }

    protected function renewalsAk(string $guid = null)
    {
        try {
            $msg = "Запускается скрипт обработки архивных контейнеров на продление юридической значимости {$this->messageGuid}";
            Log::channel('command_single')->debug($msg);

            $nowDate = Carbon::now();
            $countDaysOnExpirationSignAk = SystemParam::where('name', 'Количество дней до истечения срока действия сертификата подписи АК')
                ->pluck('value')->first();

            try {
                $countDateEndSign = Carbon::now()->parse()->addDays($countDaysOnExpirationSignAk);
            } catch (\Exception $e) {
                Log::channel('command_single')->error('Неправильное значение в системных параметров у поля, где name = "Количество дней до истечения срока действия сертификата подписи АК"');
            }

            $idStatusAk = TkStatus::where('code', 'transferred_temporary_storage')->pluck('id')->first();
            $allAk = Tk::where('tk_status_id', $idStatusAk)->whereDate('sign_end_date', '<=', $countDateEndSign->format('Y-m-d H:i:s'))->get();
            $thumb = SystemParam::where('code', 'system_signature')->pluck('value')->first();
            if (! empty($thumb)) {
                $thumbprint = Sert::where('thumbprint', $thumb)->first();
            }

            if (empty($thumb) || empty($thumbprint)) {
                Log::channel('command_single')->error("Системная подпись в системных параметрах отсутствует {$this->messageGuid}");

                throw new \Exception('Системная подпись в системных параметрах отсутствует');
            }

            $skzi = new ModuleSKZI();
            if (empty($skzi->showSignByModelSert($thumbprint))) {
                Log::channel('command_single')->error('Отпечаток в системе отсутствует. Укажите другой сертификат '.$this->messageGuid);

                throw new \Exception('Отпечаток в системе отсутствует. Укажите другой сертификат');
            }

            $sertEndDate = Carbon::parse($thumbprint->end_date);
            $diffNowEndSign = $nowDate->diffInDays($sertEndDate, false);

            if ($diffNowEndSign < 0) {
                Log::channel('command_single')->error('Системная подпись не действительна. Необходимо выбрать другой сертификат для продления юр.значимости '.$this->messageGuid);

                throw new \Exception('Сертификат в системе не действительный. Обновите сертификат');
            } elseif ($diffNowEndSign == 0) {
                $diffMinuteNowEndSign = $nowDate->diffInMinutes($sertEndDate, false);
                if ($diffMinuteNowEndSign <= 0) {
                    Log::channel('command_single')->error('Системная подпись не действительна. Необходимо выбрать другой сертификат для продления юр.значимости '.$this->messageGuid);

                    throw new \Exception('Сертификат в системе не действительный. Обновите сертификат');
                }
            }

            $msg = 'Началась проверка всех АК для продления юридической значимости '.$this->messageGuid;
            Log::channel('command_single')->notice($msg);

            $checkAk = new CheckAkonRenewals($allAk);
            $resultAk = $checkAk->checkAk(); //Получили АК, которым нужно продлить ЮЗ

            $countAk = count($resultAk);
            if (! empty($resultAk) && $countAk > 0) {
                Log::channel('command_single')->notice('Получили все АК, которым необходима процедура продления юридической значимости '.$this->messageGuid);

                $checkRenewalsAkModel = new CheckRenewalsAk();
                $checkRenewalsAkModel->date = Carbon::now()->toDateTimeString();
                $checkRenewalsAkModel->count_ak = $countAk;
                $checkRenewalsAkModel->save();

                foreach ($resultAk as $ak) {
                    RenewalsAkJob::dispatch($ak, $thumbprint, $checkRenewalsAkModel->id, $guid)->onQueue('renewals_ak_job');
                }
            }
        } catch (\Exception $exception) {
            $message = 'Не смогли выполнить проверку юр.значимости.';
            if (!empty($guid)) {
                $message .= " Пропускаем инстанцию с UUID {$guid}.";
            }

            $this->error($message.PHP_EOL.$exception->getMessage());
            Log::channel('command_single')->error("{$message}.\n{$exception}");
        }
    }
}
