<?php

namespace App\Console\Commands\RenewalsAk;

use App\Jobs\MassSendMail;
use App\Services\ConnectionDB\ConnectionDB;
use Carbon\Carbon;
use App\Jobs\SendMail;
use App\Models\User\User;
use App\Models\System\SystemParam;
use App\Models\Tk\CheckRenewalsAk;
use Illuminate\Support\Facades\Log;
use App\Console\Commands\BaseCommand;
use App\Services\MasterDB\Connection;
use App\Facades\SendMailServiceFacade;
use App\Services\System\SetLaunchStart;

class SendReportRenewalsAkCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'report:renewals {--A|all=false} {--U|uid_org=} {--I|id_app=}';
    protected $currentOikGuid;
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Отправляем отчет продления юр.значимости';

    private const chunk_size = 10;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Отправляем отчет о продлении юр.значимости у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->currentOikGuid = $guid;
                    $this->sendReport();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->sendReport();
            }
        } else {
            $this->info('Отправляем отчет о продлении юр.значимости у локального тр-архива');

            $this->sendReport();
        }
    }

    protected function sendReport()
    {
        try {
            $startLaunch = SystemParam::where('code', 'period_check_renewals_ak')->first();
            $now = Carbon::now()->format('Y-m-d H:i:s');

            if ($now >= $startLaunch->launch_start) {
                Log::channel('command_single')->debug("Будет отправлять отчет о продлении юр.значимости. Сейчас - {$now}, отправка отчета - {$startLaunch}");

                $renewalsAk = CheckRenewalsAk::where('is_send', false)->orderBy('date', 'desc')->first();
                if (!empty($renewalsAk)) {
                    if ($renewalsAk->is_use) {
                        Log::channel('command_single')->debug("Все транспортные контейнеры прошли проверку, будет отправлять отчет с идентификатором - {$renewalsAk->id}");
                    } else {
                        $message = "Не все транспортные контейнеры прошли проверку у отчета с идентификатором - {$renewalsAk->id}";
                        $renewalsAk = CheckRenewalsAk::where('is_send', '=', false)
                            ->where('id', '!=', $renewalsAk->id)
                            ->whereRaw('count_ak = (select (query.count_ak_completed::bigint + query.count_ak_error::bigint) as custom_sum from check_renewals_ak as query where query.id = check_renewals_ak.id)')
                            ->orderBy('date', 'desc')->first();

                        if (!empty($renewalsAk)) {
                            $message .= ". Отправляем отчет с идентификатором - {$renewalsAk->id}";
                            Log::channel('command_single')->debug($message);
                        }
                    }

                    if (!empty($renewalsAk)) {
                        $users = User::leftJoin('user_role', 'user_role.user_id', '=', 'user.id')
                            ->leftJoin('system_role', 'system_role.id', '=', 'user_role.system_role_id')
                            ->where('system_role.code', 'administrator')->get();

                        $nameOik = SystemParam::where('code', 'name_oik')->pluck('value')->first();

                        SendMailServiceFacade::mail($users, $nameOik . ': Контейнеры с ошибками при продлении юр.значимости', $renewalsAk->toArray(), 'emails.report_renewals',$this->currentOikGuid)->send();

                        CheckRenewalsAk::where('date', '<=', $renewalsAk->date)->where('is_send', false)->update(['is_send' => true]);
                        SetLaunchStart::setLaunchStart($startLaunch, $startLaunch->value)->save();
                    }
                }
            } else {
                Log::channel('command_single')->debug("Время отправки отчета о продлении юр.значимости еще не пришло. Сейчас - {$now}, отправка отчета - {$startLaunch}");
            }
        } catch (\Exception $exception) {
            $message = 'Не смогли отправить отчет по проверке юр.значимости.';

            $this->error($message.PHP_EOL.$exception->getMessage());
            Log::channel('command_single')->error("{$message}.\n{$exception}");
        }
    }
}
