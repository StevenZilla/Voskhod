<?php

namespace App\Console\Commands\InputContainers;

use App\Console\Commands\BaseCommand;
use App\Services\InputContainers\InputContainersFilesService;
use Illuminate\Support\Facades\Log;

class InputContainersParser extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'parse:containers';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Обработка входящих контейнеров, и отправка их в очередь';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $msg = 'Запускается скрипт парсинга директории входящих контейнеров МЭДО';
        Log::channel('command_single')->debug($msg);

        $handler = new InputContainersFilesService();
        $handler->parse();

        $msg = 'Все контейнеры отправлены в очередь';
        Log::channel('command_single')->debug($msg);
    }
}
