<?php

namespace App\Console\Commands;

use App\Facades\DatabaseConnectionFacade;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class BaseCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'base:command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Общий класс для всех команд artisan.';

    /**
     * Список инстанций, к которым должны накатить миграций.
     *
     * @var array
     */
    protected $guidOiks = [];

    /**
     * Сообщение с гуидом организации.
     *
     * @var string
     */
    protected $messageGuid = '';

    /**
     * Гуид организации.
     *
     * @var string
     */
    protected $guid = '';

    /** @var string UUID */
    protected $id_app;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->error('Данная команда artisan ничего не выполняет.');
    }

    /**
     * Получаем соединение с помощью оика.
     * @param string $guid
     * @return void
     */
    protected function setConnection(string $guid)
    {
        DatabaseConnectionFacade::setDataConnection($guid);

        Config::set('database.default', 'pgsql');
    }

    /**
     * Получаем соединение с помощью оика.
     * @param string $guid
     * @return void
     */
    protected function setConnectionWithIdApp()
    {
        DatabaseConnectionFacade::setDataConnectionWithIdApp($this->id_app);
        Config::set('database.default', 'pgsql');
    }

    /**
     * Для записи логов с конкретным оиком
     * @param string|null $guid
     * @return void
     */
    protected function setMessageGuid(string $guid = null)
    {
        if ($guid) {
            $this->messageGuid = " для оика - {$guid}";
            $this->guid = $guid;
        }
    }

    /**
     * Получаем все инстанции для которых будет выполнять команду.
     * @return void
     */
    protected function getGuidOik()
    {
        if ($this->option('all') === 'true') {
            $this->getAllGuidOik();
        } elseif ($this->hasOption('uid_org') && $this->option('uid_org') != null) {
            $this->guidOiks[] = $this->option('uid_org');
            $this->setMessageGuid($this->option('uid_org'));
            Log::channel('command_single')->info("Получили только одну инстанцию - {$this->guid}. Будем выполнять команду artisan для одной инстанциям");
            $this->info("Получили только одну инстанцию - {$this->guid}. Будем выполнять команду artisan для одной инстанциям");
        } else {
            $this->getAllGuidOik();
        }
    }

    /**
     * Получаем все инстанции для которых будет выполнять команду.
     * @return void
     */
    protected function getIdApp()
    {
        $this->id_app = $this->option('id_app');
    }

    protected function getAllGuidOik()
    {
        $this->guidOiks = DatabaseConnectionFacade::getAllGuidMedo();
        Log::channel('command_single')->info('Получили все инстанции. Будем выполнять команду artisan всем инстанциям');
        $this->info('Получили все инстанции. Будем выполнять команду artisan всем инстанциям');
    }
}
