<?php

namespace App\Console\Commands;

use App\Services\InputContainers\ValidateXmlMedoContainer;
use App\Services\RedisStream\RedisStream;
use App\Services\RedisStream\RedisStreamClient;
use Asiries335\redisSteamPhp\Data\Message;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Carbon;

class FileWatchStreamCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'medo:stream {group?} {consumer?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Отслеживаются сообщения при парсинге контейнеров из medo';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            $date = Carbon::now()->format('Y-m-d H:i:s');
            echo "Служба fileWatchStream запущена. Время запуска {$date}\n";
            $stream = config('database.redis.medo_watch.stream');
            $client = new RedisStreamClient(new RedisStream());
            while (true) {
                $infoData = $client->stream($stream)->info();

                if (is_array($infoData)) {
                    $this->info("Существует поток {$stream}");
                    break;
                }

                $this->warn("Поток {$stream} не существует");
                sleep(10);
            }

            $client->stream($stream)->listen(
                function (Message $message) use ($client, $stream) {
                    $data = json_decode($message->getBody(), true);
                    $msg = json_encode($data);
                    echo "Начинаем обрабатывать контейнер. Данные контейнера - {$msg}\n";
                    Log::channel('medo_stream_single')->debug("Начинаем обрабатывать контейнер. Путь, где хранится контейнер - {$data['path']}");

                    echo "Начинаем обрабатывать контейнер. Путь, где хранится контейнер - {$data['path']}\n";

                    if ($data['status'] !== 2) {
                        $client->stream($stream)->add($message->getKey(), $data);
                        Log::channel('medo_stream_single')
                            ->debug("Контейнер еще не готов {$data['path']}. Отправляем в его конец очереди");
                    } else {
                        if (array_key_exists('antivirus.json', $data['files'])) {
                            Log::channel('medo_stream_single')
                                ->debug("В контейнере {$data['path']} были вирусы.");
                            $dataContainer = true;
                        } else {
                            Log::channel('medo_stream_single')
                                ->debug("Начинаем парсить xml в контейнере {$data['path']}.");

                            $xmlMedo = new ValidateXmlMedoContainer($data['path']);
                            $dataContainer = $xmlMedo->parseXml();
                        }

                        if (!empty($dataContainer)) {
                            Log::channel('medo_stream_single')
                                ->debug("Успешно пропарсили xml в контейнере {$data['path']}.");
                            $redis = Redis::connection('medo_watch');
                            $streamList = config('database.redis.medo_watch.stream_list');

                            if (array_key_exists('antivirus.json', $data['files'])) {
                                Log::channel('medo_stream_single')
                                    ->debug("Контейнер {$data['path']} с вирусами перемещаем в начало списка.");

                                $redis->lpush($streamList, json_encode($data, JSON_UNESCAPED_UNICODE));
                            } elseif ($data['count'] == 2) {
                                Log::channel('medo_stream_single')
                                    ->debug("Контейнер {$data['path']} с типом квитанция, перемещаем в начало списка.");

                                $redis->lpush($streamList, json_encode($data, JSON_UNESCAPED_UNICODE));
                            } else {
                                Log::channel('medo_stream_single')
                                    ->debug("Контейнер {$data['path']} с типом не квитанция, перемещаем в конец списка.");

                                $redis->rpush($streamList, json_encode($data, JSON_UNESCAPED_UNICODE));
                            }

                            Log::channel('medo_stream_single')
                                ->debug("Успешно закончили работу с контейнером {$data['path']}.");
                            echo "Успешно закончили работу с контейнером {$data['path']}\n";
                        }
                    }
                }
            );
        } catch (\Exception $e) {
            Log::critical("МЭДО Stream упал с ошибкой - {$e->getMessage()}");

            Artisan::call('medo:stream');
        }
    }
}
