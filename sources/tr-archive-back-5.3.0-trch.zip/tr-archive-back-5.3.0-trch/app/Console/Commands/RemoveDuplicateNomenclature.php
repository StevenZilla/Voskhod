<?php

namespace App\Console\Commands;

use App\Models\Dossier\Dossier;
use App\Models\Dossier\DossierInNom;
use App\Models\Dossier\DossierStatus;
use App\Models\Message\Message;
use App\Models\Nomenclature\NomPart;
use App\Models\Tk\Tk;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RemoveDuplicateNomenclature extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'remove_doubl_nom {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Удаление дубликатов номенклатур';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Удаление дубликатов номенклатур в облачном тр-архиве');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    if ($this->option('all') === 'true') {
                        $this->setMessageGuid($guid);
                    }
                    $this->info("Удаление дубликатов номенклатур {$this->messageGuid}");

                    $this->setConnection($guid);
                    $this->delete();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->delete();
            } else {
                $this->info('Не можем удалить дубликаты, потому что не переданы флаги {--A|all=false} {--U|uid_org=}');
            }
        } else {
            $this->info('Удаление дубликатов номенклатур в локальном тр-архиве');

            $this->delete();
        }

        return 0;
    }

    private function delete()
    {
        try {
            DB::transaction(function () {
                $q = DB::table('nomenclature as n')
                    ->where('n.updated_at', '!=', function ($query) {
                        $query->select(DB::raw('MAX(n2.updated_at)'))
                            ->from('nomenclature as n2')
                            ->join('nom_status as ns', 'ns.id', '=', 'n2.nom_status_id')
                            ->whereColumn('n2.year', 'n.year');
                    });
                $ids = $q->pluck('id')->all();
                $nom_parts = NomPart::whereIn('nom_id', $ids);
                $nom_parts_ids = $nom_parts->pluck('id')->all();
                $dossiers_in_noms = DossierInNom::whereIn('nom_part_id', $nom_parts_ids);

                $deleted_code = DossierStatus::where('code', '=', 'removed_from_listings')->get()->pluck('id')[0];
                $dossier_ids = DB::table('nomenclature as n')->whereIn('n.id', $ids)
                    ->select('din.dossier_id')
                    ->join('nom_part as np', 'n.id', '=', 'np.nom_id')
                    ->join('dossier_in_nom as din', 'np.id', '=', 'din.nom_part_id')
                    ->pluck('dossier_id')->all();

                Dossier::whereIn('id', $dossier_ids)->update(['dossier_status_id' => $deleted_code]);

                $tks = Tk::whereIn('nom_id', $ids);
                Message::whereIn('tk_id', $tks->pluck('id')->all())->delete();

                $tks->delete();
                $dossiers_in_noms->delete();
                $nom_parts->delete();
                $del_num = $q->delete();


                $this->info("Удалено $del_num номенклатур");
            });
        } catch (\Exception $exception) {
            $msg = "Команда по удалению дубликатов номенклатур завершилась с ошибкой.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
