<?php

namespace App\Console\Commands;

use App\Jobs\BlockUserJob;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class BlockUserCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'block:user {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Блокируем пользователей у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    if ($this->option('all') === 'true') {
                        $this->setMessageGuid($guid);
                    }

                    $this->setConnection($guid);

                    Log::channel('command_single')->debug("Блокируем пользователей {$this->messageGuid}");
                    $this->info("Блокируем пользователей {$this->messageGuid}");

                    $this->blockUser();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();

                Log::channel('command_single')->debug("Блокируем пользователей у инстанции с идентификатором приложения {$this->id_app}");
                $this->info("Блокируем пользователей у инстанции с идентификатором приложения {$this->id_app}");

                $this->blockUser();
            }

            $this->info('Успешно выполнили блокировку пользователей у облачного тр-архива');
        } else {
            $this->info('Блокируем пользователей у локального тр-архива');

            $this->blockUser();

            $this->info('Успешно выполнили блокировку пользователей у локального тр-архива');
        }
    }

    protected function blockUser(string $guid = null)
    {
        try {
            $users = User::where('is_block', false)->get();

            if (! empty($users) && $users->count() > 0) {
                BlockUserJob::dispatch($users, $guid)->onQueue('block_user_job');
            }
        } catch (\Exception $exception) {
            $message = 'Не смогли получить пользователей';
            if (!empty($guid)) {
                $message .= " у инстанции, где 'GUID ОИК в МЭДО' - {$guid}";
            }
            $message .= '.';

            Log::channel('command_single')->critical($message.PHP_EOL.$exception);
            $this->error($message);
        }
    }
}
