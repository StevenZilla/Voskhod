<?php

namespace App\Console\Commands\Synchronization;

use App\Console\Commands\BaseCommand;
use App\Models\Ed\Ed;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class SynchronizationDosserEdCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync:dossier_ed {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Обновление поля temp_save_period у ЭД значением из Дела';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Обновление поля temp_save_period у ЭД значением из Дела у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->syncDossierEd();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->syncDossierEd();
            }
        } else {
            $this->info('Обновление поля temp_save_period у ЭД значением из Дела у локального тр-архива');
            $this->syncDossierEd();
        }
    }

    private function syncDossierEd()
    {
        try {
            $eds = Ed::with('dossier')->whereNotNull('dossier_id')->get();
            foreach ($eds as $ed) {
                if ($ed->dossier->temp_save_period != $ed->temp_save_period) {
                    $ed->temp_save_period = $ed->dossier->temp_save_period;
                    $ed->save();
                }
            }
        } catch (\Exception $exception) {
            $msg = "Не смогли синхронизировать ЭД с делами";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
