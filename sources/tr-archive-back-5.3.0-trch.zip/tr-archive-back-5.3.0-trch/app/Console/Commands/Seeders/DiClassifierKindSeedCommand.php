<?php

namespace App\Console\Commands\Seeders;

use ParseCsv\Csv;
use Webpatser\Uuid\Uuid;
use App\Models\Di\DiKind;
use App\Models\Di\DiKindGroup;
use App\Models\Di\DiClassifier;
use App\Models\Di\DiSavePeriod;
use App\Models\HandBooks\SaveType;
use Illuminate\Support\Facades\DB;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use Exception;
use Illuminate\Support\Facades\File;

class DiClassifierKindSeedCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'di-classifier-kind-seed {--A|all=false} {--U|uid_org=} {--I|id_app=} {--P|path=kinds.csv} {--E|encode=UTF-8}';


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }
            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->diClassifierSeed();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->diClassifierSeed();
            }
        } else {
            $this->diClassifierSeed();
        }
    }
    private function diClassifierSeed()
    {
        $classifier = DiClassifier::where('is_ched', true)->orderBy('version', 'desc')->first();
        $groups = DiKindGroup::where('di_classifier_id', $classifier->id)->get();
        $fileCSV = $this->option('path');
        if (File::exists($fileCSV)) {

            $csvFile = new Csv();
            if($this->option('encode')!='UTF-8'){
                $csvFile->encoding($this->option('encode'), 'UTF-8');
            }
            $csvFile->delimiter = ';';
            $csvFile->parseFile($fileCSV);
            $data = $csvFile->data;
            $saveTypes = SaveType::get();
            DB::transaction(function () use ($groups, $saveTypes, $data) {
                foreach ($data as $num => $row) {
                    try {
                        $diKind = new DiKind();
                        $diKind->name = $row['name'];
                        $diKind->num = $row['num'];
                        $diKind->code = Uuid::generate()->string;
                        $diKind->description = $row['description'];
                        $diKind->group_id = $groups->where('name', $row['group_name'])->first()->id;
                        $diKind->is_active = $row['is_active'];
                        $diKind->save();
                        $diSavePeriod = new DiSavePeriod();
                        $diSavePeriod->di_kind_id = $diKind->id;
                        $diSavePeriod->temp_save_period = intval($row['temp_save_period']) ?: null;
                        $diSavePeriod->save_type_id = $saveTypes->where('name', $row['save_type'])->first()->id;
                        $diSavePeriod->is_need_epk = $row['is_need_epk'];
                        $diSavePeriod->is_need_ek = $row['is_need_ek'];
                        $diSavePeriod->save();
                    } catch (\Exception $e) {
                        echo "ошибка при добавлении строки № {$num} \n {$e}";
                        throw new Exception("Ошибка. Откат изменений.");
                    }
                    echo "Добавлена {$num} строка\n";
                }
            });
        } else {
            echo "ошибка csv файл не обнаружен \n";
        }
    }
}
