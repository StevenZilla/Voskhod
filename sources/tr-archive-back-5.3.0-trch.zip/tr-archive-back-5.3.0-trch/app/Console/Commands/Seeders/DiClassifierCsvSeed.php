<?php

namespace App\Console\Commands\Seeders;

use ParseCsv\Csv;
use Webpatser\Uuid\Uuid;
use App\Models\Di\DiKindGroup;
use App\Models\Di\DiClassifier;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\Di\DiKindGroupLTree;
use Illuminate\Support\Facades\File;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\HandBooks\Di\DiKindGroup\DiKindGroupService;

class DiClassifierCsvSeed extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'di-classifier-csv-seed {--A|all=false} {--U|uid_org=} {--I|id_app=} {--C|cpath=} {--G|gpath=} {--E|encode=UTF-8}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';
    private $diClassifier = null;
    private $groupsTree;
    private $groups;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        echo "start";
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->diClassifierSeed();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->diClassifierSeed();
            }
        } else {
            $this->diClassifierSeed();
        }
    }

    private function diClassifierSeed()
    {
        DB::transaction(function () {
            if (!empty($this->option('cpath'))) {
                if (File::exists($this->option('cpath'))) {
                    $csvFile = new Csv();
                    if ($this->option('encode') != 'UTF-8') {
                        $csvFile->encoding($this->option('encode'), 'UTF-8');
                    }
                    $csvFile->delimiter = ';';
                    $csvFile->parseFile($this->option('cpath'));
                    $data = $csvFile->data;
                    foreach ($data as $row) {
                        $newClassifier = new DiClassifier();
                        $newClassifier->name = $row['name'];
                        $newClassifier->short_name = $row['short_name'];
                        $newClassifier->description = $row['description'];
                        $newClassifier->is_ched = $row['is_ched'];
                        $newClassifier->is_active = $row['is_active'];
                        $newClassifier->save();
                        $this->diClassifier = $newClassifier;
                    }
                } else {
                    throw new \Exception("Файл с реестром {$this->option('cpath')} не существует");
                }
            } else {
                $this->diClassifier = DiClassifier::where('is_main', true)->first();
            }


            $this->diKindGroupsSeed();


        });
    }
    private function diKindGroupsSeed()
    {
        $diKindGroupService = new DiKindGroupService();
        $this->groups = collect();
        if (!empty($this->option('gpath'))) {
            if (File::exists($this->option('gpath'))) {
                if (empty($this->diClassifier)) {
                    throw new \Exception("Невозможно выполнить импорт групп групп. Реестр не существует.");
                }
                $csvFile = new Csv();
                if ($this->option('encode') != 'UTF-8') {
                    $csvFile->encoding($this->option('encode'), 'UTF-8');
                }
                $csvFile->delimiter = ';';
                $csvFile->parseFile($this->option('gpath'));
                $data = $csvFile->data;
                foreach ($data as $num => $row) {
                    $row['di_classifier_id'] = $this->diClassifier->id;
                    $this->groups->push($row);
                }
                $t1 = 34534;

                $firstLayerGroups = $this->groups->where('parent_name', null);
                $t2 = 345;

                foreach ($firstLayerGroups as $group) {
                    $newGroup = new DiKindGroupLTree();
                    $newGroup->name = $group['name'];
                    $newGroup->code = empty($group['code']) ? Uuid::generate()->string : $group['code'];
                    $newGroup->is_active = $group['is_active'];
                    $newGroup->di_classifier_id = $this->diClassifier->id;
                    $diKindGroupService->create($newGroup);
                    $this->groupsTree[$group['name']] = $newGroup->id;
                }
                $firstLayerGroupsName = $this->groups->where('parent_name', null)->pluck('name');
                $this->createGroup($firstLayerGroupsName);
            } else {
                throw new \Exception("Файл с группами {$this->option('gpath')} не существует");
            }
        }
    }

    private function createGroup($parent_names)
    {
        $diKindGroupService = new DiKindGroupService();
        $newGroups = $this->groups->whereIn('parent_name', $parent_names);
        
        foreach ($newGroups as $group) {
            $newGroup = new DiKindGroupLTree();
            $newGroup->name = $group['name'];
            $newGroup->code = empty($group['code']) ? Uuid::generate()->string : $group['code'];
            $newGroup->is_active = $group['is_active'];
            $newGroup->di_classifier_id = $this->diClassifier->id;
            $newGroup->parent_id = $this->groupsTree[$group['parent_name']];
            $diKindGroupService->create($newGroup);
            $this->groupsTree[$group['name']] = $newGroup->id;
        }
        $newGroupsNames = $newGroups->pluck('name');
        if($newGroupsNames->isNotEmpty()) {
            $this->createGroup($newGroupsNames);
        }
    }
}
