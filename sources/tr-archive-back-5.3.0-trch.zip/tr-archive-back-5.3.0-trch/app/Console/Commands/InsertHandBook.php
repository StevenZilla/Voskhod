<?php

namespace App\Console\Commands;

use App\Services\ConnectionDB\ConnectionDB;
use App\Services\InsertHandBook\InsertHandBookService;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class InsertHandBook extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'insert:handbook {--path=} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Синхронизация справочников ЦХЭДА. path - где лежит файл в формате csv. table - какую таблицу использовать';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Синхронизация справочников ЦХЭДА облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->insertHandBook();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->insertHandBook();
            }
        } else {
            $this->info('Синхронизация справочников ЦХЭДА локального тр-архива');
            $this->insertHandBook();
        }
    }

    protected function insertHandBook()
    {
        try {
            $path_dir = $this->option('path');
            $files = File::files($path_dir);

            foreach ($files as $file) {
                if (str_contains($file->getBasename(), 'archive')) {
                    $table_archive = 'archive';
                } elseif (str_contains($file->getBasename(), 'fund')) {
                    $table_fund = 'fund';
                } else {
                    $msg = "Невозможно отпределить название таблицы по файлу {$file->getBasename()}. Синхронизация справочников ЦХЭДА невозможна";
                    Log::channel('command_single')->warning($msg);
                }
            }

            if (empty($table_archive) && ! Schema::hasTable($table_archive)) {
                $msg = "Таблица {$table_archive} отсутствеут в Базе Данных. Синхронизация справочников ЦХЭДА невозможна";
                Log::channel('command_single')->warning($msg);
                throw new \Exception($msg);
            }

            if (empty($table_fund) && ! Schema::hasTable($table_fund)) {
                $msg = "Таблица {$table_fund} отсутствеут в Базе Данных. Синхронизация справочников ЦХЭДА невозможна";
                Log::channel('command_single')->warning($msg);
                throw new \Exception($msg);
            }

            Log::channel('command_single')->debug("Запускаем синхронизацию справочников ЦХЭДА. Путь до файлов - {$path_dir}, таблицы - {$table_archive}/{$table_fund}");
            $insert_handbook = new InsertHandBookService($path_dir, $table_archive, $table_fund);
            $msg_result = $insert_handbook->start();

            $this->info($msg_result);
        } catch (\Exception $exception) {
            $msg = "Команда по синхранизации справочников ЦХЭД завершилась неудачей.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
