<?php

namespace App\Console\Commands;


use App\Models\File\File;
use App\Models\File\FileRole;
use App\Models\File\FileContent;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Support\Facades\Log;
use App\Services\ApacheTika\ApacheTikaService;
use App\Services\MasterDB\Connection;
class ApacheTikaInitCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tika:init {--A|all=false} {--U|uid_org=} {--I|id_app=}';
    private $guidCurrent;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->guidCurrent = $guid;
                    $this->extractData();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();

                $this->guidCurrent = $this->id_app;
                $this->extractData();
            }
        } else {
            $this->extractData();
        }
    }

    private function extractData()
    {
        try {
            $files = File::whereIn('role_id', [FileRole::getIdDocument(), FileRole::getIdApplication()])->doesntHave('fileContent')->get();
            foreach ($files as $file) {
                if (!FileContent::where('ed_id', $file->ed_id)->where('file_id', $file->id)->exists()) {
                    ApacheTikaService::createJob($file->path, $file->id, $file->ed_id,$this->guid ?? null);
                    echo "Для инстанции {$this->guidCurrent} Создана задача на извлечение данных из файла {$file->path} \n";
                    Log::channel('apache_tika')->debug("Создана задача на извлечение данных из файла {$file->path} \n");
                }
            }
        } catch (\Exception $exception) {
            $msg = "Не смогли извлечь данные из файла.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
