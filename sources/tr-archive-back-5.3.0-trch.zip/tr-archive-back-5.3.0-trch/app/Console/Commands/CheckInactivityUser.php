<?php

namespace App\Console\Commands;

use App\Facades\DatabaseConnectionFacade;
use App\Jobs\CheckInactivityUserJob;
use App\Models\Session\Session;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class CheckInactivityUser extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:inactivity.user {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Проверка сессий пользователей на неактивность';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Проверяем сессии облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Выполняем проверку сессии [$guid]");
                    $this->setConnection($guid);
                    $this->sessionCheck($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->sessionCheck();
            } else {
                $this->info('Не можем выполнить проверку сессий. Организации не обнаруженны');
            }
        } else {
            $this->info('Проверяем сессии локального тр-архива');
            $this->sessionCheck();
        }
    }

    /**
     * @return void
     */
    private function sessionCheck($guid = null)
    {
        try {
            Log::channel('command_single')->debug('Запускается скрипт проверки сессий у пользователя на неактивность');

            $tableSession = Session::getTableName();
            $tableUser = User::getTableName();
            $users = User::join($tableSession, "{$tableSession}.user_id", "{$tableUser}.id")
                ->whereNull("{$tableSession}.end_date")->groupBy("{$tableUser}.id")->get(["{$tableUser}.*"]);
            foreach ($users as $user) {
                CheckInactivityUserJob::dispatch($user, $guid)->onQueue('check_inactivity_user_job');
            }
            $this->info('Проверка завершена');
        } catch (\Exception $exception) {
            $msg = "Не смогли проверить сессии у пользователей на неактивность";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }

    /**
     * @return void
     */
    protected function getGuidOik()
    {
        $this->guidOiks = DatabaseConnectionFacade::getAllGuidMedo();

        Log::channel('command_single')->info('Получили все инстанции. Будем выполнять проверку сессий по всем инстанциям');

        $this->info('Получили все инстанции. Будем выполнять проверку сессий');
    }

    /**
     * @param string $guid
     * @return void
     */
    protected function setConnection(string $guid)
    {
        DatabaseConnectionFacade::setDataConnection($guid);

        Config::set('database.default', 'pgsql');
    }
}
