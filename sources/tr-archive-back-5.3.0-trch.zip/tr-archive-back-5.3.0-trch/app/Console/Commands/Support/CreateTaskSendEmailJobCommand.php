<?php

namespace App\Console\Commands\Support;

use Illuminate\Console\Command;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use App\Jobs\Support\CreateTaskSendEmailJob;

class CreateTaskSendEmailJobCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'support:email-send {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';
    protected $currentOikGuid;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->currentOikGuid = $guid;
                    $this->createTask();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->createTask();
            }
        } else {
            $this->createTask();
        }
    }

    private function createTask()
    {
        $job = new CreateTaskSendEmailJob();
        $job->dispatch()->onQueue('send_mail_job');
    }
}
