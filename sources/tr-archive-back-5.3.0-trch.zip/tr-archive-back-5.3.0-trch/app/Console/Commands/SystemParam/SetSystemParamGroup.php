<?php


namespace App\Console\Commands\SystemParam;

use App\Models\System\SystemParam;
use Illuminate\Support\Facades\DB;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;

/**
 * Class SetSystemParamGroup
 * Устанавливает
 * @package App\Console\Commands\SystemParam
 */
class SetSystemParamGroup extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'system_param_group:set
    {--A|all=false} {--U|uid_org=} {--I|id_app=}
    {--B|base64}
    {--P|param=}'
    ;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'команда установки значений группы системных параметров';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if($this->option('base64')){
            $params = json_decode(base64_decode($this->option('param')));
        }
        else{
            $params = json_decode($this->option('param'));
        }

        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Установление значения системным параметрам у облачного тр-архива');

            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("-{{$guid}}:");
                    $this->setConnection($guid);
                    $this->setSystemParameters($params);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->setSystemParameters($params);
            }

        } else {
            $this->info('Установление значения системным параметрам у локального тр-архива');
            $this->setSystemParameters($params);
        }

    }

    public function setSystemParameters($params)
    {
        DB::transaction(function () use ($params) {
            foreach ($params as $key => $value) {
                $this->info("  -{$key}:=[{$value}]");
                SystemParam::where('code', $key)->update(['value' => $value]);
            }
        });
    }

}