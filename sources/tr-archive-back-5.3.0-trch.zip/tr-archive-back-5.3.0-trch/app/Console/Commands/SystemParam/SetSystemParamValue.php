<?php

namespace App\Console\Commands\SystemParam;

use App\Console\Commands\BaseCommand;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class SetSystemParamValue extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'system_param:set {codeParam} {newValue} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Установление значения системным параметрам по указанию их имени';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Установление значения системным параметрам у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->setSystemParam();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->setSystemParam();
            }
        } else {
            $this->info('Установление значения системным параметрам у локального тр-архива');
            $this->setSystemParam();
        }
    }

    protected function setSystemParam()
    {
        try {
            if (!empty($this->argument('codeParam')) && !empty($this->argument('newValue'))) {
                $systemParam = SystemParam::where('code', $this->argument('codeParam'));
                if ($this->argument('codeParam') == 'in_containers_medo') {
                    $path = $this->argument('newValue');
                    $path = '/'.trim($path, '/').'/';

                    if (!file_exists($path)) {
                        $this->error('Директории по заданному пути не существует');
                        die();
                    }
                }

                if ($systemParam->count()) {
                    $systemParam = $systemParam->first();
                    $systemParam->value = $this->argument('newValue');
                    $systemParam->save();
                } else {
                    $this->error('Системного параметра с переданным кодом не существует');
                    die();
                }
            }

            $this->info('Значение параметра с кодом: "' . $this->argument('codeParam') . '" успешно обновилось!');
        } catch (\Exception $exception) {
            $msg = "Не смогли установить новое значение для параметра системных настроек с кодом {$this->argument('codeParam')}";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
