<?php

namespace App\Console\Commands\SystemParam;

use App\Console\Commands\BaseCommand;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SetParamVipNet extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'system_param:vipnet.set {value} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    protected $codeParams = [
        'type_skzi',
        'vipnet_host',
        'vipnet_login',
        'vipnet_password',
    ];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Устанавливаем параметры подключения к випнету. Ожидает параметр {value}, которые принимает значение http://login:password@vipnet.com';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Устанавливаем параметры подключения к випнету у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->setVipNet();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->setVipNet();
            }
        } else {
            $this->info('Устанавливаем параметры подключения к випнету у локального тр-архива');
            $this->setVipNet();
        }
    }

    protected function setVipNet()
    {
        try {
            $vipnet = [];

            if (mb_strtolower($this->argument('value')) == 'cryptopro' || mb_strtolower($this->argument('value')) == 'криптопро') {
                $vipnet['type_skzi'] = 1;
                $vipnet['vipnet_login'] = '';
                $vipnet['vipnet_password'] = '';
                $vipnet['vipnet_host'] = '';
            } else {
                $data = parse_url($this->argument('value'));

                $vipnet['type_skzi'] = 2;
                $vipnet['vipnet_login'] = $data['user'];
                $vipnet['vipnet_password'] = $data['pass'];
                $vipnet['vipnet_host'] = "{$data['scheme']}://{$data['host']}:{$data['port']}{$data['path']}";
            }

            $params = SystemParam::whereIn('code', $this->codeParams)->get();
            if (! empty($params) && count($params) > 0) {
                foreach ($params as $param) {
                    if (! empty($vipnet[$param->code])) {
                        $param->value = $vipnet[$param->code];
                        $param->save();

                        $this->info("Успешно установили значение {$vipnet[$param->code]} в параметр {$param->name} {$this->messageGuid}");
                    }
                }
            }

            $this->info("Успешно обновили системные настройки {$this->messageGuid}");
        } catch (\Exception $exception) {
            $msg = "Не смогли установить СКЗИ для инстанции с guid МЭДО {$this->messageGuid}";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
