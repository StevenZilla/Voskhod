<?php

namespace App\Console\Commands\SystemParam;

use App\Console\Commands\BaseCommand;
use App\Models\System\SystemParam;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class RestoreSystemSettings extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'restore_system_settings {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Восстановление системных настроек для пилота';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Восстанавливаем системные настройки у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->restoreSystemSettings();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->restoreSystemSettings();
            }
        } else {
            $this->info('Восстанавливаем системные настройки у локального тр-архива');
            $this->restoreSystemSettings();
        }
    }

    protected function restoreSystemSettings()
    {
        try {
            $systemParams = SystemParam::all();

            if (! empty($systemParams)) {
                foreach ($systemParams as $systemParam) {
                    if ($systemParam->name === 'Идентификатор ОИК в ЦХЭД') {
                        $systemParam->value = '01';
                        // $systemParam->value = '404115c0-4df1-11ec-af60-9f46fc323fb2'; old value
                    } elseif ($systemParam->name === 'GUID ОИК в МЭДО') {
                        $systemParam->value = '0e2b6270-b562-43c3-bbcb-a9fa79b8bc9d';
                    } elseif ($systemParam->name === 'Наименование ОИК') {
                        $systemParam->value = 'ТР "Архив"';
                    } elseif ($systemParam->name === 'Наименование ПО') {
                        $systemParam->value = 'Тр-Архив';
                    } elseif ($systemParam->name === 'Входящие контейнеры МЭДО') {
                        $systemParam->value = '/var/www/medo/in';
                    } elseif ($systemParam->name === 'Исходящие контейнеры МЭДО') {
                        $systemParam->value = '/var/www/medo/out';
                    } elseif ($systemParam->name === 'Наименование организации-получателя документов ЦХЭД в МЭДО') {
                        $systemParam->value = ' Центр хранения электронных документов';
                    } elseif ($systemParam->name === 'GUID организации-получателя документов ЦХЭД в МЭДО') {
                        $systemParam->value = '19663d5c-dd69-4bdc-ae40-ca8c1d239123';
                    } elseif ($systemParam->name === 'Источник ЭД для входящих контейнеров') {
                        $systemParam->value = '2';
                    } elseif ($systemParam->name === 'Адресат МЭДО в ini-сообщении') {
                        $systemParam->value = 'CHED_S~MEDOGU';
                    }
                    $systemParam->save();
                }
            }
        } catch (\Exception $exception) {
            $msg = "Не смогли восстановить системные настройки";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
