<?php

namespace App\Console\Commands\Health;

use App\Jobs\Skzi\CheckSkziJob;
use App\Console\Commands\BaseCommand;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Foundation\Bus\DispatchesJobs;

class HealthSkzi extends BaseCommand
{
    use DispatchesJobs;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'health:skzi {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Проверка состояния СКЗИ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Проверка СКЗИ облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (!empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->info("Проверка СКЗИ инстанции: [$guid]");
                    $this->setConnection($guid);
                    $this->healthCheckSkzi($guid);
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->healthCheckSkzi();
            } else {
                $this->info('Ошибка. Проверка СКЗИ отменена. Организации не обнаружены');
            }
        } else {
            $this->info('Проверка СКЗИ локального тр-архива');
            $this->healthCheckSkzi();
        }
    }


    public function healthCheckSkzi($guid = null)
    {
        $job =new CheckSkziJob($guid);
        $job->onQueue('check_skzi_job');
        $this->dispatch($job);
    }

}
