<?php

namespace App\Console\Commands\Health;

use App\Services\Health\HealthCheck;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;

class DiskSpaceCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'health:disk {info=true}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check disk space';


    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $health = new HealthCheck($this->argument('info'));
        $result = $health->checkDisk();
        $service = "Disk";
        switch ($result) {
            case $health->checkOkStatus:
                $this->info($service . " - " . $result);
                return (0);
                break;
            case $health->checkErrorStatus:
                $this->error($service . " - " . $result);
                return (1);
                break;
            default:
                $this->warn($service . " - " . $result);
                return (2);
                break;
        }
    }
}
