<?php

namespace App\Console\Commands\Health;

use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use App\Services\Health\HealthCheck;
use Illuminate\Support\Facades\Redis;

class RedisCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'health:redis {--info}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check redis';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $health = new HealthCheck($this->option('info'));
        $result = $health->checkRedis();
        $service = "Redis";
        switch ($result) {
            case $health->checkOkStatus:
                $this->info($service . " - " . $result);
                exit(0);
                break;
            case $health->checkErrorStatus:
                $this->error($service . " - " . $result);
                exit(1);
                break;
            default:
                $this->warn($service . " - " . $result);
                exit(2);
                break;
        }
    }
}
