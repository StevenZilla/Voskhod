<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\System\SystemParam;
use Illuminate\Support\Facades\Log;
use App\Services\MasterDB\Connection;
use App\Services\FileWatch\Medo\MedoWatchService;


class FileWatchInitCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'medo:init';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Medo init command';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $directory = config('filesystems.medo_in');
        echo "Сканирую(инициализация): " . $directory . "\n";
        Log::channel('medo_watch_single')->info("Сканирую(инициализация): " . $directory . "\n");
        $templates = json_decode(config("file_watch.templates"));
        $templates = array_map(function ($template) {
            sort($template);
            return $template;
        }, $templates);

        $mergedTemplates = [];
        foreach ($templates as $template) {
            $mergedTemplates = array_merge($mergedTemplates, $template);
        }
        $mergedTemplates = array_unique($mergedTemplates);
        $medoWatchService = new MedoWatchService($directory, null, $templates, $mergedTemplates);
        $medoWatchService->setExcept(config('filesystems.excludes'));
        $medoWatchService->initWatch();
    }
}
