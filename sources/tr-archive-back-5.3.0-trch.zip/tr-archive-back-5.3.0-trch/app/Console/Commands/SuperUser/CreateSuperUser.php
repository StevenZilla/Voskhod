<?php

namespace App\Console\Commands\SuperUser;

use App\Exceptions\BaseException;
use App\Models\Sert\Sert;
use App\Models\Sert\SertOneUse;
use App\Models\Sert\SertUse;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class CreateSuperUser extends CreateAndUpdadeUser
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'superuser:create {login} {password?} {--fio=} {--email=} {--is_block=} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Создать супер-пользователя';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info("Создаем супер-пользователя {$this->argument('login')} у облачного тр-архива");
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->createSuperUser();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->createSuperUser();
            }
        } else {
            $this->info("Создаем супер-пользователя {$this->argument('login')} у локального тр-архива");

            $this->createSuperUser();
        }
    }

    public function addSertForNewSuperUser($user)
    {
        $sert = Sert::all()->where('user_id', null)->first();
        if (! empty($sert)) {
            $sert->user_id = $user->id;
            $sert->save();

            $sertUses = SertUse::get();
            if (! empty($sertUses)) {
                foreach ($sertUses as $sertUse) {
                    $newOneUse = new SertOneUse();
                    $newOneUse->sert_id = $sert->id;
                    $newOneUse->sert_use_id = $sertUse->id;
                    $newOneUse->save();
                }
            }
        }
    }

    protected function createSuperUser()
    {
        try {
            if (User::where('login', mb_strtolower($this->argument('login')))->exists()) {
                $superUser = User::where('login', mb_strtolower($this->argument('login')))->first();
            } else {
                $superUser = new User();
                $superUser->login = mb_strtolower($this->argument('login'));
            }

            $superUser->fio = ! empty($this->option('fio')) ? $this->option('fio') : $this->argument('login');
            $superUser->email = ! empty($this->option('email')) ? $this->option('email') : $this->argument('login').'@mail.ru';

            if (! empty($this->argument('password'))) {
                $superUser->password = $this->argument('password');
            } else {
                $newPassword = $this->generatePassword();
                $superUser->password = $newPassword;
            }

            if (! empty($this->option('is_block'))) {
                $superUser->is_block = true ? $this->option('is_block') == 'true' : false;
            }

            $superUser->start_date = Carbon::now()->toDateTimeString();
            $superUser->end_date = Carbon::now()->addYear(100)->toDateTimeString();
            $superUser->is_superuser = true;
            $superUser->activated = true;
            $superUser->save();

            //Добавление сертификата пользователю со всеми возможностями
            $this->addSertForNewSuperUser($superUser);

            $message = "Супер пользователь - \"{$this->argument('login')}\" {$this->messageGuid} успешно создан";
            if (empty($this->argument('password'))) {
                $message .= ' Его сгенерированный пароль: '.$newPassword;
            }
            $this->info($message);

            Log::channel('command_single')->info("Созданный супер пользователь {$this->argument('login')} {$this->messageGuid} успешно активирован");
        } catch (BaseException $e) {
            if (str_contains($e->getMessage(), 'user_login_unique')) {
                $msgError = "Пользователь с логином - \"{$this->argument('login')}\" {$this->messageGuid} уже существует";
            } else {
                $msgError = "Не получилось создать супер-пользователя {$this->messageGuid}. Ошибка записана в лог. ";
            }

            Log::channel('command_single')->alert("Не получилось создать супер-пользователя {$this->messageGuid}.");
            $this->error($msgError);
        }
    }
}
