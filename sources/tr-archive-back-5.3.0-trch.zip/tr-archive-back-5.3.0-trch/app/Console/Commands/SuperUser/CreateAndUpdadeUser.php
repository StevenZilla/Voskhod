<?php

namespace App\Console\Commands\SuperUser;

use App\Console\Commands\BaseCommand;
use App\Exceptions\BaseException;
use App\Models\System\SystemRole;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class CreateAndUpdadeUser extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *<.
     * @var string>
     */
    protected $signature = 'user:insert {login} {password?} {--is_superuser=false} {--A|all=false} {--U|uid_org=} {--I|id_app=} {--fio=} {--email=} {--S|set_role=false}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info("Создаем пользователя {$this->argument('login')} у облачного тр-архива");
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->insertUser();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->insertUser();
            }
        } else {
            $this->info("Создаем пользователя {$this->argument('login')} у локального тр-архива");

            $this->insertUser();
        }
    }

    protected function generatePassword()
    {
        $password = uniqid(3);

        return $password;
    }

    protected function insertUser()
    {
        try {
            Log::channel('command_single')->debug("Создаем/обновляем пользователя с логином - {$this->argument('login')}");

            if (mb_strtolower($this->option('set_role')) != 'false') {
                if (mb_strtolower($this->option('set_role')) != 'true' && SystemRole::where('code', $this->option('set_role'))->exists()) {
                    $responseUser = SystemRole::where('code', $this->option('set_role'))->pluck('id')->first();
                } else {
                    $roles = SystemRole::orderBy('id')->get();
                    if (! empty($roles) && count($roles) > 0) {
                        $questionForUser = "Пользователь {$this->messageGuid}, которого вы создаете, не является супер-юзером. Поэтому выберите системную роль для пользователя.".PHP_EOL;
                        foreach ($roles as $role) {
                            $questionForUser .= "  {$role->id}. {$role->name}[{$role->id}] - {$role->description}. Роль активна с {$role->start_date} до {$role->end_date}. ";
                            $questionForUser .= "Приоритет роли: {$role->priority}.".PHP_EOL;
                        }

                        $questionForUser .= ' Выберите цифру роли';

                        $responseUser = $this->ask($questionForUser);
                    }
                }
            }

            $user = User::where('login', $this->argument('login'))->first();

            if (empty($user)) {
                $user = new User();
                $user->fio = ! empty($this->option('fio')) ? $this->option('fio') : $this->argument('login');
                $user->login = mb_strtolower($this->argument('login'));
                $user->email = ! empty($this->option('email')) ? $this->option('email') : $this->argument('login');
                $user->start_date = Carbon::now()->toDateTimeString();
                $user->activated = true;
                $user->end_date = Carbon::now()->addYear(100)->toDateTimeString();
            }

            if (! empty($this->argument('password'))) {
                $password = $this->argument('password');
                $user->password = $password;
            } else {
                $user->password = $this->generatePassword();
            }

            $user->is_superuser = $this->option('is_superuser') == 'true' ? true : false;
            $user->save();

            if (! empty($responseUser)) {
                $user->systemRole()->attach($responseUser);
            }

            $message = '';
            if ($this->option('is_superuser') && $this->option('is_superuser') != 'false') {
                $message = 'Супер-';
            }
            $message .= "Пользователь - \"{$user->login}\" {{$this->messageGuid}} успешно создан. Его пароль: {$password}";

            $this->info($message);
        } catch (BaseException $e) {
            if (str_contains($e->getMessage(), 'user_login_unique')) {
                $msgError = "Пользователь с логином - \"{$this->argument('login')}\" {{$this->messageGuid}} уже существует";
            } else {
                $msgError = "Не получилось создать пользователя {$this->messageGuid}. Ошибка записана в лог. ";
            }

            Log::channel('command_single')->alert("Не получилось создать пользователя {$this->messageGuid}.");

            $this->error($msgError);
        }
    }
}
