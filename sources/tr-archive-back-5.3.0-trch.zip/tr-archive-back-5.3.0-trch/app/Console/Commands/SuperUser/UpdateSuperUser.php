<?php

namespace App\Console\Commands\SuperUser;

use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class UpdateSuperUser extends CreateAndUpdadeUser
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'superuser:reset {login} {password?} {--fio=} {--email=} {--is_block=false} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Обновить пароль супер-пользователю';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info("Обновляем пользователя {$this->argument('login')} у облачного тр-архива");
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);

                    $this->updateSuperUser();
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->updateSuperUser();
            }
        } else {
            $this->info("Обновляем пользователя {$this->argument('login')} у локального тр-архива");

            $this->updateSuperUser();
        }
    }

    protected function updateSuperUser()
    {
        try {
            $superUser = User::where('login', $this->argument('login'))->first();
            if (! empty($superUser)) {
                if (! empty($this->argument('password'))) {
                    $superUser->password = $this->argument('password');
                } else {
                    $newPassword = $this->generatePassword();
                    $superUser->password = $newPassword;
                }

                if (! empty($this->option('fio'))) {
                    $superUser->fio = $this->option('fio');
                }

                if (! empty($this->option('is_block'))) {
                    $superUser->is_block = true ? $this->option('is_block') == 'true' : false;
                }

                if (! empty($this->option('email')) && ! $superUser->is_block) {
                    $superUser->email = $this->option('email');
                }

                $superUser->is_superuser = true;
                $superUser->save();

                if ($superUser->is_block ) {
                    $message = "Успешно заблокировали пользователя - \"{$this->argument('login')}\" {$this->messageGuid}.";
                } else {
                    $message = "Успешно обновили пароль у пользователя - \"{$this->argument('login')}\" {$this->messageGuid}.";
                    if (empty($this->argument('password'))) {
                        $message .= ' Его сгенерированный пароль: '.$newPassword;
                    }
                }
                $this->info($message);
            } else {
                $this->error("Пользователь с логином - \"{$this->argument('login')}\" {$this->messageGuid} не сущетствует");
            }
        } catch (\Exception $exception) {
            $msg = "Не смогли обновить супер-пользователя {$this->argument('login')}";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
