<?php

namespace App\Console\Commands\SuperUser;

use App\Console\Commands\BaseCommand;
use App\Models\User\User;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;

use Illuminate\Support\Facades\Log;

/**
 * Class GetSuperUser
 * @package App\Console\Commands\SuperUser
 */
class GetSuperUser extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'superuser:list {uid_org} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Получить список супер-пользователей';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->info($this->getSuperUser());
                }
            } elseif (!empty($this->id_app)) {
                $this->setConnectionWithIdApp();
                $this->info($this->getSuperUser());
            }
        }
    }

    protected function getGuidOik()
    {
        $this->guidOiks[] = $this->argument('uid_org');
        $this->setMessageGuid($this->argument('uid_org'));
    }

    public function getSuperUser()
    {
        try {
            return '::super_users::' . User::where([
                    ['is_superuser', '=', true], ['is_block', '=', false]
                ])->get()->toJson(JSON_UNESCAPED_UNICODE) . '::super_users::';
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            Log::channel('command_single')->debug("При ролучении списка суперпользователей произошла непредвиденная ошибка:\n {$msg}");
            return response()->json(['code' => 400, 'message' => $msg], 400);
        }
    }
}
