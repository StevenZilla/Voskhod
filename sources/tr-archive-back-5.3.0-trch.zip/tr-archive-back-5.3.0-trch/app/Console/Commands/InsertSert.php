<?php

namespace App\Console\Commands;

use App\Facades\DatabaseConnectionFacade;
use App\Jobs\InsertSertJob;
use App\Services\ConnectionDB\ConnectionDB;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Log;

class InsertSert extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'insert:sert {--user} {--A|all=false} {--U|uid_org=} {--I|id_app=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Записать установленные сертификаты в базу данных';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Записываем сертификаты у облачного тр-архива');
            if ($this->option('id_app') === null) {
                $this->getGuidOik();
            } else {
                $this->getIdApp();
            }

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->insertSert($guid);
                }
            } elseif (!empty($this->id_app)) {
                $guid = DatabaseConnectionFacade::getGuidMedo($this->id_app);
                $this->insertHandBook($guid);
            }
        } else {
            $this->info('Записываем сертификаты у локального тр-архива');
            $this->insertSert();
        }
    }

    /**
     * @param string|null $guidInstance
     * @return void
     */
    protected function insertSert(string $guidInstance = null)
    {
        try {
            if ($this->option('user')) {
                InsertSertJob::dispatch('true', $guidInstance)->onQueue('insert_sert_job');
            } else {
                InsertSertJob::dispatch(false, $guidInstance)->onQueue('insert_sert_job');
            }
        } catch (\Exception $exception) {
            $msg = "Команда по актуализации сертификатов в системе завершилась неудачей.";
            Log::channel('command_single')->critical($msg.PHP_EOL.$exception);

            $this->error($msg.PHP_EOL.$exception->getMessage());
        }
    }
}
