<?php

namespace App\Console\Commands;

use App\Models\Sert\Sert;
use App\Models\SKZI\Skzi;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Support\Carbon;
use App\Models\System\SystemParam;
use App\Services\MasterDB\Connection;

class FixSertCommand extends BaseCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fix:sert {--U|uid_org=} {--A|all=false}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Исправление сертификатов';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $this->info('Исправление сертификатов у облачного тр-архива');
            $this->getGuidOik();

            if (! empty($this->guidOiks)) {
                foreach ($this->guidOiks as $guid) {
                    $this->setConnection($guid);
                    $this->fixSert($guid);
                }
            }
        } else {
            $this->info('Исправление сертификатов у локального тр-архива');
            $this->fixSert();
        }
    }

    private function fixSert()
    {
        $typeSkzi = SystemParam::getSkziType();
        $serts = Sert::where('skzi_id', $typeSkzi)->get();

        foreach ($serts as $sert) {
            if($sert->start_date <= Carbon::now()->format('Y-m-d H:i:s') 
            && $sert->end_date >= Carbon::now()->format('Y-m-d H:i:s')){
                $sert->is_active = true;
            } else {
                $sert->is_active = false;
            }
            $sert->save();
        }
    }
}
