<?php

namespace App\Console;

use App\Console\Commands\ApacheTikaInitCommand;
use App\Console\Commands\FixRoute;
use App\Models\System\SystemParam;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Console\Commands\CheckFiles;
use App\Console\Commands\InsertSert;
use App\Services\MasterDB\Connection;
use Illuminate\Support\Facades\Config;
use App\Console\Commands\EntitiesClear;
use App\Console\Commands\Event\EventIb;
use App\Facades\DatabaseConnectionFacade;
use App\Console\Commands\BlockUserCommand;
use App\Console\Commands\Health\HealthSkzi;
use App\Console\Commands\SetVersionProduct;
use App\Services\ConnectionDB\ConnectionDB;
use Illuminate\Console\Scheduling\Schedule;
use App\Console\Commands\CheckInactivityUser;
use App\Console\Commands\Event\AuditSendMail;
use App\Console\Commands\FileWatchInitCommand;
use App\Console\Commands\Skzi\SertSyncCommand;
use App\Console\Commands\Event\EventMainEntities;
use App\Console\Commands\DeletionActGenerateCommand;
use App\Console\Commands\Skzi\SertMonitoringCommand;
use App\Console\Commands\GetFileDownloadEventCommand;
use App\Console\Commands\Skzi\SertSystemCheckCommand;
use App\Console\Commands\RenewalsAk\RenewalsAkCommand;
use App\Console\Commands\UpdateCertificateNotification;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Console\Commands\InputContainers\InputContainersParser;
use App\Console\Commands\RenewalsAk\SendReportRenewalsAkCommand;
use App\Console\Commands\Support\CreateTaskSendEmailJobCommand;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        InputContainersParser::class,
        RenewalsAkCommand::class,
        SendReportRenewalsAkCommand::class,
        CheckInactivityUser::class,
        GetFileDownloadEventCommand::class,
        SetVersionProduct::class,
        EntitiesClear::class,
        BlockUserCommand::class,
        EventIb::class,
        EventMainEntities::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command(InputContainersParser::class)->everyMinute();
        $schedule->command(FileWatchInitCommand::class)->everyMinute()->withoutOverlapping()->runInBackground();

        if (config('app.check_vipnet_renewals')) {
            if (config('app.check_renewals_ak')) {
                $schedule->command(RenewalsAkCommand::class)->daily()->withoutOverlapping()->runInBackground();
            } else {
                $schedule->command(RenewalsAkCommand::class)->everyMinute()->withoutOverlapping()->runInBackground();
            }
        }

        $schedule->command(SendReportRenewalsAkCommand::class)->everyMinute()->withoutOverlapping()->runInBackground();
        $schedule->command(CheckInactivityUser::class)->everyFifteenMinutes()->withoutOverlapping()->runInBackground();
//        $schedule->command(InsertSert::class)->daily()->withoutOverlapping()->runInBackground(); # TODO используем SertSyncCommand
        $schedule->command(GetFileDownloadEventCommand::class)->everyMinute()->withoutOverlapping()->runInBackground();
        $schedule->command(BlockUserCommand::class)->hourly()->withoutOverlapping()->runInBackground();
        $schedule->command(EventIb::class)->daily()->withoutOverlapping()->runInBackground();
        $schedule->command(EventMainEntities::class)->daily()->withoutOverlapping()->runInBackground();
        $schedule->command(AuditSendMail::class)->everyFifteenMinutes()->withoutOverlapping()->runInBackground();

        # Отправка уведомлений о сертификатах
        $schedule->command(UpdateCertificateNotification::class)->daily()->withoutOverlapping()->runInBackground();

        # Отправка уведомлений при отсутствие файлов ЭД
        $schedule->command(CheckFiles::class)->everyMinute()->withoutOverlapping()->runInBackground();

        # Актуализация роутов для прав доступа
        $schedule->command(FixRoute::class)->daily()->withoutOverlapping()->runInBackground();
        $this->instanceSelectExecuteDeletionActGenerate($schedule);


        $schedule->command(SertSyncCommand::class)->daily()->withoutOverlapping()->runInBackground();
        $schedule->command(SertMonitoringCommand::class)->hourly()->withoutOverlapping()->runInBackground();
        $schedule->command(SertSystemCheckCommand::class)->hourly()->withoutOverlapping()->runInBackground();

        $schedule->command(HealthSkzi::class)->everyThreeHours()->withoutOverlapping()->runInBackground();
        $schedule->command(CreateTaskSendEmailJobCommand::class)->everyThirtyMinutes()->withoutOverlapping()->runInBackground();

        $schedule->command(ApacheTikaInitCommand::class)->everyMinute()->withoutOverlapping()->runInBackground();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }


    public function instanceSelectExecuteDeletionActGenerate($schedule)
    {
        if (!ConnectionDB::isLocalConnectDB()) {
            $guidOiks = DatabaseConnectionFacade::getAllGuidMedo();
            if (!empty($guidOiks)) {
                foreach ($guidOiks as $guid) {
                    $this->setConnection($guid);

                    try {
                        $date = SystemParam::getDeleteActMonitoringDate();
                        $day = $date[0];
                        $month = $date[1];
                        $time = SystemParam::getDeleteActMonitoringTime();
                        $schedule->command(DeletionActGenerateCommand::class, ['--uid_org', $guid])->yearlyOn($month, $day, $time);
                    } catch (\Exception $exception) {
                        $msg = 'Произошла ошибка при определение начала генерации акта на удалении.';
                        Log::channel('command_single')->critical($msg.PHP_EOL.$exception);
                        echo $msg.PHP_EOL.$exception->getMessage();
                    }
                }
            }
        } else {
            try {
                $date = SystemParam::getDeleteActMonitoringDate();
                $day = $date[0];
                $month = $date[1];
                $time = SystemParam::getDeleteActMonitoringTime();
                $schedule->command(DeletionActGenerateCommand::class)->yearlyOn($month, $day, $time);
            } catch (\Exception $exception) {
                $msg = 'Произошла ошибка при определение начала генерации акта на удалении.';
                Log::channel('command_single')->critical($msg . PHP_EOL . $exception);
                echo $msg . PHP_EOL . $exception->getMessage();
            }
        }
    }

    protected function setConnection(string $guid)
    {
        DatabaseConnectionFacade::setDataConnection($guid);
        Config::set('database.default', 'pgsql');
    }
}
