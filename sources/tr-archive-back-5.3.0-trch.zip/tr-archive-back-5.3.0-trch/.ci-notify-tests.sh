#!/bin/bash

TIME="10"
URL="https://api.telegram.org/bot${GIT_TELEGRAM_ITT}/sendMessage"
URL_SEND="https://api.telegram.org/bot${GIT_TELEGRAM_ITT}/sendDocument"
TEXT="Статус сборки: $1%0A%0AПуть проекта: $CI_PROJECT_PATH%0AИмя проекта: $CI_PROJECT_TITLE%0AАвтор коммита: $CI_COMMIT_AUTHOR%0AURL: $CI_PROJECT_URL/pipelines/$CI_PIPELINE_ID/%0AВетка: $CI_COMMIT_REF_SLUG%0A%0AСообщение коммита: $CI_COMMIT_MESSAGE"

curl -s --max-time $TIME -d "chat_id=$TELEGRAM_DEV_STAND_ID_ITT&disable_web_page_preview=1&text=$TEXT" $URL > /dev/null
curl -F chat_id=$TELEGRAM_DEV_STAND_ID_ITT -F document=@newman_reporters/results/report.html $URL_SEND
