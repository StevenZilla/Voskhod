<?php

// @formatter:off
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App{
/**
 * App\DocumentType
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType query()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DocumentType extends \Eloquent {}
}

namespace App{
/**
 * App\EDAttributeType
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EDAttributeType query()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EDAttributeType extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegister
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int $year
 * @property int $accept_register_status_id
 * @property int $subdivision_id
 * @property int $user_id
 * @property string|null $path_xml_register
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property mixed|null $structure_snapshot
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|AcceptRegisterAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read User $author
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|\App\Models\AcceptRegister\AcceptRegisterPart[] $parts
 * @property-read int|null $parts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \App\Models\AcceptRegister\AcceptRegisterStatus $registerStatus
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read Subdivisions $subdivision
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereAcceptRegisterStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereStructureSnapshot($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegister extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegisterApproved
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int $year
 * @property int $accept_register_status_id
 * @property int $subdivision_id
 * @property int $user_id
 * @property string|null $path_xml_register
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property mixed|null $structure_snapshot
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereAcceptRegisterStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereStructureSnapshot($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterApproved whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\Agreement\AcceptRegisterAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \App\Models\User\User $author
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|\App\Models\AcceptRegister\AcceptRegisterPart[] $parts
 * @property-read int|null $parts_count
 * @property-read \App\Models\AcceptRegister\AcceptRegisterStatus $registerStatus
 * @property-read \App\Models\Subdivisions\Subdivisions $subdivision
 */
	class AcceptRegisterApproved extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegisterFileEpSigner
 *
 * @property int $id
 * @property string $name
 * @property string $path
 * @property int $accept_register_id
 * @property string $sign_date
 * @property int $user_id
 * @property int $system_role_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereAcceptRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereSignDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereSystemRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereUserId($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property int|null $participant_id
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileEpSigner whereParticipantId($value)
 */
	class AcceptRegisterFileEpSigner extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegisterPart
 *
 * @property int $id
 * @property string $name
 * @property int|null $parent_id
 * @property int $accept_register_id
 * @property mixed|null $path
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegister
 * @property-read int|null $dossier_in_accept_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|AcceptRegisterPart[] $ltreeChildren
 * @property-read int|null $ltree_children_count
 * @property-read AcceptRegisterPart|null $ltreeParent
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] all($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart ancestorByLevel(int $level = 1, ?string $path = null)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart ancestorsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart descendantsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] get($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart parentsOf(array $paths)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart root()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereAcceptRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterPart withoutSelf(int $id)
 * @mixin \Eloquent
 */
	class AcceptRegisterPart extends \Eloquent implements \Umbrellio\LTree\Interfaces\LTreeModelInterface, \Umbrellio\LTree\Interfaces\LTreeInterface, \Umbrellio\LTree\Interfaces\ModelInterface, \Umbrellio\LTree\Interfaces\HasLTreeScopes, \Umbrellio\LTree\Interfaces\HasLTreeRelations {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegisterProject
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int $year
 * @property int $accept_register_status_id
 * @property int $subdivision_id
 * @property int $user_id
 * @property string|null $path_xml_register
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property mixed|null $structure_snapshot
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegister autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereAcceptRegisterStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereStructureSnapshot($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterProject whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\Agreement\AcceptRegisterAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \App\Models\User\User $author
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\DossierInAcceptRegister[] $dossierInAcceptRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_accept_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|\App\Models\AcceptRegister\AcceptRegisterPart[] $parts
 * @property-read int|null $parts_count
 * @property-read \App\Models\AcceptRegister\AcceptRegisterStatus $registerStatus
 * @property-read \App\Models\Subdivisions\Subdivisions $subdivision
 */
	class AcceptRegisterProject extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\AcceptRegisterStatus
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterStatus extends \Eloquent {}
}

namespace App\Models\AcceptRegister\Agreement{
/**
 * App\Models\AcceptRegister\Agreement\AcceptRegisterAgreement
 *
 * @property int $id
 * @property int $order Номер согласования
 * @property string|null $create_date Дата создания согласования
 * @property string|null $end_date Дата окончания согласования
 * @property int $status_id Статус согласования
 * @property int $accept_register_id Идентификатор сдаточной описи
 * @property bool $is_actual Актуальность
 * @property string|null $path_xml_register Путь к xml описи
 * @property string|null $path_xml_results
 * @property int|null $decision_type_id Идентификатор решения
 * @property string|null $comment Комментарий
 * @property int|null $user_id Идентификатор согласующего
 * @property int|null $type_id Архивист/Руководитель подразделения ОИК
 * @property int|null $job_id Идентификатор задачи на генерацию и подписание xml сдаточной описи
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read AcceptRegister $acceptRegister
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\AcceptRegister\Agreement\AcceptRegisterDecisionType|null $decisionType
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\AcceptRegister\Agreement\AcceptRegisterFileComment[] $fileComment
 * @property-read int|null $file_comment_count
 * @property-read mixed $temp_uri
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|JobStatuses[] $jobs
 * @property-read int|null $jobs_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\AcceptRegister\Agreement\AcceptRegisterAgreementStatus $status
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereAcceptRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereComment($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereDecisionTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereIsActual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereJobId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement wherePathXmlResults($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreement whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterAgreement extends \Eloquent {}
}

namespace App\Models\AcceptRegister\Agreement{
/**
 * App\Models\AcceptRegister\Agreement\AcceptRegisterAgreementStatus
 *
 * @property int $id
 * @property string $name Наименование
 * @property string $code Код
 * @property string $code_xml Код для xml
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterAgreementStatus extends \Eloquent {}
}

namespace App\Models\AcceptRegister\Agreement{
/**
 * App\Models\AcceptRegister\Agreement\AcceptRegisterAgreementType
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property string $code_xml
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterAgreementType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterAgreementType extends \Eloquent {}
}

namespace App\Models\AcceptRegister\Agreement{
/**
 * App\Models\AcceptRegister\Agreement\AcceptRegisterDecisionType
 *
 * @property int $id
 * @property string $name Наименование
 * @property string $code Код
 * @property string $code_xml Код для xml
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterDecisionType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterDecisionType extends \Eloquent {}
}

namespace App\Models\AcceptRegister\Agreement{
/**
 * App\Models\AcceptRegister\Agreement\AcceptRegisterFileComment
 *
 * @property int $id
 * @property string|null $path
 * @property int $accept_register_agreement_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment query()
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment whereAcceptRegisterAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AcceptRegisterFileComment whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptRegisterFileComment extends \Eloquent {}
}

namespace App\Models\AcceptRegister{
/**
 * App\Models\AcceptRegister\DossierInAcceptRegister
 *
 * @property int $id
 * @property int $dossier_id
 * @property int $accept_register_id
 * @property int|null $accept_register_part_id
 * @property int $order_in_accept_register
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister query()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereAcceptRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereAcceptRegisterPartId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereOrderInAcceptRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInAcceptRegister whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DossierInAcceptRegister extends \Eloquent {}
}

namespace App\Models\Act{
/**
 * App\Models\Act\AcceptAct
 *
 * @property int $id
 * @property string $num
 * @property string|null $pdf_path
 * @property int $register_id
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property string|null $form_date
 * @property string $create_date
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|EdInAcceptAct[] $edInAct
 * @property-read int|null $ed_in_act_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Register|null $register
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read Tk|null $tk
 * @method static Builder|AcceptAct autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|AcceptAct newModelQuery()
 * @method static Builder|AcceptAct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|AcceptAct query()
 * @method static Builder|AcceptAct whereCreateDate($value)
 * @method static Builder|AcceptAct whereCreatedAt($value)
 * @method static Builder|AcceptAct whereFormDate($value)
 * @method static Builder|AcceptAct whereId($value)
 * @method static Builder|AcceptAct whereNum($value)
 * @method static Builder|AcceptAct wherePdfPath($value)
 * @method static Builder|AcceptAct whereRegisterId($value)
 * @method static Builder|AcceptAct whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AcceptAct extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Agreement
 *
 * @property int $id
 * @property int $order
 * @property string $create_date
 * @property string|null $end_date
 * @property int $type_id
 * @property int $status_id
 * @property int $register_id
 * @property string|null $epk_comment
 * @property bool $is_actual
 * @property string|null $path_xml_register
 * @property string|null $path_xml_results
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $approval_period_till
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\FileComment[] $fileComments
 * @property-read int|null $file_comments_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\FileComment[] $fileCommentsEpc
 * @property-read int|null $file_comments_epc_count
 * @property-read mixed $uri_path_xml_register
 * @property-read mixed $uri_path_xml_results
 * @property-read Tk|null $lastAk
 * @property-read Tk|null $lastTk
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\ParticipantInAgreement[] $parameterValue
 * @property-read int|null $parameter_value_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\ParticipantInAgreement[] $participantInAgreement
 * @property-read int|null $participant_in_agreement_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Participant[] $participants
 * @property-read int|null $participants_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Register|null $register
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\AgreementStatus|null $status
 * @property-read Tk|null $tkIn
 * @property-read Tk|null $tkOut
 * @property-read \Illuminate\Database\Eloquent\Collection|Tk[] $tks
 * @property-read int|null $tks_count
 * @property-read \App\Models\AgreementType|null $type
 * @method static Builder|Agreement newModelQuery()
 * @method static Builder|Agreement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Agreement query()
 * @method static Builder|Agreement whereApprovalPeriodTill($value)
 * @method static Builder|Agreement whereCreateDate($value)
 * @method static Builder|Agreement whereCreatedAt($value)
 * @method static Builder|Agreement whereEndDate($value)
 * @method static Builder|Agreement whereEpkComment($value)
 * @method static Builder|Agreement whereId($value)
 * @method static Builder|Agreement whereIsActual($value)
 * @method static Builder|Agreement whereOrder($value)
 * @method static Builder|Agreement wherePathXmlRegister($value)
 * @method static Builder|Agreement wherePathXmlResults($value)
 * @method static Builder|Agreement whereRegisterId($value)
 * @method static Builder|Agreement whereStatusId($value)
 * @method static Builder|Agreement whereTypeId($value)
 * @method static Builder|Agreement whereUpdatedAt($value)
 * @method static Builder|Agreement withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Agreement extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\AgreementStatus
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementStatus withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AgreementStatus extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\AgreementType
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType query()
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|AgreementType withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AgreementType extends \Eloquent {}
}

namespace App\Models\Antivirus{
/**
 * App\Models\Antivirus\Antivirus
 *
 * @property int $id
 * @property string $originalName
 * @property string $hash
 * @property int $size
 * @property string $path
 * @property string $absolutePath
 * @property int $user_id
 * @property string $checkResultStatus
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $host
 * @property string|null $ip
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus query()
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereAbsolutePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereCheckResultStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereHash($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereHost($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereIp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereOriginalName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereSize($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Antivirus whereUserId($value)
 * @mixin \Eloquent
 */
	class Antivirus extends \Eloquent implements \OwenIt\Auditing\Contracts\Auditable {}
}

namespace App\Models\Antivirus{
/**
 * App\Models\Antivirus\AntivirusStatuses
 *
 * @property int $id
 * @property string $name
 * @property string $short_name
 * @property string $code
 * @property string $service_code
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses query()
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses whereServiceCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AntivirusStatuses whereShortName($value)
 * @mixin \Eloquent
 */
	class AntivirusStatuses extends \Eloquent {}
}

namespace App\Models\Attribute{
/**
 * App\Models\Attribute\Attribute
 *
 * @property int $id
 * @property int|null $parent_id
 * @property string $name
 * @property string|null $code
 * @property string|null $description
 * @property string|null $type
 * @property int|null $etalon_attr_id
 * @property bool|null $is_etalon
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read Attribute|null $etalon
 * @property-read mixed|string $parent_path
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|Attribute newModelQuery()
 * @method static Builder|Attribute newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Attribute query()
 * @method static Builder|Attribute whereCode($value)
 * @method static Builder|Attribute whereCreatedAt($value)
 * @method static Builder|Attribute whereDescription($value)
 * @method static Builder|Attribute whereEtalonAttrId($value)
 * @method static Builder|Attribute whereId($value)
 * @method static Builder|Attribute whereIsEtalon($value)
 * @method static Builder|Attribute whereName($value)
 * @method static Builder|Attribute whereParentId($value)
 * @method static Builder|Attribute whereType($value)
 * @method static Builder|Attribute whereUpdatedAt($value)
 * @method static Builder|Attribute withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Attribute extends \Eloquent {}
}

namespace App\Models\Attribute{
/**
 * App\Models\Attribute\AttributeValue
 *
 * @property int $id
 * @property bool|int|string $value
 * @property int $attribute_type_id
 * @property int $ed_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Attribute\Attribute $attribute
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue query()
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereAttributeTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AttributeValue whereValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AttributeValue extends \Eloquent {}
}

namespace App\Models\Audit{
/**
 * App\Models\Audit\Audit
 *
 * @property int $id
 * @property string|null $user_type
 * @property string|null $user_id
 * @property string $event
 * @property string|null $message
 * @property string|null $auditable_type
 * @property string|null $auditable_id
 * @property array|null $old_values
 * @property array|null $new_values
 * @property string|null $url
 * @property string|null $ip_address
 * @property string|null $user_agent
 * @property string|null $tags
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $event_type_id
 * @property bool $is_success
 * @property mixed|null $markers
 * @property string|null $template
 * @property string|null $namespace_code
 * @property-read \Illuminate\Database\Eloquent\Model|\Eloquent $auditable
 * @property-read \App\Models\Audit\EventType|null $eventType
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|Audit autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Audit newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Audit query()
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereAuditableId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereAuditableType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereEvent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereEventTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereIpAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereIsSuccess($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereMarkers($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereNamespaceCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereNewValues($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereOldValues($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereTags($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereTemplate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereUrl($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereUserAgent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Audit whereUserType($value)
 * @mixin \Eloquent
 */
	class Audit extends \Eloquent {}
}

namespace App\Models\Audit{
/**
 * App\Models\Audit\AuditNamespace
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property string $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace query()
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AuditNamespace whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class AuditNamespace extends \Eloquent {}
}

namespace App\Models\Audit{
/**
 * App\Models\Audit\EventType
 *
 * @property int $id
 * @property string $code
 * @property string $name
 * @property string $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EventType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType query()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EventType extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\BaseModel
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel query()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class BaseModel extends \Eloquent implements \OwenIt\Auditing\Contracts\Auditable {}
}

namespace App\Models{
/**
 * App\Models\DecisionType
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType query()
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|DecisionType withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DecisionType extends \Eloquent {}
}

namespace App\Models\DeleteAct\Agreement{
/**
 * App\Models\DeleteAct\Agreement\DeleteActAgreement
 *
 * @property int $id
 * @property int $order Номер согласования
 * @property string $create_date Дата создания согласования
 * @property string|null $end_date Дата окончания согласования
 * @property int $status_id Статус согласования
 * @property int $type_id Тип согласования
 * @property int $delete_act_id Идентификатор акта
 * @property bool $is_actual Актуальность
 * @property string $path_xml_act Путь к xml акта
 * @property int|null $decision_type_id Идентификатор решения
 * @property int $user_id Идентификатор согласующего
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\DeleteAct\Agreement\DeleteActAgreementType|null $agreementType
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Signer[] $signers
 * @property-read int|null $signers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\DeleteAct\Agreement\DeleteActAgreementStatus|null $status
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereDecisionTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereDeleteActId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereIsActual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement wherePathXmlAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read DeleteActDecisionType|null $decisionType
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActParticipantInAgreement[] $deleteActParticipantInAgreement
 * @property-read int|null $delete_act_participant_in_agreement_count
 * @property int|null $job_id Идентификатор задачи на генерацию и подписание xml сдаточной описи
 * @property string $guid_arch
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreement whereJobId($value)
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\DeleteAct\Agreement\DeleteActAgreementFileComment[] $fileComment
 * @property-read int|null $file_comment_count
 * @property-read mixed $temp_uri
 * @property-read JobStatuses|null $jobs
 * @property-read \App\Models\DeleteAct\DeleteAct $deleteAct
 */
	class DeleteActAgreement extends \Eloquent {}
}

namespace App\Models\DeleteAct\Agreement{
/**
 * App\Models\DeleteAct\Agreement\DeleteActAgreementFileComment
 *
 * @property int $id
 * @property string $path Путь к файлу
 * @property int $participant_in_agreement_id Идентификатор участника согласования
 * @property string $date Дата
 * @property int $delete_act_agreement_id Идентификатор согласования акта об уничтожении
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereDeleteActAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereParticipantInAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property string $guid_arch
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementFileComment whereGuidArch($value)
 * @property-read mixed $uri
 */
	class DeleteActAgreementFileComment extends \Eloquent {}
}

namespace App\Models\DeleteAct\Agreement{
/**
 * App\Models\DeleteAct\Agreement\DeleteActAgreementStatus
 *
 * @property int $id
 * @property string $name наименование статуса согласования
 * @property string $code код статуса согласования
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementStatus whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read mixed $value
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 */
	class DeleteActAgreementStatus extends \Eloquent {}
}

namespace App\Models\DeleteAct\Agreement{
/**
 * App\Models\DeleteAct\Agreement\DeleteActAgreementType
 *
 * @property int $id
 * @property string $name наименование типа согласования
 * @property string $code код типа согласования
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActAgreementType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DeleteActAgreementType extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteAct
 *
 * @property int $id
 * @property string $num Номер
 * @property int|null $year Год
 * @property int $delete_act_status_id Статус
 * @property string $create_date Дата создания
 * @property string $path_xml_act Путь к xml акта
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\DeleteAct\DeleteActStatus $deleteActStatus
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereDeleteActStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct wherePathXmlAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Ed\Ed[] $eds
 * @property-read int|null $eds_count
 */
	class DeleteAct extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteAct
 *
 * @property int $id
 * @property string $num Номер
 * @property int|null $year Год
 * @property int $delete_act_status_id Статус
 * @property string $create_date Дата создания
 * @property string $path_xml_act Путь к xml акта
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\DeleteAct\DeleteActStatus $deleteActStatus
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereDeleteActStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct wherePathXmlAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Ed\Ed[] $eds
 * @property-read int|null $eds_count
 */
	class DeleteActApproved extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteActDecisionType
 *
 * @property int $id
 * @property string $name наименование типа решения
 * @property string $code код типа решения
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property string $xml_code
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActDecisionType whereXmlCode($value)
 */
	class DeleteActDecisionType extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteActFileEpSigner
 *
 * @property int $id
 * @property string $name Наименование файла
 * @property string $path Путь к файлу
 * @property int $delete_act_id Идентификатор акта об уничтожении
 * @property string $sign_date Дата подписания
 * @property int $user_id Идентификатор пользователя
 * @property int $system_role_id Роль пользователя
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereDeleteActId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereSignDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereSystemRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property int|null $participant_id
 * @property-read Signer|null $signer
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActFileEpSigner whereParticipantId($value)
 */
	class DeleteActFileEpSigner extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteActParticipantInAgreement
 *
 * @property int $id
 * @property int $participant_id Идентификатор согласующего
 * @property string $comment Комментарий
 * @property string|null $date Дата и время
 * @property int $delete_act_agreement_id Идентификатор согласования акта об уничтожении
 * @property int $delete_act_id Идентификатор акта об уничтожении
 * @property int|null $decision_type_id Идентификатор решения
 * @property bool $is_approving Является утверждающим
 * @property string $path_ep Путь к файлу подписи
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read Participant|null $participant
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereComment($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereDecisionTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereDeleteActAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereDeleteActId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereIsApproving($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereParticipantId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement wherePathEp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActParticipantInAgreement whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActAgreementFileComment[] $commentFiles
 * @property-read int|null $comment_files_count
 * @property-read \App\Models\DeleteAct\DeleteActDecisionType|null $decisionType
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActAgreementFileComment[] $fileComment
 * @property-read int|null $file_comment_count
 * @property-read Signer|null $signer
 */
	class DeleteActParticipantInAgreement extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteAct
 *
 * @property int $id
 * @property string $num Номер
 * @property int|null $year Год
 * @property int $delete_act_status_id Статус
 * @property string $create_date Дата создания
 * @property string $path_xml_act Путь к xml акта
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\DeleteAct\DeleteActStatus $deleteActStatus
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereDeleteActStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct wherePathXmlAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteAct whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|DeleteActAgreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Ed\Ed[] $eds
 * @property-read int|null $eds_count
 */
	class DeleteActProject extends \Eloquent {}
}

namespace App\Models\DeleteAct{
/**
 * App\Models\DeleteAct\DeleteActStatus
 *
 * @property int $id
 * @property string $name наименование статуса акта об уничтожении
 * @property string $code код статуса акта об уничтожении
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DeleteActStatus whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read mixed $value
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 */
	class DeleteActStatus extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiClassifier
 *
 * @property int $id
 * @property string $name
 * @property string $short_name
 * @property string $description
 * @property bool $is_ched (ЦХЭД – true, ОИК - false)Используется для обозначения организации, владеющей справочником. Если владелец ЦХЭД, можем только просматривать. Если владелец ОИК, то просмотр+редактирование
 * @property int $version Используется для версионирования справочника, где владелец = ЦХЭД, т.к. при получении обновленного справочника мы создаем полностью новый справочник, а старый помечается как неактивный
 * @property bool $is_main (Основной – true, Дополнительный - false) Используется для обозначения справочника, который используется пользователями в системе при назначении видов делам
 * @property bool $is_active Используется для обозначения актуальности справочника
 * @property int|null $job_id
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiKindGroup[] $diKindGroups
 * @property-read int|null $di_kind_groups_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|\App\Models\Di\DiKindGroupLTree[] $diKindGroupsTree
 * @property-read int|null $di_kind_groups_tree_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereIsChed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereIsMain($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereJobId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereShortName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiClassifier whereVersion($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DiClassifier extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiKind
 *
 * @property int $id
 * @property string $name
 * @property string $num Номер статьи по перечню
 * @property string|null $num_show (DI_CLASSIFIER.SHORT_NAME + «ст.» + DI_KIND.NUM) Используется для выпадающего списка при назначении видов ДИ в делах
 * @property string $code Необходим для возможности маппинга между справочниками ЦХЭДа и ОИКа
 * @property string $description
 * @property int $group_id
 * @property bool $is_active Используется для обозначения актуальности вида ДИ или для логического удаления
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Di\DiKindGroupLTree $diKindGroup
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiKindInDossier[] $diKindInDossier
 * @property-read int|null $di_kind_in_dossier_count
 * @property-read \App\Models\Di\DiSavePeriod|null $diSavePeriod
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossier
 * @property-read int|null $dossier_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Database\Factories\DiKindFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereGroupId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereNumShow($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKind whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DiKind extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiKindGroup
 *
 * @property int $id
 * @property string $name
 * @property string $code Необходим для возможности маппинга между справочниками ЦХЭДа и ОИКа
 * @property bool $is_active Используется для обозначения актуальности группы или для логического удаления
 * @property int|null $parent_id Идентификатор родительской группы
 * @property mixed|null $path
 * @property int $di_classifier_id Идентификатор классификатора
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DiKindGroup[] $children
 * @property-read int|null $children_count
 * @property-read \App\Models\Di\DiClassifier $diClassifier
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiKind[] $diKinds
 * @property-read int|null $di_kinds_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiSavePeriod[] $diSavePeriod
 * @property-read int|null $di_save_period_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereDiClassifierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroup whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DiKindGroup extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiKindGroupLTree
 *
 * @property int $id
 * @property string $name
 * @property string $code Необходим для возможности маппинга между справочниками ЦХЭДа и ОИКа
 * @property bool $is_active Используется для обозначения актуальности группы или для логического удаления
 * @property int|null $parent_id Идентификатор родительской группы
 * @property mixed|null $path
 * @property int $di_classifier_id Идентификатор классификатора
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiKind[] $diKinds
 * @property-read int|null $di_kinds_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiSavePeriod[] $diSavePeriod
 * @property-read int|null $di_save_period_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|DiKindGroupLTree[] $ltreeChildren
 * @property-read int|null $ltree_children_count
 * @property-read DiKindGroupLTree|null $ltreeParent
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] all($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree ancestorByLevel(int $level = 1, ?string $path = null)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree ancestorsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree descendantsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] get($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree parentsOf(array $paths)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree root()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereDiClassifierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindGroupLTree withoutSelf(int $id)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Di\DiKindGroup[] $children
 * @property-read int|null $children_count
 * @property-read \App\Models\Di\DiClassifier $diClassifier
 */
	class DiKindGroupLTree extends \Eloquent implements \Umbrellio\LTree\Interfaces\LTreeModelInterface, \Umbrellio\LTree\Interfaces\LTreeInterface, \Umbrellio\LTree\Interfaces\ModelInterface, \Umbrellio\LTree\Interfaces\HasLTreeScopes, \Umbrellio\LTree\Interfaces\HasLTreeRelations {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiKindInDossier
 *
 * @property int $id
 * @property int $di_kind_id
 * @property int $dossier_id
 * @property bool $is_block
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereDiKindId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereIsBlock($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiKindInDossier whereUpdatedAt($value)
 * @mixin \Eloquent
 */
	class DiKindInDossier extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\DiSavePeriod
 *
 * @property int $id
 * @property int $di_kind_id Идентификатор типа хранения
 * @property int|null $temp_save_type_id (Обязательно, если save_type_id = временно) Идентификатор временного типа хранения
 * @property int $save_type_id
 * @property int|null $temp_save_period Обязательно, если temp_save_type_id = 10 и более лет ИЛИ от 6 до 10 лет ИЛИ 5 и менее лет
 * @property bool $is_need_epk Требует ЭПК
 * @property bool $is_need_ek Требует ЭК
 * @property string|null $save_info Используется для: 1 – упрощенного вывода на фронт строки со всеми условиями хранения (т.к. в интерфейсе информация должна выводиться по правилу),
 *             2 – для сравнения условий срока хранения одной статьи с другой, т.к. одному делу можно назначить несколько статей НО при условии, что у них одинаковые сроки хранения
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read SaveType|null $save_type
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Di\TempSaveType|null $temp_save_type
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereDiKindId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereIsNeedEk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereIsNeedEpk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereSaveInfo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereTempSavePeriod($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereTempSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiSavePeriod whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DiSavePeriod extends \Eloquent {}
}

namespace App\Models\Di{
/**
 * App\Models\Di\TempSaveType
 *
 * @property int $id
 * @property string $name (10 и более лет, от 6 до 10 лет, 5 и менее лет, ДМН, ДЛО, ДЗН. Выводить как расшифровку к типу хранения «временно»)
 * @property int $min_year
 * @property int $max_year
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType query()
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereMaxYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereMinYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TempSaveType whereUpdatedAt($value)
 * @mixin \Eloquent
 */
	class TempSaveType extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\DocumentType
 *
 * @property int $id
 * @property string $type
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType query()
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DocumentType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DocumentType extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\Dossier
 *
 * @property int $id
 * @property string $name
 * @property string $index
 * @property int|null $source_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $dossier_status_id
 * @property int|null $size
 * @property string|null $search_vector
 * @property bool $transit
 * @property int $media_type_id
 * @property string|null $min_date
 * @property string|null $max_date
 * @property int|null $first_register_id
 * @property int|null $temp_save_period
 * @property int|null $save_type_id
 * @property bool $eds_has_act
 * @property string|null $change_reason
 * @property int|null $temp_save_type_id
 * @property int|null $subdivision_id
 * @property string $guid_arch
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection|AcceptRegister[] $acceptRegister
 * @property-read int|null $accept_register_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|AcceptRegisterPart[] $acceptRegisterPart
 * @property-read int|null $accept_register_part_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Dossier\DossierCipher|null $cipher
 * @property-read \App\Models\Dossier\DossierCipher|null $cipherIsActive
 * @property-read \Illuminate\Database\Eloquent\Collection|DiKind[] $diKind
 * @property-read int|null $di_kind_count
 * @property-read \App\Models\Dossier\DossierCipher|null $dossierChipher
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $dossierInNom
 * @property-read int|null $dossier_in_nom_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|NomPartLTree[] $dossierInNomLTree
 * @property-read int|null $dossier_in_nom_l_tree_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegister
 * @property-read int|null $dossier_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Ed[] $eds
 * @property-read int|null $eds_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Ed[] $edsWihtoutRegisters
 * @property-read int|null $eds_wihtout_registers_count
 * @property-read Register|null $firstRegister
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $lastDossierInNom
 * @property-read int|null $last_dossier_in_nom_count
 * @property-read MediaTypeDossier $mediaType
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $nomenclature
 * @property-read int|null $nomenclature_count
 * @property-read PaperInfo|null $paperInfo
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Register[] $register
 * @property-read int|null $register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $removedDossierInNom
 * @property-read int|null $removed_dossier_in_nom_count
 * @property-read SaveType|null $saveType
 * @property-read Source|null $source
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Dossier\DossierStatus|null $status
 * @property-read Subdivisions|null $subdivision
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier newQuery()
 * @method static \Illuminate\Database\Query\Builder|Dossier onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier query()
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereChangeReason($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereDossierStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereEdsHasAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereFirstRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereIndex($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereMaxDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereMediaTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereMinDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereSearchVector($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereSize($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereSourceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereTempSavePeriod($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereTempSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereTransit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Dossier whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Query\Builder|Dossier withTrashed()
 * @method static \Illuminate\Database\Query\Builder|Dossier withoutTrashed()
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInAcceptRegister[] $dossierInAcceptRegister
 * @property-read int|null $dossier_in_accept_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|File[] $files
 * @property-read int|null $files_count
 */
	class Dossier extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\DossierCipher
 *
 * @property int $id
 * @property string $value
 * @property bool $is_active
 * @property int $dossier_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher query()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierCipher whereValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DossierCipher extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\DossierInNom
 *
 * @property int $id
 * @property int $nom_part_id
 * @property int $dossier_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Dossier\Dossier|null $dossier
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $nomParts
 * @property-read int|null $nom_parts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom query()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom whereNomPartId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInNom whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DossierInNom extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\DossierInRegister
 *
 * @property int $id
 * @property string $dossier_add_date
 * @property int|null $dossier_id
 * @property int|null $register_id
 * @property int|null $register_part_id
 * @property int|null $user_id
 * @property int $order_in_register
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read Ed|null $allEd
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Dossier\Dossier|null $dossier
 * @property-read Ed $ed
 * @property-read string|null $ed_add_date
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Register|null $register
 * @property-read \App\Models\Register\RegisterPart|null $registerPart
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\User\User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister query()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereDossierAddDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereOrderInRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereRegisterPartId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierInRegister whereUserId($value)
 * @method static Builder|EdInRegister withFilters(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withPaginate(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DossierInRegister extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\DossierStatus
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DossierStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class DossierStatus extends \Eloquent {}
}

namespace App\Models\Dossier{
/**
 * App\Models\Dossier\RemovedDossierInNom
 *
 * @property int $id
 * @property int $dossier_id
 * @property int $nom_id
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom query()
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RemovedDossierInNom whereNomId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RemovedDossierInNom extends \Eloquent {}
}

namespace App\Models\Ed{
/**
 * App\Models\Ed\Ed
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property string $reg_date
 * @property int|null $ed_type_id
 * @property int $source_id
 * @property string|null $source_ed_id
 * @property int|null $dossier_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $create_date
 * @property string|null $update_date
 * @property int $ed_status_id
 * @property bool $resend_ak
 * @property string|null $search_vector
 * @property int|null $full_size
 * @property bool $is_dsp
 * @property int $media_type_id
 * @property int $order_ed_in_dossier
 * @property int|null $save_type_id
 * @property bool $has_act
 * @property string|null $change_reason
 * @property int|null $temp_save_type_id
 * @property int|null $temp_save_period
 * @property string $guid_arch
 * @property int|null $subdivision_id
 * @property int|null $delete_act_id Идентификатор акта об уничтожении
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection|AttributeValue[] $attributeValue
 * @property-read int|null $attribute_value_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Ed\EdCipher|null $cipherIsActive
 * @property-read Dossier|null $dossier
 * @property-read \App\Models\Ed\EdCipher|null $edChipher
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $edInRegister
 * @property-read int|null $ed_in_register_count
 * @property-read \App\Models\Ed\EdStatus $edStatus
 * @property-read \Illuminate\Database\Eloquent\Collection|File[] $file
 * @property-read int|null $file_count
 * @property-read string $order
 * @property-read mixed $path_dir
 * @property-read mixed $registers
 * @property-read Tk|null $lastAk
 * @property-read DossierInRegister|null $lastEdInRegister
 * @property-read Tk|null $lastTk
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read SaveType|null $saveType
 * @property-read Source $source
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read Subdivisions|null $subdivision
 * @property-read TempSaveType|null $tempSaveTypeId
 * @property-read \Illuminate\Database\Eloquent\Collection|Tk[] $tk
 * @property-read int|null $tk_count
 * @method static \Illuminate\Database\Eloquent\Builder|Ed autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Database\Factories\EdSlimFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Ed newQuery()
 * @method static \Illuminate\Database\Query\Builder|Ed onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Ed query()
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereChangeReason($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereDeleteActId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereEdStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereEdTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereFullSize($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereHasAct($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereIsDsp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereMediaTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereOrderEdInDossier($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereRegDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereResendAk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereSearchVector($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereSourceEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereSourceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereTempSavePeriod($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereTempSaveTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereUpdateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|Ed withTimestamps()
 * @method static \Illuminate\Database\Eloquent\Builder|Ed withTkLimit()
 * @method static \Illuminate\Database\Query\Builder|Ed withTrashed()
 * @method static \Illuminate\Database\Query\Builder|Ed withoutTrashed()
 * @mixin \Eloquent
 * @property-read \App\Models\DeleteAct\DeleteAct|null $deleteAct
 */
	class Ed extends \Eloquent {}
}

namespace App\Models\Ed{
/**
 * App\Models\Ed\EdCipher
 *
 * @property int $id
 * @property string $value
 * @property bool $is_active
 * @property int $ed_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher query()
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdCipher whereValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EdCipher extends \Eloquent {}
}

namespace App\Models\Ed{
/**
 * App\Models\Ed\EdInAcceptAct
 *
 * @property int $id
 * @property int $act_accept_id
 * @property int $register_id
 * @property int $ed_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct query()
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereActAcceptId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdInAcceptAct whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EdInAcceptAct extends \Eloquent {}
}

namespace App\Models\Ed{
/**
 * App\Models\Ed\EdInRegister
 *
 * @property int $id
 * @property string|null $ed_add_date
 * @property int|null $ed_id
 * @property int|null $register_id
 * @property int|null $register_part_id
 * @property int|null $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Ed\Ed|null $allEd
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Ed\Ed|null $ed
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Register|null $register
 * @property-read RegisterPart|null $registerPart
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read User|null $user
 * @method static Builder|EdInRegister newModelQuery()
 * @method static Builder|EdInRegister newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|EdInRegister query()
 * @method static Builder|EdInRegister whereCreatedAt($value)
 * @method static Builder|EdInRegister whereEdAddDate($value)
 * @method static Builder|EdInRegister whereEdId($value)
 * @method static Builder|EdInRegister whereId($value)
 * @method static Builder|EdInRegister whereRegisterId($value)
 * @method static Builder|EdInRegister whereRegisterPartId($value)
 * @method static Builder|EdInRegister whereUpdatedAt($value)
 * @method static Builder|EdInRegister whereUserId($value)
 * @method static Builder|EdInRegister withFilters(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withPaginate(\Illuminate\Http\Request $request)
 * @method static Builder|EdInRegister withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EdInRegister extends \Eloquent {}
}

namespace App\Models\Ed{
/**
 * App\Models\Ed\EdStatus
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EdStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EdStatus extends \Eloquent {}
}

namespace App\Models\Event{
/**
 * App\Models\Event\EventStream
 *
 * @property int $id
 * @property int $user_id
 * @property string $message
 * @property string $event
 * @property string $type
 * @property string $delivered
 * @property string|null $client
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $description
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|EventStream newModelQuery()
 * @method static Builder|EventStream newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|EventStream query()
 * @method static Builder|EventStream whereClient($value)
 * @method static Builder|EventStream whereCreatedAt($value)
 * @method static Builder|EventStream whereDelivered($value)
 * @method static Builder|EventStream whereEvent($value)
 * @method static Builder|EventStream whereId($value)
 * @method static Builder|EventStream whereMessage($value)
 * @method static Builder|EventStream whereType($value)
 * @method static Builder|EventStream whereUpdatedAt($value)
 * @method static Builder|EventStream whereUserId($value)
 * @method static Builder|EventStream withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EventStream extends \Eloquent {}
}

namespace App\Models\Event{
/**
 * App\Models\Event\EventType
 *
 * @property int $id
 * @property string $code
 * @property string $name
 * @property string $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|EventType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType query()
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EventType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class EventType extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\FileComment
 *
 * @property int $id
 * @property string $path
 * @property int $agreement_id
 * @property int|null $participant_in_agreement_id
 * @property string $date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment query()
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereParticipantInAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileComment whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class FileComment extends \Eloquent {}
}

namespace App\Models\File{
/**
 * App\Models\File\File
 *
 * @property int $id
 * @property string $name
 * @property int $fe_id
 * @property float|null $size
 * @property int $role_id
 * @property int $ed_id
 * @property string $path
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $message_error
 * @property string|null $viewer_path
 * @property bool $is_original
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read Ed $ed
 * @property-read \App\Models\File\FileExtension $extension
 * @property-read mixed $uri
 * @property-read mixed $viewer_uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|File[] $rel
 * @property-read int|null $rel_count
 * @property-read \Illuminate\Database\Eloquent\Collection|File[] $reversalRel
 * @property-read int|null $reversal_rel_count
 * @property-read \App\Models\File\FileRole $role
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Database\Factories\File2Factory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|File newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|File newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|File query()
 * @method static \Illuminate\Database\Eloquent\Builder|File whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereFeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereIsOriginal($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereMessageError($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereSize($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|File whereViewerPath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class File extends \Eloquent {}
}

namespace App\Models\File{
/**
 * App\Models\File\FileContent
 *
 * @property int $id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $file_id Идентификатор файла
 * @property int|null $ed_id Идентификатор электронного документа
 * @property mixed|null $meta_info Мета информация о файле
 * @property string|null $content Контент файла
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent query()
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereEdId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereFileId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereMetaInfo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileContent whereUpdatedAt($value)
 * @mixin \Eloquent
 */
	class FileContent extends \Eloquent {}
}

namespace App\Models\File{
/**
 * App\Models\File\FileExtension
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|FileExtension newModelQuery()
 * @method static Builder|FileExtension newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|FileExtension query()
 * @method static Builder|FileExtension whereCode($value)
 * @method static Builder|FileExtension whereCreatedAt($value)
 * @method static Builder|FileExtension whereId($value)
 * @method static Builder|FileExtension whereName($value)
 * @method static Builder|FileExtension whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static Builder|FileExtension withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class FileExtension extends \Eloquent {}
}

namespace App\Models\File{
/**
 * App\Models\File\FileFile
 *
 * @property int $id
 * @property int $f1_id
 * @property int $f2_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile query()
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile whereF1Id($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile whereF2Id($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileFile whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class FileFile extends \Eloquent {}
}

namespace App\Models\File{
/**
 * App\Models\File\FileRole
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property string $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole query()
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|FileRole whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class FileRole extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\Archive
 *
 * @property int $id
 * @property string $name
 * @property string $short_name
 * @property string|null $description
 * @property string|null $email
 * @property string|null $address
 * @property string|null $head
 * @property string|null $head_phone
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property bool|null $is_actual
 * @property string $actual_date
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\HandBooks\Fund[] $funds
 * @property-read int|null $funds_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|Archive autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Archive newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Archive query()
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereActualDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereHead($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereHeadPhone($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereIsActual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereShortName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Archive whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Archive extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\Fund
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property string|null $description
 * @property int $archive_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property bool|null $is_actual
 * @property string $actual_date
 * @property bool $is_default
 * @property string $guid_arch
 * @property-read \App\Models\HandBooks\Archive|null $archive
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|Fund autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|Fund newModelQuery()
 * @method static Builder|Fund newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Fund query()
 * @method static Builder|Fund whereActualDate($value)
 * @method static Builder|Fund whereArchiveId($value)
 * @method static Builder|Fund whereCode($value)
 * @method static Builder|Fund whereCreatedAt($value)
 * @method static Builder|Fund whereDescription($value)
 * @method static Builder|Fund whereGuidArch($value)
 * @method static Builder|Fund whereId($value)
 * @method static Builder|Fund whereIsActual($value)
 * @method static Builder|Fund whereIsDefault($value)
 * @method static Builder|Fund whereName($value)
 * @method static Builder|Fund whereNum($value)
 * @method static Builder|Fund whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static Builder|Fund withFilters(\Illuminate\Http\Request $request)
 * @method static Builder|Fund withLimitOffset(\Illuminate\Http\Request $request)
 * @method static Builder|Fund withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Fund withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Fund extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\LocationType
 *
 * @property int $id
 * @property string $name
 * @property string|null $code
 * @property int|null $parent_id
 * @property mixed|null $path
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|LocationType[] $locationTypes
 * @property-read int|null $location_types_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|LocationType[] $ltreeChildren
 * @property-read int|null $ltree_children_count
 * @property-read LocationType|null $ltreeParent
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] all($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType ancestorByLevel(int $level = 1, ?string $path = null)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType ancestorsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType descendantsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] get($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType parentsOf(array $paths)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType query()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType root()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType withoutSelf(int $id)
 * @mixin \Eloquent
 */
	class LocationType extends \Eloquent implements \Umbrellio\LTree\Interfaces\LTreeModelInterface, \Umbrellio\LTree\Interfaces\LTreeInterface, \Umbrellio\LTree\Interfaces\ModelInterface, \Umbrellio\LTree\Interfaces\HasLTreeScopes, \Umbrellio\LTree\Interfaces\HasLTreeRelations {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\MediaTypeDossier
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossier
 * @property-read int|null $dossier_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier query()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeDossier whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class MediaTypeDossier extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\MediaTypeED
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED query()
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|MediaTypeED whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class MediaTypeED extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\SaveType
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType query()
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SaveType whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SaveType extends \Eloquent {}
}

namespace App\Models\HandBooks{
/**
 * App\Models\HandBooks\Source
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property string $actual_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property bool|null $is_actual
 * @property string|null $guid
 * @property bool $is_send_ack
 * @property string $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|Source autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|Source newModelQuery()
 * @method static Builder|Source newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Source query()
 * @method static Builder|Source whereActualDate($value)
 * @method static Builder|Source whereCode($value)
 * @method static Builder|Source whereCodeXml($value)
 * @method static Builder|Source whereCreatedAt($value)
 * @method static Builder|Source whereDescription($value)
 * @method static Builder|Source whereGuid($value)
 * @method static Builder|Source whereId($value)
 * @method static Builder|Source whereIsActual($value)
 * @method static Builder|Source whereIsSendAck($value)
 * @method static Builder|Source whereName($value)
 * @method static Builder|Source whereUpdatedAt($value)
 * @method static Builder|Source withFilters(\Illuminate\Http\Request $request)
 * @method static Builder|Source withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Source withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Source extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\JobStatuses
 *
 * @property int $id
 * @property string|null $job_id
 * @property string $type
 * @property string|null $queue
 * @property int $attempts
 * @property int $progress_now
 * @property int $progress_max
 * @property string $status
 * @property string|null $input
 * @property string|null $output
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $started_at
 * @property string|null $finished_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses query()
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereAttempts($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereFinishedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereInput($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereJobId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereOutput($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereProgressMax($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereProgressNow($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereQueue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereStartedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|JobStatuses whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class JobStatuses extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Mchd
 *
 * @property int $id
 * @property string $num Номер доверенности
 * @property int $sert_id Идентификатор Сертификата
 * @property string $fio ФИО физического лица
 * @property string $start_date Дата выдачи доверенности
 * @property string $end_date Дата окончания доверенности
 * @property string $path Относительный путь до хранении файла
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Sert|null $sert
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd query()
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereFio($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereSertId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read mixed $uri
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $base64_file
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereBase64File($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Mchd whereUpdatedAt($value)
 */
	class Mchd extends \Eloquent {}
}

namespace App\Models\Message{
/**
 * App\Models\Message\Message
 *
 * @property int $id
 * @property string $message
 * @property string|null $date
 * @property int|null $mt_id
 * @property int|null $tk_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Message\MessageType|null $messageType
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|Message newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Message newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Message query()
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereMtId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereTkId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Message whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Message extends \Eloquent {}
}

namespace App\Models\Message{
/**
 * App\Models\Message\MessageType
 *
 * @property int $id
 * @property string $code
 * @property string|null $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $name
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|MessageType newModelQuery()
 * @method static Builder|MessageType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|MessageType query()
 * @method static Builder|MessageType whereCode($value)
 * @method static Builder|MessageType whereCodeXml($value)
 * @method static Builder|MessageType whereCreatedAt($value)
 * @method static Builder|MessageType whereDescription($value)
 * @method static Builder|MessageType whereId($value)
 * @method static Builder|MessageType whereName($value)
 * @method static Builder|MessageType whereUpdatedAt($value)
 * @method static Builder|MessageType withFilter(\Illuminate\Http\Request $request)
 * @method static Builder|MessageType withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|MessageType withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class MessageType extends \Eloquent {}
}

namespace App\Models\Nomenclature{
/**
 * App\Models\Nomenclature\NomPart
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int|null $parent_id
 * @property int $nom_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $subdivision_id
 * @property mixed|null $path
 * @property int $count_closed_dossier
 * @property int $count_dossier
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInNom[] $dossierInNom
 * @property-read int|null $dossier_in_nom_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossierInNomBelongsToMany
 * @property-read int|null $dossier_in_nom_belongs_to_many_count
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $nomPart
 * @property-read int|null $nom_part_count
 * @property-read \App\Models\Nomenclature\Nomenclature $nomenclature
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read Subdivisions|null $subdivision
 * @method static Builder|NomPart newModelQuery()
 * @method static Builder|NomPart newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|NomPart query()
 * @method static Builder|NomPart whereCountClosedDossier($value)
 * @method static Builder|NomPart whereCountDossier($value)
 * @method static Builder|NomPart whereCreatedAt($value)
 * @method static Builder|NomPart whereGuidArch($value)
 * @method static Builder|NomPart whereId($value)
 * @method static Builder|NomPart whereName($value)
 * @method static Builder|NomPart whereNomId($value)
 * @method static Builder|NomPart whereNum($value)
 * @method static Builder|NomPart whereParentId($value)
 * @method static Builder|NomPart wherePath($value)
 * @method static Builder|NomPart whereSubdivisionId($value)
 * @method static Builder|NomPart whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class NomPart extends \Eloquent {}
}

namespace App\Models\Nomenclature{
/**
 * App\Models\Nomenclature\NomPartLTree
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int|null $parent_id
 * @property int $nom_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $subdivision_id
 * @property mixed|null $path
 * @property int $count_closed_dossier
 * @property int $count_dossier
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInNom[] $dossierInNom
 * @property-read int|null $dossier_in_nom_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\Dossier[] $dossierInNomBelongsToMany
 * @property-read int|null $dossier_in_nom_belongs_to_many_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|NomPartLTree[] $ltreeChildren
 * @property-read int|null $ltree_children_count
 * @property-read NomPartLTree|null $ltreeParent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Nomenclature\NomPart[] $nomPart
 * @property-read int|null $nom_part_count
 * @property-read \App\Models\Nomenclature\Nomenclature $nomenclature
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Subdivisions\Subdivisions|null $subdivision
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] all($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree ancestorByLevel(int $level = 1, ?string $path = null)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree ancestorsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree descendantsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] get($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree parentsOf(array $paths)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree query()
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree root()
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereCountClosedDossier($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereCountDossier($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereNomId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|NomPartLTree withoutSelf(int $id)
 * @mixin \Eloquent
 */
	class NomPartLTree extends \Eloquent implements \Umbrellio\LTree\Interfaces\LTreeModelInterface, \Umbrellio\LTree\Interfaces\LTreeInterface, \Umbrellio\LTree\Interfaces\ModelInterface, \Umbrellio\LTree\Interfaces\HasLTreeScopes, \Umbrellio\LTree\Interfaces\HasLTreeRelations {}
}

namespace App\Models\Nomenclature{
/**
 * App\Models\Nomenclature\NomStatus
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|NomStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class NomStatus extends \Eloquent {}
}

namespace App\Models\Nomenclature{
/**
 * App\Models\Nomenclature\Nomenclature
 *
 * @property int $id
 * @property string|null $num
 * @property int $year
 * @property int|null $source_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool $resend_tk
 * @property string|null $create_date
 * @property string $update_date
 * @property int|null $nom_status_id
 * @property string $change_reason
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read Tk|null $lastAk
 * @property-read Tk|null $lastTk
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Nomenclature\NomPart[] $nomParts
 * @property-read int|null $nom_parts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Nomenclature\NomStatus|null $status
 * @property-read \Illuminate\Database\Eloquent\Collection|Tk[] $tk
 * @property-read int|null $tk_count
 * @method static Builder|Nomenclature autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Database\Factories\NomenclatureFactory factory(...$parameters)
 * @method static Builder|Nomenclature newModelQuery()
 * @method static Builder|Nomenclature newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Nomenclature query()
 * @method static Builder|Nomenclature whereChangeReason($value)
 * @method static Builder|Nomenclature whereCreateDate($value)
 * @method static Builder|Nomenclature whereCreatedAt($value)
 * @method static Builder|Nomenclature whereGuidArch($value)
 * @method static Builder|Nomenclature whereId($value)
 * @method static Builder|Nomenclature whereNomStatusId($value)
 * @method static Builder|Nomenclature whereNum($value)
 * @method static Builder|Nomenclature whereResendTk($value)
 * @method static Builder|Nomenclature whereSourceId($value)
 * @method static Builder|Nomenclature whereUpdateDate($value)
 * @method static Builder|Nomenclature whereUpdatedAt($value)
 * @method static Builder|Nomenclature whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Nomenclature extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\NsiBaseModel
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|NsiBaseModel newModelQuery()
 * @method static Builder|NsiBaseModel newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|NsiBaseModel query()
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class NsiBaseModel extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\PaperInfo
 *
 * @property int $id
 * @property int $dossier_id
 * @property int|null $sheets_num
 * @property string $location
 * @property string|null $paper_register_num
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo query()
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereDossierId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereLocation($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo wherePaperRegisterNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereSheetsNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaperInfo whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class PaperInfo extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ParticipantInAgreement
 *
 * @property int $id
 * @property string|null $comment
 * @property string|null $date
 * @property int $agreement_id
 * @property int|null $decision_type_id
 * @property bool $is_approving
 * @property string|null $path_ep
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $participant_id
 * @property-read \App\Models\Agreement|null $agreement
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\DecisionType|null $decision
 * @property-read \App\Models\FileComment|null $fileComment
 * @property-read Participant|null $participant
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement query()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereComment($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereDecisionTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereIsApproving($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereParticipantId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement wherePathEp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantInAgreement whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class ParticipantInAgreement extends \Eloquent {}
}

namespace App\Models\Participant{
/**
 * App\Models\Participant\Participant
 *
 * @property int $id
 * @property string $position
 * @property int $signer_role_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $user_id
 * @property bool|null $is_actual
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFile
 * @property-read int|null $register_file_count
 * @property-read \App\Models\Signer\SignerRole|null $role
 * @property-read \App\Models\Signer\SignerRole $roleDetail
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read User|null $user
 * @method static Builder|Signer autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Participant newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Participant query()
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereIsActual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant wherePosition($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereSignerRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Participant whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Participant extends \Eloquent {}
}

namespace App\Models\Participant{
/**
 * App\Models\Participant\ParticipantRole
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole query()
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ParticipantRole whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class ParticipantRole extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\PermissionCategory
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|ActionPermission[] $items
 * @property-read int|null $items_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PermissionCategory whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class PermissionCategory extends \Eloquent {}
}

namespace App\Models\Permission{
/**
 * App\Models\Permission\ActionPermission
 *
 * @property int $id
 * @property string $name
 * @property string $tech_name
 * @property string|null $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $category_id
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read PermissionCategory|null $category
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Permission\Permission[] $permission
 * @property-read int|null $permission_count
 * @property-read \App\Models\Permission\RoutePermission|null $route
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission query()
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereTechName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ActionPermission whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class ActionPermission extends \Eloquent {}
}

namespace App\Models\Permission{
/**
 * App\Models\Permission\PatternPermission
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string $code
 * @property string $matchers
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $default_value
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission query()
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereDefaultValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereMatchers($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PatternPermission whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class PatternPermission extends \Eloquent {}
}

namespace App\Models\Permission{
/**
 * App\Models\Permission\Permission
 *
 * @property int $id
 * @property string|null $ptype
 * @property string|null $v0
 * @property string|null $v1
 * @property string|null $v2
 * @property string|null $v3
 * @property string|null $v4
 * @property string|null $v5
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Permission\ActionPermission|null $action
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \App\Models\Permission\RoutePermission|null $route
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|Permission newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Permission newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Permission query()
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission wherePtype($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV0($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV1($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV2($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV3($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV4($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Permission whereV5($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Permission extends \Eloquent {}
}

namespace App\Models\Permission{
/**
 * App\Models\Permission\RoutePermission
 *
 * @property int $id
 * @property string $name
 * @property string $route
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission query()
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission whereRoute($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RoutePermission whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RoutePermission extends \Eloquent {}
}

namespace App\Models\Project{
/**
 * App\Models\Project\RegisterProject
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int|null $year
 * @property string|null $create_date
 * @property int $register_type_id
 * @property int $archive_id
 * @property int $fund_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool|null $resend_tk
 * @property bool|null $resend_ak
 * @property int|null $register_status_id
 * @property string|null $update_date
 * @property string|null $search_vector
 * @property int|null $user_id
 * @property string|null $path_xml_register
 * @property string|null $guid_path
 * @property string $guid_arch
 * @property-read Agreement|null $agreement
 * @property-read \Illuminate\Database\Eloquent\Collection|Agreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Archive[] $archive
 * @property-read int|null $archive_count
 * @property-read Archive $archiveDetail
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegister
 * @property-read int|null $dossier_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterDesc
 * @property-read int|null $dossier_in_register_desc_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $edInRegister
 * @property-read int|null $ed_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $edInRegisterWithSort
 * @property-read int|null $ed_in_register_with_sort_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Ed\Ed[] $eds
 * @property-read int|null $eds_count
 * @property-read Agreement|null $epkAgreement
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\HandBooks\Fund[] $fund
 * @property-read int|null $fund_count
 * @property-read \App\Models\HandBooks\Fund $fundDetail
 * @property-read mixed $uri_path_xml_register
 * @property-read string $xml_register_type
 * @property-read \App\Models\Tk\Tk|null $lastAk
 * @property-read Agreement|null $lastEkAgreement
 * @property-read Agreement|null $lastEpkAgreement
 * @property-read \App\Models\Tk\Tk|null $lastTk
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFile
 * @property-read int|null $register_file_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFilePath
 * @property-read int|null $register_file_path_count
 * @property-read \App\Models\Register\RegisterFile|null $registerFileWhereTypeOne
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFileWhereTypeTwo
 * @property-read int|null $register_file_where_type_two_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterPart[] $registerPart
 * @property-read int|null $register_part_count
 * @property-read \App\Models\Register\RegisterStatus|null $registerStatus
 * @property-read \App\Models\Register\RegisterType $registerType
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Signer\Signer[] $signers
 * @property-read int|null $signers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Tk\Tk[] $tk
 * @property-read int|null $tk_count
 * @property-read User|null $user
 * @method static Builder|Register autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject query()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereArchiveId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereFundId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereGuidPath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereRegisterStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereRegisterTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereResendAk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereResendTk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereSearchVector($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereUpdateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterProject whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Register withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RegisterProject extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Protocol
 *
 * @property int $id
 * @property string $path
 * @property int $agreement_id
 * @property string $date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol query()
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol whereAgreementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Protocol whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Protocol extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\Register
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int|null $year
 * @property string|null $create_date
 * @property int $register_type_id
 * @property int $archive_id
 * @property int $fund_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool|null $resend_tk
 * @property bool|null $resend_ak
 * @property int|null $register_status_id
 * @property string|null $update_date
 * @property string|null $search_vector
 * @property int|null $user_id
 * @property string|null $path_xml_register
 * @property string|null $guid_path
 * @property string $guid_arch
 * @property-read Agreement|null $agreement
 * @property-read \Illuminate\Database\Eloquent\Collection|Agreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Archive[] $archive
 * @property-read int|null $archive_count
 * @property-read Archive $archiveDetail
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $dossierInRegister
 * @property-read int|null $dossier_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $dossierInRegisterDesc
 * @property-read int|null $dossier_in_register_desc_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $dossierInRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $dossierInRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $edInRegister
 * @property-read int|null $ed_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $edInRegisterWithSort
 * @property-read int|null $ed_in_register_with_sort_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Ed[] $eds
 * @property-read int|null $eds_count
 * @property-read Agreement|null $epkAgreement
 * @property-read \Illuminate\Database\Eloquent\Collection|Fund[] $fund
 * @property-read int|null $fund_count
 * @property-read Fund $fundDetail
 * @property-read mixed $uri_path_xml_register
 * @property-read string $xml_register_type
 * @property-read Tk|null $lastAk
 * @property-read Agreement|null $lastEkAgreement
 * @property-read Agreement|null $lastEpkAgreement
 * @property-read Tk|null $lastTk
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFile
 * @property-read int|null $register_file_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFilePath
 * @property-read int|null $register_file_path_count
 * @property-read \App\Models\Register\RegisterFile|null $registerFileWhereTypeOne
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFileWhereTypeTwo
 * @property-read int|null $register_file_where_type_two_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterPart[] $registerPart
 * @property-read int|null $register_part_count
 * @property-read \App\Models\Register\RegisterStatus|null $registerStatus
 * @property-read \App\Models\Register\RegisterType $registerType
 * @property-read \Illuminate\Database\Eloquent\Collection|Signer[] $signers
 * @property-read int|null $signers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Tk[] $tk
 * @property-read int|null $tk_count
 * @property-read User|null $user
 * @method static Builder|Register autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|Register newModelQuery()
 * @method static Builder|Register newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Register query()
 * @method static Builder|Register whereArchiveId($value)
 * @method static Builder|Register whereCreateDate($value)
 * @method static Builder|Register whereCreatedAt($value)
 * @method static Builder|Register whereFundId($value)
 * @method static Builder|Register whereGuidArch($value)
 * @method static Builder|Register whereGuidPath($value)
 * @method static Builder|Register whereId($value)
 * @method static Builder|Register whereName($value)
 * @method static Builder|Register whereNum($value)
 * @method static Builder|Register wherePathXmlRegister($value)
 * @method static Builder|Register whereRegisterStatusId($value)
 * @method static Builder|Register whereRegisterTypeId($value)
 * @method static Builder|Register whereResendAk($value)
 * @method static Builder|Register whereResendTk($value)
 * @method static Builder|Register whereSearchVector($value)
 * @method static Builder|Register whereUpdateDate($value)
 * @method static Builder|Register whereUpdatedAt($value)
 * @method static Builder|Register whereUserId($value)
 * @method static Builder|Register whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Register withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Register extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\RegisterApproved
 *
 * @property int $id
 * @property string $name
 * @property string $num
 * @property int|null $year
 * @property string|null $create_date
 * @property int $register_type_id
 * @property int $archive_id
 * @property int $fund_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool|null $resend_tk
 * @property bool|null $resend_ak
 * @property int|null $register_status_id
 * @property string|null $update_date
 * @property string|null $search_vector
 * @property int|null $user_id
 * @property string|null $path_xml_register
 * @property string|null $guid_path
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\HandBooks\Archive[] $archive
 * @property-read int|null $archive_count
 * @property-read \App\Models\HandBooks\Archive $archiveDetail
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegister
 * @property-read int|null $dossier_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterDesc
 * @property-read int|null $dossier_in_register_desc_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterOnRegisterPartNotNull
 * @property-read int|null $dossier_in_register_on_register_part_not_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $dossierInRegisterOnRegisterPartNull
 * @property-read int|null $dossier_in_register_on_register_part_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $edInRegister
 * @property-read int|null $ed_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Dossier\DossierInRegister[] $edInRegisterWithSort
 * @property-read int|null $ed_in_register_with_sort_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Ed\Ed[] $eds
 * @property-read int|null $eds_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\HandBooks\Fund[] $fund
 * @property-read int|null $fund_count
 * @property-read \App\Models\HandBooks\Fund $fundDetail
 * @property-read mixed $uri_path_xml_register
 * @property-read string $xml_register_type
 * @property-read \App\Models\Tk\Tk|null $lastAk
 * @property-read \App\Models\Agreement $lastEpkAgreement
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFile
 * @property-read int|null $register_file_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFilePath
 * @property-read int|null $register_file_path_count
 * @property-read \App\Models\Register\RegisterFile|null $registerFileWhereTypeOne
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterFile[] $registerFileWhereTypeTwo
 * @property-read int|null $register_file_where_type_two_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Register\RegisterPart[] $registerPart
 * @property-read int|null $register_part_count
 * @property-read \App\Models\Register\RegisterStatus|null $registerStatus
 * @property-read \App\Models\Register\RegisterType $registerType
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Signer\Signer[] $signers
 * @property-read int|null $signers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Tk\Tk[] $tk
 * @property-read int|null $tk_count
 * @property-read \App\Models\User\User|null $user
 * @method static Builder|Register autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved query()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereArchiveId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereFundId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereGuidArch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereGuidPath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereNum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved wherePathXmlRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereRegisterStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereRegisterTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereResendAk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereResendTk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereSearchVector($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereUpdateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterApproved whereYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Register withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read \App\Models\Agreement|null $agreement
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Agreement[] $agreements
 * @property-read int|null $agreements_count
 * @property-read \App\Models\Agreement|null $epkAgreement
 * @property-read \App\Models\Agreement|null $lastEkAgreement
 * @property-read \App\Models\Tk\Tk|null $lastTk
 */
	class RegisterApproved extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\RegisterFile
 *
 * @property int $id
 * @property string|null $sign_date
 * @property string|null $name
 * @property int $register_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $path
 * @property int $user_id
 * @property int $system_role_id
 * @property bool $is_actual
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \App\Models\Register\Register $register
 * @property-read Signer|null $signer
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read SystemRole $systemRole
 * @property-read User $user
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile query()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereIsActual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereSignDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereSystemRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterFile whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RegisterFile extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\RegisterPart
 *
 * @property int $id
 * @property string $name
 * @property int|null $parent_id
 * @property int|null $register_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $time
 * @property string $guid_arch
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $dossierInRegister
 * @property-read int|null $dossier_in_register_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|DossierInRegister[] $edInRegister
 * @property-read int|null $ed_in_register_count
 * @property-read RegisterPart|null $parentRegisterPart
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|RegisterPart[] $registerPart
 * @property-read int|null $register_part_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|RegisterPart newModelQuery()
 * @method static Builder|RegisterPart newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|RegisterPart query()
 * @method static Builder|RegisterPart whereCreatedAt($value)
 * @method static Builder|RegisterPart whereGuidArch($value)
 * @method static Builder|RegisterPart whereId($value)
 * @method static Builder|RegisterPart whereName($value)
 * @method static Builder|RegisterPart whereParentId($value)
 * @method static Builder|RegisterPart whereRegisterId($value)
 * @method static Builder|RegisterPart whereTime($value)
 * @method static Builder|RegisterPart whereUpdatedAt($value)
 * @method static Builder|RegisterPart withFilters(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RegisterPart extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\RegisterStatus
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RegisterStatus extends \Eloquent {}
}

namespace App\Models\Register{
/**
 * App\Models\Register\RegisterType
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property string $code_xml
 * @property int|null $min_year
 * @property int|null $max_year
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType query()
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereMaxYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereMinYear($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|RegisterType whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class RegisterType extends \Eloquent {}
}

namespace App\Models\Report{
/**
 * App\Models\Report\Report
 *
 * @property int $id
 * @property string|null $path
 * @property int $object_id
 * @property string $object_type
 * @property int $status_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $form_date
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Report\StatusReport|null $status
 * @method static Builder|Report newModelQuery()
 * @method static Builder|Report newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Report query()
 * @method static Builder|Report whereCreatedAt($value)
 * @method static Builder|Report whereFormDate($value)
 * @method static Builder|Report whereId($value)
 * @method static Builder|Report whereObjectId($value)
 * @method static Builder|Report whereObjectType($value)
 * @method static Builder|Report wherePath($value)
 * @method static Builder|Report whereStatusId($value)
 * @method static Builder|Report whereUpdatedAt($value)
 * @method static Builder|Report withFilter($request)
 * @method static Builder|Report withGroup($request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Report extends \Eloquent {}
}

namespace App\Models\Report{
/**
 * App\Models\Report\StatusReport
 *
 * @property int $id
 * @property string $name
 * @property string|null $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatusReport whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatusReport extends \Eloquent {}
}

namespace App\Models\Sert{
/**
 * App\Models\Sert\Sert
 *
 * @property int $id
 * @property string $num
 * @property string $name
 * @property string|null $path
 * @property string $start_date
 * @property string $end_date
 * @property string $thumbprint
 * @property string $subject
 * @property int|null $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $id_cert_from
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Sert\SertOneUse[] $sertOneUse
 * @property-read int|null $sert_one_use_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Sert\SertUse[] $sertUse
 * @property-read int|null $sert_use_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read User|null $user
 * @property-read User|null $userUse
 * @method static Builder|Sert newModelQuery()
 * @method static Builder|Sert newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Sert query()
 * @method static Builder|Sert whereCreatedAt($value)
 * @method static Builder|Sert whereEndDate($value)
 * @method static Builder|Sert whereId($value)
 * @method static Builder|Sert whereIdCertFrom($value)
 * @method static Builder|Sert whereName($value)
 * @method static Builder|Sert whereNum($value)
 * @method static Builder|Sert wherePath($value)
 * @method static Builder|Sert whereStartDate($value)
 * @method static Builder|Sert whereSubject($value)
 * @method static Builder|Sert whereThumbprint($value)
 * @method static Builder|Sert whereUpdatedAt($value)
 * @method static Builder|Sert whereUserId($value)
 * @method static Builder|Sert withFilters(\Illuminate\Http\Request $request)
 * @method static Builder|Sert withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 * @property-read Mchd|null $mchd
 * @method static \Illuminate\Database\Eloquent\Builder|Sert autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 */
	class Sert extends \Eloquent {}
}

namespace App\Models\Sert{
/**
 * App\Models\Sert\SertOneUse
 *
 * @property int $id
 * @property int $sert_id
 * @property int $sert_use_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Sert\Sert|null $cert
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Sert\SertUse $use
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse query()
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse whereSertId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse whereSertUseId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertOneUse whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SertOneUse extends \Eloquent {}
}

namespace App\Models\Sert{
/**
 * App\Models\Sert\SertUse
 *
 * @property int $id
 * @property string $code
 * @property string $name
 * @property string $description
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Sert\Sert[] $serts
 * @property-read int|null $serts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse query()
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SertUse whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SertUse extends \Eloquent {}
}

namespace App\Models\Session{
/**
 * App\Models\Session\Session
 *
 * @property int $id
 * @property int $user_id
 * @property string|null $start_date
 * @property string|null $end_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $sessions_id
 * @property int|null $last_activity
 * @property string|null $2fa_code
 * @property string|null $2fa_code_end_time
 * @property bool $is_trust
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \App\Models\Session\SessionDetail|null $detailSession
 * @property-read mixed $message_inactivity_job
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|Session newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Session newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Session query()
 * @method static \Illuminate\Database\Eloquent\Builder|Session where2faCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session where2faCodeEndTime($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereIsTrust($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereLastActivity($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereSessionsId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Session whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Session extends \Eloquent {}
}

namespace App\Models\Session{
/**
 * App\Models\Session\SessionDetail
 *
 * @property int $id
 * @property int|null $user_id
 * @property string|null $ip_address
 * @property string|null $user_agent
 * @property string $payload
 * @property int $last_activity
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \App\Models\Session\Session|null $session
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail query()
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail whereIpAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail whereLastActivity($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail wherePayload($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail whereUserAgent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SessionDetail whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SessionDetail extends \Eloquent {}
}

namespace App\Models\Signer{
/**
 * App\Models\Signer\Signer
 *
 * @property int $id
 * @property string $position
 * @property int $signer_role_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $user_id
 * @property bool|null $is_actual
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|RegisterFile[] $registerFile
 * @property-read int|null $register_file_count
 * @property-read \App\Models\Signer\SignerRole|null $role
 * @property-read \App\Models\Signer\SignerRole $roleDetail
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read User $user
 * @method static Builder|Signer autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|Signer newModelQuery()
 * @method static Builder|Signer newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Signer query()
 * @method static Builder|Signer whereCreatedAt($value)
 * @method static Builder|Signer whereId($value)
 * @method static Builder|Signer whereIsActual($value)
 * @method static Builder|Signer wherePosition($value)
 * @method static Builder|Signer whereSignerRoleId($value)
 * @method static Builder|Signer whereUpdatedAt($value)
 * @method static Builder|Signer whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Signer extends \Eloquent {}
}

namespace App\Models\Signer{
/**
 * App\Models\Signer\SignerRole
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole query()
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereCodeXml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SignerRole whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SignerRole extends \Eloquent {}
}

namespace App\Models\Statistic{
/**
 * App\Models\Statistic\StatisticActEdInChed
 *
 * @property int $id
 * @property string|null $form_date
 * @property int $statistic_status_id
 * @property int $accepted_act_ed_in_ched
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Statistic\StatisticRegisterStatus $statisticStatus
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereAcceptedActEdInChed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereFormDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereStatisticStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticActEdInChed whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatisticActEdInChed extends \Eloquent {}
}

namespace App\Models\Statistic{
/**
 * App\Models\Statistic\StatisticEdInRegisterByYear
 *
 * @property int $id
 * @property string|null $form_date
 * @property int $statistic_status_id
 * @property mixed|null $ed_in_dossiers_info
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Statistic\StatisticRegisterStatus $statisticStatus
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereEdInDossiersInfo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereFormDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereStatisticStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticEdInRegisterByYear whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatisticEdInRegisterByYear extends \Eloquent {}
}

namespace App\Models\Statistic{
/**
 * App\Models\Statistic\StatisticRegister
 *
 * @property int $id
 * @property int $register_id
 * @property int $count_ed_in_register
 * @property int|null $statistic_ed_in_register_by_year_id
 * @property int|null $statistic_tk_ed_in_ched_id
 * @property int|null $statistic_act_ed_in_ched_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Statistic\StatisticActEdInChed|null $statisticActEdInChed
 * @property-read \App\Models\Statistic\StatisticEdInRegisterByYear|null $statisticEdInRegisterByYear
 * @property-read \App\Models\Statistic\StatisticTkEdInChed|null $statisticTkEdInChed
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereCountEdInRegister($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereRegisterId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereStatisticActEdInChedId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereStatisticEdInRegisterByYearId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereStatisticTkEdInChedId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegister whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatisticRegister extends \Eloquent {}
}

namespace App\Models\Statistic{
/**
 * App\Models\Statistic\StatisticRegisterStatus
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticRegisterStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatisticRegisterStatus extends \Eloquent {}
}

namespace App\Models\Statistic{
/**
 * App\Models\Statistic\StatisticTkEdInChed
 *
 * @property int $id
 * @property string|null $form_date
 * @property int $statistic_status_id
 * @property int $send_ed_in_ched
 * @property int $accepted_ed_in_ched
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Statistic\StatisticRegisterStatus $statisticStatus
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed query()
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereAcceptedEdInChed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereFormDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereSendEdInChed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereStatisticStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|StatisticTkEdInChed whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class StatisticTkEdInChed extends \Eloquent {}
}

namespace App\Models\Storage{
/**
 * App\Models\Storage\LocationType
 *
 * @property int $id
 * @property string $name
 * @property string|null $code
 * @property int|null $parent_id
 * @property mixed|null $path
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|LocationType[] $locationTypes
 * @property-read int|null $location_types_count
 * @property-read \Umbrellio\LTree\Collections\LTreeCollection|LocationType[] $ltreeChildren
 * @property-read int|null $ltree_children_count
 * @property-read LocationType|null $ltreeParent
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] all($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType ancestorByLevel(int $level = 1, ?string $path = null)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType ancestorsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType descendantsOf(\Umbrellio\LTree\Interfaces\LTreeModelInterface $model, bool $reverse = true)
 * @method static \Umbrellio\LTree\Collections\LTreeCollection|static[] get($columns = ['*'])
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType parentsOf(array $paths)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType query()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType root()
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType wherePath($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|LocationType withoutSelf(int $id)
 * @mixin \Eloquent
 */
	class LocationType extends \Eloquent implements \Umbrellio\LTree\Interfaces\LTreeModelInterface, \Umbrellio\LTree\Interfaces\LTreeInterface, \Umbrellio\LTree\Interfaces\ModelInterface, \Umbrellio\LTree\Interfaces\HasLTreeScopes, \Umbrellio\LTree\Interfaces\HasLTreeRelations {}
}

namespace App\Models\Subdivisions{
/**
 * App\Models\Subdivisions\Subdivisions
 *
 * @property int $id
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property bool $is_org Если true, то первый уровень иерархии, т.е. сама организация. Если false, то второй
 *                 уровень иерархии, т.е. подразделение. Необходимо для назначения прав на все подразделения организации.
 *                 Пример - если есть связь с subdivision, у которой is_org = true, то пользователю предоставляется доступ
 *                 ко всем подразделениям
 * @property string $name
 * @property string $code
 * @property string $contact
 * @property bool $is_active
 * @property int $create_year
 * @property int|null $delete_year Заполняется автоматически при ликвидации подразделения
 * @property string $note Заполняется автоматически при ликвидации подразделения: "Объекты перешли к подразделению <название подразделения>"
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int $order
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Dossier[] $dossiers
 * @property-read int|null $dossiers_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Ed[] $eds
 * @property-read int|null $eds_count
 * @property-read \Illuminate\Database\Eloquent\Collection|NomPart[] $nomParts
 * @property-read int|null $nom_parts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \Illuminate\Database\Eloquent\Collection|User[] $users
 * @property-read int|null $users_count
 * @method static Builder|Subdivisions newModelQuery()
 * @method static Builder|Subdivisions newQuery()
 * @method static \Illuminate\Database\Query\Builder|Subdivisions onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Subdivisions query()
 * @method static Builder|Subdivisions whereCode($value)
 * @method static Builder|Subdivisions whereContact($value)
 * @method static Builder|Subdivisions whereCreateYear($value)
 * @method static Builder|Subdivisions whereCreatedAt($value)
 * @method static Builder|Subdivisions whereDeleteYear($value)
 * @method static Builder|Subdivisions whereDeletedAt($value)
 * @method static Builder|Subdivisions whereId($value)
 * @method static Builder|Subdivisions whereIsActive($value)
 * @method static Builder|Subdivisions whereIsOrg($value)
 * @method static Builder|Subdivisions whereName($value)
 * @method static Builder|Subdivisions whereNote($value)
 * @method static Builder|Subdivisions whereOrder($value)
 * @method static Builder|Subdivisions whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Query\Builder|Subdivisions withTrashed()
 * @method static \Illuminate\Database\Query\Builder|Subdivisions withoutTrashed()
 * @mixin \Eloquent
 */
	class Subdivisions extends \Eloquent {}
}

namespace App\Models\Subdivisions{
/**
 * App\Models\Subdivisions\UserInSubdivision
 *
 * @property int $id
 * @property int $user_id
 * @property int $subdivision_id
 * @property string $start_date
 * @property string $end_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision newQuery()
 * @method static \Illuminate\Database\Query\Builder|UserInSubdivision onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision query()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereSubdivisionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInSubdivision whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Query\Builder|UserInSubdivision withTrashed()
 * @method static \Illuminate\Database\Query\Builder|UserInSubdivision withoutTrashed()
 * @mixin \Eloquent
 */
	class UserInSubdivision extends \Eloquent {}
}

namespace App\Models\System{
/**
 * App\Models\System\SystemCategory
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\System\SystemParam[] $system_params
 * @property-read int|null $system_params_count
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemCategory whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SystemCategory extends \Eloquent {}
}

namespace App\Models\System{
/**
 * App\Models\System\SystemParam
 *
 * @property int $id
 * @property string $name
 * @property string $value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $category_id
 * @property int|null $list_number
 * @property string|null $code
 * @property string|null $launch_start
 * @property bool $is_edit
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam query()
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereIsEdit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereLaunchStart($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereListNumber($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|SystemParam whereValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SystemParam extends \Eloquent {}
}

namespace App\Models\System{
/**
 * App\Models\System\SystemRole
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property string|null $start_date
 * @property string|null $end_date
 * @property int $priority
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property string|null $code_xml
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static Builder|SystemRole autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|SystemRole newModelQuery()
 * @method static Builder|SystemRole newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|SystemRole query()
 * @method static Builder|SystemRole whereCode($value)
 * @method static Builder|SystemRole whereCodeXml($value)
 * @method static Builder|SystemRole whereCreatedAt($value)
 * @method static Builder|SystemRole whereDescription($value)
 * @method static Builder|SystemRole whereEndDate($value)
 * @method static Builder|SystemRole whereId($value)
 * @method static Builder|SystemRole whereName($value)
 * @method static Builder|SystemRole wherePriority($value)
 * @method static Builder|SystemRole whereStartDate($value)
 * @method static Builder|SystemRole whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class SystemRole extends \Eloquent {}
}

namespace App\Models\Tk{
/**
 * App\Models\Tk\CheckRenewalsAk
 *
 * @property int $id
 * @property string $date
 * @property int $count_ak
 * @property int $count_ak_completed
 * @property int $count_ak_error
 * @property mixed|null $error
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool $is_send
 * @property mixed|null $success
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read bool $is_use
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk query()
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereCountAk($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereCountAkCompleted($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereCountAkError($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereError($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereIsSend($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereSuccess($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CheckRenewalsAk whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class CheckRenewalsAk extends \Eloquent {}
}

namespace App\Models\Tk{
/**
 * App\Models\Tk\Tk
 *
 * @property int $id
 * @property string|null $send_date
 * @property string|null $form_date
 * @property string|null $sign_end_date
 * @property string $tk_path
 * @property string $ep_path
 * @property int|null $archive_id
 * @property int|null $fund_id
 * @property int|null $ed_id
 * @property int|null $tk_status_id
 * @property int|null $register_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $message_guid
 * @property int|null $user_id
 * @property bool $in_out
 * @property int $tk_type
 * @property string $tk_receipt
 * @property int|null $agreement_id
 * @property int|null $accept_act_id
 * @property string|null $guid
 * @property int|null $nom_id
 * @property string|null $object_num
 * @property int|null $di_classifier_id
 * @property-read Agreement|null $agreement
 * @property-read \Illuminate\Database\Eloquent\Collection|Archive[] $archive
 * @property-read int|null $archive_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read Ed|null $ed
 * @property-read \Illuminate\Database\Eloquent\Collection|Fund[] $fund
 * @property-read int|null $fund_count
 * @property-read string $example_path
 * @property-read mixed $message_created
 * @property-read mixed $message_deleted
 * @property-read mixed $message_renewals_ak_error
 * @property-read mixed $message_renewals_ak_success
 * @property-read int $object_id
 * @property-read mixed $uri
 * @property-read mixed $uri_receipt
 * @property-read \Illuminate\Database\Eloquent\Collection|Message[] $messages
 * @property-read int|null $messages_count
 * @property-read Nomenclature|null $nomenclature
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read Register|null $register
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Tk\TkStatus|null $status
 * @property-read \App\Models\Tk\TkType|null $type
 * @property-read User|null $user
 * @method static Builder|Tk autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static Builder|Tk newModelQuery()
 * @method static Builder|Tk newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static Builder|Tk query()
 * @method static Builder|Tk whereAcceptActId($value)
 * @method static Builder|Tk whereAgreementId($value)
 * @method static Builder|Tk whereArchiveId($value)
 * @method static Builder|Tk whereCreatedAt($value)
 * @method static Builder|Tk whereDiClassifierId($value)
 * @method static Builder|Tk whereEdId($value)
 * @method static Builder|Tk whereEpPath($value)
 * @method static Builder|Tk whereFormDate($value)
 * @method static Builder|Tk whereFundId($value)
 * @method static Builder|Tk whereGuid($value)
 * @method static Builder|Tk whereId($value)
 * @method static Builder|Tk whereInOut($value)
 * @method static Builder|Tk whereMessageGuid($value)
 * @method static Builder|Tk whereNomId($value)
 * @method static Builder|Tk whereObjectNum($value)
 * @method static Builder|Tk whereRegisterId($value)
 * @method static Builder|Tk whereSendDate($value)
 * @method static Builder|Tk whereSignEndDate($value)
 * @method static Builder|Tk whereTkPath($value)
 * @method static Builder|Tk whereTkReceipt($value)
 * @method static Builder|Tk whereTkStatusId($value)
 * @method static Builder|Tk whereTkType($value)
 * @method static Builder|Tk whereUpdatedAt($value)
 * @method static Builder|Tk whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|Tk withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Tk extends \Eloquent {}
}

namespace App\Models\Tk{
/**
 * App\Models\Tk\TkStatus
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool $is_visible
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereIsVisible($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkStatus withDefaultFilter(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class TkStatus extends \Eloquent {}
}

namespace App\Models\Tk{
/**
 * App\Models\Tk\TkType
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|TkType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TkType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|TkType query()
 * @method static \Illuminate\Database\Eloquent\Builder|TkType whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkType whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TkType whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class TkType extends \Eloquent {}
}

namespace App\Models\Upload{
/**
 * App\Models\Upload\Upload
 *
 * @property int $id
 * @property string|null $file
 * @property int $status_id
 * @property string|null $error
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $user_id
 * @property mixed|null $data
 * @property string|null $type
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $uri
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read \App\Models\Upload\UploadStatus|null $status
 * @method static \Illuminate\Database\Eloquent\Builder|Upload newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Upload newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|Upload query()
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereData($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereError($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereFile($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Upload whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class Upload extends \Eloquent {}
}

namespace App\Models\Upload{
/**
 * App\Models\Upload\UploadStatus
 *
 * @property int $id
 * @property string $name
 * @property string $code
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus query()
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UploadStatus whereUpdatedAt($value)
 * @method static Builder|NsiBaseModel withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class UploadStatus extends \Eloquent {}
}

namespace App\Models\User{
/**
 * App\Models\User\CompromPassword
 *
 * @property int $id
 * @property string $password
 * @property string $hash
 * @property string $salt
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $value
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword query()
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword whereHash($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword whereSalt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompromPassword withFilter(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static Builder|NsiBaseModel withOrderDefault(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class CompromPassword extends \Eloquent {}
}

namespace App\Models\User{
/**
 * App\Models\User\UsedPasswords
 *
 * @property int $id
 * @property string $password
 * @property int $user_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string $salt
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords query()
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords whereSalt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UsedPasswords whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class UsedPasswords extends \Eloquent {}
}

namespace App\Models\User{
/**
 * App\Models\User\User
 *
 * @property int $id
 * @property string $fio
 * @property string $login
 * @property string $password
 * @property string $salt
 * @property string|null $start_date
 * @property string|null $end_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property bool $is_superuser
 * @property string|null $email
 * @property string|null $log_date
 * @property string|null $update_password_date
 * @property bool $is_2fa
 * @property bool $activated
 * @property bool $is_block
 * @property string|null $tmp_password
 * @property string|null $tmp_password_end_time
 * @property string $guid
 * @property string|null $esia_oid Внутренний идентификатор пользователя в ЕСИА
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read mixed $appeal_user
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Sert[] $serts
 * @property-read int|null $serts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Session[] $sessionWhereEndDateNull
 * @property-read int|null $session_where_end_date_null_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Signer[] $signer
 * @property-read int|null $signer_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Signer[] $signerRole
 * @property-read int|null $signer_role_count
 * @property-read \Illuminate\Database\Eloquent\Collection|Subdivisions[] $subdivisions
 * @property-read int|null $subdivisions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|SystemRole[] $systemRole
 * @property-read int|null $system_role_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\User\UsedPasswords[] $usedPasswords
 * @property-read int|null $used_passwords_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\User\UserRole[] $userRole
 * @property-read int|null $user_role_count
 * @method static \Illuminate\Database\Eloquent\Builder|User autoPaginate(\Illuminate\Http\Request $request, array $columns = [], ?int $pageLength = null, ?int $pageNumber = null)
 * @method static \Illuminate\Database\Eloquent\Builder|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User query()
 * @method static \Illuminate\Database\Eloquent\Builder|User whereActivated($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEsiaOid($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereFio($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereGuid($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereIs2fa($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereIsBlock($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereIsSuperuser($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereLogDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereLogin($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereSalt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereTmpPassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereTmpPasswordEndTime($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatePasswordDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User withPaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class User extends \Eloquent implements \OwenIt\Auditing\Contracts\Auditable {}
}

namespace App\Models\User{
/**
 * App\Models\User\UserRole
 *
 * @property int $id
 * @property int $user_id
 * @property int $system_role_id
 * @property string|null $start_date
 * @property string|null $end_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $code
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\PendingTransition[] $pendingTransitions
 * @property-read int|null $pending_transitions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Asantibanez\LaravelEloquentStateMachines\Models\StateHistory[] $stateHistory
 * @property-read int|null $state_history_count
 * @property-read SystemRole|null $systemRole
 * @property-read \App\Models\User\User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel permissions()
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole query()
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereSystemRoleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserRole whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withOrder(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withPaginate(\Illuminate\Http\Request $request)
 * @method static \Illuminate\Database\Eloquent\Builder|BaseModel withSimplePaginate(\Illuminate\Http\Request $request)
 * @mixin \Eloquent
 */
	class UserRole extends \Eloquent {}
}

namespace Lauthz\Models{
/**
 * Rule Model.
 *
 * @property int $id
 * @property string|null $ptype
 * @property string|null $v0
 * @property string|null $v1
 * @property string|null $v2
 * @property string|null $v3
 * @property string|null $v4
 * @property string|null $v5
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Audit\Audit[] $audits
 * @property-read int|null $audits_count
 * @property-read bool $is_only_user
 * @method static \Illuminate\Database\Eloquent\Builder|Rule newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Rule newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Rule query()
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule wherePtype($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV0($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV1($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV2($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV3($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV4($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Rule whereV5($value)
 * @mixin \Eloquent
 */
	class Rule extends \Eloquent implements \OwenIt\Auditing\Contracts\Auditable {}
}

