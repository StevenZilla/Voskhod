### ТР-Архив-API

### По ведению кода

1. Все  доработки, заметки, мысли, помечаем   тегом TODO: обоснования: что как зачем почему ( вообщем  нафига? )  
2. Скучаем)  хотим улучшить  жизнь  дубущим чтецам кода :   замечательный редактор   позволяет отобрать такой  список  TASK LIST: View->Tools Windows->TODO
3. Ведем  корретно   комментарии, описываем:

   =  Общую архитектуру, вид «с высоты птичьего полёта».
   =  Использование функций.
   =  Неочевидные решения, важные детали. 
   =  и вдург  если  запутанный  код,  пока:  ЧТО, ЗАЧЕМ,  ДЛЯ ЧЕГО
4. TODO:   если  данный  TODO  требует  внимания  и  детального обсуждения,  делаем через  task в гите или  ISSUE 
   помечая  в коде,  рядом с TODO, номер  задачи

####   dev установка 
- устанока зависимостей 

> composer install

- указать в .env параметры БД

// Перед выполнением миграций выполнить установку расширений postgres
> sudo -su postgres psql -d "tr_archive" -c "CREATE EXTENSION IF NOT EXISTS pg_trgm;"
 
// Чтобы проверить список установленных расширений postgres
> sudo -su postgres psql -d "tr_archive" -c "SELECT * FROM pg_extension;"
   
// выполнить миграции 
> php artisan migrate --seed - старая команда
    
// можно очищаться несколько соединений к базе данных
>  php artisan migration:fresh --conn=pgsql,tr_archive --seed

// для менеджера. накатывание миграций для всех оиков/конкретного оика. -S или --seed накатывание всех фикстур. -A или --all - накатывание всех миграций (ожидает параметр true). -U или --uid_org - уид конкретной организации. Если передан флаг -A true, то будет игнорироваться флаг -U   
>  php artisan migration -S|--seed -A|--all=false -U|--uid_org=

// удаляет все данных из соединений к бд
> php artisan migration:drop --conn=pgsql,tr_archive 

// для обработки очередей
> php artisan queue:work --sleep=3 --tries=3 

После установки сертификато необходимо выполнить команду

>  sudo php {путь до проекта/}artisan insert:sert, либо сертификаты автоматически запишутся в полночь


### Необходимо установить зависимости png

```
sudo apt-get install php7.0-gd && sudo service apache2 restart
sudo apt-get install p7zip-full

```

### Необходимо обновить файл php.ini

```
upload_max_filesize = 500M 

post_max_size = 500M

max_file_uploads - если необходимо изменить количетсво загружаемых файлов (по умолчанию 20 файлов)

```

###  Настройка .env

**USE_DEBUG_FIXTURES = true**, чтобы использовать тестовые фикстуры для ed,tk,user,file

Если в .env добавить **SET_TIME=true**, то воркер по продлению АК будет раз в день(в полночь), иначе **каждую минуту**

**SESSION_DRIVER=database** - чтобы была информации о сессии

**SESSION_LIFETIME=604800** - Время жизни сессии (неделя)

**SESSION_COOKIE=tr-archive** - Наименование куки

**COUNT_THROTTLE** - количество throttle, по **умолчанию 2000**

**QUEUE_TIMEOUT** - количество секунд для выполнения jobs, по **умолчанию 60**

**REQUIRED_ED=name,num,source_id,create_date,dossier_id** - обязательные поля для ЭД, чтобы проставить статус **Обработан**

**COUNT_MINUTES_LIFE_TMP_PASS** - количество минут для использования временного пароля

**COUNT_DAYS_UPDATE_PASS** - количество дней до истечения жизни основного пароля

**DISALLOW_TK_UNKNOWN_SOURCES** - можем ли мы парсить контейнеры с документами при отсутствии источника  

**CODE_LIFETIME_2FA** - количество минут жизни кода 2FA

**CODE_LENGTH_2FA** - количество символов для кода 2FA

**LOG_CHANNEL** - как будут храниться логи. Значение **single** будет храниться 1 файл логов. Значение **daily** - логи будут храниться по дням.

**USE_LOGS_CHANNEL** - количество используемых каналов для вывода логов. Указывается через запятую и без пробела

**LOG_FILES** - сколько дней хранятся логи. По умолчанию: 2 дня

### Возможности / Особенности

**Каскадное удаление**

Каскадное удаление сейчас настроено в таблицах: 

* file_file - отношение родительского файла к дочернему (и наоборот) 

* nom_part - по отношению раздела номенклатуры к его дочернм элементам 

* register_part - по отношению раздела описи к дочернм элементам 

* ed_in_register - по отношению раздела описи к документам


**Подпись**

> Если попробовать подписать файл подписью, которая просрочена, то выдаст ошибку, что данная подпись не действительна. Сообщение об ошибке пишутся в лог


### Очереди:

Описание queue: 

1) **input_container_job** Обрабатывает входящие контейнеры из МЭДО. 

2) **input_receipt_job** Обрабатывает контейнеры с квитанцией. 

3) **input_message_job** Обрабатывает контейнер с сообщением. Конкретно обрабатывает в нем уведомления, получая информацию о ТК. 

4) **renewals_ak_job** Обрабатывает архивные контейнеры с целью продления подписи. 

5) **check_inactivity_user_job** Проверяет активность сессии пользователя. 

6) **create_ed_tk_job** Создает транспортный контейнер электронного документа и отправляет его. 

7) **create_register_tk_job** Создает транспортный контейнер для описи и отправляет его. 

8) **create_ed_ak_job** Создает архивный контейнер для электронного документа и отправляет его на хранение. 

9) **create_register_ak_job** Создает архивный контейнер для описи и отправляет его на хранение. 

10) **converter_file_job** Конвертирует файлы электронного документа в тип pdf.


#### Документация

Создание документации: 

Скачиваем phpDocumentor.phar релиз 2.9.0(PHP-7 Syntax support) с оффициального репозитория: https://github.com/phpDocumentor/phpDocumentor/releases?page=2. Переходим в каталог с загруженным файлом и выполняем команду:

> sudo mv phpDocumentor.phar /usr/local/bin/phpdoc, которая устанавливает глобальную переменную среды. Затем наделяем ее правами: 

> sudo chmod 755 /usr/local/bin/phpdoc Далее выполняем саму генерацию документации, указав флаг "-d" или "-f" (дирректория/файл), флаг "-t" - место расположения документации. 

Пример генерации: 

> sudo phpdoc -d /var/www/trarchive-api-application/app/Http/Controllers -t /var/www/trarchive-api-application/public/media/docs/controlles


#### Кастомные  команды 


Кастомные консольные команды приложения 

* **php artisan insert:handbook** --path={путь до директории, где лежат архивы и фонды} - для запуска сихнронизации справочников ЦХЭДА 

* **php insert:sert --user** - добавляет сертификаты в сестему из ОС, опция "user" используется для того, чтобы проставить пользователя сертификатам

* **php artisan reset.sert {login} {--A|all=false} {--T|thumbprint=}** - обнуляет сертификаты у пользователя. login - логин пользователя, у которого обнуляем сертификаты. Флаг -А или --all = обнуляем все сертификаты у пользователя, флаг -T или --thumbprint = обнуляем конкретный сертификат

* **php artisan version_product:set {--u|uid=}** Установка версии продукта в системные настройки. Флаг -u или --uid устанавливает новое соединение с бд

* **php artisan entities:clear {--S|clear_storage=false}** Удаляет основные сущности БД. Флаг -S или --clear_storage ожидает значение true

* **php artisan user:insert {login} {password?} {email} {--fio} {--is_superuser=false} {--uid_org=} {--S|set_role=false}** Создаем обычного пользователя. Аргумент login - обязательный. Аргумент email - обязательный. Аргумент password - необязательный, если не передаем этот аргумент, пароль будет сгенерирован. Флаг --fio 'fio user' - устанавливает юзеру ФИО, необходимо передавать в кавычках. Флаг --is_superuser false - необязательный, по умолчанию идет false. Флаг uid_org - ожидает иуд организации. Флаг -S|--set_role - ожидает true, спросит какую роль установить для пользователя, но если передать код системной роли, установит ее. Коды системных ролей:  administrator, supervisor, archivist.

* **php artisan version.tk:set {--U|uid=} {--S|show_versions=false}** Устанавливаем версию ТК в системных параметров. Опция -U || --uid - смена конфига подключения к бд. Опция -S || --show_versions - ожидает любое значение, кроме false

#### Используемые библиотеки: 

1) Метрика приложения - Larametrics(https://github.com/aschmelyun/larametrics). 

2) Профайлер приложения в режиме разработки - Clockwork(https://github.com/itsgoingd/clockwork). 

3) Просмотр логов приложения - Log-viewer(https://github.com/rap2hpoutre/laravel-log-viewer).

#### Решение проблем

___
Если возникает ошибка
> [ErrorException]                                                                                                                              
include(/var/www/trarchive-api-application/vendor/composer/../aschmelyun/larametrics/src/Models/LarametricsLog.php): failed to open stream:   
No such file or directory

**Необходимо выполнить команду:**

>php -r 'include "MetricsRenameFolderModels.php"; metrics_rename_folder_models();'

>> В include необходимо указать абсолютный путь до проекта. Например

>>> include "/var/www/trarchive-api-application/MetricsRenameFolderModels.php";
___

Установить библиотеку гост алгоритмов хеширования:
1) sudo apt install libgost-astra
2) gunzip -c /usr/share/doc/libgost-astra/openssl.cnf.gz | sudo tee /etc/ssl/openssl.cnf1 > /dev/null
3) unrar  и unzip 

Триггеры:
1) set_min_and_max_date_for_dossier - устанавливает min_date и max_date делу. Вычисляется: min_date = min(ed.reg_date), max_date = max(max_date(ed.reg_date))

## VipNet Services

**MODULE_SKZI=** - указываем, что используем для подписания. CRYPTOPRO или VIPNET

**VIPNET_HOST=http://localhost/api** - указываем куда будем слать запросы

**VIPNET_LOGIN=user** - указываем логин для авторизации

**VIPNET_PASSWORD=password** - указываем пароль для авторизации
