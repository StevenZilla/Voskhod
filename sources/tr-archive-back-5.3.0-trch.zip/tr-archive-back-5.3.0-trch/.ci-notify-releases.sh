#!/bin/bash

TIME="10"
URL="https://api.telegram.org/bot${TELEGRAM_RELEASES_BOT_TOKEN}/sendMessage"
TEXT="Релиз: ТР-архив бэк $CI_BUILD_TAG успешно собран $1%0AАрхив: https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-back/-/releases/$CI_BUILD_TAG "

curl -s --max-time $TIME -d "chat_id=$RELEASES_CHAT_ID&disable_web_page_preview=1&text=$TEXT" $URL > /dev/null

