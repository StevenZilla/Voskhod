<?php

function metrics_rename_folder_models ()
{
    $name_folder_old = 'models';
    $name_folder_new = 'Models';
    $path_to_dir = __DIR__.'/vendor/aschmelyun/larametrics/src/';

    if (!file_exists($path_to_dir.$name_folder_new)) {
        shell_exec("cp -r {$path_to_dir}{$name_folder_old} {$path_to_dir}{$name_folder_new}");

        if (!file_exists($path_to_dir.$name_folder_new)) {
            echo "Директория не была скопирована {$path_to_dir}{$name_folder_new}".PHP_EOL;
            return false;
        }

        shell_exec("rm -r {$path_to_dir}{$name_folder_old}");

        if (file_exists($path_to_dir.$name_folder_old)) {
            echo "Директория не была удалена {$path_to_dir}{$name_folder_old}".PHP_EOL;
            return false;
        }
    }

    echo "Успешно переименовали директорию {$path_to_dir}{$name_folder_old} в {$path_to_dir}{$name_folder_new}".PHP_EOL;
    return true;
}

