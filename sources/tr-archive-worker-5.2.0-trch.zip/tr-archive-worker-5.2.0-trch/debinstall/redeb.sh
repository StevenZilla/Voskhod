#!/usr/bin/env bash

# IMPORTANT
# Protect agaisnt mispelling a var and rm -rf /
set -u
set -e

SRC=/tmp/tr-archive-worker-deb-src
DIST=/tmp/tr-archive-worker-deb-dist
SYSROOT=${SRC}/sysroot
DEBIAN=${SRC}/DEBIAN

rm -rf ${DIST}
mkdir -p ${DIST}/

rm -rf ${SRC}
rsync -a deb-src/ ${SRC}/

mkdir -p ${SYSROOT}/etc/systemd/system

rsync -a --exclude 'debinstall' --exclude '.releaserc.yml' --exclude 'readme.md' --exclude 'CHANGELOG.md' --exclude '.git' --exclude '.gitlab-ci.yml' --exclude 'VERSION.txt' ../. ${SYSROOT}/etc/systemd/system/. --delete

find ${SRC}/ -type d -exec chmod 0755 {} \;
find ${SRC}/ -type f -exec chmod go-w {} \;

let SIZE=`du -s ${SYSROOT} | sed s'/\s\+.*//'`+8
pushd ${SYSROOT}/
tar czf ${DIST}/data.tar.gz [a-z]*
popd
sed s"/SIZE/${SIZE}/" -i ${DEBIAN}/control
pushd ${DEBIAN}
tar czf ${DIST}/control.tar.gz *
popd

pushd ${DIST}/
echo 2.0 > ./debian-binary

find ${DIST}/ -type d -exec chmod 0755 {} \;
find ${DIST}/ -type f -exec chmod go-w {} \;
ar r ${DIST}/trarchive_worker.deb debian-binary control.tar.gz data.tar.gz
popd
rsync -a ${DIST}/trarchive_worker.deb ./
