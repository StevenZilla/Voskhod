## [3.0.0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-worker/compare/systemd-archive-v.2.0.0.rc...systemd-archive-v.3.0.0.rc) (2023-07-18)

## [2.0.0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-worker/compare/systemd-archive-v.1.0.0.rc...systemd-archive-v.2.0.0.rc) (2023-07-18)

## [1.0.0](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-worker/compare/...systemd-archive-v.1.0.0.rc) (2023-07-18)


### 🚀 Features

* add cangelog ([b060d79](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-worker/commit/b060d79b78860dd13f4788221f17407c7f0ed393))


### 🛠 Fixes

* changlog ([8a19c96](https://git.voskhod-11.ru/voskhod/ched/tr-archive-g/trarchive/tr-archive-worker/commit/8a19c96250a6ad6c62c5791e9b762b1a12b5263c))
