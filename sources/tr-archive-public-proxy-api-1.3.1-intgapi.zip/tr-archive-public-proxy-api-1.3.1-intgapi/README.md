* [Специкация и коллекция для API](https://documenter.getpostman.com/view/26493313/2sA3Bt3AF2)

# Особенности деплоя
## Генерация Ключа приложения
  * Необходимо сгенерировать ключ приложения через команду
    ```bash
    php artisan key:generate
    ```
  * Все, что находится в квадратных скобках, необходимо скопировать и записать в .env в переменную APP_KEY
    ```bash
    Application key [base64:PFwPXCfvGRymHQrvTkIq+uLhEbmfXLX0Mf1HnPbivyk=] set successfully.
    ```
  * Пример
    ```text
    APP_KEY=base64:PFwPXCfvGRymHQrvTkIq+uLhEbmfXLX0Mf1HnPbivyk=
    ```
# Особенности скачивания файлов:
## Через APACHE на одном порту
 * Можно указать alias, который будет редектить на нужный сервис
## Через ARTISAN SERVE/PHP -S/APACHE на другом порту
 * Необходимо в env добавить сервис downloader по аналогии с archive, но указать свои данные отправки запроса. Например, **http://localhost:8888**
 * Пример
  ```json
  {"archive": {"hostname": "http://localhost:8000"}, "downloader": {"hostname": "http://localhost:8888"}}
  ```
# Компонентная диаграмма 

https://drive.google.com/file/d/1u3UoIGXT4ApTQxAj-jj1RQLfgQtGU3-b/view?usp=sharing


![image.png](https://media.discordapp.net/attachments/983385864308678696/1161300013415141376/image.png?ex=6541066b&is=652e916b&hm=5299e7a363f06d0fd9bfb2000796ed2155d4e1cb36a1ec481fd9c995b7d379a3&=&width=962&height=545)
