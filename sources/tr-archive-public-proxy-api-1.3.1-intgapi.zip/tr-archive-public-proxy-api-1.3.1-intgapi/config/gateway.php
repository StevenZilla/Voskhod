<?php

$prefixApi = trim(env('GATEWAY_PREFIX', ''), '/');
$prefixApiArchive = trim(env('API_ARCHIVE_PREFIX', ''), '/');

if (!empty($prefixApi)) {
    $prefixApi = '/'.$prefixApi.'/';
} else {
    $prefixApi = '/';
}

if (!empty($prefixApiArchive)) {
    $prefixApiArchive = '/'.$prefixApiArchive.'/';
}

return (static function() use($prefixApi, $prefixApiArchive) {
    $sections = ['services', 'routes', 'global', 'subdomain_archive', 'gateway_prefix'];
    $customSections = ['subdomain_archive', 'gateway_prefix'];
    foreach ($sections as $section) {
        if (!in_array($section, $customSections)) {
            if ($section === 'routes') {
                $filesGatewayRoutes = findFilesRecursive(app()->basePath('gateway_routes/'));
                $filesGatewayRouteContent = [];

                foreach ($filesGatewayRoutes as $fileGatewayRoute) {
                    $fileGatewayRouteContent = file_get_contents($fileGatewayRoute);
                    $filesGatewayRouteContent = array_merge(json_decode($fileGatewayRouteContent), $filesGatewayRouteContent);
                }

                $fileContents = json_encode($filesGatewayRouteContent);
                $fileContents = str_replace('"', '\"', $fileContents);
                eval('$config = "'.$fileContents.'";');
            } else {
                $config = env('GATEWAY_' . strtoupper($section), false);
            }

            ${$section} = json_decode($config, true);
        } else {
            if ($section == 'subdomain_archive') {
                ${$section} = env('SUBDOMAIN_ARCHIVE', 'localhost');
            } elseif ($section == 'gateway_prefix') {
                ${$section} = $prefixApi;

            }
        }

        if (${$section} === null) throw new \Exception('Unable to decode GATEWAY_' . strtoupper($section) . ' variable');
    }

    return compact($sections);
})();
