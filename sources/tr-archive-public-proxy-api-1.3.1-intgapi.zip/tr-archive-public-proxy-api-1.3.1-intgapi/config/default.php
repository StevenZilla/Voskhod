<?php

return [
    'guzzle_timeout_files' => env('GUZZLE_TIMEOUT_FILES', 55),
    'throttle' => env('THROTTLE', 60),
];