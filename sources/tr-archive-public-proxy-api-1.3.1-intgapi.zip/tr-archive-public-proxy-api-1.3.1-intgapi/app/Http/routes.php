<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
$prefixApi = trim(env('GATEWAY_PREFIX', ''), '/');
if (!empty($prefixApi)) {
    $prefixApi = '/'.$prefixApi.'/';
} else {
    $prefixApi = '/';
}

$app->get("{$prefixApi}", function () use ($app) {
    return response()->json(['version' => app()->version()]);
});
