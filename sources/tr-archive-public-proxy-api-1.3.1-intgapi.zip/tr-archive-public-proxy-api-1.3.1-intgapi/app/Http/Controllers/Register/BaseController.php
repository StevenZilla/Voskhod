<?php

namespace App\Http\Controllers\Register;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\Register\RegisterService;

class BaseController extends GatewayController
{
    protected $registerService;

    public function __construct(Request $request, RegisterService $registerService)
    {
        parent::__construct($request);

        $this->registerService = $registerService;
    }
}