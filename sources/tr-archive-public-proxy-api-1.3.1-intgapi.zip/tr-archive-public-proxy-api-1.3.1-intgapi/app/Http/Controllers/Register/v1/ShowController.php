<?php

namespace App\Http\Controllers\Register\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Register\BaseController;
use App\Http\Request;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

class ShowController extends BaseController
{
    public function show(Request $request, RestClient $client, $id)
    {
        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $id));

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем выполнять запрос на получения детальной информации сводной описи. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);
        if ($response->getStatusCode() > 400) {
            $dataResponse = json_decode($response->getBody()->getContents(), true);
            $responseJson = response()->json($dataResponse, $response->getStatusCode());
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно получили детальную информацию сводной описи. Время: {$nowDate}");

        $register = $this->registerService->parsingResponseShow($response->getBody()->getContents());

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Получаем разделы и дела для сводной описи с идентификаторов {$id}. Время: {$nowDate}");
        $data = $this->getRegPartData($request, $client, $id, $this->actions);
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно получили разделы и дела для сводной описи с идентификаторов {$id}. Время: {$nowDate}");

        $register['register_parts'] = $data[0];
        $register['dossiers'] = $data[1];

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Начинаем формировать ответ для детальной информации сводной описи. Время: {$nowDate}");
        $responseNom = $this->registerService->getFormattingResponseShow($register);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_register')->debug("Успешно сформировали ответ для детальной информации сводной описи. Время: {$nowDate}. Время получения детальной информации сводной описи: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseNom);
    }

    protected function getRegPartData(Request $request, RestClient $client, int $id, Collection $actions) : array{
        $key = $actions->keys()[0];
        $actions->first()->get(0)->setUrl(sprintf($actions->first()->get(0)->getUrl(), $id));
        $actions->first()->get(1)->setUrl(sprintf($actions->first()->get(1)->getUrl(), $id));
        $regPartsResponses = $this->getMultiActions($request, $client, collect([$actions->first()]));
        $actions->forget($key);
        return $this->registerService->parsingRegPartsShow($regPartsResponses->getContent());
    }

}