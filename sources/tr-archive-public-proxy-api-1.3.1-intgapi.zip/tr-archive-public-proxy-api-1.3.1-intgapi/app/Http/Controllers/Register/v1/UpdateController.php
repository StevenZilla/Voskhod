<?php

namespace App\Http\Controllers\Register\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\Register\ValidateRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class UpdateController extends StoreController
{
    public function update(Request $request, RestClient $client, ValidateRegisterService $validateAcceptRegisterService, $registerId)
    {
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем выполнять запрос на обновление сводной описи. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем валидировать данные для обновления сводной описи. Время: {$nowDate}");
        $data = $validateAcceptRegisterService->storeValidateRequest($request->all());
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно свалидировали данные для обновление сводной описи. Время: {$nowDate}");

        $this->addActionSearchDossiers($data, $this->actions->first()[1]);
        $this->actions->first()->forget(1);

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Ищем дела для обновлении сводной описи. Время: {$nowDate}");
        $responseSettingsAndDossiers = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно нашли дела для обновлении сводной описи. Время: {$nowDate}");

        $this->actions->forget(0);

        $resultSearchSubdivisionAndDossier = json_decode($responseSettingsAndDossiers->getContent(), true)['data'];
        $settings = $this->registerService->setArchiveAndFund($resultSearchSubdivisionAndDossier['settings']['settings']);
        $data = array_merge($this->setDossiersId($resultSearchSubdivisionAndDossier, $data), $settings);
        $registerTypeCode = $this->registerService->checkSavePeriodDossiers($this->dataSaveTypeDossiers, $this->dataTempSavePeriodDossier);
        $data['register_type_id'] = $this->registerService->getRegisterType($registerTypeCode, $resultSearchSubdivisionAndDossier['register_type']['register_types']);

        $this->actions->first()->forget(0);

        try {
            $nowDate = microtime(true);
            Log::channel('single_register')->debug("Закрываем дела для обновления сводной описи. Время: {$nowDate}");
            $responseCloseDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        } catch (\Exception $exception) {
            $data = json_decode($exception->getMessage(), true);
            $data['target'] = 'REGISTER';
            $data['code'] = $exception->getCode();
            throw new CustomHttpResponseException(response()->json($data, $exception->getCode()));
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно закрыли дела для обновления сводной описи. Время: {$nowDate}");

        $this->actions->forget(1);

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        $action = $this->actions->first()->first();
        $action->setUrl(sprintf($action->getUrl(), $registerId));

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Отправляем запрос на обновление сводной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->registerService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно создали сводную опись. Время: {$nowDate}");

        return $this->searchRegister($request, $client, $registerId);
    }

    private function searchRegister(Request $request, RestClient $client, int $registerId)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $registerId));

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Отправляем запрос на поиск сводной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно нашли сводную опись, которую обновили. Время: {$nowDate}");

        $url = $this->registerService->returnUrl($request, $registerId);

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Начинаем формировать ответ сводную опись. Время: {$nowDate}");
        $dataResponse = $this->registerService->getFormattingResponseUpdate($response->getBody()->getContents(), $url);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_register')->debug("Успешно сформировали ответ сводной описи. Время: {$nowDate}. Время выполнения обновления сводной описи: {$diffDate}\n\n");


        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}
