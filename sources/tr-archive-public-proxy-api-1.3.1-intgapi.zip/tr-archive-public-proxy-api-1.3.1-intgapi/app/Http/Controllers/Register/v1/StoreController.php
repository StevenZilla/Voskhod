<?php

namespace App\Http\Controllers\Register\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Register\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Register\ValidateRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    protected $dataSaveTypeDossiers = [];
    protected $dataTempSavePeriodDossier = [];

    public function store(Request $request, RestClient $client, ValidateRegisterService $validateAcceptRegisterService)
    {
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем выполнять запрос на сохранении сводной описи. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем валидировать данные для создание сводной описи. Время: {$nowDate}");
        $data = $validateAcceptRegisterService->storeValidateRequest($request->all());
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно свалидировали данные для создание сводной описи. Время: {$nowDate}");

        $this->addActionSearchDossiers($data, $this->actions->first()[1]);
        $this->actions->first()->forget(1);

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Ищем дела для создание сводной описи. Время: {$nowDate}");
        $responseSettingsAndDossiers = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно нашли дела для создание сводной описи. Время: {$nowDate}");

        $resultSearchSubdivisionAndDossier = json_decode($responseSettingsAndDossiers->getContent(), true)['data'];
        $settings = $this->registerService->setArchiveAndFund($resultSearchSubdivisionAndDossier['settings']['settings']);
        $data = array_merge($this->setDossiersId($resultSearchSubdivisionAndDossier, $data), $settings);
        $registerTypeCode = $this->registerService->checkSavePeriodDossiers($this->dataSaveTypeDossiers, $this->dataTempSavePeriodDossier);
        $data['register_type_id'] = $this->registerService->getRegisterType($registerTypeCode, $resultSearchSubdivisionAndDossier['register_type']['register_types']);

        $this->actions->first()->forget(0);

        try {
            $nowDate = microtime(true);
            Log::channel('single_register')->debug("Закрываем дела для создание сводной описи. Время: {$nowDate}");
            $responseCloseDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        } catch (\Exception $exception) {
            $data = json_decode($exception->getMessage(), true);
            $data['target'] = 'REGISTER';
            $data['code'] = $exception->getCode();
            throw new CustomHttpResponseException(response()->json($data, $exception->getCode()));
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно закрыли дела для создание сводной описи. Время: {$nowDate}");

        $this->actions->forget(1);

        if (empty($data['dossier_ids'])) {
            $data['dossier_ids'] = [];
        }

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Отправляем запрос на создание сводной описи. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->registerService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно создали сводную опись. Время: {$nowDate}");

        return $this->searchRegister($request, $client, $dataResponse);
    }

    protected function addActionSearchDossiers(array $dataRegister, Action $action)
    {
        if (!empty($dataRegister['dossiers'])) {
            $this->createActionSearchDossiers($dataRegister['dossiers'], $action);
        }

        if (!empty($dataRegister['register_parts'])) {
            foreach ($dataRegister['register_parts'] as $registerPart) {
                if (!empty($registerPart['dossiers'])) {
                    $this->createActionSearchDossiers($registerPart['dossiers'], $action);
                }

                if (!empty($registerPart['children'])) {
                    $this->addActionSearchDossiers($registerPart['children'], $action);
                }
            }
        } else {
            foreach ($dataRegister as $childRegisterPart) {
                if (!empty($childRegisterPart['dossiers'])) {
                    $this->createActionSearchDossiers($childRegisterPart['dossiers'], $action);
                }

                if (!empty($childRegisterPart['children'])) {
                    $this->addActionSearchDossiers($childRegisterPart['children'], $action);
                }
            }
        }
    }

    protected function createActionSearchDossiers(array $dossiers, Action $action)
    {
        foreach ($dossiers as $dossier) {
            if (empty($dossier['id']) && !empty($dossier['dossier_index']) && !empty($dossier['nom_year'])) {
                $actionConfig = $action->getConfig();
                $aliasDossier = implode(',', [$dossier['dossier_index'], $dossier['nom_year']]);
                $actionConfig['path'] = sprintf($actionConfig['path'], $dossier['dossier_index'], $dossier['nom_year']);
                $aliasDossier = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $aliasDossier);
                $actionConfig['alias'] = $actionConfig['alias'] . '_' . $aliasDossier;

                $this->actions->first()->push(new Action($actionConfig));
            }
        }
    }

    protected function setDossiersId(array $dataResponseDossiers, array $dataRequestRegister) : array
    {
        if (!empty($dataRequestRegister['dossiers'])) {
            $dataRequestRegister['dossier_ids'] = array_merge(
                $this->setDossierId($dataResponseDossiers, $dataRequestRegister['dossiers']),
                $dataRequestRegister['dossier_ids'] ?? []
            );

            $this->addActionCloseDossier($dataRequestRegister['dossier_ids']);
        }

        if (!empty($dataRequestRegister['register_parts'])) {
            foreach ($dataRequestRegister['register_parts'] as $indexRegisterPart => $registerPart) {
                if (!empty($registerPart['dossiers'])) {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] = array_merge(
                        $this->setDossierId($dataResponseDossiers, $registerPart['dossiers']),
                        $dataRequestRegister['dossier_ids'] ?? []
                    );

                    $this->addActionCloseDossier($dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids']);
                } else {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] = !empty($dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids']) ? $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] : null;
                }

                if (!empty($registerPart['children'])) {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['children'] = $this->setDossiersId(
                        $dataResponseDossiers,
                        $registerPart['children']
                    );
                }
            }
        } else {
            if (!isset($dataRequestRegister['register_parts'])) {
                foreach ($dataRequestRegister as $indexChildRegisterPart => $childRegisterPart) {
                    if (!empty($childRegisterPart)) {
                        if (!empty($childRegisterPart['dossiers'])) {
                            $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] = array_merge(
                                $this->setDossierId($dataResponseDossiers, $childRegisterPart['dossiers']),
                                $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] ?? []
                            );

                            $this->addActionCloseDossier($dataRequestRegister[$indexChildRegisterPart]['dossier_ids']);
                        } else {
                            $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] = !empty($dataRequestRegister[$indexChildRegisterPart]['dossier_ids']) ? $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] : null;
                        }

                        if (!empty($childRegisterPart['children'])) {
                            $dataRequestRegister[$indexChildRegisterPart]['children'] = $this->setDossiersId(
                                $dataResponseDossiers,
                                $childRegisterPart['children']
                            );
                        }
                    }
                }
            }
        }

        return $dataRequestRegister;
    }

    protected function setDossierId(array $dataResponseDossiers, array $dossiers) : array
    {
        $data = [];

        foreach ($dossiers as $dossier) {
            $aliasDossier = implode(',', [$dossier['dossier_index'], $dossier['nom_year']]);
            $aliasDossier = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $aliasDossier);

            if (!empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]) && empty($dossier['id'])) {
                if (empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'])) {
                    throw new CustomHttpResponseException(response()->json([
                        'code' => 400,
                        'message' => "На нашли дело с индексом - {$dossier['dossier_index']} и годом номенклатуры {$dossier['nom_year']}",
                        'target' => 'ACCEPT_REGISTER',
                    ], 400));
                }

                $data[] = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['id'];
            } elseif (!empty($dossier['id'])) {
                $data[] = $dossier['id'];
            }

            if (!empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['save_type'])) {
                $dossierIndex = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['index'];
                $nomYear = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['nomenclatures']['year'];
                $saveType = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['save_type']['value'];
                $key = "Дело с индексом {$dossierIndex} и годом номенклатуры {$nomYear} имеет тип хранения {$saveType}";

                if (!empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['temp_save_period'])) {
                    $key .= " со сроком хранение {$dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['temp_save_period']} лет.";
                } else {
                    $key .= '.';
                }

                $this->dataSaveTypeDossiers[$key] = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['save_type']['code'];
                $this->dataTempSavePeriodDossier[$key] = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['temp_save_period'];
            }
        }

        return $data;
    }

    protected function addActionCloseDossier(array $idsDossier)
    {
        foreach ($idsDossier as $idDossier) {
            $actionConfig =  $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $idDossier);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $idDossier;

            $this->actions->first()->push(new Action($actionConfig));
        }
    }

    private function searchRegister(Request $request, RestClient $client, array $dataResponse)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $dataResponse['message']));

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Отправляем запрос на поиск сводной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно нашли сводную опись, которую создали. Время: {$nowDate}");

        $url = $this->registerService->returnUrl($request, $dataResponse['message']);

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Начинаем формировать ответ сводную опись. Время: {$nowDate}");
        $dataResponse = $this->registerService->getFormattingResponseStore($response->getBody()->getContents(), $url);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_register')->debug("Успешно сформировали ответ сводной описи. Время: {$nowDate}. Время выполнения сохранения сводной описи: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}