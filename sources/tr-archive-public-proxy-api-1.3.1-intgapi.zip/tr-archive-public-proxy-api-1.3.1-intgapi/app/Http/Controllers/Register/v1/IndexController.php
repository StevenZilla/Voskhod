<?php

namespace App\Http\Controllers\Register\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\Register\FilterRegisterService;
use App\Services\Controllers\Register\ValidateRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;
use function DeepCopy\deep_copy;

class IndexController extends ShowController
{
    public function index(Request $request, RestClient $client, ValidateRegisterService $validateService, FilterRegisterService $filterService)
    {
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Будем выполнять запрос на получения списка сводных описей. Время: {$nowDate}");

        $data = $validateService->indexValidateQueryRequest($request->query->all());
        $queryString = $filterService->filter($data);
        if (!empty($queryString)) {
            $this->actions->first()->first()->setUrl($this->actions->first()->first()->getUrl() . '?' . urldecode($queryString));
        }

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Запрашиваем список сводных описей. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);
        if ($response->getStatusCode() > 400) {
            $dataResponse = json_decode($response->getBody()->getContents(), true);
            $responseJson = response()->json($dataResponse, $response->getStatusCode());
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Успешно получили список сводных описей. Время: {$nowDate}");

        $registers = $this->registerService->parsingResponseIndex($response->getBody()->getContents(), $request->url());

        foreach ($registers['project_registers'] as &$reg) {
            $actions = deep_copy($this->actions);

            $nowDate = microtime(true);
            Log::channel('single_register')->debug("Получаем разделы и дела для сводной описи с идентификаторов {$reg['id']}. Время: {$nowDate}");
            $data = $this->getRegPartData($request, $client, $reg['id'], $actions);
            $nowDate = microtime(true);
            Log::channel('single_register')->debug("Успешно получили разделы и дела для сводной описи с идентификаторов {$reg['id']}. Время: {$nowDate}");

            $reg['register_parts'] = $data[0];
            $reg['dossiers'] = $data[1];
        }

        $nowDate = microtime(true);
        Log::channel('single_register')->debug("Начинаем формировать ответ для списка сводных описей. Время: {$nowDate}");
        $responseNom = $this->registerService->getFormattingResponseIndex($registers);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_register')->debug("Успешно сформировали ответ для списка сводных описей. Время: {$nowDate}. Время получения списка сводных описей: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseNom);
    }

}