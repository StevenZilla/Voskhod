<?php

namespace App\Http\Controllers\AcceptRegister;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\AcceptRegister\AcceptRegisterService;

class BaseController extends GatewayController
{
    protected $acceptRegisterService;

    public function __construct(Request $request, AcceptRegisterService $acceptRegisterService)
    {
        parent::__construct($request);

        $this->acceptRegisterService = $acceptRegisterService;
    }
}