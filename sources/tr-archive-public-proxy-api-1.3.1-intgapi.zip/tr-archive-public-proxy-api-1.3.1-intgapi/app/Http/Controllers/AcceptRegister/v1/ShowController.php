<?php

namespace App\Http\Controllers\AcceptRegister\v1;

use App\Http\Request;
use App\Routing\Action;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class ShowController extends IndexController
{
    public function show(Request $request, RestClient $client, $id)
    {
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем выполнять запрос на получения детальной информации сдаточной описи. Время: {$nowDate}");

        $this->prepareRequest($id);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получаем детальную информацию сдаточных описей, разделов и дел. Время: {$nowDate}");
        $response = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно получили детальную информацию сдаточных описей, разделов и дел. Время: {$nowDate}");

        $acceptRegisterResponse = json_decode($response->getContent(), true)['data'];
        $this->actions->forget(0);
        $registers = [];
        foreach ($acceptRegisterResponse as $keyWithId => $itemData) {
            preg_match('/((?:detail_accept_register)|(?:accept_register_parts)|(?:aggregate_accept_register_parts))_(\d+)/', $keyWithId, $matches);
            $acceptRegisterId = $matches[2];
            if ($matches[1] == 'detail_accept_register') {
                $registers[$acceptRegisterId] = $itemData;
            }
        }
        $acceptRegisters = $this->constructProjectRegisterData($acceptRegisterResponse, $registers);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получаем информацию о номенклатуре для дел в сдаточной описи Время: {$nowDate}");
        $nomenclaturesResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получили информацию о номенклатуре для дел в сдаточной описи Время: {$nowDate}");

        $dataResponse = $this->setNomenclatureYear(json_decode($nomenclaturesResponses->getContent(), true)['data'], $acceptRegisters)[$id];

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Начинаем формировать ответ для детальной информации сдаточной описи. Время: {$nowDate}");
        $responseAcceptRegister = $this->acceptRegisterService->getFormattingResponseShow($dataResponse);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_accept_register')->debug("Успешно сформировали ответ для детальной информации сдаточной описи. Время: {$nowDate}. Время запроса: {$diffDate}\n\n");

        return $responseAcceptRegister;

    }

    private function prepareRequest($id) {
        $actions = $this->actions->first()->toArray();
        foreach ($actions as $action) {
            $actionConfig = $action->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $id);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $id;

            $this->actions->first()->push(new Action($actionConfig));
        }
        $this->actions->first()->forget(0);
        $this->actions->first()->forget(1);
        $this->actions->first()->forget(2);
    }
}