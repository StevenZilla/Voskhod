<?php

namespace App\Http\Controllers\AcceptRegister\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\AcceptRegister\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\AcceptRegister\ValidateAcceptRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    public function store(Request $request, RestClient $client, ValidateAcceptRegisterService $validateAcceptRegisterService)
    {
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем выполнять запрос на сохранении сдаточной описи. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем валидировать данные для создание сдаточной описи. Время: {$nowDate}");
        $data = $validateAcceptRegisterService->storeValidateRequest($request->all());
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно свалидировали данные для создание сдаточной описи. Время: {$nowDate}");

        $this->updateActionSearchSubdivision($data['subdivision_code'], $this->actions->first()[0]);
        $this->addActionSearchDossiers($data, $this->actions->first()[1]);
        $this->actions->first()->forget(1);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Ищем дела и подразделение для создание сдаточной описи. Время: {$nowDate}");
        $responseSearchSubdivisionAndDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно нашли дела и подразделение для создание сдаточной описи. Время: {$nowDate}");

        $resultSearchSubdivisionAndDossier = json_decode($responseSearchSubdivisionAndDossier->getContent(), true)['data'];
        $data['subdivision_id'] = $this->acceptRegisterService->setSubdivisionId($resultSearchSubdivisionAndDossier['search_subdivision'], $data['subdivision_code']);
        $data = $this->setDossiersId($resultSearchSubdivisionAndDossier, $data);
        $this->actions->first()->forget(0);

        try {
            $nowDate = microtime(true);
            Log::channel('single_accept_register')->debug("Закрываем дела для создание сдаточной описи. Время: {$nowDate}");
            $responseCloseDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        } catch (\Exception $exception) {
            $data = json_decode($exception->getMessage(), true);
            $data['target'] = 'ACCEPT_REGISTER';
            $data['code'] = $exception->getCode();
            throw new CustomHttpResponseException(response()->json($data, $exception->getCode()));
        }
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно закрыли дела для создание сдаточной описи. Время: {$nowDate}");

        $this->actions->forget(1);

        if (empty($data['dossier_ids'])) {
            $data['dossier_ids'] = [];
        }

        foreach ($data as $key => $value) {
            if ($key === 'register_parts') {
                $request->request->set('accept_register_parts', $value);
            }

            $request->request->set($key, $value);
        }

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Отправляем запрос на создание сдаточной описи. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->acceptRegisterService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно создали сдаточную опись. Время: {$nowDate}");

        return $this->searchAcceptRegister($request, $client, $dataResponse);
    }

    protected function updateActionSearchSubdivision(string $subdivisionCode, Action $action)
    {
        $action->setUrl(sprintf($action->getUrl(), $subdivisionCode));
        return $action;
    }

    protected function addActionSearchDossiers(array $dataRegister, Action $action)
    {
        if (!empty($dataRegister['dossiers'])) {
            $this->createActionSearchDossiers($dataRegister['dossiers'], $action);
        }

        if (!empty($dataRegister['register_parts'])) {
            foreach ($dataRegister['register_parts'] as $registerPart) {
                if (!empty($registerPart['dossiers'])) {
                    $this->createActionSearchDossiers($registerPart['dossiers'], $action);
                }

                if (!empty($registerPart['children'])) {
                    $this->addActionSearchDossiers($registerPart['children'], $action);
                }
            }
        } else {
            foreach ($dataRegister as $childRegisterPart) {
                if (!empty($childRegisterPart['dossiers'])) {
                    $this->createActionSearchDossiers($childRegisterPart['dossiers'], $action);
                }

                if (!empty($childRegisterPart['children'])) {
                    $this->addActionSearchDossiers($childRegisterPart['children'], $action);
                }
            }
        }
    }

    protected function createActionSearchDossiers(array $dossiers, Action $action)
    {
        foreach ($dossiers as $dossier) {
            if (empty($dossier['id']) && !empty($dossier['index']) && !empty($dossier['nom_year'])) {
                $actionConfig = $action->getConfig();
                $aliasDossier = implode(',', [$dossier['index'], $dossier['nom_year']]);
                $actionConfig['path'] = sprintf($actionConfig['path'], $dossier['index'], $dossier['nom_year']);
                $aliasDossier = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $aliasDossier);
                $actionConfig['alias'] = $actionConfig['alias'] . '_' . $aliasDossier;

                $this->actions->first()->push(new Action($actionConfig));
            }
        }
    }

    private function searchAcceptRegister(Request $request, RestClient $client, array $dataResponse)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $dataResponse['message']));

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Отправляем запрос на поиск сдаточной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно нашли сдаточную опись, которую создали. Время: {$nowDate}");

        $url = $this->acceptRegisterService->returnUrl($request, $dataResponse['message']);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Начинаем формировать ответ сдаточную опись. Время: {$nowDate}");
        $dataResponse = $this->acceptRegisterService->getFormattingResponseStore($response->getBody()->getContents(), $url);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_accept_register')->debug("Успешно сформировали ответ сдаточной описи. Время: {$nowDate}. Время выполнения сохранения сдаточной описи: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }

    protected function setDossiersId(array $dataResponseDossiers, array $dataRequestRegister) : array
    {
        if (!empty($dataRequestRegister['dossiers'])) {
            $dataRequestRegister['dossier_ids'] = array_merge(
                $this->setDossierId($dataResponseDossiers, $dataRequestRegister['dossiers']),
                $dataRequestRegister['dossier_ids'] ?? []
            );

            $this->addActionCloseDossier($dataRequestRegister['dossier_ids']);
        }

        if (!empty($dataRequestRegister['register_parts'])) {
            foreach ($dataRequestRegister['register_parts'] as $indexRegisterPart => $registerPart) {
                if (!empty($registerPart['dossiers'])) {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] = array_merge(
                        $this->setDossierId($dataResponseDossiers, $registerPart['dossiers']),
                        $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] ?? []
                    );

                    $this->addActionCloseDossier($dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids']);
                } else {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] = !empty($dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids']) ? $dataRequestRegister['register_parts'][$indexRegisterPart]['dossier_ids'] : [];
                }

                if (!empty($registerPart['children'])) {
                    $dataRequestRegister['register_parts'][$indexRegisterPart]['children'] = $this->setDossiersId(
                        $dataResponseDossiers,
                        $registerPart['children']
                    );
                }
            }
        } else {
            if (!isset($dataRequestRegister['register_parts'])) {
                foreach ($dataRequestRegister as $indexChildRegisterPart => $childRegisterPart) {
                    if (!empty($childRegisterPart)) {
                        if (!empty($childRegisterPart['dossiers'])) {
                            $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] = array_merge(
                                $this->setDossierId($dataResponseDossiers, $childRegisterPart['dossiers']),
                                $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] ?? []
                            );

                            $this->addActionCloseDossier($dataRequestRegister[$indexChildRegisterPart]['dossier_ids']);
                        } else {
                            $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] = !empty($dataRequestRegister[$indexChildRegisterPart]['dossier_ids']) ? $dataRequestRegister[$indexChildRegisterPart]['dossier_ids'] : [];
                        }

                        if (!empty($childRegisterPart['children'])) {
                            $dataRequestRegister[$indexChildRegisterPart]['children'] = $this->setDossiersId(
                                $dataResponseDossiers,
                                $childRegisterPart['children']
                            );
                        }
                    }
                }
            }
        }

        return $dataRequestRegister;
    }

    protected function setDossierId(array $dataResponseDossiers, array $dossiers) : array
    {
        $data = [];

        foreach ($dossiers as $dossier) {
            $aliasDossier = implode(',', [$dossier['index'], $dossier['nom_year']]);
            $aliasDossier = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $aliasDossier);

            if (!empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]) && empty($dossier['id'])) {
                if (empty($dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'])) {
                    throw new CustomHttpResponseException(response()->json([
                        'code' => 400,
                        'message' => "На нашли дело с индексом - {$dossier['index']} и годом номенклатуры {$dossier['nom_year']}",
                        'target' => 'ACCEPT_REGISTER',
                    ], 400));
                }

                $data[] = $dataResponseDossiers["search_dossiers_{$aliasDossier}"]['dossiers'][0]['id'];
            } elseif (!empty($dossier['id'])) {
                $data[] = $dossier['id'];
            }
        }

        return $data;
    }

    private function addActionCloseDossier(array $idsDossier)
    {
        foreach ($idsDossier as $idDossier) {
            $actionConfig =  $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $idDossier);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $idDossier;

            $this->actions->first()->push(new Action($actionConfig));
        }
    }
}