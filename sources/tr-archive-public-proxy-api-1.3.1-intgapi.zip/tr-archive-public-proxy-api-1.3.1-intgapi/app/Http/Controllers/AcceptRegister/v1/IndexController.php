<?php

namespace App\Http\Controllers\AcceptRegister\v1;

use App\Http\Controllers\AcceptRegister\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\AcceptRegister\FilterAcceptRegisterService;
use App\Services\Controllers\AcceptRegister\ValidateAcceptRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class IndexController extends BaseController
{
    public function index(Request $request, RestClient $client, ValidateAcceptRegisterService $validateAcceptRegisterService, FilterAcceptRegisterService $filterAcceptRegisterService) {
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем выполнять запрос на получения списка сдаточных описей. Время: {$nowDate}");

        $data = $validateAcceptRegisterService->indexValidateQueryRequest($request->query->all());
        $queryString = $filterAcceptRegisterService->filter($data);

        if (!empty($queryString)) {
            $this->actions->first()->first()->setUrl($this->actions->first()->first()->getUrl() . '?' .urldecode($queryString));
        }

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Запрашиваем список сдаточных описей. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно получили список сдаточных описей. Время: {$nowDate}");

        $dataResponse = $this->acceptRegisterService->parsingResponseIndex($response->getBody()->getContents(), $request->url());

        $this->setProjectRegisterDataActions($dataResponse['accept_registers']);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получаем детальную информацию сдаточных описей, разделов и дел. Время: {$nowDate}");
        $acceptRegistersResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно получили детальную информацию сдаточных описей, разделов и дел. Время: {$nowDate}");

        $acceptRegisters = $this->constructProjectRegisterData(json_decode($acceptRegistersResponse->getContent(), true)['data'], $dataResponse['accept_registers']);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получаем информацию о номенклатуре для дел в сдаточной описи Время: {$nowDate}");
        $nomenclaturesResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(2);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Получили информацию о номенклатуре для дел в сдаточной описи Время: {$nowDate}");

        $dataResponse['accept_registers'] = $this->setNomenclatureYear(json_decode($nomenclaturesResponses->getContent(), true)['data'], $acceptRegisters);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Начинаем формировать ответ для списка сдаточных описей. Время: {$nowDate}");
        $responseAcceptRegister = $this->acceptRegisterService->getFormattingResponseIndex($dataResponse);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_accept_register')->debug("Успешно сформировали ответ для списка сдаточных описей. Время: {$nowDate}. Время получения списка сдаточных описей: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseAcceptRegister);
    }

    protected function setProjectRegisterDataActions(array $acceptRegisters)
    {
        $actions = $this->actions->first()->toArray();
        foreach ($acceptRegisters as $acceptRegister) {
            foreach ($actions as $action) {
                $actionConfig = $action->getConfig();
                $actionConfig['path'] = sprintf($actionConfig['path'], $acceptRegister['id']);
                $actionConfig['alias'] = $actionConfig['alias'] . '_' . $acceptRegister['id'];

                $this->actions->first()->push(new Action($actionConfig));
            }
        }

        $this->actions->first()->forget(0);
        $this->actions->first()->forget(1);
        $this->actions->first()->forget(2);
    }

    protected function constructProjectRegisterData(array $responseAcceptRegisters, array $acceptRegisters)
    {
        $detailedRegisters = [];
        $parts = [];
        $aggregatedParts = [];
        foreach ($responseAcceptRegisters as $keyWithId => $itemData) {
            preg_match('/((?:detail_accept_register)|(?:accept_register_parts)|(?:aggregate_accept_register_parts))_(\d+)/', $keyWithId, $matches);
            $acceptRegisterId = $matches[2];
            if ($matches[1] == 'detail_accept_register') {
                $detailedRegisters[$acceptRegisterId] = $itemData;
            } elseif ($matches[1] == 'accept_register_parts') {
                $parts[$acceptRegisterId] = $itemData;
            } elseif ($matches[1] == 'aggregate_accept_register_parts') {
                $aggregatedParts[$acceptRegisterId] = $itemData;
            }
        }

        foreach ($detailedRegisters as $registerId => $detailedRegister) {
            $acceptRegisters[$registerId]['create_date'] = $detailedRegister['create_date'];
            $acceptRegisters[$registerId]['guid_arch'] = $detailedRegister['guid_arch'];
            $acceptRegisters[$registerId]['dossiers'] = [];
        }

        foreach ($parts as $registerId => $part) {
            $acceptRegisters[$registerId]['register_parts'] = $part['accept_register_parts'];
        }

        foreach ($aggregatedParts as $registerId => $aggregatedPart) {
            foreach ($aggregatedPart['accept_register_parts'] as $part) {
                foreach ($part['dossiers'] as $dossier) {
                    if ($part['id'] == null) {
                        $acceptRegisters[$registerId]['dossiers'][] = ['id' => $dossier['id'], 'index' => $dossier['index']];
                    } else {
                        $acceptRegisters[$registerId]['register_parts'] = $this->setDossierInfoInRegisterPart($acceptRegisters[$registerId]['register_parts'], $part['id'], $dossier);
                    }

                    $actionConfig = $this->actions->first()->first()->getConfig();
                    $actionConfig['path'] = sprintf($actionConfig['path'], $dossier['id']);
                    $actionConfig['alias'] = $actionConfig['alias'] . '_' . $dossier['id'];

                    $this->actions->first()->push(new Action($actionConfig));
                }
            }
        }

        $this->actions->first()->forget(0);

        return $acceptRegisters;
    }


    private function setDossierInfoInRegisterPart(array $children, ?int $neededId, array $dossier)
    {
        $result = [];

        foreach($children as $key => $part) {
            if (!empty($part['children'])) {
                $part['children'] = $this->setDossierInfoInRegisterPart($part['children'], $neededId, $dossier);
            }
            if (isset($part['id']) && $part['id'] == $neededId) {
                $part['dossiers'][] = ['id' => $dossier['id'], 'index' => $dossier['index']];
            }
            $result[$key] = $part;
        }

        return $result;
    }

    protected function setNomenclatureYear(array $dossiersNomenclatures, array $acceptRegisters)
    {
        foreach ($dossiersNomenclatures as $keyWithId => $dossierNomenclatures) {
            $year = $dossierNomenclatures['nomenclatures'][0]['year'];
            preg_match('/get_nomenclature_(\d+)/', $keyWithId, $matches);
            $dossierId = $matches[1];
            $acceptRegisters = $this->setNomYear($year, $acceptRegisters, $dossierId);
        }

        return $acceptRegisters;
    }

    private function setNomYear(int $year, array $acceptRegisters, int $dossierId)
    {
        foreach ($acceptRegisters as $arKey => $acceptRegister) {
            $acceptRegister['dossiers'] = $this->setNomYearInDossiers($year, $dossierId, $acceptRegister['dossiers']);
            $acceptRegister['register_parts'] = $this->setNomYearInChildren($year, $dossierId, $acceptRegister['register_parts']);
            $acceptRegisters[$arKey] = $acceptRegister;
        }
        return $acceptRegisters;
    }

    private function setNomYearInDossiers(int $year, int $dossierId, array $dossiers)
    {
        $result = [];
        foreach ($dossiers as $key => $dossier) {
            if ($dossier['id'] == $dossierId) {
                $dossier['nom_year'] = $year;
            }
            $result[$key] = $dossier;
        }
        return $result;
    }

    private function setNomYearInChildren(int $year, int $dossierId, array $children)
    {
        $result = [];

        foreach ($children as $rpKey => $registerPart) {
            if (!empty($registerPart['children'])) {
                $registerPart['children'] = $this->setNomYearInChildren($year, $dossierId, $registerPart['children']);
            }
            if (!empty($registerPart['dossiers'])) {
                foreach ($registerPart['dossiers'] as $dKey => $dossier) {
                    if ($dossierId == $dossier['id']) {
                        $registerPart['dossiers'][$dKey]['nom_year'] = $year;
                    }
                }

            }
            $result[$rpKey] = $registerPart;
        }

        return $result;
    }
}