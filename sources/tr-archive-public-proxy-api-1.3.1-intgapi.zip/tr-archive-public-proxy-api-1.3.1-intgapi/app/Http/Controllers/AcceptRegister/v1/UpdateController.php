<?php

namespace App\Http\Controllers\AcceptRegister\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\AcceptRegister\ValidateAcceptRegisterService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class UpdateController extends StoreController
{
    public function update(Request $request, RestClient $client, ValidateAcceptRegisterService $validateAcceptRegisterService, $idRegister)
    {
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем выполнять запрос на обновление сдаточной описи. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Будем валидировать данные для обновления сдаточной описи. Время: {$nowDate}");
        $data = $validateAcceptRegisterService->storeValidateRequest($request->all());
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно свалидировали данные для обновление сдаточной описи. Время: {$nowDate}");

        $this->updateActionSearchSubdivision($data['subdivision_code'], $this->actions->first()[0]);
        $this->addActionSearchDossiers($data, $this->actions->first()[1]);
        $this->actions->first()->forget(1);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Ищем дела и подразделение для обновлении сдаточной описи. Время: {$nowDate}");
        $responseSearchSubdivisionAndDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно нашли дела и подразделение для обновлении сдаточной описи. Время: {$nowDate}");

        $resultSearchSubdivisionAndDossier = json_decode($responseSearchSubdivisionAndDossier->getContent(), true)['data'];
        $data['subdivision_id'] = $this->acceptRegisterService->setSubdivisionId($resultSearchSubdivisionAndDossier['search_subdivision'], $data['subdivision_code']);
        $data = $this->setDossiersId($resultSearchSubdivisionAndDossier, $data);
        $this->actions->first()->forget(0);

        try {
            $nowDate = microtime(true);
            Log::channel('single_accept_register')->debug("Закрываем дела для обновления сдаточной описи. Время: {$nowDate}");
            $responseCloseDossier = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        } catch (\Exception $exception) {
            $data = json_decode($exception->getMessage(), true);
            $data['target'] = 'ACCEPT_REGISTER';
            $data['code'] = $exception->getCode();
            throw new CustomHttpResponseException(response()->json($data, $exception->getCode()));
        }
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно закрыли дела для обновления сдаточной описи. Время: {$nowDate}");

        $this->actions->forget(1);

        foreach ($data as $key => $value) {
            if ($key === 'register_parts') {
                $request->request->set('accept_register_parts', $value);
            }

            $request->request->set($key, $value);
        }

        $action = $this->actions->first()->first();
        $action->setUrl(sprintf($action->getUrl(), $idRegister));

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Отправляем запрос на обновление сдаточной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->acceptRegisterService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно создали сдаточную опись. Время: {$nowDate}");

        return $this->searchAcceptRegister($request, $client, $idRegister);
    }

    private function searchAcceptRegister(Request $request, RestClient $client, $idAcceptRegister)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $idAcceptRegister));

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Отправляем запрос на поиск сдаточной описи. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Успешно нашли сдаточную опись, которую обновили. Время: {$nowDate}");

        $url = $this->acceptRegisterService->returnUrl($request, $idAcceptRegister);

        $nowDate = microtime(true);
        Log::channel('single_accept_register')->debug("Начинаем формировать ответ сдаточную опись. Время: {$nowDate}");
        $dataResponse = $this->acceptRegisterService->getFormattingResponseUpdate($response->getBody()->getContents(), $url);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_accept_register')->debug("Успешно сформировали ответ сдаточной описи. Время: {$nowDate}. Время выполнения обновления сдаточной описи: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }

    private function addActionCloseDossier(array $idsDossier)
    {
        foreach ($idsDossier as $idDossier) {
            $actionConfig =  $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $idDossier);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $idDossier;

            $this->actions->first()->push(new Action($actionConfig));
        }
    }
}
