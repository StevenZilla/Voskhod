<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\Auth\AuthService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;

class LoginController extends GatewayController
{
    public function auth(Request $request, RestClient $client, AuthService $authService)
    {
        $authService->authValidateRequest($request->all());
        $response = $this->post($request, $client);
        $dataResponse = $authService->getFormattingResponseAuth($response->getBody()->getContents(), $response->getStatusCode());

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}