<?php

namespace App\Http\Controllers\Healthcheck\v2;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class HealthcheckController extends GatewayController
{
    public function healthcheck(Request $request, RestClient $client)
    {
        try {
            $response = $this->simpleRequest($request, $client);
            if ($response->getStatusCode() === 200) {
                $isOk = true;
                $data = json_decode($response->getBody()->getContents(), true);

                $manifestPath = app()->basePath('manifest.json');
                if (file_exists($manifestPath)) {
                    $jsonString = file_get_contents($manifestPath);
                    $manifestData = json_decode($jsonString);
                } else {
                    $manifestData = new \stdClass();
                    $manifestData->plus_current_version_app = new \stdClass();
                    $manifestData->match_version_app = new \stdClass();
                    $manifestData->match_version_app->tr_archive_public_api = 'В корне проекта отсутствует файл manifest.json';
                    $isOk = false;
                }

                $manifestData->plus_current_version_app->tr_archive = $data['settings']['version_po'];

                $versionPath = app()->basePath('VERSION.txt');
                if (file_exists($versionPath)) {
                    $manifestData->plus_current_version_app->tr_archive_public_api = str_replace(array(' ', "\n", "\r", "\t"), '', file_get_contents($versionPath));
                } else {
                    $manifestData->plus_current_version_app->tr_archive_public_api = 'В корне проекта отсутствует файл VERSION.txt';
                    $isOk = false;
                }

                if ($isOk) {
                    $manifestData->code = 200;
                } else {
                    $manifestData->code = 500;
                }

                return response()->json($manifestData, $manifestData->code);
            } else {
                return $response;
            }
        } catch (\Exception $e) {
            if ($e instanceof CustomHttpResponseException) {
                return $e->getResponse();
            } else {
                Log::error("Не смогли получить healthcheck. Ошибка:\n{$e}");

                if ($e->getCode() === 0) {
                    $code = 500;
                } else {
                    $code = $e->getCode();
                }

                return response()->json([
                    'message' => 'Система Тр-Архива не доступна. Проверьте конфиги подключения.',
                    'code' => $code,
                ], $code);
            }
        }
    }
}