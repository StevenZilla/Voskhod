<?php

namespace App\Http\Controllers\Healthcheck\v1;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\RestClient;

class HealthcheckController extends GatewayController
{
    public function healthcheck(Request $request, RestClient $client)
    {
        try {
            $response = $this->simpleRequest($request, $client);

            if ($response->getStatusCode() === 200) {
                return response()->json([
                    'message' => 'Система Тр-Архива доступна.',
                    'code' => $response->getStatusCode(),
                ], $response->getStatusCode());
            } else {
                return $response;
            }
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Система Тр-Архива не доступна. Проверьте конфиги подключения.',
                'code' => $e->getCode(),
            ], $e->getCode());
        }
    }
}