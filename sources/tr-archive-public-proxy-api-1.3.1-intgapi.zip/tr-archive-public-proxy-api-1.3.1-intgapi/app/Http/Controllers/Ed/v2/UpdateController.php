<?php

namespace App\Http\Controllers\Ed\v2;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\v1\StoreController;
use App\Http\Request;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Http\Exceptions\HttpResponseException;


class UpdateController extends StoreController
{
    public function update(Request $request, RestClient $client, ValidateEdService $validateEdService, $guidArch)
    {
        $data = $validateEdService->storeValidateRequest($request->all());
        $data['dossier_id'] = null;

        $this->actions->first()->first()->setPathVariables(['guid_arch' => $guidArch]);

        if (!empty($data['dossiers'])) {
            $resultActionDossierId = $this->edService->setActionDossierId($this->actions->first()[1], $data['dossiers']);
        } else {
            $this->actions->first()->forget(1);
        }

        if (!empty($data['subdivision_code'])) {
            $resultActionSubdivisionId = $this->edService->setActionSubdivisionId($this->actions->first()[2], $data['subdivision_code']);
        } else {
            $this->actions->first()->forget(2);
        }

        $dataResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $resultDataResponse = json_decode($dataResponse->getContent(), true)['data'];

        if (!empty($data['dossiers'])) {
            $data['dossier_id'] = $this->edService->getDossierId($resultDataResponse['search_dossier']);
        }

        if (!empty($data['subdivision_code'])) {
            $data['subdivision_id'] = $this->edService->setSubdivisionId($resultDataResponse['search_subdivision'], $data['subdivision_code']);
        }

        if (!empty($resultDataResponse['search_id_ed']['id'])) {
            $id = $resultDataResponse['search_id_ed']['id'];
        } else {
            if (empty($idEd)) {
                throw new HttpResponseException(response()->json([
                    'code' => 404,
                    'message' => "Не нашли ЭД с идентификатором {$guidArch}",
                    'target' => 'ED',
                ], 404));
            }
        }

        $this->addActionsEd($id);

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        $responses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $resultResponses = json_decode($responses->getContent(), true);

        if (empty($resultResponses['data']['update_ed'])) {
            $url = $this->edService->returnUrl($request, $resultResponses['data']['search_ed']['guid_arch']);

            $dataFormattingResponseStore = $this->edService->getFormattingResponseStore($resultResponses['data']['search_ed'], $url, 200);
            $this->registrationActions('Успешно обновили электронный документ.');
            return $dataFormattingResponseStore;
        } else {
            throw new CustomHttpResponseException(response()->json($resultResponses['data']['update_ed'], $resultResponses['data']['update_ed']['code'] ?? 400));
        }
    }

    protected function addActionsEd(int $id)
    {
        $actionSearchEd = $this->actions->first()[0];
        $actionSearchEd->setPathVariables(['ed_id' => $id]);

        $actionUpdateEd = $this->actions->first()[1];
        $actionUpdateEd->setPathVariables(['ed_id' => $id]);
    }
}