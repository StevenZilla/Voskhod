<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Ed\FilterEdService;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class IndexController extends BaseController
{
    public function index(Request $request, RestClient $client, ValidateEdService $validateEdService, FilterEdService $filterEdService)
    {
        $data = $validateEdService->indexValidateQueryRequest($request->query->all());
        $queryString = $filterEdService->filter($data);

        if (!empty($queryString)) {
            $this->actions->first()->first()->setUrl($this->actions->first()->first()->getUrl() . '?' .urldecode($queryString));
        }

        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);

        $dataResponse = $this->edService->parsingResponseIndex($response->getBody()->getContents(), $request->url());

        $this->addActionSearchEd($dataResponse['eds']);

        $edResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);

        $responseSearchDataEd = json_decode($edResponses->getContent(), true);

        $dataResponse['eds'] = $this->getParsingDetailEds($responseSearchDataEd['data'], $dataResponse['eds']);

        $dossierResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(2);

        $dataDossiersResponse = json_decode($dossierResponses->getContent(), true);
        $dataResponse['eds'] = $this->edService->mergeEdsAndDossier($dataResponse['eds'], $dataDossiersResponse['data']);

        $responseEds = $this->edService->getFormattingResponseIndex($dataResponse);

        $this->registrationActions('Успешно сформировали ответ для списка электронных документов.');
        return SetResponseHeaders::setHeadersResponse($response, $responseEds);
    }

    protected function addActionSearchEd(array $eds)
    {
        $cloneActionDetailEd = clone $this->actions->first()[0];
        $cloneActionFiles = clone $this->actions->first()[1];
        $this->actions->first()->forget(0);
        $this->actions->first()->forget(1);

        foreach ($eds as $ed) {
            $actionDetailEd = clone $cloneActionDetailEd;
            $actionDetailEd->setAlias("detail_ed_{$ed['id']}");
            $actionDetailEd->setPathVariables(['id_ed' => $ed['id']]);

            $actionFiles = clone $cloneActionFiles;
            $actionFiles->setAlias("ed_files_{$ed['id']}");
            $actionFiles->setPathVariables(['id_ed' => $ed['id']]);

            $this->actions->first()->push($actionDetailEd);
            $this->actions->first()->push($actionFiles);
        }
    }

    protected function getParsingDetailEds(array $responseEds, array $eds)
    {
        $cloneActionDetailDossier = clone $this->actions->first()[0];
        $cloneActionNomenclatures = clone $this->actions->first()[1];
        $this->actions->first()->forget(0);
        $this->actions->first()->forget(1);

        foreach ($eds as $id => $ed) {
            if (!empty($responseEds["detail_ed_{$id}"])) {
                $eds[$id]['save_type'] = !empty($responseEds["detail_ed_{$id}"]['save_type']['value']) ? $responseEds["detail_ed_{$id}"]['save_type']['value'] : null;

                if (!empty($responseEds["detail_ed_{$id}"]['dossier']['id'])) {
                    $eds[$id]['dossier_id'] = $responseEds["detail_ed_{$id}"]['dossier']['id'];

                    $actionDetailDossier = clone $cloneActionDetailDossier;
                    $actionDetailDossier->setAlias("detail_dossier_{$id}");
                    $actionDetailDossier->setPathVariables(['dossier_id' => $responseEds["detail_ed_{$id}"]['dossier']['id']]);

                    $actionNomenclature = clone $cloneActionNomenclatures;
                    $actionNomenclature->setAlias("list_nomenclature_{$id}");
                    $actionNomenclature->setPathVariables(['dossier_id' => $responseEds["detail_ed_{$id}"]['dossier']['id']]);

                    $this->actions->first()->push($actionDetailDossier);
                    $this->actions->first()->push($actionNomenclature);
                } else {
                    $eds[$id]['dossier_id'] = $responseEds["detail_ed_{$id}"]['dossier']['id'];
                }

            }

            if (!empty($responseEds["ed_files_{$id}"])) {
                $fullSize = 0;
                if (!empty($responseEds["ed_files_{$id}"]['files'])) {
                    foreach ($responseEds["ed_files_{$id}"]['files'] as $file) {
                        $fullSize += $file['size'];
                    }
                }


                $eds[$id]['full_size'] = $fullSize;
            }
        }

        return $eds;
    }

    protected function setKeyIdDossier(array $dossiers) : array
    {
        $data = [];
        foreach ($dossiers as $dossier) {
            $data[$dossier['id']] = $dossier;

            $actionConfig = $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $dossier['id']);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $dossier['id'];

            $this->actions->first()->push(new Action($actionConfig));
        }

        $this->actions->first()->forget(0);
        return $data;
    }
}