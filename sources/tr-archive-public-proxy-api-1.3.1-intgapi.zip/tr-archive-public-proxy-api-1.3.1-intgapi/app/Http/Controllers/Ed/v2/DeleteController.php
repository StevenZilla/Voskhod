<?php

namespace App\Http\Controllers\Ed\v2;

use App\Http\Controllers\Ed\BaseController;
use App\Http\Request;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\RestClient;

class DeleteController extends BaseController
{
    public function destroy(Request $request, RestClient $client, ValidateEdService $validateEdService)
    {
        $data = $validateEdService->deleteValidateRequest($request->all());

        $this->edService->setActionSearchEdId($data['guid_eds'], $this->actions->first());

        $responseSearchEd = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);

        $edsId = $this->edService->setEdId(json_decode($responseSearchEd->getContent(), true)['data']);
        $this->edService->setActionDeleteEd($edsId, $this->actions->first());

        $responseDeleteEd = $this->getMultiActions($request, $client, collect([$this->actions->first()]));

        $dataResponse = json_decode($responseDeleteEd->getContent(), true)['data'];
        $this->edService->setResponseDeleteEds($dataResponse);

        $this->registrationActions('Успешно выполнили запрос на удаление ЭД');
        return $this->edService->getFormattingResponseDelete();
    }
}