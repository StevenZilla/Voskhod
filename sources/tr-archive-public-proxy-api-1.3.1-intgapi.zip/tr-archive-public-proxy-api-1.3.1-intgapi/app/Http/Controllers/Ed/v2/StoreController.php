<?php

namespace App\Http\Controllers\Ed\v2;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\BaseController;
use App\Http\Request;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    public function store(Request $request, RestClient $client, ValidateEdService $validateEdService)
    {
        $data = $validateEdService->storeValidateRequest($request->all());
        $data['dossier_id'] = null;

        if (!empty($data['dossiers'])) {
            $resultActionDossierId = $this->edService->setActionDossierId($this->actions->first()[0], $data['dossiers']);
        } else {
            $this->actions->first()->forget(0);
        }

        if (!empty($data['subdivision_code'])) {
            $resultActionSubdivisionId = $this->edService->setActionSubdivisionId($this->actions->first()[1], $data['subdivision_code'] ?? '');
        } else {
            $this->actions->first()->forget(1);
        }

        if (!empty($resultActionSubdivisionId) || !empty($resultActionDossierId)) {
            $dataResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));

            $resultDataResponse = json_decode($dataResponse->getContent(), true)['data'];

            if (!empty($data['dossiers'])) {
                $data['dossier_id'] = $this->edService->getDossierId($resultDataResponse['search_dossier']);
            }

            if (!empty($data['subdivision_code'])) {
                $data['subdivision_id'] = $this->edService->setSubdivisionId($resultDataResponse['search_subdivision'], $data['subdivision_code']);
            }
        }

        $this->actions->forget(0);

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        return $this->saveEd($request, $client);
    }

    private function saveEd(Request $request, RestClient $client)
    {
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(1);
        $jsonEd = $response->getBody()->getContents();
        $dataResponse = json_decode($jsonEd, true);

        if (!empty($dataResponse['code']) && $dataResponse['code'] >= 400) {
            $responseJson = response()->json($dataResponse, $dataResponse['code']);
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }

        return $this->searchEd($request, $client, $dataResponse);
    }

    private function searchEd(Request $request, RestClient $client, array $dataResponse)
    {
        $action = $this->actions->first()->first();
        $action->setPathVariables(['ed_id' => $dataResponse['message']]);

        $response = $this->simpleActionRequest($request, $client, $action);

        $dataResponseSearchEd = json_decode($response->getBody()->getContents(), true);
        $url = $this->edService->returnUrl($request, $dataResponseSearchEd['guid_arch']);

        $dataFormattingResponseStore = $this->edService->getFormattingResponseStore($dataResponseSearchEd, $url);

        $this->registrationActions('Успешно создали электронный документ.');
        return SetResponseHeaders::setHeadersResponse($response, $dataFormattingResponseStore);
    }
}