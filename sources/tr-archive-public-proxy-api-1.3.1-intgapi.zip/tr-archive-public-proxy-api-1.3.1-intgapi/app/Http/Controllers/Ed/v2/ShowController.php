<?php

namespace App\Http\Controllers\Ed\v2;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class ShowController extends IndexController
{
    public function show(Request $request, RestClient $client, $guidArch)
    {
        $this->actions->first()->first()->setPathVariables(['guid_arch' => $guidArch]);

        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);
        $id = json_decode($response->getBody()->getContents(), true)['id'];

        $this->addActionSearchEd([['id' => $id]]);

        $edResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);
        $responseSearchDataEd = json_decode($edResponses->getContent(), true);

        $dataResponse['eds'] = $this->getParsingDetailEds($responseSearchDataEd['data'], [$id => $responseSearchDataEd['data']["detail_ed_{$id}"]]);
        $dossierResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(2);

        $dataDossiersResponse = json_decode($dossierResponses->getContent(), true);
        $dataResponse['eds'] = $this->edService->mergeEdsAndDossier($dataResponse['eds'], $dataDossiersResponse['data']);

        $responseEds = $this->edService->getFormattingResponseShow($dataResponse);

        $this->registrationActions('Успешно сформировали ответ для детальной информации электронного документа.');

        return SetResponseHeaders::setHeadersResponse($response, $responseEds);
    }
}