<?php

namespace App\Http\Controllers\Ed\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\BaseController;
use App\Http\Request;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    public function store(Request $request, RestClient $client, ValidateEdService $validateEdService)
    {
        return response()->json(['code' => 404, 'message' => 'Текущий запрос не работает. Используйте версию v2.', 'logic_status_code' => 404, 'target' => 'ED'], 404);
//        $nowDate = microtime(true);
//        Log::channel('single_ed')->debug("Будем выполнять запрос на создание электронного документа. Время: {$nowDate}");
//
//        $nowDate = microtime(true);
//        Log::channel('single_ed')->debug("Будем валидировать данные для создание электронного документа. Время: {$nowDate}");
//        $data = $validateEdService->storeValidateRequest($request->all());
//        $nowDate = microtime(true);
//        Log::channel('single_ed')->debug("Успешно свалидировали данные для создание электронного документа. Время: {$nowDate}");
//
//        $this->getActionDossierId($data['dossiers'] ?? null);
//        $this->getActionSubdivisionId($data['subdivision_code'] ?? null);
//
//        $nowDate = microtime(true);
//        Log::channel('single_ed')->debug("Будем делать запрос на получение подразделения и дела для электронного документа. Время: {$nowDate}");
//        $dataResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
//        $this->actions->forget(0);
//        $nowDate = microtime(true);
//        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение подразделения и дела для электронного документа. Время: {$nowDate}");
//
//        $resultDataResponse = json_decode($dataResponse->getContent(), true)['data'];
//
//        if (!empty($data['dossiers'])) {
//            $data['dossier_id'] = $this->edService->getDossierId($resultDataResponse['search_dossier']);
//        } else {
//            $data['dossier_id'] = null;
//        }
//
//        if (!empty($data['subdivision_code'])) {
//            $data['subdivision_id'] = $this->edService->setSubdivisionId($resultDataResponse['search_subdivision'], $data['subdivision_code']);
//        }
//
//        foreach ($data as $key => $value) {
//            $request->request->set($key, $value);
//        }
//
//        return $this->saveEd($request, $client);
    }

    protected function getActionDossierId(array $dossier = null)
    {
        if (!empty($dossier)) {
            $action = $this->actions->first()->first();
            $action->setUrl(sprintf($action->getUrl(), $dossier['dossier_index'], $dossier['nom_year']));
        } else {
            $this->actions->first()->forget(0);
        }

        return null;
    }

    protected function getActionSubdivisionId(string $codeSubdivision = null)
    {
        if (!empty($codeSubdivision)) {
            $action = $this->actions->first()[1];
            $action->setUrl(sprintf($action->getUrl(), $codeSubdivision));
        }

        return null;
    }

    private function saveEd(Request $request, RestClient $client)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Отправляем запрос на создание электронного документа. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(1);
        $jsonEd = $response->getBody()->getContents();
        $dataResponse = json_decode($jsonEd, true);
        if (!empty($dataResponse['code']) && $dataResponse['code'] >= 400) {
            $responseJson = response()->json($dataResponse, 400);
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно создали электронный документ. Время: {$nowDate}");

        return $this->searchEd($request, $client, $dataResponse);
    }

    private function searchEd(Request $request, RestClient $client, array $dataResponse)
    {
        $action = $this->actions->first()->first();
        $action->setUrl(sprintf($action->getUrl(), $dataResponse['message']));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем запрашивать информацию об электронном документе. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно запросили информацию об электронном документе. Время: {$nowDate}");

        $url = $this->edService->returnUrl($request, $dataResponse['message']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем формировать ответ электронного документа. Время: {$nowDate}");
        $dataResponse = $this->edService->getFormattingResponseStore($response->getBody()->getContents(), $url);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_ed')->debug("Успешно сформировали ответ электронного документа. Время: {$nowDate}. Время выполнения сохранения электронного документа: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}