<?php

namespace App\Http\Controllers\Ed\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class ShowController extends IndexController
{
    public function show(Request $request, RestClient $client, $id)
    {
        # TODO необходимо сгруппировать роуты

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на получения детальной информации электронного документа. Время: {$nowDate}");

        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $id));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на получения детальной страницы электронного документа. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);

        if ($response->getStatusCode() > 400) {
            $dataResponse = json_decode($response->getBody()->getContents(), true);
            $responseJson = response()->json($dataResponse, $response->getStatusCode());
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получения детальной страницы электронного документа. Время: {$nowDate}");

        $this->actions->forget(0);
        $dataResponse = $this->edService->parsingResponseShow($response->getBody()->getContents());

        $dataResponse['eds'] = $this->getParsingDetailEds($dataResponse['eds'], $dataResponse['eds']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение дел электронных документов. Время: {$nowDate}");
        $dossierResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение дел электронных документов. Время: {$nowDate}");

        $dataDossiers = $this->setKeyIdDossier(json_decode($dossierResponses->getContent(), true)['data']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение номенклатур для дел электронных документов. Время: {$nowDate}");
        $nomResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(2);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение номенклатур для дел электронных документов. Время: {$nowDate}");

        $dataDossiers = $this->edService->mergeDossierAndNom(json_decode($nomResponses->getContent(), true)['data'], $dataDossiers);

        $dataResponse['eds'] = $this->edService->mergeEdsAndDossier($dataResponse['eds'], $dataDossiers);
        $this->createActionOnRequestFilesEd($dataResponse['eds']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение файлов электронных документов. Время: {$nowDate}");
        $filesResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(3);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение файлов электронных документов. Время: {$nowDate}");

        $dataResponse['eds'] = $this->edService->setFullSizeEds($dataResponse['eds'], json_decode($filesResponses->getContent(), true)['data']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем формировать ответ для детальной информации электронного документа. Время: {$nowDate}");
        $responseEds = $this->edService->getFormattingResponseShow($dataResponse);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_ed')->debug("Успешно сформировали ответ для детальной информации электронного документа. Время: {$nowDate}. Время получения детальной информации электронного документа: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseEds);
    }
}