<?php

namespace App\Http\Controllers\Ed\v1;

use App\Http\Controllers\Ed\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Ed\FilterEdService;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class IndexController extends BaseController
{
    public function index(Request $request, RestClient $client, ValidateEdService $validateEdService, FilterEdService $filterEdService)
    {
        # TODO необходимо сгруппировать роуты

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на получения списка электронных документов. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем валидировать фильтрацию списка электронных документов. Время: {$nowDate}");
        $data = $validateEdService->indexValidateQueryRequest($request->query->all());
        $queryString = $filterEdService->filter($data);

        if (!empty($queryString)) {
            $this->actions->first()->first()->setUrl($this->actions->first()->first()->getUrl() . '?' .urldecode($queryString));
        }
        Log::channel('single_ed')->debug("Успешно свалидировали фильтрацию списка электронных документов. Время: {$nowDate}");


        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на получения списка электронных документов. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение списка электронных документов. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем парсить ответ на получение списка электронных документов. Изменяем роуты для пагинации. Время: {$nowDate}");
        $dataResponse = $this->edService->parsingResponseIndex($response->getBody()->getContents(), $request->url());
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно пропарсили ответ на получение списка электронных документов. Изменили роуты для пагинации. Время: {$nowDate}");

        $this->addActionSearchDossier($dataResponse['eds']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение детальной информации электронных документов. Время: {$nowDate}");
        $edResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(1);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно завершили запрос на получение детальной информации электронных документов. Время: {$nowDate}");

        $dataResponse['eds'] = $this->getParsingDetailEds(json_decode($edResponses->getContent(), true)['data'], $dataResponse['eds']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение дел электронных документов. Время: {$nowDate}");
        $dossierResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(2);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение дел электронных документов. Время: {$nowDate}");
        $dataDossiers = $this->setKeyIdDossier(json_decode($dossierResponses->getContent(), true)['data']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение номенклатур для дел электронных документов. Время: {$nowDate}");
        $nomResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(3);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение номенклатур для дел электронных документов. Время: {$nowDate}");

        $dataDossiers = $this->edService->mergeDossierAndNom(json_decode($nomResponses->getContent(), true)['data'], $dataDossiers);

        $dataResponse['eds'] = $this->edService->mergeEdsAndDossier($dataResponse['eds'], $dataDossiers);
        $this->createActionOnRequestFilesEd($dataResponse['eds']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение файлов электронных документов. Время: {$nowDate}");
        $filesResponses = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(4);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение файлов электронных документов. Время: {$nowDate}");

        $dataResponse['eds'] = $this->edService->setFullSizeEds($dataResponse['eds'], json_decode($filesResponses->getContent(), true)['data']);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем формировать ответ для списка электронных документов. Время: {$nowDate}");
        $responseEds = $this->edService->getFormattingResponseIndex($dataResponse);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_ed')->debug("Успешно сформировали ответ для списка электронных документов. Время: {$nowDate}. Время получения списка электронных документов: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseEds);
    }

    protected function addActionSearchDossier(array $eds)
    {
        foreach ($eds as $ed) {
            $actionConfig = $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $ed['id']);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $ed['guid_arch'];

            $this->actions->first()->push(new Action($actionConfig));
        }

        $this->actions->first()->forget(0);
    }

    protected function getParsingDetailEds(array $responseEds, array $eds)
    {
        foreach ($responseEds as $responseEd) {
            $eds[$responseEd['id']]['save_type'] = !empty($responseEd['save_type']['value']) ? $responseEd['save_type']['value'] : null;
            $eds[$responseEd['id']]['dossier_id'] = !empty($responseEd['dossier']['id']) ? $responseEd['dossier']['id'] : null;
            if (!empty($responseEd['dossier']['id'])) {
                $actionConfig = $this->actions->first()->first()->getConfig();
                $actionConfig['path'] = sprintf($actionConfig['path'], $responseEd['dossier']['id']);
                $actionConfig['alias'] = $actionConfig['alias'] . '_' . $responseEd['dossier']['id'];

                $this->actions->first()->push(new Action($actionConfig));
            }
        }

        $this->actions->first()->forget(0);

        return $eds;
    }

    protected function setKeyIdDossier(array $dossiers) : array
    {
        $data = [];
        foreach ($dossiers as $dossier) {
            $data[$dossier['id']] = $dossier;

            $actionConfig = $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $dossier['id']);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $dossier['id'];

            $this->actions->first()->push(new Action($actionConfig));
        }

        $this->actions->first()->forget(0);
        return $data;
    }

    protected function createActionOnRequestFilesEd(array $eds)
    {
        foreach ($eds as $ed) {
            $actionConfig = $this->actions->first()->first()->getConfig();
            $actionConfig['path'] = sprintf($actionConfig['path'], $ed['id']);
            $actionConfig['alias'] = $actionConfig['alias'] . '_' . $ed['id'];

            $this->actions->first()->push(new Action($actionConfig));
        }

        $this->actions->first()->forget(0);
    }
}