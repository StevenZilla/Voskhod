<?php

namespace App\Http\Controllers\Ed\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\Ed\ValidateEdService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class UpdateController extends StoreController
{
    public function update(Request $request, RestClient $client, string $edId, ValidateEdService $validateEdService)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на обновление электронного документа. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем валидировать данные для обновления электронного документа. Время: {$nowDate}");
        $data = $validateEdService->storeValidateRequest($request->all());
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно свалидировали данные для обновления электронного документа. Время: {$nowDate}");

        $this->getActionDossierId($data['dossiers'] ?? null);
        $this->getActionSubdivisionId($data['subdivision_code'] ?? null);

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем делать запрос на получение подразделения и дела для электронного документа. Время: {$nowDate}");
        $dataResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение подразделения и дела для электронного документа. Время: {$nowDate}");

        $resultDataResponse = json_decode($dataResponse->getContent(), true)['data'];

        if (!empty($data['dossiers'])) {
            $data['dossier_id'] = $this->edService->getDossierId($resultDataResponse['search_dossier']);
        } else {
            $data['dossier_id'] = null;
        }

        if (!empty($data['subdivision_code'])) {
            $data['subdivision_id'] = $this->edService->setSubdivisionId($resultDataResponse['search_subdivision'], $data['subdivision_code']);
        } else {
            $data['subdivision_id'] = null;
        }

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        return $this->saveEd($request, $client, $edId);
    }

    private function saveEd(Request $request, RestClient $client, string $edId)
    {
        $action = $this->actions->first()->first();
        $action->setUrl(sprintf($action->getUrl(), $edId));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Отправляем запрос на обновление электронного документа. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(1);
        $jsonEd = $response->getBody()->getContents();
        $dataResponse = json_decode($jsonEd, true);
        if (!empty($dataResponse['code']) && $dataResponse['code'] >= 400) {
            $responseJson = response()->json($dataResponse, 400);
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно обновили электронный документ. Время: {$nowDate}");

        return $this->searchEd($request, $client, $edId);
    }

    private function searchEd(Request $request, RestClient $client, string $edId)
    {
        foreach ($this->actions->first() as $action) {
            if ($action->getAlias() === 'search_ed') {
                $action->setUrl(sprintf($action->getUrl(), $edId));
                $nowDate = microtime(true);
                Log::channel('single_ed')->debug("Будем запрашивать информацию об электронном документе. Время: {$nowDate}");
                $response = $this->simpleActionRequest($request, $client, $action);
                $nowDate = microtime(true);
                Log::channel('single_ed')->debug("Успешно запросили информацию об электронном документе. Время: {$nowDate}");

                $url = $this->edService->returnUrl($request, $edId);

                $nowDate = microtime(true);
                Log::channel('single_ed')->debug("Начинаем формировать ответ электронного документа. Время: {$nowDate}");
                $dataResponse = $this->edService->getFormattingResponseStore($response->getBody()->getContents(), $url);
                $nowDate = microtime(true);
                $diffDate = $nowDate - $this->startTimestamp;
                Log::channel('single_ed')->debug("Успешно сформировали ответ электронного документа. Время: {$nowDate}. Время выполнения сохранения электронного документа: {$diffDate}\n\n");

                return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
            }
        }
    }
}