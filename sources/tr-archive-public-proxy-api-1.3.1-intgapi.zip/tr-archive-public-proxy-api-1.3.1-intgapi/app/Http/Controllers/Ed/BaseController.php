<?php

namespace App\Http\Controllers\Ed;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\Ed\EdService;
use Illuminate\Support\Facades\Log;

class BaseController extends GatewayController
{
    protected $edService;

    public function __construct(Request $request, EdService $edService)
    {
        parent::__construct($request);

        $this->edService = $edService;
    }
}