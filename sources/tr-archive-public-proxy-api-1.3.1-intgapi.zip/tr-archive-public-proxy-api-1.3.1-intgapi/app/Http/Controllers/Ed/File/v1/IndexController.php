<?php

namespace App\Http\Controllers\Ed\File\v1;

use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class IndexController extends BaseController
{
    public function index(Request $request, RestClient $client, $idEd)
    {
        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $idEd));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на получения списка файлов электронных документов. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на получение файлов электронных документов. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Начинаем формировать ответ для списка файлов электронного документа. Время: {$nowDate}");
        $fileResponse = $this->fileService->getFormattingResponseIndex(json_decode($response->getBody()->getContents(), true));
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_ed')->debug("Успешно сформировали ответ для списка файлов электронных документов. Время: {$nowDate}. Время получения списка электронных документов: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $fileResponse);
    }
}