<?php

namespace App\Http\Controllers\Ed\File\v1;

use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class ViewerController extends BaseController
{
    public function viewer(Request $request, RestClient $client, string $base64Path)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на предпросмотр файла электронного документа. Время: {$nowDate}");

        $pathToFile = base64_decode($base64Path);
        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $pathToFile));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Выполняем запрос на предпросмотр файла электронного документа. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно выполнили запрос на предпросмотр файла электронного документа. Время: {$nowDate}");

        return $response;
    }
}