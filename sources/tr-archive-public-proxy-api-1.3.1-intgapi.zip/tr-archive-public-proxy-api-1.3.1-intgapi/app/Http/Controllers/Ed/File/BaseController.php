<?php

namespace App\Http\Controllers\Ed\File;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\Ed\File\FileService;

class BaseController extends GatewayController
{
    protected $fileService;

    public function __construct(Request $request, FileService $fileService)
    {
        parent::__construct($request);

        $this->fileService = $fileService;
    }
}