<?php

namespace App\Http\Controllers\Ed\File\v2;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Ed\File\ValidateFileService;
use App\Services\RestClient;
use GuzzleHttp\Cookie\CookieJar;
use Illuminate\Http\Exceptions\HttpResponseException;

class UploadController extends BaseController
{
    public function upload(Request $request, RestClient $client, ValidateFileService $validateFileService, $guidArch)
    {
        $validateFileService->updateFilesValidate($request->all());

        $settingsResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);

        $dataSettingsResponse = json_decode($settingsResponse->getContent(), true);
        $idEd = $dataSettingsResponse['data']['search_id_ed']['id'];

        if (empty($idEd)) {
            throw new HttpResponseException(response()->json([
                'code' => 404,
                'message' => "Не нашли ЭД с идентификатором {$guidArch}",
                'target' => 'ED',
            ], 404));
        }

        $this->actions->first()->first()->setPathVariables(['ed_id' => $idEd]);
        $responseFiles = $this->simpleActionRequestIgnoreMethod($request, $client, $this->actions->first()->first());
        $this->actions->forget(1);
        $dataRequest = json_decode($request->all('data')['data'], true);

        $this->mappingSourceGuidSed(json_decode($responseFiles->getBody(), true)['files'], $dataRequest['files']);

        $request->request->set('data', json_encode($dataRequest, JSON_UNESCAPED_UNICODE));

        $this->checkFiles($request, $client, $dataSettingsResponse['data']['settings']);

        foreach ($this->actions->first() as $action) {
            $action->setPathVariables(['ed_id' => $idEd]);
        }

        $response = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $responseData = json_decode($response->getContent(), true);
        if (!empty($responseData['data']['detail_ed']) && is_null($responseData['data']['files'])) {
            $url = $this->fileService->returnUrl($request, $guidArch);
            $fileResponse = $this->fileService->getFormattingResponseUpload($responseData['data']['detail_ed'], $url);

            $this->registrationActions('Успешно сформировали ответ для обновления списка файлов электронного документа.');
            return $fileResponse;
        } else {
            throw new HttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Загрузка файлов невозможна. Документ имеет',
                'target' => 'ED',
            ], 400));
        }
    }

    private function checkFiles(Request $request, RestClient $client, array $dataSettingResponse)
    {
        if (!empty($dataSettingResponse['settings']['is_check_antivirus'])) {
            $this->isCheckAntivirus($request, $client, $this->actions->first()->first());
        }

        $this->actions->forget(2);

        if ((isset($dataSettingResponse['settings']['is_reception_not_sign'])
                && $dataSettingResponse['settings']['is_reception_not_sign'] === false)
                    || (isset($dataSettingResponse['settings']['is_check_ead_files_mchd'])
                            && $dataSettingResponse['settings']['is_check_ead_files_mchd'] === false)) {
            $this->isReceptionNotSign($request, $client, $this->actions->first()->first());
        }

        $this->actions->forget(3);
    }

    private function isCheckAntivirus(Request $request, RestClient $client, Action $action)
    {
        $response = $this->simpleActionRequestOnlyFiles($request, $client, $action);
        $this->fileService->parsingResponseCheckAntivirus($response->getBody()->getContents(), json_decode($request->all('data')['data'], true)['files']);
    }

    private function isReceptionNotSign(Request $request, RestClient $client, Action $action)
    {
        $response = $this->simpleActionRequestIgnoreMethod($request, $client, $action);
        if ($response->getStatusCode() !== 204) {
            $this->fileService->parsingResponseCheckVerify($response->getBody()->getContents());
        }
    }

    private function simpleActionRequestOnlyFiles(Request $request, RestClient $client, Action $action)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
            $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
            $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Отсутствуют файлы в запросе.',
                'target' => 'File',
            ], 400));
        }

        $multiparts = $client->getMulripart();
        foreach ($multiparts as $index => $multipart) {
            if ($multipart['name'] === '_method') {
                unset($multiparts[$index]);
            }
        }
        $client->setMulripart($multiparts);

        $parametersJar = array_merge($request->getRouteParams(), ['query_string' => $request->getQueryString()]);
        $response = $client->syncRequest($action, $parametersJar);

        return $response;
    }
    private function simpleActionRequestIgnoreMethod(Request $request, RestClient $client, Action $action)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
            $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
            $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Отсутствуют файлы в запросе.',
                'target' => 'File',
            ], 400));
        }

        $multiparts = $client->getMulripart();
        foreach ($multiparts as $index => $multipart) {
            if ($multipart['name'] === '_method') {
                unset($multiparts[$index]);
            }
        }
        $client->setMulripart($multiparts);

        $parametersJar = array_merge($request->getRouteParams(), ['query_string' => $request->getQueryString()]);
        $response = $client->syncRequest($action, $parametersJar);

        return $response;
    }

    private function mappingSourceGuidSed(array $responseData, array &$requestData)
    {
        foreach ($requestData as $key => &$value) {
            foreach ($responseData as $datum) {
                if (!empty($value['guid_arch'])) {
                    if ($value['guid_arch'] === $datum['guid_arch']) {
                        $value['id'] = $datum['id'];
                    }
                }
            }

            if (!empty($value['children'])) {
                $this->mappingSourceGuidSed($responseData, $value['children']);
            }
        }
    }
}