<?php

namespace App\Http\Controllers\Ed\File\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Ed\File\ValidateFileService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use GuzzleHttp\Cookie\CookieJar;
use Illuminate\Support\Facades\Log;

class UploadController extends BaseController
{
    public function upload(Request $request, RestClient $client, string $idEd, ValidateFileService $validateFileService)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Будем выполнять запрос на загрузку файлов для электронного документа. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Валидируем тело запроса на загрузку файлов для электронного документа. Время: {$nowDate}");
        $validateFileService->updateFilesValidate($request->all());
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно свалидировали тело запроса на загрузку файлов для электронного документа. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Запрашиваем настройки Тр-Архива. Время: {$nowDate}");
        $settingsResponse = $this->simpleActionRequest($request, $client, $this->actions->first()->first());
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно получили настройки Тр-Архива. Время: {$nowDate}");

        $this->checkFiles($request, $client, $settingsResponse->getBody()->getContents());
        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $idEd));

        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Отправляем файлы Электронного документа на сохранение. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $this->actions->first()->first());

        if ($response->getStatusCode() === 204) {
            $this->actions->forget(2);
            $nowDate = microtime(true);
            Log::channel('single_ed')->debug("Успешно сохранили файлы электронного документа. Время: {$nowDate}");

            $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $idEd));

            $nowDate = microtime(true);
            Log::channel('single_ed')->debug("Запрашиваем детальную информацию об электронном документе. Время: {$nowDate}");
            $edResponse = $this->simpleRequest($request, $client);
            $url = $this->fileService->returnUrl($request, $idEd);
            $fileResponse = $this->fileService->getFormattingResponseUpload($edResponse->getBody()->getContents(), $url);
            $nowDate = microtime(true);
            $diffDate = $nowDate - $this->startTimestamp;
            Log::channel('single_ed')->debug("Успешно сформировали ответ для обновления списка файлов электронного документа. Время: {$nowDate}. Время на выполнения запроса: {$diffDate}\n\n");

            return SetResponseHeaders::setHeadersResponse($edResponse, $fileResponse);
        } else {
            throw new CustomHttpResponseException(response()->json(json_decode($response->getBody()->getContents(), true)));
        }
    }

    private function checkFiles(Request $request, RestClient $client, string $settingResponse)
    {
        $dataSettingResponse = json_decode($settingResponse, true);
        foreach ($this->actions->first() as $action) {
            if (!empty($dataSettingResponse['settings'][$action->getAlias()])) {
                $this->{$action->getAlias()}($request, $client, $action);
            }
        }

        $this->actions->forget(1);
    }

    private function is_check_antivirus(Request $request, RestClient $client, Action $action)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Отправляем файлы на антивирусную проверку. Время: {$nowDate}");
        $response = $this->simpleActionRequestOnlyFiles($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно получили результат по антивирусной проверки. Время: {$nowDate}");

        $this->fileService->parsingResponseCheckAntivirus($response->getBody()->getContents());
    }

    private function is_reception_not_sign(Request $request, RestClient $client, Action $action)
    {
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Отправляем файлы на проверку подписи. Время: {$nowDate}");
        $response = $this->simpleActionRequestIgnoreMethod($request, $client, $action);
        $nowDate = microtime(true);
        Log::channel('single_ed')->debug("Успешно получили результат по проверки подписи. Время: {$nowDate}");

        if ($response->getStatusCode() !== 204) {
            $this->fileService->parsingResponseCheckVerify($response->getBody()->getContents());
        }
    }

    private function simpleActionRequestOnlyFiles(Request $request, RestClient $client, Action $action)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
            $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
            $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Отсутствуют файлы в запросе.',
                'target' => 'File',
            ], 400));
        }

        $multiparts = $client->getMulripart();
        foreach ($multiparts as $index => $multipart) {
            if ($multipart['name'] === '_method') {
                unset($multiparts[$index]);
            }
        }
        $client->setMulripart($multiparts);

        $parametersJar = array_merge($request->getRouteParams(), ['query_string' => $request->getQueryString()]);
        $response = $client->syncRequest($action, $parametersJar);

        return $response;
    }
    private function simpleActionRequestIgnoreMethod(Request $request, RestClient $client, Action $action)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
            $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
            $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Отсутствуют файлы в запросе.',
                'target' => 'File',
            ], 400));
        }

        $multiparts = $client->getMulripart();
        foreach ($multiparts as $index => $multipart) {
            if ($multipart['name'] === '_method') {
                unset($multiparts[$index]);
            }
        }
        $client->setMulripart($multiparts);

        $parametersJar = array_merge($request->getRouteParams(), ['query_string' => $request->getQueryString()]);
        $response = $client->syncRequest($action, $parametersJar);

        return $response;
    }
}