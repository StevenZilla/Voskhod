<?php

namespace App\Http\Controllers\Ed\File\v2;

use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class IndexController extends BaseController
{
    public function index(Request $request, RestClient $client, $guidArch)
    {
        $responseEdId = $this->simpleActionRequest($request, $client, $this->actions->first()->first());
        $this->actions->forget(0);

        $edId = json_decode($responseEdId->getBody()->getContents(), true)['id'];
        $this->actions->first()->first()->setPathVariables(['ed_id' => $edId]);

        $response = $this->simpleRequest($request, $client);

        $fileResponse = $this->fileService->getFormattingResponseIndex(json_decode($response->getBody()->getContents(), true));

        $this->registrationActions('Успешно вернули все файлы ЭД');
        return SetResponseHeaders::setHeadersResponse($response, $fileResponse);
    }
}