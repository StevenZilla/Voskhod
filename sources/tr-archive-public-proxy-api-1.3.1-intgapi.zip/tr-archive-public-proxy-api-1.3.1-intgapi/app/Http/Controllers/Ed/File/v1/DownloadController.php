<?php

namespace App\Http\Controllers\Ed\File\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Ed\File\BaseController;
use App\Http\Request;
use App\Services\Controllers\Ed\File\FilterFileService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class DownloadController extends BaseController
{
    public function download(Request $request, RestClient $client, FilterFileService $filterFileService)
    {
        $queryString = $filterFileService->filter($request->all());

        if (!empty($queryString)) {
            foreach ($this->actions->first() as $action) {
                $action->setUrl($action->getUrl() . '?' . urldecode($request->getQueryString()));
            }
        }

        foreach ($this->actions->first() as $action) {
            $nowDate = microtime(true);
            Log::channel('single_ed')->debug("Будем выполнять запрос на скачивание файла электронного документа. Время: {$nowDate}");
            $response = $this->simpleActionRequest($request, $client, $action);

            if (!str_contains($response->getHeader('Content-Type')[0], 'text/html;')) {
                $nowDate = microtime(true);
                $diffDate = $nowDate - $this->startTimestamp;
                Log::channel('single_ed')->debug("Успешно выполнили запрос на скачивание файла электронного документа. Время: {$nowDate}. Время выполнения запроса: {$diffDate}\n\n");

                return $response;
            }

//            if (!$response->hasHeader('Content-Disposition')) {
//                $data = json_decode($response->getBody()->getContents(), true);
//
//                if (empty($data)) {
//                    $data['message'] = 'Не смогли скачать файл. Проблема с ссылкой.';
//                }
//
//                $data['target'] = 'DOWNLOADER';
//                $responseJson = response()->json($data, 400);
//                throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
//            }
        }

        $responseJson = response()->json(['target' => 'DOWNLOADER', 'message' => 'Не смогли скачать файл. Проблема с ссылкой.', 'code' => 400], 400);
        throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
    }
}