<?php

namespace App\Http\Controllers;

use App\Exceptions\DataFormatException;
use App\Exceptions\NotImplementedException;
use App\Presenters\PresenterContract;
use App\Routing\Action;
use App\Services\RestClient;
use App\Http\Request;
use Carbon\Carbon;
use GuzzleHttp\Cookie\CookieJar;
use Illuminate\Http\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Laravel\Lumen\Routing\Controller;

class GatewayController extends Controller
{
    /**
     * @var array ActionContract
     */
    protected $actions;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var PresenterContract
     */
    protected $presenter;

    protected $startTimestamp;

    /**
     * GatewayController constructor.
     * @param Request $request
     * @throws DataFormatException
     * @throws NotImplementedException
     */
    public function __construct(Request $request)
    {
        if (empty($request->getRoute())) throw new DataFormatException('Unable to find original URI pattern');

        $this->config = $request
            ->getRoute()
            ->getConfig();

        $this->actions = $request
            ->getRoute()
            ->getActions()
            ->groupBy(function ($action) {
                return $action->getSequence();
            })
            ->sortBy(function ($batch, $key) {
                return intval($key);
            });

        $this->presenter = $request
            ->getRoute()
            ->getPresenter();

        $this->startTimestamp = microtime(true);
    }

    /**
     * @param Request $request
     * @param RestClient $client
     * @return Response
     */
    public function get(Request $request, RestClient $client)
    {
        if (! $request->getRoute()->isAggregate()) return $this->simpleRequest($request, $client);

        $parametersJar = array_merge($request->getRouteParams());

        $output = $this->actions->reduce(function($carry, $batch) use (&$parametersJar, $client, $request) {
            $headers = $client->getHeaders();
            $headers['uid'] = $request->header('uid');

            if (!empty($request->cookie())) {
                $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
                $client->setCookie($cookieJar);
            }

            $headers['Authorization'] = $request->header('Authorization');
            $client->setHeaders($headers);

            $responses = $client->asyncRequest($batch, $parametersJar);
            $parametersJar = array_merge($parametersJar, $responses->exportParameters());

            return array_merge($carry, $responses->getResponses()->toArray());
        }, []);

        return $this->presenter->format($this->rearrangeKeys($output), 200);
    }

    public function getMultiActions(Request $request, RestClient $client, Collection $actionCollection)
    {
        if (! $request->getRoute()->isAggregate()) return $this->simpleRequest($request, $client);

        $parametersJar = array_merge($request->getRouteParams());

        $output = $actionCollection->reduce(function($carry, $batch) use (&$parametersJar, $client, $request) {
            $headers = $client->getHeaders();
            $headers['uid'] = $request->header('uid');

            if (!empty($request->cookie())) {
                $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
                $client->setCookie($cookieJar);
            }

            $headers['Authorization'] = $request->header('Authorization');
            $client->setHeaders($headers);

            if (count($request->allFiles()) !== 0) {
                $client->setFiles($request->all());
            } else {
                $client->setBody(json_encode($request->all(), JSON_UNESCAPED_UNICODE));
            }

            $responses = $client->asyncRequest($batch, $parametersJar);
            $parametersJar = array_merge($parametersJar, $responses->exportParameters());

            return array_merge($carry, $responses->getResponses()->toArray());
        }, []);

        return $this->presenter->format($this->rearrangeKeys($output), 200);
    }

    /**
     * @param array $output
     * @return array
     */
    private function rearrangeKeys(array $output)
    {
        return collect(array_keys($output))->reduce(function($carry, $alias) use ($output) {
            $key = $this->config['actions'][$alias]['output_key'] ?? $alias;

            if ($key === false) return $carry;

            $data = isset($this->config['actions'][$alias]['input_key']) ? $output[$alias][$this->config['actions'][$alias]['input_key']] : $output[$alias];

            if (empty($key)) {
                return array_merge($carry, $data);
            }

            if (is_string($key)) {
                array_set($carry, $key, $data);
            }

            if (is_array($key)) {
                collect($key)->each(function($outputKey, $property) use (&$data, &$carry, $key) {
                    if ($property == '*') {
                        array_set($carry, $outputKey, $data);
                        return;
                    }

                    if (isset($data[$property])) {
                        array_set($carry, $outputKey, $data[$property]);
                        unset($data[$property]);
                    }
                });
            }

            return $carry;
        }, []);
    }

    /**
     * @param Request $request
     * @param RestClient $client
     * @return Response
     */
    public function delete(Request $request, RestClient $client)
    {
        return $this->simpleRequest($request, $client);
    }

    /**
     * @param Request $request
     * @param RestClient $client
     * @return Response
     */
    public function post(Request $request, RestClient $client)
    {
        return $this->simpleRequest($request, $client);
    }

    /**
     * @param Request $request
     * @param RestClient $client
     * @return Response
     */
    public function put(Request $request, RestClient $client)
    {
        return $this->simpleRequest($request, $client);
    }

    /**
     * @param Request $request
     * @param RestClient $client
     * @return \GuzzleHttp\Psr7\Response
     * @throws \App\Exceptions\UnableToExecuteRequestException
     */
    protected function simpleRequest(Request $request, RestClient $client)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
             $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
             $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            $client->setBody(json_encode($request->all(), JSON_UNESCAPED_UNICODE));
        }

        $parametersJar = array_merge($request->getRouteParams());
        $response = $client->syncRequest($this->actions->first()->first(), $parametersJar);

        return $response;
    }

    protected function simpleActionRequest(Request $request, RestClient $client, Action $action)
    {
        $headers = $client->getHeaders();
        $headers['uid'] = $request->header('uid');

        if (!empty($request->cookie())) {
            $cookieJar = CookieJar::fromArray($request->cookie(), config('gateway.subdomain_archive'));
            $client->setCookie($cookieJar);
        }

        $headers['Authorization'] = $request->header('Authorization');
        $client->setHeaders($headers);

        if (count($request->allFiles()) !== 0) {
            $client->setFiles($request->all());
        } else {
            $client->setBody(json_encode($request->all(), JSON_UNESCAPED_UNICODE));
        }

        $parametersJar = array_merge($request->getRouteParams());
        $response = $client->syncRequest($action, $parametersJar);

        return $response;
    }

    protected function registrationActions(string $message)
    {
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_ed')->debug("{$message} Время старта: {$this->startTimestamp}. Время завершения: {$nowDate}. Разница: {$diffDate}");
    }
}
