<?php

namespace App\Http\Controllers\Nomenclature\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Nomenclature\BaseController;
use App\Http\Request;
use App\Routing\Action;
use App\Services\Controllers\Nomenclature\ValidateNomenclatureService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class StoreController extends BaseController
{
    public function store(Request $request, RestClient $client, ValidateNomenclatureService $validateNomenclatureService)
    {
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Будем выполнять запрос создания номенклатуры. Время: {$nowDate}");
        $data = $validateNomenclatureService->storeValidateRequest($request->all());
        $this->addActionSearchSubdivision($data['nom_parts']);

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем для всех разделов номенклатуры информацию о подразделений. Время: {$nowDate}");
        $subdivisionResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно запросили для всех разделов номенклатуры информацию о подразделений. Время: {$nowDate}");

        $data = $this->nomenclatureService->setSubdivisionId($subdivisionResponse->getContent(), $data);

        $this->addActionSearchDiKindNum($data['nom_parts']);
        $this->actions->first()->forget(0);

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем для всех дел номенклатуры информацию о сроках хранения. Время: {$nowDate}");
        $diKindNumResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно запросили для всех дел номенклатуры информацию о сроках хранения. Время: {$nowDate}");


        $data = $this->nomenclatureService->setDiKindId($diKindNumResponse->getContent(), $data);
        $this->actions->forget(1);

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Выполняем запрос на сохранение номенклатуры. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->nomenclatureService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно сохранили номенклатуру. Время: {$nowDate}");

        return $this->searchNomenclature($request, $client, $dataResponse);
    }

    protected function addActionSearchSubdivision(array $nomParts)
    {
        foreach ($nomParts as $index => $nomPart) {
            if (!empty($nomPart['subdivision_code'])) {
                $actionConfig = $this->actions->first()->first()->getConfig();
                $actionConfig['path'] = sprintf($actionConfig['path'], $nomPart['subdivision_code']);
                $actionConfig['alias'] = $actionConfig['alias'] . '_' . $index . '_' . $nomPart['subdivision_code'];

                $this->actions->first()->push(new Action($actionConfig));
            }
        }

        $this->actions->first()->forget(0);
    }

    protected function addActionSearchDiKindNum(array $nomParts)
    {
        foreach ($nomParts as $index => $nomPart) {
            if (!empty($nomPart['dossiers'])) {
                foreach ($nomPart['dossiers'] as $dossier) {
                    if (!empty($dossier['di_kind_num'])) {
                        $actionConfig = $this->actions->first()->first()->getConfig();
                        $diKindNumString = implode(',', $dossier['di_kind_num']);
                        $actionConfig['path'] = sprintf($actionConfig['path'], $diKindNumString);
                        $diKindNumString = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $diKindNumString);
                        $actionConfig['alias'] = $actionConfig['alias'] . '_' . $diKindNumString;

                        $this->actions->first()->push(new Action($actionConfig));
                    }
                }
            }

            if (!empty($nomPart['children'])) {
                $this->addActionSearchDiKindNum($nomPart['children']);
            }
        }
    }

    private function searchNomenclature(Request $request, RestClient $client, array $dataResponse)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $dataResponse['message']));

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем созданную номенклатуру. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $url = $this->nomenclatureService->returnUrl($request, $dataResponse['message']);
        $dataResponse = $this->nomenclatureService->getFormattingResponseStore($response->getBody()->getContents(), $url);

        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_nomenclature')->debug("Успешно получили созданную номенклатуру. Время: {$nowDate}. Время выполнения запроса: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}