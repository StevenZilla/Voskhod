<?php

namespace App\Http\Controllers\Nomenclature\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Controllers\Nomenclature\BaseController;
use App\Http\Request;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

class ShowController extends BaseController
{
    public function show(Request $request, RestClient $client, $id)
    {
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Будем выполнять запрос получение детальной информации номенклатуры. Время: {$nowDate}");
        $this->actions->first()->first()->setUrl(sprintf($this->actions->first()->first()->getUrl(), $id));
        $response = $this->simpleRequest($request, $client);
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно выполнили запрос получение детальной информации номенклатуры. Время: {$nowDate}");

        $this->actions->forget(0);
        if ($response->getStatusCode() > 400) {
            $dataResponse = json_decode($response->getBody()->getContents(), true);
            $responseJson = response()->json($dataResponse, $response->getStatusCode());
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }
        $nomenclature = $this->nomenclatureService->parsingResponseShow($response->getBody()->getContents());

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем запрашивать разделы и дела для номенклатуры с идентификатором {$id}. Время: {$nowDate}");
        $nomenclature['nom_parts'] = $this->getAddNomData($request, $client, $id, $this->actions);
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно запросили разделы и дела для номенклатуры с идентификатором {$id}. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем формировать ответ для детальной информации номенклатуры. Время: {$nowDate}");
        $responseNom = $this->nomenclatureService->getFormattingResponseShow($nomenclature);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_nomenclature')->debug("Успешно сформировали ответ для детальной информации номенклатур. Время: {$nowDate}. Время получения списка номенклатур: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseNom);
    }

    protected function getAddNomData(Request $request, RestClient $client, int $id, Collection $actions): array
    {
        $key = $actions->keys()[0];
        $actions->first()->get(0)->setUrl(sprintf($actions->first()->get(0)->getUrl(), $id));
        $actions->first()->get(1)->setUrl(sprintf($actions->first()->get(1)->getUrl(), $id));
        $nomPartsResponses = $this->getMultiActions($request, $client, $actions);
        $actions->forget($key);
        return $this->nomenclatureService->parsingNomPartsShow($nomPartsResponses->getContent());
    }
}