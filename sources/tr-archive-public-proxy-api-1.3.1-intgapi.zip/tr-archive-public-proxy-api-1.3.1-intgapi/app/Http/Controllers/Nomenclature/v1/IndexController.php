<?php

namespace App\Http\Controllers\Nomenclature\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\Nomenclature\FilterNomenclatureService;
use App\Services\Controllers\Nomenclature\ValidateNomenclatureService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;
use function DeepCopy\deep_copy;

class IndexController extends ShowController
{
    public function index(Request $request, RestClient $client, ValidateNomenclatureService $validateService, FilterNomenclatureService $filterService)
    {
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Будем выполнять запрос на получения списка номенклатур. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем валидировать фильтрацию списка номенклатур. Время: {$nowDate}");
        $data = $validateService->indexValidateQueryRequest($request->query->all());
        $queryString = $filterService->filter($data);
        if (!empty($queryString)) {
            $this->actions->first()->first()->setUrl($this->actions->first()->first()->getUrl() . '?' . urldecode($queryString));
        }
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно свалидировали фильтрацию списка номенклатур. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Выполняем запрос на получение списка номенклатур. Время: {$nowDate}");
        $response = $this->simpleRequest($request, $client);
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно выполнили запрос на получение списка номенклатур. Время: {$nowDate}");

        $this->actions->forget(0);
        if ($response->getStatusCode() > 400) {
            $dataResponse = json_decode($response->getBody()->getContents(), true);
            $responseJson = response()->json($dataResponse, $response->getStatusCode());
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse($response, $responseJson));
        }

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем парсить ответ на получение списка номенклатур. Изменяем роуты для пагинации. Время: {$nowDate}");
        $nomenclatures = $this->nomenclatureService->parsingResponseIndex($response->getBody()->getContents(), $request->url());
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно пропарсили ответ на получение списка номенклатур. Изменили роуты для пагинации. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем перебирать номенклатуры для получения разделов и дел. Время: {$nowDate}");
        foreach ($nomenclatures['nomenclatures'] as &$nom) {
            $actions = deep_copy($this->actions);

            $nowDate = microtime(true);
            Log::channel('single_nomenclature')->debug("Начинаем запрашивать разделы и дела для номенклатуры с идентификатором {$nom['id']}. Время: {$nowDate}");
            $nom['nom_parts'] = $this->getAddNomData($request, $client, $nom['id'], $actions);
            $nowDate = microtime(true);
            Log::channel('single_nomenclature')->debug("Успешно запросили разделы и дела для номенклатуры с идентификатором {$nom['id']}. Время: {$nowDate}");
        }
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно перебрали номенклатуры для получения разделов и дел. Время: {$nowDate}");

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Начинаем формировать ответ для списка номенклатур. Время: {$nowDate}");
        $responseNom = $this->nomenclatureService->getFormattingResponseIndex($nomenclatures);
        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_nomenclature')->debug("Успешно сформировали ответ для списка номенклатур. Время: {$nowDate}. Время получения списка номенклатур: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $responseNom);
    }
}