<?php

namespace App\Http\Controllers\Nomenclature\v1;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Services\Controllers\Nomenclature\ValidateNomenclatureService;
use App\Services\Controllers\SetResponseHeaders;
use App\Services\RestClient;
use Illuminate\Support\Facades\Log;

class UpdateController extends StoreController
{
    public function update(Request $request, RestClient $client, ValidateNomenclatureService $validateNomenclatureService, $idNom)
    {
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Будем выполнять запрос на обновление номенклатуры. Время: {$nowDate}");

        $data = $validateNomenclatureService->storeValidateRequest($request->all());
        $this->addActionSearchSubdivision($data['nom_parts']);

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем для всех разделов номенклатуры информацию о подразделений. Время: {$nowDate}");
        $subdivisionResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $this->actions->forget(0);
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно запросили для всех разделов номенклатуры информацию о подразделений. Время: {$nowDate}");

        $data = $this->nomenclatureService->setSubdivisionId($subdivisionResponse->getContent(), $data);
        $this->addActionSearchDiKindNum($data['nom_parts']);
        $this->actions->first()->forget(0);

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем для всех дел номенклатуры информацию о сроках хранения. Время: {$nowDate}");
        $diKindNumResponse = $this->getMultiActions($request, $client, collect([$this->actions->first()]));
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно запросили для всех дел номенклатуры информацию о сроках хранения. Время: {$nowDate}");

        $data = $this->nomenclatureService->setDiKindId($diKindNumResponse->getContent(), $data);
        $this->actions->forget(1);

        foreach ($data as $key => $value) {
            $request->request->set($key, $value);
        }

        $action = $this->actions->first()->first();
        $action->setUrl(sprintf($action->getUrl(), $idNom));

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Выполняем запрос на обновление номенклатуры. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $this->actions->forget(2);
        $dataResponse = json_decode($response->getBody()->getContents(), true);
        if ($response->getStatusCode() >= 400) {
            throw new CustomHttpResponseException(SetResponseHeaders::setHeadersResponse(
                $response,
                $this->nomenclatureService->getFormattingErrorResponseStore($dataResponse))
            );
        }
        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Успешно обновили номенклатуру. Время: {$nowDate}");

        return $this->searchNomenclature($request, $client, $idNom);
    }

    private function searchNomenclature(Request $request, RestClient $client, $idNom)
    {
        $action =  $this->actions->first()->first();

        $action->setUrl(sprintf($action->getUrl(), $idNom));

        $nowDate = microtime(true);
        Log::channel('single_nomenclature')->debug("Запрашиваем обновленную номенклатуру. Время: {$nowDate}");
        $response = $this->simpleActionRequest($request, $client, $action);
        $url = $this->nomenclatureService->returnUrl($request, $idNom);
        $dataResponse = $this->nomenclatureService->getFormattingResponseStore($response->getBody()->getContents(), $url);

        $nowDate = microtime(true);
        $diffDate = $nowDate - $this->startTimestamp;
        Log::channel('single_nomenclature')->debug("Успешно получили обновленную номенклатуру. Время: {$nowDate}. Время выполнения запроса: {$diffDate}\n\n");

        return SetResponseHeaders::setHeadersResponse($response, $dataResponse);
    }
}