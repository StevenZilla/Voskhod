<?php

namespace App\Http\Controllers\Nomenclature;

use App\Http\Controllers\GatewayController;
use App\Http\Request;
use App\Services\Controllers\Nomenclature\NomenclatureService;

class BaseController extends GatewayController
{
    protected $nomenclatureService;

    public function __construct(Request $request, NomenclatureService $nomenclatureService)
    {
        parent::__construct($request);

        $this->nomenclatureService = $nomenclatureService;
    }
}