<?php

namespace App\Http\Resources\AcceptRegister;

use Illuminate\Http\Resources\Json\JsonResource;

class RegisterPartResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'] ?? null,
            'name' => $this->resource['name'] ?? null,
            'dossiers' => !empty($this->resource['dossiers']) ? (new DossiersResource($this->resource['dossiers']))->resolve() : [],
            'children' => !empty($this->resource['children']) ? (new RegisterPartsResource($this->resource['children']))->resolve() : [],
        ];
    }
}