<?php

namespace App\Http\Resources\AcceptRegister;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $acceptRegisters = [];
        foreach ($this->resource as $acceptRegister) {
            $acceptRegisters[] = (new ShowResource($acceptRegister))->resolve();
        }

        return $acceptRegisters;
    }
}