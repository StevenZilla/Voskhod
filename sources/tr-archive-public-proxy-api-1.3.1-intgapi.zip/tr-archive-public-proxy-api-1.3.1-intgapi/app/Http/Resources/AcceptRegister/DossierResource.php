<?php

namespace App\Http\Resources\AcceptRegister;

use Illuminate\Http\Resources\Json\JsonResource;

class DossierResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'],
            'dossier_index' => $this->resource['index'] ?? null,
            'nom_year' => $this->resource['nom_year'],
        ];
    }
}