<?php

namespace App\Http\Resources\AcceptRegister;

use Illuminate\Http\Resources\Json\JsonResource;

class DossiersResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $dossiers = [];
        foreach ($this->resource as $dossier) {
            $dossiers[] = $dossier ? (new DossierResource($dossier))->resolve() : [];
        }
        return $dossiers;
    }
}