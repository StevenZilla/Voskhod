<?php

namespace App\Http\Resources\AcceptRegister;

use App\Http\Resources\Ed\SubdivisionResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ShowResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'],
            'guid_arch' => $this->resource['guid_arch'] ?? null,
            'name' => $this->resource['name'],
            'num' => $this->resource['num'],
            'dossiers' => !empty($this->resource['dossiers']) ? (new DossiersResource($this->resource['dossiers']))->resolve() : [],
            'subdivision' => !empty($this->resource['subdivision']) ? (new SubdivisionResource($this->resource['subdivision']))->resolve() : [],
            'year' => $this->resource['year'],
            'create_date' => $this->resource['create_date'],
            'register_parts' => !empty($this->resource['register_parts']) ? (new RegisterPartsResource($this->resource['register_parts']))->resolve() : [],
        ];
    }
}