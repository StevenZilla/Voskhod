<?php

namespace App\Http\Resources\Ed;

use Illuminate\Http\Resources\Json\JsonResource;

class SubdivisionResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'name' => $this->resource['name'],
            'code' => $this->resource['code'],
        ];
    }
}
