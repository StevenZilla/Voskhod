<?php

namespace App\Http\Resources\Ed;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $eds = [];
        foreach ($this->resource as $ed) {
            $eds[] = (new ShowResource($ed))->resolve();
        }

        return $eds;
    }
}
