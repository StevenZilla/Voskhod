<?php

namespace App\Http\Resources\Ed\File;

use App\Http\Resources\Ed\SubdivisionResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ShowResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $file =  [
            'id' => $this->resource['id'],
            'guid_arch' => $this->resource['guid_arch'],
            'guid_source_sed' => $this->resource['guid_source_sed'],
            'name' => $this->resource['name'],
            'viewer_path' => $this->changeViewerPath($this->resource['viewer_path']),
            'file_role' => $this->resource['file_role'],
            'file_ext' => $this->resource['file_ext'],
            'parent_id' => $this->resource['parent_id'],
            'parent_name' => $this->resource['parent_name'],
        ];

        return array_merge($file, $this->changeUri($this->resource['uri']));
    }

    private function changeUri(string $uri = null) : array
    {
        if (!empty($uri)) {
            $dataUri = parse_url($uri);
            if (!empty($dataUri['query'])) {
                $data = [];
                $prefixRoutes = config('gateway.gateway_prefix');
                $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/media"]['uri'];
                $data['uri'] =  $route . '?' . $dataUri['query'];

                if (!empty(config('gateway.services.downloader'))) {
                    $routeDevelop = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/develop/media"]['uri'];
                    $data['uri_develop'] =  $routeDevelop . '?' . $dataUri['query'];
                }

                return $data;
            }
        }

        return ['uri' => null];
    }

    private function changeViewerPath(string $viewerPath = null)
    {
        if (!empty($viewerPath)) {
            $prefixRoutes = config('gateway.gateway_prefix');
            $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/storage/viewer/ed/{base64_path}"]['uri'];
            $dataViewerPath = explode('/', $viewerPath);
            $fileName = array_pop($dataViewerPath);
            $directory = array_pop($dataViewerPath);

            return str_replace('{base64_path}', base64_encode("{$directory}/{$fileName}"), $route);
        }

        return null;
    }
}
