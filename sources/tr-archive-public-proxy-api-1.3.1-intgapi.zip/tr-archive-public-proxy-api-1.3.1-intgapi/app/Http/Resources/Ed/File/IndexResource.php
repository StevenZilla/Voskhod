<?php

namespace App\Http\Resources\Ed\File;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $eds = [];
        foreach ($this->resource as $file) {
            $eds[] = (new ShowResource($file))->resolve();
        }

        return $eds;
    }
}
