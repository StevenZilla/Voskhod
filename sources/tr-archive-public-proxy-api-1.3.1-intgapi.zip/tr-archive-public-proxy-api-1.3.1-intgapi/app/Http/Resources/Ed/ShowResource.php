<?php

namespace App\Http\Resources\Ed;

use Illuminate\Http\Resources\Json\JsonResource;

class ShowResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'],
            'guid_arch' => $this->resource['guid_arch'],
            'name' => $this->resource['name'],
            'num' => $this->resource['num'],
            'reg_date' => $this->resource['reg_date'],
            'is_dsp' => $this->resource['is_dsp'],
            'subdivision' => !empty($this->resource['subdivision']) ? (new SubdivisionResource($this->resource['subdivision']))->resolve() : null,
            'di_kind' => $this->resource['di_kinds'] ?? null,
            'save_type' => $this->resource['save_type'],
            'full_size' => $this->resource['full_size'],
            'nom' => $this->resource['nom'] ?? null,
        ];
    }
}
