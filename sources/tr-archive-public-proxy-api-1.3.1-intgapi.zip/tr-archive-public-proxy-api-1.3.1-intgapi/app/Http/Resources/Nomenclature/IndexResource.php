<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res) {
            $resource[] = [
                'id' => $res['id'],
                'guid_arch' => $res['guid_arch'],
                'num' => $res['num'],
                'year' => $res['year'],
                'nom_parts' => !empty($res['nom_parts']) ? new NomPartsResource($res['nom_parts']) : null,
            ];
        }
        return $resource;
    }
}