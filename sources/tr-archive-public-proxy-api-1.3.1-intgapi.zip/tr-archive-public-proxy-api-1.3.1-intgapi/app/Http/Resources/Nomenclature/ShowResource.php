<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class ShowResource extends JsonResource
{
    public static $wrap = null;
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'],
            'guid_arch' => $this->resource['guid_arch'],
            'num' => $this->resource['num'],
            'year' => $this->resource['year'],
            'nom_parts' => !empty($this->resource['nom_parts']) ? new NomPartsResource($this->resource['nom_parts']) : null,
        ];
    }
}