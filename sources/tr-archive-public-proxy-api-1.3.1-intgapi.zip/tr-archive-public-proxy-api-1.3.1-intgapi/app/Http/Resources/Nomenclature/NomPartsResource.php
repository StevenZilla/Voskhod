<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class NomPartsResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'id' => $res['id'],
                'name' => $res['name'],
                'num' => $res['num'],
                'subdivision' => !empty($res['subdivision']) ? new SubdivisionResource($res['subdivision']) : null,
                'dossiers' => !empty($res['dossiers']) ? new DossierResource($res['dossiers']) : null,
                'children' => !empty($res['children']) ? new NomPartsResource($res['children']) : null,
            ];
        }
        return $resource;
    }
}