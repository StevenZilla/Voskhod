<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class DiKindsResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'id' => $res['id'],
                'name' => $res['name'],
                'num_show' => $res['num_show'],
                'save_info' => $res['save_info'],
            ];
        }
        return $resource;
    }
}