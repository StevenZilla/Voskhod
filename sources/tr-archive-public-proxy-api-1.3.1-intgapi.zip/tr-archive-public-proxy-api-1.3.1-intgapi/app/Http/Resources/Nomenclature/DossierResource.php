<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class DossierResource extends JsonResource
{
    public static $wrap = null;

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'id' => $res['id'],
                'index' => $res['index'],
                'name' => $res['name'],
                'di_kinds' => !empty($res['di_kinds']) ? new DiKindsResource($res['di_kinds']) : null,
                'save_type' => $res['save_type']['value'],
            ];
        }
        return $resource;
    }
}