<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class SubdivisionResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        return [
            'code' => $this->resource['code'],
            'name' => $this->resource['name'],
        ];
    }
}