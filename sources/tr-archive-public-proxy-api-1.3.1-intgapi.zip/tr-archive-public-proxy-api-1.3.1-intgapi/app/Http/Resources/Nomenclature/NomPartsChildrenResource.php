<?php

namespace App\Http\Resources\Nomenclature;

use Illuminate\Http\Resources\Json\JsonResource;

class NomPartsChildrenResource extends JsonResource
{
    public static $wrap = null;
    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'name' => $res['name'],
                'num' => $res['num'],
            ];
        }
        return $resource;
    }
}