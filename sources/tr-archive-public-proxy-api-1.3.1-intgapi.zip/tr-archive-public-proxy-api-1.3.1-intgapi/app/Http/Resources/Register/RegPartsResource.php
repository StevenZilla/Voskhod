<?php

namespace App\Http\Resources\Register;

use Illuminate\Http\Resources\Json\JsonResource;

class RegPartsResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'id' => $res['id'],
                'name' => $res['name'],
                'dossiers' => !empty($res['dossiers']) ? new DossierResource($res['dossiers']) : null,
                'children' => !empty($res['children']) ? new RegPartsResource($res['children']) : null,
            ];
        }
        return $resource;
    }

}