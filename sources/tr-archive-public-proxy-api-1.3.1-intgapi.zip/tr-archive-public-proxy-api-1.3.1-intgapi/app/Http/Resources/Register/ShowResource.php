<?php

namespace App\Http\Resources\Register;

use Illuminate\Http\Resources\Json\JsonResource;

class ShowResource extends JsonResource
{
    public static $wrap = null;
    public function toArray($request)
    {
        return [
            'id' => $this->resource['id'],
            'guid_arch' => $this->resource['guid_arch'],
            'name' => $this->resource['name'],
            'num' => $this->resource['num'],
            'year' => $this->resource['year'],
            'create_date' => $this->resource['create_date'],
            'dossiers' => $this->resource['dossiers'] != null ? new DossierResource($this->resource['dossiers']) : null,
            'register_parts' => !empty($this->resource['register_parts']) ? new RegPartsResource($this->resource['register_parts']) : null,
        ];
    }

}