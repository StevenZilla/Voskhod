<?php

namespace App\Http\Resources\Register;

use Illuminate\Http\Resources\Json\JsonResource;

class IndexResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res) {
            $resource[] = [
                'id' => $res['id'],
                'guid_arch' => $res['guid_arch'],
                'name' => $res['name'],
                'num' => $res['num'],
                'year' => $res['year'],
                'create_date' => $res['create_date'],
                'dossiers' => $res['dossiers'] != null ? new DossierResource($res['dossiers']) : null,
                'register_parts' => !empty($res['register_parts']) ? new RegPartsResource($res['register_parts']) : null,
            ];
        }
        return $resource;
    }

}