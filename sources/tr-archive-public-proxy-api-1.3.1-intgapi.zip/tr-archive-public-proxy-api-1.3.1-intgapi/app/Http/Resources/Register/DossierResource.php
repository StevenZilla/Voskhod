<?php

namespace App\Http\Resources\Register;

use Illuminate\Http\Resources\Json\JsonResource;

class DossierResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request)
    {
        $resource = [];
        foreach ($this->resource as $res){
            $resource[] = [
                'id' => $res['id'],
                'dossier_index' => $res['index'],
                'nom_year' => $res['nom_year'],
            ];
        }
        return $resource;
    }

}