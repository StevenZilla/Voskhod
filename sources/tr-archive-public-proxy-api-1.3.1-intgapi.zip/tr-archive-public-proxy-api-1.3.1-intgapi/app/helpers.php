<?php

function findFilesRecursive($dir, $pattern = '/.json/') : array
{
    $files = [];

    // Проверяем, существует ли директория
    if (!is_dir($dir)) {
        return $files;
    }

    // Получаем список файлов и директорий в текущей директории
    $items = scandir($dir);

    // Проходим по каждому элементу
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $path = realpath("{$dir}/{$item}");

        // Если это директория, вызываем функцию рекурсивно
        if (is_dir($path)) {
            $files = array_merge($files, findFilesRecursive($path, $pattern));
        }

        // Если это файл и имя соответствует шаблону, добавляем его в массив
        elseif (is_file($path) && preg_match($pattern, $item)) {
            $files[] = $path;
        }
    }

    return $files;
}
