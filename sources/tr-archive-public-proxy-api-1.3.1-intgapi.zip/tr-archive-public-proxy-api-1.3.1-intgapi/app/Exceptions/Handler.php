<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Laravel\Lumen\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception  $e
     * @return void
     */
    public function report(Exception $e)
    {
        parent::report($e);
    }


    public function render($request, Exception $e)
    {
        if ($e instanceof UnableToExecuteRequestException) {
            Log::critical("Что-то пошло не так, и мы обнаружили ошибку. \n\n {$e}");

            $data = json_decode($e->getMessage(), true);
            if (empty($data['code'])) {
                $data['code'] = 400;
            }

            if (empty($data['message'])) {
                $data['message'] = 'Что-то пошло не так, и мы обнаружили ошибку. Детали записаны в логах.';
            }

            if (empty($data['logic_status_code'])) {
                $data['logic_status_code'] = $data['code'];
            }

            if (empty($data['errors'])) {
                $data['errors'] = [];
            }

            if (empty($data['target'])) {
                if (!empty($request->getRoute()->getConfig()['target'])) {
                    $target = $request->getRoute()->getConfig()['target'];
                } else {
                    $target = 'system';
                }

                $data['target'] = mb_strtoupper($target);
            }

            return response()->json($data, $data['code']);
        }

        if ($e instanceof MethodNotAllowedHttpException) {
            Log::critical("Выполнен запрос, который не поддерживается. \n\n {$e}");
            return response()->json(['message' => 'Выполнен запрос, который не поддерживается.', 'code' => $e->getCode()], $e->getCode());
        }

        if ($e instanceof NotFoundHttpException) {
            return response()->json(['code' => 404, 'message' => 'Роут отсутствует в системе или неправильное тело запроса.'], 404);
        }

        return parent::render($request, $e);
    }
}
