<?php

namespace App\Exceptions;

/**
 * Class DataFormatException
 * @package App\Exceptions
 */
class DataFormatException extends \Exception
{

}