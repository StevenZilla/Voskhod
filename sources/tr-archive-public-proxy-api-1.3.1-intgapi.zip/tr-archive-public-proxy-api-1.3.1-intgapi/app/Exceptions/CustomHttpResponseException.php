<?php

namespace App\Exceptions;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Log;

/**
 * Class DataFormatException
 * @package App\Exceptions
 */
class CustomHttpResponseException extends HttpResponseException
{
    /**
     * Get the underlying response instance.
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getResponse()
    {
        if (!empty($this->response->original['trace'])) {
            if ($this->response->getStatusCode() === 401) {
                $message = 'Невозможно авторизоваться. Возможно, пользователя';

                if (!empty($_SERVER['PHP_AUTH_USER'])) {
                    $message .= " {$_SERVER['PHP_AUTH_USER']}";
                }

                $message .= ' нет в системе Тр-Архив.';
            } elseif ($this->response->getStatusCode() === 403) {
                $message = 'Нет доступа к текущему ресурсу. Обратитесь к администратору.';
            } else {
                $message = 'Не смогли свалидировать ошибку. Ошибку можно посмотреть в логах.';
                $errorJson = json_encode($this->response->original, JSON_UNESCAPED_UNICODE);
                $errorMessage = 'Не смогли выполнить запрос';
                if (!empty($_SERVER['REQUEST_URI'])) {
                    $errorMessage .= " {$_SERVER['REQUEST_URI']}";
                }

                Log::error("{$errorMessage}.\n {$errorJson}");
            }

            $content = json_encode([
                'message' => $message,
                'code' => $this->response->getStatusCode(),
                'target' => $this->response->original['target']
            ], JSON_UNESCAPED_UNICODE);
        }

        if (!empty($content)) {
            $this->response->setContent($content);
        }

        return $this->response;
    }
}