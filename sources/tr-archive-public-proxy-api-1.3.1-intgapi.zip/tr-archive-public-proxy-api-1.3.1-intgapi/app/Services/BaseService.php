<?php

namespace App\Services;

class BaseService
{
    protected function changeUrlPaginate(string $oldUrl, string $newUrl) : string
    {
        $dataOldUrl = parse_url($oldUrl);
        return $newUrl . '?' . $dataOldUrl['query'];
    }

    protected function setKeyId(array $items) : array
    {
        $data = [];
        foreach ($items as $item) {
            $data[$item['id']] = $item;
        }
        return $data;
    }
}