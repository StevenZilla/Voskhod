<?php

namespace App\Services\Controllers\Nomenclature;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Support\Facades\Validator;

class ValidateNomenclatureService
{
    private $storeRules = [
        'num' => 'nullable|string',
        'year' => 'required|regex:/\d{4}/',
        'nom_parts' => 'required|array',
        'nom_parts.*.num' => 'required|string',
        'nom_parts.*.name' => 'required|string',
        'nom_parts.*.subdivision_code' => 'nullable|string',
        'nom_parts.*.dossiers' => 'nullable|array',
        'nom_parts.*.dossiers.*.index' => 'required|string',
        'nom_parts.*.dossiers.*.name' => 'required|string',
        'nom_parts.*.dossiers.*.di_kind_num' => 'nullable|array',
        'nom_parts.*.dossiers.*.di_kind_num.*' => 'required|string',
        'nom_parts.*.children' => 'nullable|array',
    ];

    private $childrenRules = [
        'num' => 'required|string',
        'name' => 'required|string',
        'subdivision_code' => 'nullable|string',
        'dossiers' => 'nullable|array',
        'dossiers.*.index' => 'required|string',
        'dossiers.*.name' => 'required|string',
        'dossiers.*.di_kind_num' => 'nullable|array',
        'dossiers.*.di_kind_num.*' => 'required|string',
        'children' => 'nullable|array',
    ];

    private $childrenMessages = [
        'num.required' => 'Номер раздела номенклатуры является обязательным параметром.',
        'num.string' => 'Номер раздела номенклатуры должен быть в формате строки.',
        'subdivision_code.string' => 'Кодовое обозначение подразделения должно быть в формате строки.',
        'dossiers.array' => 'Дела должны быть в формате массива.',
        'dossiers.*.index.required' => 'Индекс дела является обязательным значением.',
        'dossiers.*.index.string' => 'Индекс дела должен быть в формате строки.',
        'dossiers.*.name.required' => 'Наименование дела должно быть обязательным параметром.',
        'dossiers.*.name.string' => 'Наименование дела должно быть в формате строки.',
        'dossiers.*.di_kind_num.array' => 'Номера статей должны быть в формате массива.',
        'dossiers.*.di_kind_num.*.required' => 'Номер статьи является обязательным параметром.',
        'dossiers.*.di_kind_num.*.string' => 'Номер статьи должен быть в формате строки.',
        'children.array' => 'Подразделы должны быть в формате массива.',
    ];

    private $storeMessages = [
        'num.string' => 'Номер номенклатуры должен быть в формате строки.',
        'year.required' => 'Год номенклатуры является обязательным параметром.',
        'year.regex' => 'Год номенклатуры должен быть в формате ГГГГ.',
        'nom_parts.required' => 'Разделы номенклатуры являются обязательным параметром.',
        'nom_parts.array' => 'Разделы номенклатуры должны быть в формате массива.',
        'nom_parts.*.num.required' => 'Номер раздела номенклатуры является обязательным параметром.',
        'nom_parts.*.num.string' => 'Номер раздела номенклатуры должен быть в формате строки.',
        'nom_parts.*.subdivision_code.string' => 'Кодовое обозначение подразделения должно быть в формате строки.',
        'nom_parts.*.dossiers.array' => 'Дела должны быть в формате массива.',
        'nom_parts.*.dossiers.*.index.required' => 'Индекс дела является обязательным значением.',
        'nom_parts.*.dossiers.*.index.string' => 'Индекс дела должен быть в формате строки.',
        'nom_parts.*.dossiers.*.name.required' => 'Наименование дела должно быть обязательным параметром.',
        'nom_parts.*.dossiers.*.name.string' => 'Наименование дела должно быть в формате строки.',
        'nom_parts.*.dossiers.*.di_kind_num.array' => 'Номера статей должны быть в формате массива.',
        'nom_parts.*.dossiers.*.di_kind_num.*.required' => 'Номер статьи является обязательным параметром.',
        'nom_parts.*.dossiers.*.di_kind_num.*.string' => 'Номер статьи должен быть в формате строки.',
        'nom_parts.*.children.array' => 'Подразделы должны быть в формате массива.',
    ];

    private $indexRules = [
        'num' => 'nullable|string',
        'year' => 'nullable|regex:/\d{4}/',
        'dossier_index' => 'nullable|numeric',
        'q' => 'nullable|string'
    ];

    private $indexMessages = [
        'num' => 'Фильтрация по номеру сдаточной описи',
        'year.regex' => 'Год сдаточной описи должен быть в формате - ГГГГ',
        'dossier_index.numeric' => 'Индекс дела должен быть числом',
        'q' => 'Контекстный поиск по номеру и заголовку сдаточной описи'
    ];


    public function storeValidateRequest(array $data): array
    {
        $validator = Validator::make($data, $this->storeRules, $this->storeMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' ' . implode(' ', $errorMessage);
            }
        }

        foreach ($data['nom_parts'] as $nomPart) {
            if (!empty($nomPart['children'])) {
                $message .= ' ' . $this->childrenValidate($nomPart['children']);
            }
        }

        if (str_replace(' ', '', $message) !== 'Валидациянепройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'NOMENCLATURE',
            ], 400));
        }

        return $data;
    }

    public function childrenValidate(array $children): string
    {
        $message = '';
        foreach ($children as $child) {
            $validator = Validator::make($child, $this->childrenRules, $this->childrenRules);

            if ($validator->fails()) {
                foreach ($validator->errors()->getMessages() as $errorMessage) {
                    $message .= ' ' . implode(' ', $errorMessage);
                }
            }

            if (!empty($child['children'])) {
                $message .= $this->childrenValidate($child['children']);
            }
        }

        return $message;
    }

    public function indexValidateQueryRequest(array $data): array
    {
        $validator = Validator::make($data, $this->indexRules, $this->indexMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' ' . implode(' ', $errorMessage);
            }
        }

        if ($message !== 'Валидация не пройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'Nomenclature',
            ], 400));
        }

        return $data;
    }

}