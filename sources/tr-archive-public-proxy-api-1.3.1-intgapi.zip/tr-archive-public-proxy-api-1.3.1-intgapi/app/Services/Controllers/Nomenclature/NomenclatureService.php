<?php

namespace App\Services\Controllers\Nomenclature;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Http\Resources\Nomenclature\IndexResource;
use App\Http\Resources\Nomenclature\ShowResource;

class NomenclatureService
{
    public function setSubdivisionId(string $responseSubdivision, array $data)
    {
        $message = 'У раздела номенклатуры не нашли подразделение.';
        $dataSubdivision = json_decode($responseSubdivision, true)['data'];
        foreach ($data['nom_parts'] as $index => $nomPart) {
            if (!empty($nomPart['subdivision_code'])) {
                if ($dataSubdivision["search_subdivision_{$index}_{$nomPart['subdivision_code']}"]['count'] === 0) {
                    $message .= " У раздела {$nomPart['name']} назначено подразделение {$nomPart['subdivision_code']}. А этого подразделения нет в системе.";
                } else {
                    $subdivision = $dataSubdivision["search_subdivision_{$index}_{$nomPart['subdivision_code']}"]['subdivisions'][0];

                    $data['nom_parts'][$index]['subdivision_id'] = $subdivision['id'];
                }
            }
        }


        if ($message !== 'У раздела номенклатуры не нашли подразделение.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'NOMENCLATURE',
            ], 400));
        }

        return $data;
    }

    public function setDiKindId(string $responseDiKind, array $data)
    {
        $message = 'У дела номенклатуры не нашли номер статьи.';
        $dataDiKindNum = json_decode($responseDiKind, true)['data'];
        foreach ($data['nom_parts'] as $index => $nomPart) {
            if (!empty($nomPart['dossiers'])) {
                foreach ($nomPart['dossiers'] as $dossierIndex => $dossier) {
                    if (!empty($dossier['di_kind_num'])) {
                        $diKindNumString = implode(',', $dossier['di_kind_num']);
                        $diKindNumIndex = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $diKindNumString);

                        if (empty($dataDiKindNum["search_di_kind_num_{$diKindNumIndex}"])) {
                            $message .= " У дела {$dossier['name']} с индексом {$dossier['index']} назначены статьи {$diKindNumString}. А этих статей нет в системе.";
                        } else {
                            foreach ($dataDiKindNum["search_di_kind_num_{$diKindNumIndex}"] as $diKind) {
                                $data['nom_parts'][$index]['dossiers'][$dossierIndex]['di_kind_ids'][] = $diKind['id'];
                            }
                        }
                    }
                }
            }

            if (!empty($nomPart['children'])) {
                $data['nom_parts'][$index]['children'] = $this->setDiKindIdChildren($dataDiKindNum, $nomPart['children']);
            }
        }

        if ($message !== 'У дела номенклатуры не нашли номер статьи.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'NOMENCLATURE',
            ], 400));
        }

        return $data;
    }

    public function setDiKindIdChildren(array $dataDiKindNum, array $children)
    {
        $message = 'У дела номенклатуры не нашли номер статьи.';
        foreach ($children as $index => $child) {
            if (!empty($child['dossiers'])) {
                foreach ($child['dossiers'] as $dossierIndex => $dossier) {
                    if (!empty($dossier['di_kind_num'])) {
                        $diKindNumString = implode(',', $dossier['di_kind_num']);
                        $diKindNumIndex = preg_replace('/[^a-zA-Z0-9а-яА-Я\s]/u', '', $diKindNumString);

                        if (empty($dataDiKindNum["search_di_kind_num_{$diKindNumIndex}"])) {
                            $message .= " У дела {$dossier['name']} с индексом {$dossier['index']} назначены статьи {$diKindNumString}. А этих статей нет в системе.";
                        } else {
                            foreach ($dataDiKindNum["search_di_kind_num_{$diKindNumIndex}"] as $diKind) {
                                $children[$index]['dossiers'][$dossierIndex]['di_kind_ids'][] = $diKind['id'];
                            }
                        }
                    }
                }
            }

            if (!empty($child['children'])) {
                $child['children'][$index]['children'] = $this->setDiKindIdChildren($dataDiKindNum, $child['children']);
            }
        }

        if ($message !== 'У дела номенклатуры не нашли номер статьи.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'NOMENCLATURE',
            ], 400));
        }

        return $children;
    }

    public function returnUrl(Request $request, $nomId): string
    {
        $prefixRoutes = config('gateway.gateway_prefix');
        $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/nomenclatures/{id}"]['uri'];
        $uri = preg_replace('/\{id\}/', $nomId, $route);

        return str_replace($request->getPathInfo(), $uri, $request->url());
    }

    public function getFormattingResponseStore(string $jsonResponse, string $url)
    {
        $dataResponse = json_decode($jsonResponse, true);

        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 201,
            'message' => $dataResponse['nomenclatures']['id'],
            'guid_arch' => $dataResponse['nomenclatures']['guid_arch'],
            'links' => $urlObj
        ], 201);
    }

    public function getFormattingErrorResponseStore(array $nomResponse)
    {
        $nomResponse['target'] = 'NOMENCLATURE';
        if (!empty($nomResponse['error'])) {
            foreach ($nomResponse['error'] as $error) {
                if (is_array($error)) {
                    $nomResponse['message'] .= ' ' . implode('. ', $error);
                } elseif (is_string($error)) {
                    $nomResponse['message'] .= ' ' . $error;
                }
            }

            unset($nomResponse['error']);
        }

        return response()->json($nomResponse, 400);
    }

    public function formattingNomPartsResponse(string $nomPartsResponse): array
    {
        $data = [];
        $nomParts = json_decode($nomPartsResponse, true);
        foreach ($nomParts['nom_parts'] as $nomPart) {
            $key = str_replace(' ', '', $nomPart['num'] . $nomPart['name']);
            $data[$key] = $nomPart;
        }

        return $data;
    }

    public function setNomPartId(array $dataNomParts, array $nomParts): array
    {
        foreach ($dataNomParts as $indexNomPart => $itemNomPart) {
            $key = str_replace(' ', '', $itemNomPart['num'] . $itemNomPart['name']);
            if (!empty($nomParts[$key])) {
                $dataNomParts[$indexNomPart]['id'] = $nomParts[$key];
            }

            if (!empty($itemNomPart['children'])) {
                $dataNomParts[$indexNomPart]['children'] = $this->setNomPartId($itemNomPart['children'], $nomParts);
            }
        }

        return $dataNomParts;
    }

    public function parsingResponseShow(string $jsonResponse): array
    {
        return json_decode($jsonResponse, true)['nomenclatures'];
    }

    public function parsingNomPartsShow(string $jsonResponse): array
    {
        $data = json_decode($jsonResponse, true)['data'];
        $nomParts = $data['nom_parts']['nom_parts'];
        $dossiers = $data['nom_parts_dossiers']['nom_parts'];
        $nomParts = $this->setIdsNomParts($nomParts);
        $dossiers = $this->setIdsDossiers($dossiers);
        $this->joinNomPartAndDossiers($nomParts, $dossiers);

        $this->createTree($nomParts);

        return $nomParts;
    }

    private function createTree(array &$nomParts)
    {
        $childIds = [];
        foreach ($nomParts as $key => &$part) {
            $path = [$key => 1];
            if(isset($childIds[$key])) continue;

            $this->processPart($part, $path, $childIds, $nomParts);

            unset($path[$key]);
        }

        foreach ($childIds as $key => $id){
            unset($nomParts[$key]);
        }
    }

    private function processPart(array &$part, array &$path, array &$childIds, array $regParts)
    {
        if ($part['children'] == null) return;

        foreach ($part['children'] as &$child) {
            $childIds[$child['id']] = 1;

            if (isset($path[$child['id']])) continue;
            $path[$child['id']] = 1;

            $child = $regParts[$child['id']];
            $this->processPart($child, $path, $childIds, $regParts);

            unset($path[$child['id']]);
        }
    }


    private function setIdsNomParts(array $nomParts): array
    {
        $data = [];
        foreach ($nomParts as $part) {
            $data[$part['id']] = $part;
        }

        return $data;
    }

    private function setIdsDossiers(array $dossiers): array
    {
        $data = [];
        foreach ($dossiers as $dos) {
            $data[$dos['id']] = $dos['dossiers'];
        }

        return $data;
    }

    private function joinNomPartAndDossiers(array &$nomParts, array $dossiers)
    {
        foreach ($nomParts as &$part) {
            $part['dossiers'] = $dossiers[$part['id']];
        }
    }

    public function getFormattingResponseShow(array $nomenclature)
    {
        $response['nomenclatures'] = new ShowResource($nomenclature);
        return response()->json($response);
    }

    public function parsingResponseIndex(string $jsonResponse, string $urlPublicApi): array
    {
        $data = json_decode($jsonResponse, true);
        $ignoreKey = ['nomenclatures', 'count'];
        foreach ($data as $key => $value) {
            if (!in_array($key, $ignoreKey) && !empty($value)) {
                $data[$key] = $this->changeUrlPaginate($value, $urlPublicApi);
            }
        }

        return $data;
    }

    private function changeUrlPaginate(string $oldUrl, string $newUrl): string
    {
        $dataOldUrl = parse_url($oldUrl);
        return $newUrl . '?' . $dataOldUrl['query'];
    }

    public function getFormattingResponseIndex(array $response)
    {
        $response['nomenclatures'] = new IndexResource($response['nomenclatures']);
        return response()->json($response);
    }
}