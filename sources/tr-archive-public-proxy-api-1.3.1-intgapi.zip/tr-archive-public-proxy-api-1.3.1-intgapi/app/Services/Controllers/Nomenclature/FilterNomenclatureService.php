<?php

namespace App\Services\Controllers\Nomenclature;

class FilterNomenclatureService
{
    private $filtersMap = [
        'year' => ['year'],
        'num' => ['num'],
        'dossier_index' => ['dossier_id'],
        'q' => ['q'],
    ];

    public function filter(array $data): string
    {
        $queryParams = [];
        foreach ($data as $index => $value) {
            if (!empty($this->filtersMap[$index])) {
                foreach ($this->filtersMap[$index] as $item) {
                    $queryParams[$item] = $value;
                }
            } else {
                $queryParams[$index] = $value;
            }
        }

        return http_build_query($queryParams);
    }
}