<?php

namespace App\Services\Controllers\Auth;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Support\Facades\Validator;

class AuthService
{
    private $authRules = [
        'login' => 'required|string',
        'password' => 'required|string',

    ];

    private $authMessages = [
        'login.required' => 'Логин пользователя является обязательным параметром.',
        'login.string' => 'Логин пользователя должен быть строкой.',
        'password.required' => 'Пароль пользователя является обязательным параметром.',
        'password.string' => 'Пароль пользователя должен быть строкой.',
    ];

    public function authValidateRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->authRules, $this->authMessages);

        $message = 'Валидация не пройдена.';
        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' '.implode(' ', $errorMessage);
            }
        }

        if ($message !== 'Валидация не пройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'Auth',
            ], 400));
        }

        return $data;
    }

    public function getFormattingResponseAuth(string $jsonResponse, int $statusCode)
    {
        $dataResponse = json_decode($jsonResponse, true);

        if ($statusCode >= 400) {
            $dataResponse['message'] = $this->formattingErrorResponseAuth($dataResponse['error'] ?? [], $dataResponse['message'] ?? 'Валидация не пройдена');
            unset($dataResponse['error']);
        }

        return response()->json($dataResponse, $statusCode);

    }

    private function formattingErrorResponseAuth(array $errorMessages, string $message) : string
    {
        $message .= '.';
        foreach ($errorMessages as $errorMessage) {
            $message .= ' '.implode('. ', $errorMessage);
        }

        return $message;
    }
}