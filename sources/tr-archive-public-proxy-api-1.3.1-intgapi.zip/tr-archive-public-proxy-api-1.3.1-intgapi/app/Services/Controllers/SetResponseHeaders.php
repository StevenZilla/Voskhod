<?php

namespace App\Services\Controllers;

use GuzzleHttp\Psr7\Response as GuzzleHttpResponse;
use Illuminate\Http\JsonResponse;

class SetResponseHeaders
{
    /**
     * @param GuzzleHttpResponse $guzzleHttpResponse
     * @param JsonResponse $jsonResponse
     * @return JsonResponse
     */
    public static function setHeadersResponse(GuzzleHttpResponse $guzzleHttpResponse, JsonResponse $jsonResponse) : JsonResponse
    {
        foreach ($guzzleHttpResponse->withoutHeader('Transfer-Encoding')->getHeaders() as $key => $header) {
            $jsonResponse->headers->set($key, $header);
        }

//        $jsonResponse->setStatusCode($guzzleHttpResponse->getStatusCode());

        return $jsonResponse;
    }
}