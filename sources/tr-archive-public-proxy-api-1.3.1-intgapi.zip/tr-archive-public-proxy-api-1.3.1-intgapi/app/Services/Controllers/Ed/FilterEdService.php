<?php

namespace App\Services\Controllers\Ed;

class FilterEdService
{
    private $filtersMap = [
        'reg_date' => ['start_reg_date', 'end_reg_date'],
        'project_register_num' => ['project_register_num'],
        'dossier_index' => ['dossier_index'],
        'di_kind' => ['di_kind'],
        'nom_year' => ['nom_year'],
        'project_accept_registers_num' => ['project_accept_registers_num'],
        'reg_date_min' => ['start_reg_date'],
        'reg_date_max' => ['end_reg_date'],
    ];

    public function filter(array $data) : string
    {
        $queryParams = [];
        foreach ($data as $index => $value) {
            if (!empty($this->filtersMap[$index])) {
                foreach ($this->filtersMap[$index] as $item) {
                    $queryParams[$item] = $value;
                }
            } else {
                $queryParams[$index] = $value;
            }
        }

        return http_build_query($queryParams);
    }
}