<?php

namespace App\Services\Controllers\Ed;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Http\Resources\Ed\IndexResource;
use App\Http\Resources\Ed\ShowResource;
use App\Routing\Action;
use App\Services\BaseService;
use Illuminate\Support\Collection;

class EdService extends BaseService
{
    public function getDossierId(array $dataDossiers)
    {
        if (!empty($dataDossiers['dossiers'][0]['id'])) {
            return $dataDossiers['dossiers'][0]['id'];
        } elseif (!empty($dataDossiers['logic_status_code']) || $dataDossiers['count'] === 0) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Дело не найдено в системе Тр-Архива.',
                'target' => 'ED',
                'logic_status_code' => $dataDossiers['logic_status_code'] ?? 400,
            ], 400));
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => $dataDossiers['code'] ?? 400,
                'message' => !empty($dataDossiers['message']) ? $dataDossiers['message'] : 'Не смогли найти подразделение.',
                'target' => 'ED',
                'logic_status_code' => $dataDossiers['code'] ?? 400,
            ], $dataDossiers['code'] ?? 400));
        }
    }

    public function getFormattingResponseStore(array $dataResponse, string $url, $httpStatusCode = 201)
    {
        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => $httpStatusCode,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], $httpStatusCode);
    }

    public function getFormattingResponseDelete()
    {
        return response('', 204);
    }

    public function parsingResponseIndex(string $jsonResponse, string $urlPublicApi) : array
    {
        $dataResponse = json_decode($jsonResponse, true);
        $ignoreKey = ['eds', 'count'];
        foreach ($dataResponse as $key => $value) {
            if (!in_array($key, $ignoreKey) && !empty($value)) {
                $dataResponse[$key] = $this->changeUrlPaginate($value, $urlPublicApi);
            }
        }

        $dataResponse['eds'] = $this->setKeyId($dataResponse['eds']);

        return $dataResponse;
    }

    public function parsingResponseShow(string $jsonResponse) : array
    {
        $dataResponse['eds'][] = json_decode($jsonResponse, true);
        $dataResponse['eds'] = $this->setKeyId($dataResponse['eds']);

        return $dataResponse;
    }

    public function mergeDossierAndNom(array $nomResponses, array $dossiers) : array
    {
        foreach ($dossiers as $idDossier => $dossier) {
            if (!empty($nomResponses["list_nomenclature_{$idDossier}"]['nomenclatures'])) {
                foreach ($nomResponses["list_nomenclature_{$idDossier}"]['nomenclatures'] as $nomenclature) {
                    $dossiers[$idDossier]['nom'] = [
                        'id' => $nomenclature['id'],
                        'year' => $nomenclature['year'],
                        'dossier_index' => $dossier['index'],
                        'save_type' => !empty($dossier['save_type']['value']) ? $dossier['save_type']['value'] : null,
                    ];
                }
            }
        }

        return $dossiers;
    }

    public function mergeEdsAndDossier(array $eds, array $dossiers)
    {
        foreach ($eds as $idEd => $ed) {
            $dataDiKind = [];
            $dataNom = [];
            if (!empty($dossiers["detail_dossier_{$idEd}"])) {
                $dataNom['index'] = $dossiers["detail_dossier_{$idEd}"]['index'];
                $dataNom['save_type'] = !empty($dossiers["detail_dossier_{$idEd}"]['save_type']['value'])
                                            ? $dossiers["detail_dossier_{$idEd}"]['save_type']['value'] : null;
                $dataDiKind[] = $dossiers["detail_dossier_{$idEd}"]['di_kinds'];
            }
            if (!empty($dossiers["list_nomenclature_{$idEd}"])) {
                $dataNom['id'] = $dossiers["list_nomenclature_{$idEd}"]['nomenclatures'][0]['id'];
                $dataNom['year'] = $dossiers["list_nomenclature_{$idEd}"]['nomenclatures'][0]['year'];
            }

            $eds[$idEd]['di_kind'] = $dataDiKind;
            $eds[$idEd]['nom'] = $dataNom;
        }

        return $eds;
    }

    public function setFullSizeEds(array $eds, array $files)
    {
        foreach ($eds as $idEd => $ed) {
            $fullSize = 0;
            if (!empty($files['ed_files_' . $idEd])) {
                foreach ($files['ed_files_' . $idEd] as $response) {
                    foreach ($response as $file) {
                        $fullSize += $file['size'];
                    }
                }
            }

            $eds[$idEd]['full_size'] = $fullSize;
        }

        return $eds;
    }

    public function getFormattingResponseIndex(array $edResponse)
    {
        $edResponse['eds'] = (new IndexResource($edResponse['eds']))->resolve();
        return response()->json($edResponse, 200);
    }

    public function getFormattingResponseShow(array $edResponse)
    {
        $response = (new ShowResource(array_first($edResponse['eds'])))->resolve();
        return response()->json($response);
    }

    public function returnUrl(Request $request, $edId) : string
    {
        $prefixRoutes = config('gateway.gateway_prefix');
        $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v2/eds/{guid_arch}"]['uri'];
        $uri = preg_replace('/\{guid_arch\}/', $edId, $route);

        return str_replace($request->getPathInfo(), $uri, $request->url());
    }

    public function setSubdivisionId(array $responseSubdivision, string $subdivisionCode) : int
    {
        if (!empty($responseSubdivision['subdivisions'][0]['id'])) {
            return $responseSubdivision['subdivisions'][0]['id'];
        } elseif (!empty($responseSubdivision['logic_status_code'])) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Подразделение не найдено в системе Тр-Архива.',
                'target' => 'ED',
                'logic_status_code' => $responseSubdivision['logic_status_code'],
            ], 400));
        } else {
            throw new CustomHttpResponseException(response()->json([
                'code' => $responseSubdivision['code'] ?? 400,
                'message' => !empty($responseSubdivision['message']) ? $responseSubdivision['message'] : 'Не смогли найти подразделение.',
                'target' => 'ED',
                'logic_status_code' => $responseSubdivision['code'] ?? 400,
            ], $responseSubdivision['code'] ?? 400));
        }
    }

    public function setActionSearchEdId(array $guidArchEds, Collection $collectionAction)
    {
        foreach ($guidArchEds as $key => $guidArch) {
            $cloneAction = clone $collectionAction->first();
            $cloneAction->setAlias("guid_eds.{$key}");
            $cloneAction->setPathVariables(['guid_arch' => $guidArch]);

            $collectionAction->push($cloneAction);
        }

        $collectionAction->forget(0);
        return $collectionAction;
    }

    public function setActionDossierId(Action $action, array $dossier = []) : bool
    {
        if (!empty($dossier)) {
            $action->setPathVariables(['dossier_index' => $dossier['dossier_index'], 'nomenclature_year' => $dossier['nom_year']]);
            return true;
        }

        return false;
    }

    public function setActionSubdivisionId(Action $action, string $subdivisionCode = '') : bool
    {
        if (!empty($subdivisionCode)) {
            $action->setPathVariables(['subdivision_code' => $subdivisionCode]);
            return true;
        }

        return false;
    }

    public function setActionDeleteEd(array $edsId, Collection $collectionAction)
    {
        foreach ($edsId as $key => $guidArch) {
            $cloneAction = clone $collectionAction->first();
            $cloneAction->setAlias($key);
            $cloneAction->setPathVariables(['ed_id' => $guidArch]);
            $collectionAction->push($cloneAction);
        }

        $collectionAction->forget(0);
        return $collectionAction;
    }


    public function setEdId(array $data) : array
    {
        $resultEdId = [];
        $errorMessage = [];
        $logicStatusCode = 0;

        foreach ($data['guid_eds'] as $key => $value) {
            if (!empty($value['logic_status_code']) && $logicStatusCode === 0) {
                $logicStatusCode = $value['logic_status_code'];
            }

            if (!empty($value['id'])) {
                $resultEdId["guid_eds.{$key}"] = $value['id'];
            } elseif (!empty($value['message'])) {
                $errorMessage["guid_eds.{$key}"] = [$value['message']];
            } else {
                $errorMessage["guid_eds.{$key}"] = ['Ответ от внутренней системы не соответствует нашим ожиданиям.'];
            }
        }

        if (!empty($errorMessage)) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 404,
                'message' => 'Не смогли установить внутрение идентификаторы электронных документов.',
                'target' => 'ED',
                'logic_status_code' => $logicStatusCode,
                'errors' => [
                    $errorMessage
                ]
            ], 404));
        }

        return $resultEdId;
    }

    public function setResponseDeleteEds(array $dataEds)
    {
        $errorMessage = [];
        $logicStatusCode = 0;

        foreach ($dataEds['guid_eds'] as $key => $value) {
            if ($value !== null) {
                if ($logicStatusCode === 0) {
                    if (!empty($value['logic_status_code'])) {
                        $logicStatusCode = $value['logic_status_code'];
                    }
                }

                if (!empty($value['message'])) {
                    $errorMessage["guid_eds.{$key}"] = [$value['message']];
                } else {
                    $errorMessage["guid_eds.{$key}"] = ['Ответ от внутренней системы не соответствует нашим ожиданиям.'];
                }
            }
        }

        if (!empty($errorMessage)) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Не смогли удалить электронные документы.',
                'target' => 'ED',
                'logic_status_code' => $logicStatusCode === 0 ? 400 : $logicStatusCode,
                'errors' => [
                    $errorMessage
                ]
            ], 400));
        }
    }
}
