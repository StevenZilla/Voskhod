<?php

namespace App\Services\Controllers\Ed\File;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Http\Resources\Ed\File\IndexResource;

class FileService
{
    public function getFormattingResponseIndex(array $files)
    {
        $edResponse['files'] = (new IndexResource($files['files']))->resolve();
        return response()->json($edResponse);
    }

    public function getFormattingResponseUpload(array $dataResponse, string $url)
    {
        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 200,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 200);
    }

    public function getFormattingResponseStore(string $jsonResponse, string $url)
    {
        $urlObj = new \stdClass();
        $urlObj->self = config('gateway.global.domain').'/'.$url;

        $dataResponse = json_decode($jsonResponse, true);
        return response()->json([
            'code' => 201,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 201);
    }

    public function parsingResponseCheckAntivirus(string $jsonResponse, array $dataFiles)
    {
        $dataResponse = json_decode($jsonResponse, true);
        $error = [];
        $hasError = false;
        foreach ($dataResponse['files'] as $index => $file) {
            $guidSourceSer = $this->searchGuidSourceSed($file['originalName'], $dataFiles);

            if (empty($guidSourceSer)) {
                $guidSourceSer = $index;
            }

            $error[$guidSourceSer] = $file;
            $error[$guidSourceSer]['guid_source_sed'] = $guidSourceSer;
            if (!empty($file['status']) && mb_strtolower($file['status']['code']) !== 'ok') {
                $hasError = true;
            }
        }

        if ($hasError) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 422,
                'message' => 'Файлы не прошли проверку антивирусом.',
                'target' => 'File',
                'logic_status_code' => 422,
                'errors' => $error
            ], 422));
        }
    }

    public function searchGuidSourceSed(string $fileName, array $files): string
    {
        foreach ($files as $file) {
            if ($file['name'] === $fileName) {
                if (isset($file['guid_source_sed'])) {
                    return $file['guid_source_sed'];
                }
            }

            if (isset($file['children'])) {
                $result = $this->searchGuidSourceSed($fileName, $file['children']);
                if ($result !== '') {
                    return $result;
                }
            }
        }

        return '';
    }

    public function parsingResponseCheckVerify(string $jsonResponse)
    {
        $dataResponse = json_decode($jsonResponse, true);
        if (!empty($dataResponse['error'])) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 422,
                'message' => 'Файлы не прошли проверку подписи и МЧД.',
                'target' => 'File',
                'error' => $dataResponse['error'],
                'logic_status_code' => $dataResponse['logic_status_code'] ?? 422
            ], 422));
        } else {
            throw new CustomHttpResponseException(response()->json($dataResponse, $dataResponse['logic_status_code'] ?? $dataResponse['code']));
        }
    }

    public function returnUrl(Request $request, $edId) : string
    {
        $prefixRoutes = config('gateway.gateway_prefix');
        $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/eds/{id}"]['uri'];
        $uri = preg_replace('/\{id\}/', $edId, $route);

        return str_replace($request->getPathInfo(), $uri, $request->url());
    }
}