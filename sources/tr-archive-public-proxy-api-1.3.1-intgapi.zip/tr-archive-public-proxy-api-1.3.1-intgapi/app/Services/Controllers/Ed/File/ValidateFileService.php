<?php

namespace App\Services\Controllers\Ed\File;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Validator;

class ValidateFileService
{
    private $filesRules = [
        'data' => 'required|json',
        'files' => 'nullable|array',
        '_method' => 'required|string|in:PUT',
    ];

    private $filesMessages = [
        'data.required' => 'Мета-информация о физических ЭД обязательна.',
        'data.json' => 'Мета-информация о физических ЭД должна быть json строкой.',
        'files.required' => 'Массив файлов обязателен.',
        'files.array' => 'Файлы должны быть массивом.',
        '_method.required' => '_method является обязательным параметром.',
        '_method.string' => '_method является строкой.',
        '_method.in' => '_method ожидает значение PUT.',
    ];

    private $fileMetaDataRules = [
        'guid_arch' => ['nullable', 'string', 'regex:/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i'],
        'guid_source_sed' => ['required', 'string', 'regex:/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i'],
        'name' => 'required|string',
        'fr_id' => 'required|numeric|min:1|max:5',
        'is_original' => 'nullable|boolean',
        'children' => 'nullable|array',
    ];

    private $fileMetaDataMessages = [
        'guid_arch.string' => 'Идентификатор файла должен быть строкой.',
        'guid_arch.regex' => 'Файл с переданным идентификатором должен быть в формате UUID.',
        'guid_source_sed.required' => 'Идентификатор файла в источнике является обязательным значением.',
        'guid_source_sed.string' => 'Идентификатор файла в источнике должен быть строкой.',
        'guid_source_sed.regex' => 'Идентификатор файла в источнике должен быть в формате UUID.',
        'name.required' => 'Наименование файла обязательно.',
        'name.string' => 'Наименование файла должно быть строкой.',
        'fr_id.required' => 'Роль файла обязательна.',
        'fr_id.numeric' => 'Роль файла должна быть числом.',
        'fr_id.min' => 'Минимальное значение роли файла - 1. 1 - ДОКУМЕНТ, 2 - ПРИЛОЖЕНИЕ, 3 - ВИЗУАЛИЗАЦИЯ ДОКУМЕНТА, 4 - ПОДПИСЬ, 5 - ФАЙЛ МЧД',
        'fr_id.max' => 'Максимальное значение роли файла - 4. 1 - ДОКУМЕНТ, 2 - ПРИЛОЖЕНИЕ, 3 - ВИЗУАЛИЗАЦИЯ ДОКУМЕНТА, 4 - ПОДПИСЬ, 5 - ФАЙЛ МЧД',
        'is_original.boolean' => 'Оригинальность файла должна быть в виде логического значения.',
        'children.array' => 'Массив мета-информации о дочерних файлов должен быть массивом.',
    ];

    public function updateFilesValidate(array $input)
    {
        $this->validateFilesData($input);

        $metaData = json_decode($input["data"], true)["files"];
        $errors = $this->validateMetaData([], 'files', $metaData, $input['files'] ?? []);
        if (!empty($errors)) {
            throw new HttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Валидация не пройдена',
                'target' => 'File',
                'error' => [$errors],
            ], 400));
        }
    }

    private function validateFilesData(array $input)
    {
        $validator = Validator::make($input, $this->filesRules, $this->filesMessages);
        if ($validator->fails()) {
            throw new HttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Валидация не пройдена',
                'target' => 'File',
                'error' => $validator->errors(),
            ], 400));
        }
    }

    private function validateMetaData(array $errors, string $path, array $filesMetaData, array $files = null)
    {
        foreach ($filesMetaData as $index => $fileMetaData) {
            if (!empty($fileMetaData['guid_source_sed']) &&
                    preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $fileMetaData['guid_source_sed'])) {
                $key = $fileMetaData['guid_source_sed'];
            } else {
                $key = "{$path}.{$index}";
            }

            $filePath = "{$path}.{$index}";

            if (!isset($fileMetaData['guid_arch']) && !$this->checkFileName($fileMetaData['name'], $files)) {
                if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $key)) {
                    $errorKey = $key;
                } else {
                    $errorKey = $filePath.'.files';
                }

                $errors[$errorKey][] = "В теле запроса не передан файл с именем {$fileMetaData['name']}";
            }

            if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $key)) {
                $resultValidateFileMetaData = $this->validateFileMetaData($fileMetaData, $key);

                if (!empty($resultValidateFileMetaData[$key])) {
                    $errors[$key] = array_merge($errors[$key], $resultValidateFileMetaData[$key]);
                }
            } else {
                $resultValidateFileMetaData = $this->validateFileMetaData($fileMetaData, $key);

                if (!empty($resultValidateFileMetaData)) {
                    $errors = array_merge($errors, $resultValidateFileMetaData);
                }
            }


            if (!empty($fileMetaData['children'])) {
                $errors = array_merge($errors, $this->validateMetaData($errors, "{$filePath}.children", $fileMetaData['children'], $files));
            }
        }

        return $errors;
    }

    private function validateFileMetaData(array $fileMetaData, string $path)
    {
        $errors = [];
        $validator = Validator::make($fileMetaData, $this->fileMetaDataRules, $this->fileMetaDataMessages);
        if ($validator->fails()) {
            foreach ($validator->errors()->messages() as $index => $message) {
                if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $path)) {
                    $errors[$path] = $message;
                } else {
                    $errors[$path.'.'.$index] = $message;
                }

            }
        }

        return $errors;
    }

    private function checkFileName(string $name, array $files): bool
    {
        $res = false;
        foreach ($files as $file) {
            if ($file->getClientOriginalName() == $name) {
                $res = true;
                break;
            }
        }
        return $res;
    }
}