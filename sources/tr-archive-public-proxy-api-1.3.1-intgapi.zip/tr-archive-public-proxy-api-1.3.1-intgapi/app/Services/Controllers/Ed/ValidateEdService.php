<?php

namespace App\Services\Controllers\Ed;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Support\Facades\Validator;

class ValidateEdService
{
    private $indexRules = [
        'reg_date' => 'nullable|regex:/\d{4}-\d{1,2}-\d{1,2}/',
        'reg_date_min' => 'nullable|regex:/\d{4}-\d{1,2}-\d{1,2}/',
        'reg_date_max' => 'nullable|regex:/\d{4}-\d{1,2}-\d{1,2}/',
        'project_register_num' => 'nullable|string',
        'project_accept_registers_num' => 'nullable|string',
        'dossier_index' => 'nullable|string',
        'di_kind' => 'nullable|string',
        'nom_year' => 'nullable|regex:/\d{4}/',
        'q' => 'nullable|string'
    ];

    private $indexMessages = [
        'reg_date.regex' => 'Фильтрация по дате регистрации должна быть в формате - ГГГГ-ММ-ДД.',
        'reg_date_min.regex' => 'Фильтрация по дате начала регистрации должна быть в формате - ГГГГ-ММ-ДД.',
        'reg_date_max.regex' => 'Фильтрация по дате окончания регистрации должна быть в формате - ГГГГ-ММ-ДД.',
        'project_register_num.string' => 'Номер проекта сводной описи должен быть строкой',
        'project_accept_registers_num.string' => 'Номер проекта сдаточной описи должен быть строкой',
        'dossier_index.string' => 'Индекс дела должен быть строкой',
        'di_kind.string' => 'Номер статьи должен быть строкой',
        'nom_year.regex' => 'Год номенклатуры должен быть в формате - ГГГГ',
        'q' => 'Контекстный поиск по номеру и наименованию документа'
    ];

    private $deleteRules = [
        'guid_eds' => 'required|array|max:100', // Поле guid_eds обязательно, должно быть массивом и не содержать более 100 элементов
        'guid_eds.*' => ['required', 'string', 'regex:/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i'], // Каждый элемент массива должен соответствовать формату UUID через регулярное выражение
    ];

    private $deleteMessages = [
        'guid_eds.required' => 'Поле guid_eds должно быть массивом и обязательным',
        'guid_eds.array' => 'Поле guid_eds должно быть массивом.',
        'guid_eds.max' => 'Поле guid_eds должно быть массивом и не должно содержать более 100 элементов.',
        'guid_eds.*.required' => 'Каждый элемент массива должен быть обязательным, строкой и соответствовать формату UUID.',
        'guid_eds.*.string' => 'Каждый элемент массива должен быть строкой.',
        'guid_eds.*.regex' => 'Каждый элемент массива должен соответствовать формату UUID.',
    ];

    private $storeRules = [
        'name' => 'required|string',
        'is_dsp' => 'nullable|bool',
        'num' => 'required|string',
        'subdivision_code' => 'nullable|string',
        'reg_date' => 'required|regex:/\d{4}-\d{1,2}-\d{1,2}/',
        'dossiers' => 'nullable|array',
    ];

    private $dossierRules = [
        'nom_year' => 'required|regex:/\d{4}/',
        'dossier_index' => 'required|string',
    ];

    private $storeMessages = [
        'name.required' => 'Наименование электронного является обязательным параметром.',
        'name.string' => 'Наименование электронного документа должно быть строкой.',
        'is_dsp.bool' => 'Флаг грифа ДСП должно быть логического типа.',
        'is_dsp.in' => 'Флаг грифа ДСП ожидает значения: true или false.',
        'num.required' => 'Номер электронного документа обязателен.',
        'num.string' => 'Номер электронного документа должен быть строкой.',
        'subdivision_code.string' => 'Код подразделения электронного документа должен быть строкой.',
        'reg_date.required' => 'Дата регистрации электронного документа обязательна.',
        'reg_date.regex' => 'Дата регистрации электронного документа должна быть в формате ГГГГ-ММ-ДД.',
        'dossiers.array' => 'Дела должны быть в формате json.',
    ];

    private $dossierMessages = [
        'nom_year.required' => 'Год номенклатуры обязательный параметр.',
        'nom_year.regex' => 'Год номенклатуры должен быть в формате - YYYY',
        'dossier_index.required' => 'Индекс дела является обязательным параметром.',
        'dossier_index.string' => 'Индекс дела должен быть строкой.',
    ];

    public function storeValidateRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->storeRules, $this->storeMessages);

        if ($validator->fails()) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Неправильное тело запроса на создание электронного документа.',
                'logic_status_code' => 400,
                'target' => 'ED',
                'errors' => [$validator->errors()->getMessages()],
            ], 400));
        }

        return $data;
    }

    public function deleteValidateRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->deleteRules, $this->deleteMessages);

        if ($validator->fails()) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'Неправильное тело запроса на удаление электронных документов.',
                'logic_status_code' => 400,
                'target' => 'ED',
                'errors' => [$validator->errors()->getMessages()],
            ], 400));
        }

        return $data;
    }

    public function indexValidateQueryRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->indexRules, $this->indexMessages);

        $message = 'Валидация не пройдена.';
        if (!empty($data['dossiers'])) {
            $validatorDossier = Validator::make($data['dossiers'], $this->dossierRules, $this->dossierMessages);
            if ($validatorDossier->fails()) {
                foreach ($validatorDossier->errors()->getMessages() as $errorMessage) {
                    $message .= ' '.implode(' ', $errorMessage);
                }
            }
        }

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' '.implode(' ', $errorMessage);
            }
        }

        if ($message !== 'Валидация не пройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'ED',
                'logic_status_code' => 400,
            ], 400));
        }

        return $data;
    }
}