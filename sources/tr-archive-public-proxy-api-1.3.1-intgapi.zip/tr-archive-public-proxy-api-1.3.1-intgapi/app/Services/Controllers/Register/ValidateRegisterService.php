<?php

namespace App\Services\Controllers\Register;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Support\Facades\Validator;

class ValidateRegisterService
{
    private $storeRules = [
        'name' => 'required|string',
        'num' => 'required|string',
        'year' => 'required|regex:/\d{4}/',
        'dossiers' => 'nullable|array',
        'dossiers.*.dossier_index' => 'required|string',
        'dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'dossier_ids' => 'nullable|array',
        'dossier_ids.*' => 'required|integer',
        'register_parts' => 'nullable|array',
        'register_parts.*.name' => 'required|string',
        'register_parts.*.children' => 'nullable|array',
        'register_parts.*.dossiers' => 'nullable|array',
        'register_parts.*.dossiers.*.dossier_index' => 'required|string',
        'register_parts.*.dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'register_parts.*.dossier_ids' => 'nullable|array',
        'register_parts.*.dossier_ids.*' => 'required|integer',
    ];

    private $storeMessages = [
        'name.required' => 'Наименование сводной описи является обязательным параметром.',
        'name.string' => 'Наименование сводной описи должно быть в формате строки.',
        'num.required' => 'Номер сводной описи является обязательным параметром.',
        'num.string' => 'Номер сводной описи должно быть в формате строки.',
        'subdivision_code.required' => 'Кодовое обозначение у сводной описи является обязательным параметром.',
        'subdivision_code.string' => 'Кодовое обозначение у сводной описи должно быть в формате строки.',
        'year.required' => 'Год сводной описи является обязательным параметром.',
        'year.regex' => 'Год сводной описи должен быть в формате - ГГГГ.',
        'dossiers.array' => 'Дела должны быть в формате массива.',
        'dossiers.*.dossier_index.required' => 'Индекс дела является обязательным параметром.',
        'dossiers.*.dossier_index.string' => 'Индекс дела должен быть в формате строки.',
        'dossiers.*.nom_year.required' => 'Год номенклатуры является обязательным параметром.',
        'dossiers.*.nom_year.regex' => 'Год номенклатуры должен быть в формате ГГГГ.',
        'dossier_ids.array' => 'Идентификаторы дел должны быть в формате массива.',
        'dossier_ids.*.required' => 'Идентификатор дела должен быть обязательным параметром',
        'dossier_ids.*.integer' => 'Идентификатор дела должен быть в формате строки',
        'register_parts.array' => 'Разделы сводной описи должны быть в формате массива.',
        'register_parts.*.name.required' => 'Наименование раздела сводной описи является обязательным параметром.',
        'register_parts.*.name.string' => 'Наименование разделов сводной описи должен быть в формате строки.',
        'register_parts.*.children.array' => 'Подразделы сводной описи должен быть в формате массива.',
        'register_parts.*.dossiers.array' => 'Дела у раздела сводной описи должны быть в формате массива.',
        'register_parts.*.dossiers.*.dossier_index.required' => 'Индекс дела у раздела сводной описи является обязательным параметром.',
        'register_parts.*.dossiers.*.dossier_index.string' => 'Индекс дела у раздела сводной описи должен быть в формате строки.',
        'register_parts.*.dossiers.*.nom_year.required' => 'Год номенклатуры у раздела сводной описи является обязательным параметром.',
        'register_parts.*.dossiers.*.nom_year.regex' => 'Год номенклатуры у раздела сводной описи должен быть в формате ГГГГ.',
        'register_parts.*.dossier_ids.array' => 'Идентификаторы дел у раздела сводной описи должны быть в формате массива.',
        'register_parts.*.dossier_ids.*.required' => 'Идентификатор дела у раздела сводной описи должен быть обязательным параметром',
        'register_parts.*.dossier_ids.*.integer' => 'Идентификатор дела у раздела сводной описи должен быть в формате строки',
    ];

    private $childrenRules = [
        'name' => 'required|string',
        'dossiers' => 'nullable|array',
        'dossiers.*.dossier_index' => 'required|string',
        'dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'dossier_ids' => 'nullable|array',
        'dossier_ids.*' => 'required|integer',
        'children' => 'nullable|array',
    ];

    private $childrenMessages = [
        'name.required' => 'Наименование подраздела сдаточной описи является обязательным параметром.',
        'name.string' => 'Наименование подраздела сдаточной описи должен быть в формате строки.',
        'dossiers.array' => 'Дела у подраздела сдаточной описи должны быть в формате массива.',
        'dossiers.*.dossier_index.required' => 'Индекс дела у подраздела сдаточной описи является обязательным параметром.',
        'dossiers.*.dossier_index.string' => 'Индекс дела у подраздела сдаточной описи должен быть в формате строки.',
        'dossiers.*.nom_year.required' => 'Год номенклатуры у подраздела сдаточной описи является обязательным параметром.',
        'dossiers.*.nom_year.regex' => 'Год номенклатуры у подраздела сдаточной описи должен быть в формате ГГГГ.',
        'dossier_ids.array' => 'Идентификаторы дел у подраздела сдаточной описи должны быть в формате массива.',
        'dossier_ids.*.required' => 'Идентификатор дела у подраздела сдаточной описи должен быть обязательным параметром',
        'dossier_ids.*.integer' => 'Идентификатор дела у подраздела сдаточной описи должен быть в формате строки',
        'children.array' => 'Подразделы сдаточной описи должен быть в формате массива.',
    ];

    private $indexRules = [
        'num' => 'nullable|string',
        'year' => 'nullable|regex:/\d{4}/',
        'q' => 'nullable|string'
    ];

    private $indexMessages = [
        'num' => 'Фильтрация по номеру сдаточной описи',
        'year.regex' => 'Год сдаточной описи должен быть в формате - ГГГГ',
        'q' => 'Контекстный поиск по номеру и заголовку сдаточной описи'
    ];


    public function storeValidateRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->storeRules, $this->storeMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' '.implode(' ', $errorMessage);
            }
        }

        foreach ($data['register_parts'] as $registerPart) {
            if (!empty($registerPart['children'])) {
                $message .= ' ' . $this->childrenValidate($registerPart['children']);
            }
        }

        if (str_replace(' ', '', $message) !== 'Валидациянепройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'REGISTER',
            ], 400));
        }

        return $data;
    }

    public function childrenValidate(array $children) :string
    {
        $message = '';
        foreach ($children as $child) {
            $validator = Validator::make($child, $this->childrenRules, $this->childrenRules);

            if ($validator->fails()) {
                foreach ($validator->errors()->getMessages() as $errorMessage) {
                    $message .= ' '.implode(' ', $errorMessage);
                }
            }

            if (!empty($child['children'])) {
                $message .= $this->childrenValidate($child['children']);
            }
        }

        return $message;
    }

    public function indexValidateQueryRequest(array $data): array
    {
        $validator = Validator::make($data, $this->indexRules, $this->indexMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' ' . implode(' ', $errorMessage);
            }
        }

        if ($message !== 'Валидация не пройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'Register',
            ], 400));
        }

        return $data;
    }


}