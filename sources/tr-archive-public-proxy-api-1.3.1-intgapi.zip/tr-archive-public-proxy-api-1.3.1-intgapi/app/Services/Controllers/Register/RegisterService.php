<?php

namespace App\Services\Controllers\Register;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Request;
use App\Http\Resources\Register\IndexResource;
use App\Http\Resources\Register\ShowResource;
use Illuminate\Http\JsonResponse;

class RegisterService
{
    const CONSTANTLY = 'constantly';
    const BY_PERSONNEL = 'by_personnel';
    const GREATER_THAN_EQUAL_YEARS = 'greater_than_equal_years';
    const FROM_6_TO_10_YEARS = 'from_6_to_10_years';

    private $registerTypeTempSave = ['temporarily', 'DMN', 'DLO', 'DZN'];
    private $registerTypeIgnoreTempSavePeriod = ['DMN', 'DLO', 'DZN'];
    private $registerTypeFrom6To10Years = 0;
    private $registerTypeFrom10ToMoreYears = 0;
    private $registerTypeTo10Years = 0;

    public function setArchiveAndFund(array $settings): array
    {
        if (empty($settings['fund_id'])) {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => 'В системных настройках не установлены "Архивы" и "Фонды". Создание описи невозможна.',
                'target' => 'REGISTER',
            ], 400));
        }

        return [
            'fund_id' => $settings['fund_id'],
            'archive_id' => $settings['archive_id'],
        ];
    }

    public function checkSavePeriodDossiers(array $dataSaveTypeDossiers, array $dataTempSavePeriod): string
    {
        $dataUniqueSaveTypeDossiers = array_unique($dataSaveTypeDossiers);
        $dataDiffSaveType = array_diff($dataUniqueSaveTypeDossiers, $this->registerTypeTempSave);
        if (!empty($dataDiffSaveType)) {
            if (count($dataUniqueSaveTypeDossiers) === 1) {
                return self::CONSTANTLY;
            } else {
                $message = 'У дел отличается срок хранения. ' . implode(' ', array_keys($dataSaveTypeDossiers));

                throw new CustomHttpResponseException(response()->json([
                    'code' => 400,
                    'message' => $message,
                    'target' => 'REGISTER',
                ], 400));
            }
        }

        $dataUniqueTempSavePeriod = array_unique($dataTempSavePeriod);
        foreach ($dataUniqueTempSavePeriod as $key => $value) {
            $saveTypeDossier = $dataSaveTypeDossiers[$key];
            if (!in_array($saveTypeDossier, $this->registerTypeIgnoreTempSavePeriod)) {
                if ($value <= 5) {
                    $this->registerTypeTo10Years++;
                } elseif ($value >= 6 && $value <= 9) {
                    $this->registerTypeFrom6To10Years++;
                } elseif ($value >= 10) {
                    $this->registerTypeFrom10ToMoreYears++;
                }
            }
        }

        if (!empty($this->registerTypeTo10Years)) {
            $message = 'В опись добавлены дела со сроком хранения меньше 5 лет. ' . implode(' ', array_keys($dataSaveTypeDossiers));
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'REGISTER',
            ], 400));
        } elseif (!empty($this->registerTypeFrom6To10Years) && !empty($this->registerTypeFrom10ToMoreYears)) {
            $message = 'В опись добавлены дела со сроком хранения от 6 до 10 и больше или равно 10 лет. ' . implode(' ', array_keys($dataSaveTypeDossiers));
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'REGISTER',
            ], 400));
        } elseif (!empty($this->registerTypeFrom6To10Years) && empty($this->registerTypeFrom10ToMoreYears)) {
            return self::FROM_6_TO_10_YEARS;
        } elseif (empty($this->registerTypeFrom6To10Years) && !empty($this->registerTypeFrom10ToMoreYears)) {
            return self::GREATER_THAN_EQUAL_YEARS;
        } else {
            $message = 'В опись добавлены дела со сроком хранения ДМН, ДЛО, ДЗН. Не смогли определить Вид сводной описи. ' . implode(' ', array_keys($dataSaveTypeDossiers));
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'REGISTER',
            ], 400));
        }
    }

    public function getRegisterType(string $registerTypeCode, array $registerTypeData): int
    {
        foreach ($registerTypeData as $registerType) {
            if ($registerType['code'] === $registerTypeCode) {
                return $registerType['id'];
            }
        }

        throw new CustomHttpResponseException(response()->json([
            'code' => 400,
            'message' => "Не смогли определить идентификатор вида сводной описи по коду - {$registerTypeCode}",
            'target' => 'REGISTER',
        ], 400));
    }

    public function getFormattingErrorResponseStore(array $registerResponse)
    {
        $registerResponse['target'] = 'REGISTER';
        if (!empty($registerResponse['error'])) {
            foreach ($registerResponse['error'] as $error) {
                if (is_array($error)) {
                    $registerResponse['message'] .= ' ' . implode('. ', $error);
                } elseif (is_string($error)) {
                    $registerResponse['message'] .= ' ' . $error;
                }
            }

            unset($registerResponse['error']);
        }

        return response()->json($registerResponse, 400);
    }

    public function returnUrl(Request $request, $nomId): string
    {
        $prefixRoutes = config('gateway.gateway_prefix');
        $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/project_registers/{id}"]['uri'];
        $uri = preg_replace('/\{id\}/', $nomId, $route);

        return str_replace($request->getPathInfo(), $uri, $request->url());
    }

    public function getFormattingResponseStore(string $jsonResponse, string $url)
    {
        $dataResponse = json_decode($jsonResponse, true);

        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 201,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 201);
    }

    public function getFormattingResponseUpdate(string $jsonResponse, string $url)
    {
        $dataResponse = json_decode($jsonResponse, true);

        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 200,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 200);
    }



    public function parsingResponseShow(string $jsonResponse): array
    {
        return json_decode($jsonResponse, true);
    }

    public function parsingRegPartsShow(string $jsonResponse)
    {
        $data = json_decode($jsonResponse, true)['data'];

        $regParts = $data['register_parts']['register_parts'];
        $dossiers = $data['register_parts_dossiers']['register_parts'];
        $regParts = $this->setIdsRegisters($regParts);
        $dossiers = $this->setIdsDossiers($dossiers);
        $this->joinRegPartAndDossiers($regParts, $dossiers);

        $this->createTree($regParts);

        return array($regParts, $dossiers[null]);
    }

    private function createTree(array &$regParts)
    {
        $childIds = [];
        foreach ($regParts as $key => &$part) {
            $path = [$key => 1];
            if(isset($childIds[$key])) continue;

            $this->processPart($part, $path, $childIds, $regParts);

            unset($path[$key]);
        }

        foreach ($childIds as $key => $id){
            unset($regParts[$key]);
        }
    }

    private function processPart(array &$part, array &$path, array &$childIds, array $regParts)
    {
        if ($part['children'] == null) return;

        foreach ($part['children'] as &$child) {
            $childIds[$child['id']] = 1;

            if (isset($path[$child['id']])) continue;
            $path[$child['id']] = 1;

            $child = $regParts[$child['id']];
            $this->processPart($child, $path, $childIds, $regParts);

            unset($path[$child['id']]);
        }
    }

    private function setIdsRegisters(array $regParts): array
    {
        $data = [];
        foreach ($regParts as $part) {
            $data[$part['id']] = $part;
        }

        return $data;
    }

    private function setIdsDossiers(array $dossiers): array
    {
        $data = [];
        foreach ($dossiers as $dos) {
            $data[$dos['id']] = $dos['dossiers'];
        }

        return $data;
    }

    private function joinRegPartAndDossiers(array &$regParts, array $dossiers)
    {
        foreach ($regParts as &$part) {
            $part['dossiers'] = $dossiers[$part['id']];
        }
    }

    public function getFormattingResponseShow(array $register): JsonResponse
    {
        $response['project_registers'] = new ShowResource($register);
        return response()->json($response);
    }

    public function parsingResponseIndex(string $jsonResponse, string $urlPublicApi): array
    {
        $data = json_decode($jsonResponse, true);
        $data['project_registers'] = $data['registers'];
        unset($data['registers']);
        $ignoreKey = ['project_registers', 'count'];
        foreach ($data as $key => $value) {
            if (!in_array($key, $ignoreKey) && !empty($value)) {
                $data[$key] = $this->changeUrlPaginate($value, $urlPublicApi);
            }
        }

        return $data;
    }

    private function changeUrlPaginate(string $oldUrl, string $newUrl): string
    {
        $dataOldUrl = parse_url($oldUrl);
        return $newUrl . '?' . $dataOldUrl['query'];
    }


    public function getFormattingResponseIndex(array $response)
    {
        $response['project_registers'] = new IndexResource($response['project_registers']);
        return response()->json($response);
    }


}
