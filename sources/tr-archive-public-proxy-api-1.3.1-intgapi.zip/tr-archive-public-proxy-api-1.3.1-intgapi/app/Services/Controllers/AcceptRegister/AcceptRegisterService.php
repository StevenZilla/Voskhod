<?php

namespace App\Services\Controllers\AcceptRegister;

use App\Exceptions\CustomHttpResponseException;
use App\Http\Resources\AcceptRegister\IndexResource;
use App\Http\Resources\AcceptRegister\ShowResource;
use App\Services\BaseService;
use App\Http\Request;

class AcceptRegisterService extends BaseService
{
    public function parsingResponseIndex(string $jsonResponse, string $urlPublicApi) : array
    {
        $dataResponse = json_decode($jsonResponse, true);
        $ignoreKey = ['accept_registers', 'count'];
        foreach ($dataResponse as $key => $value) {
            if ($key == 'accept_registers') {
                foreach ($value as $id => $register) {
                    unset($register['accept_register_status']);
                    $dataResponse[$key][$id] = $register;
                }
            }
            if (!in_array($key, $ignoreKey) && !empty($value)) {
                $dataResponse[$key] = $this->changeUrlPaginate($value, $urlPublicApi);
            }
        }

        $dataResponse['accept_registers'] = $this->setKeyId($dataResponse['accept_registers']);
        return $dataResponse;
    }

    public function setSubdivisionId(array $responseSubdivision, string $subdivisionCode) : int
    {
        if (!empty($responseSubdivision['count'])) {
            if ($responseSubdivision['count'] > 1) {
                $message = "Нашли несколько подразделений по коду - {$subdivisionCode}.";
                foreach ($responseSubdivision['subdivisions'] as $index => $subdivision) {
                    $index++;
                    $message .= " {$index}) Подразделение называется - {$subdivision['name']}, кодовое обозначение - {$subdivision['code']}";
                }

                throw new CustomHttpResponseException(response()->json([
                    'code' => 400,
                    'message' => $message,
                    'target' => 'ACCEPT_REGISTER',
                ], 400));
            } elseif ($responseSubdivision['count'] === 1) {
                return $responseSubdivision['subdivisions'][0]['id'];
            }
        }

        throw new CustomHttpResponseException(response()->json([
            'code' => 400,
            'message' => "Не смогли найти подразделение по коду - {$subdivisionCode}",
            'target' => 'ACCEPT_REGISTER',
        ], 400));
    }

    public function getFormattingErrorResponseStore(array $acceptRegisterResponse)
    {
        $acceptRegisterResponse['target'] = 'ACCEPT_REGISTER';
        if (!empty($acceptRegisterResponse['error'])) {
            foreach ($acceptRegisterResponse['error'] as $error) {
                if (is_array($error)) {
                    $acceptRegisterResponse['message'] .= ' '.implode('. ', $error);
                } elseif (is_string($error)) {
                    $acceptRegisterResponse['message'] .= ' '.$error;
                }
            }

            unset($acceptRegisterResponse['error']);
        }

        return response()->json($acceptRegisterResponse, 400);
    }

    public function returnUrl(Request $request, $nomId) : string
    {
        $prefixRoutes = config('gateway.gateway_prefix');
        $route = app()->router->getRoutes()["GET{$prefixRoutes}api/v1/project_accept_registers/{id}"]['uri'];
        $uri = preg_replace('/\{id\}/', $nomId, $route);

        return str_replace($request->getPathInfo(), $uri, $request->url());
    }

    public function getFormattingResponseStore(string $jsonResponse, string $url)
    {
        $dataResponse = json_decode($jsonResponse, true);

        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 201,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 201);
    }

    public function getFormattingResponseUpdate(string $jsonResponse, string $url)
    {
        $dataResponse = json_decode($jsonResponse, true);

        $urlObj = new \stdClass();
        $urlObj->self = $url;

        return response()->json([
            'code' => 200,
            'message' => $dataResponse['id'],
            'guid_arch' => $dataResponse['guid_arch'],
            'links' => $urlObj
        ], 200);
    }

    public function getFormattingResponseIndex(array $acceptRegistersResponse)
    {
        $acceptRegistersResponse['accept_registers'] = (new IndexResource($acceptRegistersResponse['accept_registers']))->resolve();
        return response()->json($acceptRegistersResponse, 200);
    }

    public function getFormattingResponseShow(array $acceptRegisterResponse)
    {
        $acceptRegisterResponse = (new ShowResource($acceptRegisterResponse))->resolve();
        return response()->json($acceptRegisterResponse, 200);
    }
}
