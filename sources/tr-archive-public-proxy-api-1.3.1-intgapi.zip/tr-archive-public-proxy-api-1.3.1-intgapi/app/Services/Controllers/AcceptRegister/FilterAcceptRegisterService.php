<?php

namespace App\Services\Controllers\AcceptRegister;

class FilterAcceptRegisterService
{
    private $filtersMap = [
        'year' => ['year'],
        'num' => ['num'],
        'q' => ['q'],
    ];

    public function filter(array $data) : string
    {
        $queryParams = [];
        foreach ($data as $index => $value) {
            if (!empty($this->filtersMap[$index])) {
                foreach ($this->filtersMap[$index] as $item) {
                    $queryParams[$item] = $value;
                }
            } else {
                $queryParams[$index] = $value;
            }
        }

        return http_build_query($queryParams);
    }
}