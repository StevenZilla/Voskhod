<?php

namespace App\Services\Controllers\AcceptRegister;

use App\Exceptions\CustomHttpResponseException;
use Illuminate\Support\Facades\Validator;

class ValidateAcceptRegisterService
{
    private $storeRules = [
        'name' => 'required|string',
        'num' => 'required|string',
        'subdivision_code' => 'required|string',
        'year' => 'required|regex:/\d{4}/',
        'dossiers' => 'nullable|array',
        'dossiers.*.index' => 'required|string',
        'dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'dossier_ids' => 'nullable|array',
        'dossier_ids.*' => 'required|integer',
        'register_parts' => 'nullable|array',
        'register_parts.*.name' => 'required|string',
        'register_parts.*.children' => 'nullable|array',
        'register_parts.*.dossiers' => 'nullable|array',
        'register_parts.*.dossiers.*.index' => 'required|string',
        'register_parts.*.dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'register_parts.*.dossier_ids' => 'nullable|array',
        'register_parts.*.dossier_ids.*' => 'required|integer',
    ];

    private $storeMessages = [
        'name.required' => 'Наименование сдаточной описи является обязательным параметром.',
        'name.string' => 'Наименование сдаточной описи должно быть в формате строки.',
        'num.required' => 'Номер сдаточной описи является обязательным параметром.',
        'num.string' => 'Номер сдаточной описи должно быть в формате строки.',
        'subdivision_code.required' => 'Кодовое обозначение у сдаточной описи является обязательным параметром.',
        'subdivision_code.string' => 'Кодовое обозначение у сдаточной описи должно быть в формате строки.',
        'year.required' => 'Год сдаточной описи является обязательным параметром.',
        'year.regex' => 'Год сдаточной описи должен быть в формате - ГГГГ.',
        'dossiers.array' => 'Дела должны быть в формате массива.',
        'dossiers.*.index.required' => 'Индекс дела является обязательным параметром.',
        'dossiers.*.index.string' => 'Индекс дела должен быть в формате строки.',
        'dossiers.*.nom_year.required' => 'Год номенклатуры является обязательным параметром.',
        'dossiers.*.nom_year.regex' => 'Год номенклатуры должен быть в формате ГГГГ.',
        'dossier_ids.array' => 'Идентификаторы дел должны быть в формате массива.',
        'dossier_ids.*.required' => 'Идентификатор дела должен быть обязательным параметром',
        'dossier_ids.*.integer' => 'Идентификатор дела должен быть в формате строки',
        'register_parts.array' => 'Разделы сдаточной описи должны быть в формате массива.',
        'register_parts.*.name.required' => 'Наименование раздела описи является обязательным параметром.',
        'register_parts.*.name.string' => 'Наименование разделов сдаточной описи должен быть в формате строки.',
        'register_parts.*.children.array' => 'Подразделы сдаточной описи должен быть в формате массива.',
        'register_parts.*.dossiers.array' => 'Дела у раздела сдаточной описи должны быть в формате массива.',
        'register_parts.*.dossiers.*.index.required' => 'Индекс дела у раздела сдаточной описи является обязательным параметром.',
        'register_parts.*.dossiers.*.index.string' => 'Индекс дела у раздела сдаточной описи должен быть в формате строки.',
        'register_parts.*.dossiers.*.nom_year.required' => 'Год номенклатуры у раздела сдаточной описи является обязательным параметром.',
        'register_parts.*.dossiers.*.nom_year.regex' => 'Год номенклатуры у раздела сдаточной описи должен быть в формате ГГГГ.',
        'register_parts.*.dossier_ids.array' => 'Идентификаторы дел у раздела сдаточной описи должны быть в формате массива.',
        'register_parts.*.dossier_ids.*.required' => 'Идентификатор дела у раздела сдаточной описи должен быть обязательным параметром',
        'register_parts.*.dossier_ids.*.integer' => 'Идентификатор дела у раздела сдаточной описи должен быть в формате строки',
    ];

    private $childrenRules = [
        'name' => 'required|string',
        'dossiers' => 'nullable|array',
        'dossiers.*.index' => 'required|string',
        'dossiers.*.nom_year' => 'required|regex:/\d{4}/',
        'dossier_ids' => 'nullable|array',
        'dossier_ids.*' => 'required|integer',
        'children' => 'nullable|array',
    ];

    private $childrenMessages = [
        'name.required' => 'Наименование подраздела сдаточной описи является обязательным параметром.',
        'name.string' => 'Наименование подраздела сдаточной описи должен быть в формате строки.',
        'dossiers.array' => 'Дела у подраздела сдаточной описи должны быть в формате массива.',
        'dossiers.*.index.required' => 'Индекс дела у подраздела сдаточной описи является обязательным параметром.',
        'dossiers.*.index.string' => 'Индекс дела у подраздела сдаточной описи должен быть в формате строки.',
        'dossiers.*.nom_year.required' => 'Год номенклатуры у подраздела сдаточной описи является обязательным параметром.',
        'dossiers.*.nom_year.regex' => 'Год номенклатуры у подраздела сдаточной описи должен быть в формате ГГГГ.',
        'dossier_ids.array' => 'Идентификаторы дел у подраздела сдаточной описи должны быть в формате массива.',
        'dossier_ids.*.required' => 'Идентификатор дела у подраздела сдаточной описи должен быть обязательным параметром',
        'dossier_ids.*.integer' => 'Идентификатор дела у подраздела сдаточной описи должен быть в формате строки',
        'children.array' => 'Подразделы сдаточной описи должен быть в формате массива.',
    ];

    private $indexRules = [
        'num' => 'nullable|string',
        'year' => 'nullable|regex:/\d{4}/',
        'q' => 'nullable|string'
    ];

    private $indexMessages = [
        'num' => 'Фильтрация по номеру сдаточной описи',
        'year.regex' => 'Год сдаточной описи должен быть в формате - ГГГГ',
        'q' => 'Контекстный поиск по номеру и заголовку сдаточной описи'
    ];

    public function indexValidateQueryRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->indexRules, $this->indexMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' '.implode(' ', $errorMessage);
            }
        }

        if ($message !== 'Валидация не пройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'AcceptRegister',
            ], 400));
        }

        return $data;
    }

    public function storeValidateRequest(array $data) : array
    {
        $validator = Validator::make($data, $this->storeRules, $this->storeMessages);

        $message = 'Валидация не пройдена.';

        if ($validator->fails()) {
            foreach ($validator->errors()->getMessages() as $errorMessage) {
                $message .= ' '.implode(' ', $errorMessage);
            }
        }

        foreach ($data['register_parts'] as $registerPart) {
            if (!empty($registerPart['children'])) {
                $message .= ' ' . $this->childrenValidate($registerPart['children']);
            }
        }

        if (str_replace(' ', '', $message) !== 'Валидациянепройдена.') {
            throw new CustomHttpResponseException(response()->json([
                'code' => 400,
                'message' => $message,
                'target' => 'ACCEPT_REGISTER',
            ], 400));
        }

        return $data;
    }

    public function childrenValidate(array $children) :string
    {
        $message = '';
        foreach ($children as $child) {
            $validator = Validator::make($child, $this->childrenRules, $this->childrenRules);

            if ($validator->fails()) {
                foreach ($validator->errors()->getMessages() as $errorMessage) {
                    $message .= ' '.implode(' ', $errorMessage);
                }
            }

            if (!empty($child['children'])) {
                $message .= $this->childrenValidate($child['children']);
            }
        }

        return $message;
    }
}