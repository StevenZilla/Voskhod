<?php

namespace App\Services;

use App\Exceptions\CustomHttpResponseException;
use App\Exceptions\UnableToExecuteRequestException;
use App\Routing\ActionContract;
use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Middleware;
use GuzzleHttp\Promise;
use Illuminate\Support\Collection;
use App\Http\Request;
use GuzzleHttp\Psr7\Response as PsrResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class RestClient
 * @package App\Services
 */
class RestClient
{
    /**
     * @var Client
     */
    protected $client;

    /**
     * @var ServiceRegistryContract
     */
    protected $services;

    /**
     * @var array
     */
    protected $guzzleParams = [
        'headers' => [],
        'timeout' => 40
    ];

    /**
     * @var int
     */
    const USER_ID_ANONYMOUS = -1;

    protected $error_messages = [
        'Успех',
        'URL-адрес, который вы передали libcurl, использовал протокол, который не поддерживает этот libcurl.',
        'Не удалось выполнить ранний код инициализации. Скорее всего, это внутренняя ошибка или проблема, либо проблема с ресурсами, когда что-то фундаментальное не может быть выполнено во время инициализации.',
        'URL-адрес был неправильно отформатирован',
        'Запрошенная функция, протокол или опция не были встроены в этот libcurl из-за решения, принятого во время сборки. Это означает, что функция или параметр не были включены или явно отключены при сборке libcurl, и для того, чтобы заставить его работать, вам нужно получить перестроенный libcurl.',
        'Не удалось разрешить прокси. Данный прокси-хост не может быть разрешен.',
        'Не удалось разрешить хост. Данный удаленный хост не был разрешен.',
        'Не удалось подключиться к хосту или прокси.',
        'Сервер отправил данные, которые libcurl не смог проанализировать. Этот код ошибки был известен как CURLE_FTP_WEIRD_SERVER_REPLY до версии 7.51.0.',
        'Нам было отказано в доступе к ресурсу, указанному в URL. Для FTP это происходит при попытке перейти в удаленный каталог.',
        'Во время ожидания обратного подключения сервера при использовании активного сеанса FTP код ошибки был отправлен по управляющему соединению или аналогичному.',
        'После отправки FTP-пароля на сервер libcurl ожидает надлежащего ответа. Этот код ошибки указывает на то, что был возвращен неожиданный код.',
        'Во время активного сеанса FTP во время ожидания подключения сервера истекло время ожидания CURLOPT_ACCEPTTIMEOUT_MS (или внутреннее значение по умолчанию).',
        'libcurl не удалось получить разумный результат от сервера в ответ на команду PASV или EPSV.',
        'FTP-серверы возвращают 227-строчный ответ на команду PASV. Если libcurl не удается разобрать эту строку, этот код возврата передается обратно.',
        'Внутренняя ошибка при поиске хоста, используемого для нового подключения.',
        'Обнаружена проблема на уровне кадрирования HTTP2. Это несколько общее и может быть одной из нескольких проблем, подробности см. в буфере ошибок.',
        'Получена ошибка при попытке установить режим передачи на двоичный или ASCII.',
        'Передача файла оказалась короче или больше, чем ожидалось. Это происходит, когда сервер сначала сообщает ожидаемый размер передачи, а затем доставляет данные, которые не соответствуют ранее заданному размеру.',
        'Это был либо странный ответ на команду RETR, либо завершена передача нулевого байта.',
        'В современных версиях не используется.',
        'При отправке пользовательских команд «QUOTE» на удаленный сервер одна из команд возвращала код ошибки 400 или выше (для FTP) или иным образом указывала на неудачное выполнение команды.',
        'Это возвращается, если для параметра CURLOPT_FAILONERROR установлено значение TRUE, а HTTP-сервер возвращает код ошибки >= 400.',
        'Произошла ошибка при записи полученных данных в локальный файл, или в libcurl была возвращена ошибка из обратного вызова записи.',
        'В современных версиях не используется.',
        'Не удалось начать загрузку. Для FTP сервер обычно отклонял команду STOR. Буфер ошибок обычно содержит объяснение сервера по этому поводу.',
        'Возникла проблема при чтении локального файла или ошибка, возвращенная обратным вызовом чтения.',
        'Не удалось выполнить запрос на выделение памяти. Это серьезное зло, и все сильно облажается, если это когда-либо произойдет.',
        'Тайм-аут операции. Указанный период тайм-аута был достигнут в соответствии с условиями.',
        'В современных версиях не используется.',
        'Команда FTP PORT вернула ошибку. В основном это происходит, когда вы не указали достаточно хороший адрес для использования libcurl. См. CURLOPT_FTPPORT.',
        'Команда FTP REST вернула ошибку. Этого никогда не должно происходить, если сервер в здравом уме.',
        'В современных версиях не используется.',
        'Сервер не поддерживает и не принимает запросы диапазона.',
        'Это странная ошибка, которая в основном возникает из-за внутренней путаницы.',
        'Где-то возникла проблема при рукопожатии SSL/TLS. Вам действительно нужен буфер ошибок и прочтите там сообщение, так как оно немного больше указывает на проблему. Это могут быть сертификаты (форматы файлов, пути, разрешения), пароли и другие.',
        'Загрузка не может быть возобновлена, так как указанное смещение выходит за границы файла.',
        'Файл, заданный с помощью FILE://, не может быть открыт. Скорее всего, потому что путь к файлу не идентифицирует существующий файл. Вы проверяли права доступа к файлам?',
        'LDAP не может выполнить привязку. Сбой операции привязки LDAP.',
        'Ошибка поиска LDAP.',
        'В современных версиях не используется.',
        'Функция не найдена. Требуемая функция zlib не найдена.',
        'Прервано обратным вызовом. Обратный вызов вернул libcurl «abort».',
        'Функция была вызвана с неверным параметром.',
        'В современных версиях не используется.',
        'Ошибка интерфейса. Не удалось использовать указанный исходящий интерфейс. Укажите, какой интерфейс использовать для IP-адреса источника исходящих подключений, с помощью CURLOPT_INTERFACE.',
        'В современных версиях не используется.',
        'Слишком много редиректов. При следовании перенаправлениям libcurl достигает максимальной суммы. Установите лимит с помощью CURLOPT_MAXREDIRS.',
        'Параметр, переданный в libcurl, не распознан/известен. См. соответствующую документацию. Скорее всего проблема в программе, которая использует libcurl. Буфер ошибок может содержать более конкретную информацию о том, к какому именно параметру он относится.',
        'Параметр, переданный в setopt, был неправильно отформатирован. См. сообщение об ошибке для получения подробной информации о том, какой вариант.',
        'В современных версиях не используется.',
        'В современных версиях не используется.',
        'С сервера ничего не было возвращено, и в данных обстоятельствах получение ничего не считается ошибкой.',
        'Указанный криптодвижок не найден.',
        'Не удалось установить выбранный механизм шифрования SSL по умолчанию.',
        'Ошибка отправки сетевых данных.',
        'Сбой при получении сетевых данных.',
        'В современных версиях не используется.',
        'проблема с сертификатом локального клиента.',
        'Не удалось использовать указанный шифр.',
        'SSL-сертификат или отпечаток SSH удаленного сервера были сочтены неправильными. Этот код ошибки был унифицирован с CURLE_SSL_CACERT с версии 7.62.0. Его предыдущее значение было 51.',
        'Нераспознанная кодировка передачи.',
        'В современных версиях не используется.',
        'Превышен максимальный размер файла.',
        'Запрошенный уровень FTP SSL не выполнен.',
        'При выполнении операции отправки curl должен был перемотать данные для повторной передачи, но операция перемотки не удалась.',
        'Не удалось запустить механизм SSL.',
        'Удаленный сервер отказал curl в входе в систему (добавлено в 7.13.1)',
        'Файл не найден на сервере TFTP.',
        'Проблема с правами доступа на TFTP-сервере.',
        'Недостаточно места на сервере.',
        'Незаконная операция TFTP.',
        'Неизвестный идентификатор передачи TFTP.',
        'Файл уже существует и не будет перезаписан.',
        'Эта ошибка никогда не должна возвращаться правильно работающим сервером TFTP.',
        'В современных версиях не используется.',
        'В современных версиях не используется.',
        'Проблема с чтением сертификата SSL CA (путь? права доступа?)',
        'Ресурс, указанный в URL-адресе, не существует.',
        'Во время сеанса SSH произошла неизвестная ошибка.',
        'Не удалось закрыть соединение SSL.',
        'Сокет не готов к отправке/получению, подождите, пока он не будет готов, и повторите попытку. Этот код возврата возвращается только из curl_easy_recv и curl_easy_send (добавлено в 7.18.2)',
        'Не удалось загрузить файл CRL (добавлено в 7.19.0)',
        'Ошибка проверки эмитента (добавлено в 7.19.0)',
        'FTP-сервер вообще не понимает команду PRET или не поддерживает данный аргумент. Будьте осторожны при использовании CURLOPT_CUSTOMREQUEST, пользовательская команда LIST будет отправлена ​​с командой PRET перед PASV. (Добавлено в 7.20.0)',
        'Несоответствие номеров RTSP CSeq.',
        'Несоответствие идентификаторов сеанса RTSP.',
        'Невозможно проанализировать список файлов FTP (во время загрузки подстановочных знаков FTP).',
        'Обратный вызов фрагмента сообщил об ошибке.',
        '(Только для внутреннего использования, никогда не будет возвращено libcurl) Соединение недоступно, сеанс будет поставлен в очередь. (добавлено в 7.30.0)',
        'Не удалось сопоставить закрепленный ключ, указанный с помощью CURLOPT_PINNEDPUBLICKEY.',
        'Статус вернул ошибку при запросе с помощью CURLOPT_SSL_VERIFYSTATUS.',
        'Ошибка потока на уровне кадрирования HTTP/2.',
        'Функция API была вызвана из обратного вызова.',
        'Функция аутентификации вернула ошибку.',
        'Обнаружена проблема на уровне HTTP/3. Это несколько общее и может быть одной из нескольких проблем, подробности см. в буфере ошибок.',
        'Ошибка подключения QUIC. Эта ошибка может быть вызвана ошибкой библиотеки SSL. QUIC — это протокол, используемый для передачи HTTP/3.',
        'Ошибка рукопожатия прокси. CURLINFO_PROXY_ERROR предоставляет дополнительные сведения о конкретной проблеме.',
        'Требуется SSL-сертификат клиента.',
        'Внутренний вызов poll() или select() вернул неисправимую ошибку.',
    ];

    /**
     * RestClient constructor.
     * @param Client $client
     * @param ServiceRegistryContract $services
     * @param Request $request
     */
    public function __construct(Client $client, ServiceRegistryContract $services, Request $request)
    {
        $dataConfigClient = $client->getConfig();
        $dataConfigClient['verify'] = false;
//        $dataConfigClient['handler'] = $this->createHandler();

        $this->client = new Client($dataConfigClient);
        $this->services = $services;
        $this->injectHeaders($request);
    }

    /**
     * @param Request $request
     */
    private function injectHeaders(Request $request)
    {
        $this->setHeaders(
            [
                'X-User' => $request->user()->id ?? self::USER_ID_ANONYMOUS,
                'X-Token-Scopes' => $request->user() && ! empty($request->user()->token()) ? implode(',', $request->user()->token()->scopes) : '',
                'X-Client-Ip' => $request->getClientIp(),
                'User-Agent' => $request->header('User-Agent'),
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ]
        );
    }

    /**
     * @param array $headers
     */
    public function setHeaders(array $headers)
    {
        $this->guzzleParams['headers'] = $headers;
    }

    /**
     * @param $contentType
     * @return $this
     */
    public function setContentType($contentType)
    {
        $this->guzzleParams['headers']['Content-Type'] = $contentType;

        return $this;
    }

    /**
     * @param $contentSize
     * @return $this
     */
    public function setContentSize($contentSize)
    {
        $this->guzzleParams['headers']['Content-Length'] = $contentSize;

        return $this;
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->guzzleParams['headers'];
    }

    /**
     * @return array
     */
    public function getMulripart()
    {
        return $this->guzzleParams['multipart'];
    }

    public function setMulripart(array $data)
    {
        $this->guzzleParams['multipart'] = $data;
        return $this;
    }

    public function setCookie(CookieJar $cookie)
    {
        $this->guzzleParams['cookies'] = $cookie;

        return $this;
    }

    /**
     * @param string $body
     * @return $this
     */
    public function setBody($body)
    {
        $this->guzzleParams['body'] = $body;

        return $this;
    }

    /**
     * @param string $body
     * @return $this
     */
    public function setFormParams(array $body)
    {
        $this->guzzleParams['form_params'] = $body;

        return $this;
    }

    /**
     * @param array $files
     * @return $this
     */
    public function setFiles(array $data)
    {
        $headers = array_intersect_key($this->getHeaders(), ['X-User' => null, 'X-Token-Scopes' => null]);
        if (!empty($this->getHeaders()['Authorization'])) {
            $headers['Authorization'] = $this->getHeaders()['Authorization'];
        }

        if (!empty($this->getHeaders()['uid'])) {
            $headers['uid'] = $this->getHeaders()['uid'];
        }

        $this->setHeaders($headers);

        $this->guzzleParams['timeout'] = config('default.guzzle_timeout_files');
        $this->guzzleParams['multipart'] = [];

        if (!empty($data['data'])) {
            $this->guzzleParams['multipart'][] = [
                'name' => 'data',
                'contents' => $data['data'],
            ];
        }

        if (!empty($data['_method'])) {
            $this->guzzleParams['multipart'][] = [
                'name' => '_method',
                'contents' => 'PUT'
            ];
        }

        foreach ($data['files'] as $key => $file) {
            $this->guzzleParams['multipart'][] = [
                'name' => "files[{$key}]",
                'contents' => file_get_contents($file->getRealPath()),
                'filename' => $file->getClientOriginalName(),
                'headers' => ['Content-Type' => $file->getMimeType()]
            ];
        }

        return $this;
    }

    /**
     * @param $url
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function post($url)
    {
        return $this->client->request('POST', $url, $this->guzzleParams);
    }

    /**
     * @param $url
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function put($url)
    {
        return $this->client->request('PUT', $url, $this->guzzleParams);
    }

    /**
     * @param $url
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function get($url)
    {
        return $this->client->request('GET', $url, $this->guzzleParams);
    }

    /**
     * @param $url
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function delete($url)
    {
        return $this->client->delete($url, $this->guzzleParams);
    }

    /**
     * @param Collection $batch
     * @param $parametersJar
     * @return RestBatchResponse
     */
    public function asyncRequest(Collection $batch, $parametersJar)
    {
        $wrapper = new RestBatchResponse();
        $wrapper->setCritical($batch->filter(function($action) { return $action->isCritical(); })->count());

        $promises = $batch->reduce(function($carry, $action) use ($parametersJar) {
            $method = strtolower($action->getMethod());
            $url = $this->buildUrl($action, $parametersJar);
            $carry[$action->getAlias()] = $this->client->{$method . 'Async'}($url, $this->guzzleParams);
            return $carry;
        }, []);

        return $this->processResponses(
            $wrapper,
            collect(Promise\settle($promises)->wait())
        );
    }

    /**
     * @param RestBatchResponse $wrapper
     * @param Collection $responses
     * @return RestBatchResponse
     */
    private function processResponses(RestBatchResponse $wrapper, Collection $responses)
    {
        // Process successful responses
        $responses->filter(function ($response) {
            return $response['state'] == 'fulfilled';
        })->each(function ($response, $alias) use ($wrapper) {
            $wrapper->addSuccessfulAction($alias, $response['value']);
        });

        // Process failures
        $responses->filter(function ($response) {
            return $response['state'] != 'fulfilled';
        })->each(function ($response, $alias) use ($wrapper) {
            $response = $response['reason']->getResponse();
//            if ($wrapper->hasCriticalActions()) throw new UnableToExecuteRequestException($response);
            if ($wrapper->hasCriticalActions()) throw new UnableToExecuteRequestException($response);

            // Do we have an error response from the service?
            if (! $response) $response = new PsrResponse(502, []);
            $wrapper->addFailedAction($alias, $response);
        });

        return $wrapper;
    }

    /**
     * @param ActionContract $action
     * @param $parametersJar
     * @return mixed
     */
    public function syncRequest(ActionContract $action, $parametersJar)
    {
        try {
            $response = $this->{strtolower($action->getMethod())}(
                $this->buildUrl($action, $parametersJar)
            );
        } catch (\Exception $exception) {
            Log::critical("Не смогли получить ответ.\nОшибка: {$exception}");

            if ($exception instanceof ConnectException) {
                $errorIndex = $exception->getHandlerContext()['errno'];
                throw new CustomHttpResponseException(response()->json(['message' => $this->error_messages[$errorIndex], 'code' => 500], 500));
            } elseif ($exception instanceof RequestException) {
                $response = json_decode($exception->getResponse()->getBody()->getContents(), true);
                throw new CustomHttpResponseException(response()->json($response, $response['code'] ?? $exception->getCode()));
            } else {
                throw new CustomHttpResponseException(response()->json(['message' => 'Произошла непредвиденная ошибка. Обратитесь к администратору для решения проблемы.', 'code' => 500], 500));
            }
        }

        return $response;
    }

    /**
     * catch (ConnectException $e) {
     * Log::critical("Не смогли получить ответ. Ошибка: {$e}");
     * throw new UnableToExecuteRequestException();
     * } catch (RequestException $e) {
     * return $e->getResponse();
     * }
     */

    /**
     * @param string $url
     * @param array $params
     * @param string $prefix
     * @return string
     */
    private function injectParams($url, array $params, $prefix = '')
    {
        foreach ($params as $key => $value) {
            if (is_array($value)) {
                $url = $this->injectParams($url, $value, $prefix . $key . '.');
            }

            if (is_string($value) || is_numeric($value)) {
                $url = str_replace("{" . $prefix . $key . "}", $value, $url);
            }
        }

        return $url;
    }

    /**
     * @param ActionContract $action
     * @param $parametersJar
     * @return string
     */
    private function buildUrl(ActionContract $action, $parametersJar)
    {
        $url = $this->injectParams($action->getUrl(), $parametersJar);
        if ($url[0] != '/') $url = '/' . $url;
        if (isset($parametersJar['query_string'])) $url .= '?' . $parametersJar['query_string'];

        return $this->services->resolveInstance($action->getService()) . $url;
    }

    /**
     * This is used to log all the requests & responses
     * to the log provider.
     * @return HandlerStack
     */
    private function createHandler()
    {
        $handlerStack = HandlerStack::create();

        $id = Str::random();

        $messageFormats = [
            "{$id} REQUEST: {method} - {uri} - HTTP/{version} - {req_headers} - {req_body}",
            "{$id} RESPONSE: {code} - {res_body}",
        ];

        collect($messageFormats)->each(function ($messageFormat) use ($handlerStack) {
            $handlerStack->unshift(
                Middleware::log(
                    app('log'),
                    new MessageFormatter($messageFormat),
                    'debug'
                )
            );
        });

        return $handlerStack;
    }
}
