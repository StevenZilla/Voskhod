<?php

namespace Laravel\Lumen\Routing;

class Closure
{
    use ProvidesConvenienceMethods;
}
