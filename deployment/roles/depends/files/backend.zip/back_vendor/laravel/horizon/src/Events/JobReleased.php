<?php

namespace Laravel\Horizon\Events;

class JobReleased extends RedisEvent
{
    //
}
