#! /bin/sh
adev runserver -p 8000 server.py
