PGSync version: 

Postgres version: 

Elasticsearch version: 

Redis version: 

Python version: 

Problem Description: 



Error Message (if any): 

```


```
