=======
Credits
=======

Development Lead
----------------

* Tolu Aina <tolu@pgsync.com>

Contributors
------------

- Francois Deschenes
- chokosabe
- Densol92
- harish-everest
- Shogoki
- EgoPingvina
- sinwoobang
- asovanek
- yangyaofei
- hyperphoton
- laurent-pujol
- JacobReynolds
- echi1995
